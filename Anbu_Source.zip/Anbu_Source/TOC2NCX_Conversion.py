
# ---------------------------------------------------------------------
#  Tool Name	: TOC2NCX_Conversion.py
#  Developer	: Anbu G
#  Description  : To Create OPF and NCX
#  Client/DU	: Pearson
#  Syntax		: <EXE> <Epub Folder location>
# -----------------------------------------------------------------------



# ------------ Rivision History  -------------------------------------------
#  16-09-2022 | v1.0.0.0 | Anbu G | Initial Development
# --------------------------------------------------------------------------



import re
import os
import sys
from iModule.ToolTracking import _local_tracking, _get_timestamp, _get_file_size

ToolVersion = "1.0.0.0";

print("\n\n\tCleanUp Tool v" + ToolVersion + " is Running...");
print("\tCopyright @ Integra Software Services Ltd.\n");


try :
    _filedirname = sys.argv[1]

except :
    # src = r'D:\Anbu\XML\pdftest.pdf'
    print("Please Enter XML file location")
    sys.exit()

# ------------ Tracking --------------------------------------------
Tra_input = sys.argv[1];
tool_id = 487;  # TOC2NCX_Conversion
run_size = 0;
st_time = _get_timestamp();
# ------------------------------------------------------------------



OPS_Path=_filedirname+"\\OPS"

#Make Xhtml path
toc_Path=OPS_Path+"\\xhtml"

#Make Images Path
images_Path=OPS_Path+"\\images"
try:
    list_image = [x for x in os.listdir(images_Path) if x.endswith((".jpg",".png"))]
except:
    pass
    list_image=[]
imgtaglist=[]
# print(list_image)
for imglist in list_image:
    imglist1=imglist.split(".")
    if imglist1[0]!='cover':
        imgtagpath='<item href="images/'+imglist+'" media-type="image/'+imglist1[len(imglist1)-1]+'" id="'+imglist1[0]+'"/>'
        imgtaglist.append(imgtagpath)


try:
# TOC_Path
    with open(toc_Path+"\\toc.xhtml", "r", encoding="utf-8") as f1:
        toccontent=f1.read()
        f1.close()
except:
    pass
    print("Toc.xhtml file not found!!!")
    sys.exit()


try:
# TOC_Path
    with open(toc_Path+"\\title.xhtml", "r", encoding="utf-8") as f1:
        titlecontent=f1.read()
        f1.close()
except:
    pass
    print("Toc.xhtml file not found!!!")
    sys.exit()

if re.search(r'<header(?: [^>]*)?>((?:(?!</header>).)*)</header>',titlecontent,re.I|re.S):
    titlecontent1=re.search(r'<header(?: [^>]*)?>((?:(?!</header>).)*)</header>',titlecontent,re.I|re.S)
    titlecontent2=re.sub(r'<(?:[^>]*)>','',titlecontent1.group(),0,re.I|re.S)
else:
    titlecontent2=''


# print(toccontent)
navcontent=re.search(r'<nav(?: [^>]*)? id="toc"[^>]*?>((?:(?!</nav>).)*)</nav>',toccontent,re.I|re.S)
try:
    navcontent1=navcontent.group(1)
except:
    pass

ISBN_Path_name=os.path.basename(_filedirname)

xmlfronttext='''<?xml version="1.0" encoding="UTF-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" xmlns:ncx="http://www.daisy.org/z3986/2005/ncx/" version="2005-1" xml:lang="en">
<head xmlns:m="http://www.w3.org/1998/Math/MathML">
<meta name="dtb:uid" content="'''+str(ISBN_Path_name)+'''"/>
<meta name="dtb:depth" content="1"/>
<meta name="dtb:totalPageCount" content="0"/>
<meta name="dtb:maxPageNumber" content="0"/>
</head>
<docTitle xmlns:m="http://www.w3.org/1998/Math/MathML">
<text>'''+titlecontent2+'''</text>
</docTitle>'''
defaultmanifest='''<item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>
<item id="cover" href="xhtml/cover.xhtml" media-type="application/xhtml+xml"/>
<item id="toc" href="xhtml/toc.xhtml" media-type="application/xhtml+xml" properties="nav mathml scripted remote-resources"/>
'''
defaultmanifes='''<item id="title" href="xhtml/title.xhtml" media-type="application/xhtml+xml" properties="scripted remote-resources"/>
<item id="contents" href="xhtml/contents.xhtml" media-type="application/xhtml+xml" properties="mathml scripted remote-resources"/>
<item id="copyright" href="xhtml/copyright.xhtml" media-type="application/xhtml+xml" properties="scripted remote-resources"/>
'''
defaultcss='''\n<item href="css/main.css" id="css_0" media-type="text/css"/>
<item href="css/night.css" id="css_1" media-type="text/css"/>
<item href="css/print.css" id="css_2" media-type="text/css"/>
<item href="css/sepia.css" id="css_3" media-type="text/css"/>
<item href="css/images/iconmonstr-info-8-icon-20x20.png" id="css_4" media-type="image/png"/>
<item href="css/images/iconmonstr-info-8-icon.png" id="css_5" media-type="image/png"/>
<item href="css/images/iconmonstr-window-new-icon-20x20.png" id="css_6" media-type="image/png"/>
<item href="css/images/iconmonstr-window-new-icon.png" id="css_7" media-type="image/png"/>
<item href="css/theme/default.css" id="css_8" media-type="text/css"/>
<item href="css/theme/night.css" id="css_9" media-type="text/css"/>
<item href="css/theme/print.css" id="css_10" media-type="text/css"/>
<item href="css/theme/sepia.css" id="css_11" media-type="text/css"/>
<item href="xhtml/js/format_lg_obj.js" id="format_lg_obj" media-type="text/javascript"/>
<item href="images/cover.jpg" media-type="image/jpeg" id="cover-image" properties="cover-image"/>
'''
packagemeta='''<?xml version="1.0" encoding="utf-8"?>
<package xmlns:m="http://www.w3.org/1998/Math/MathML" xmlns="http://www.idpf.org/2007/opf" version="3.0" xml:lang="en" unique-identifier="pub-id">
<metadata xmlns:opf="http://www.idpf.org/2007/opf" xmlns:dc="http://purl.org/dc/elements/1.1/">
<meta xmlns:html="http://www.w3.org/1999/xhtml" property="schema:accessibilitySummary">This publication includes mark-up to enable accessibility and compatibility with assistive technology. Images, audio, and video in the publication are well-described in conformance with WCAG 2.0 AA. Structural navigation may be inconsistent.</meta>
<meta xmlns:html="http://www.w3.org/1999/xhtml" property="schema:accessMode">textual</meta>
<meta xmlns:html="http://www.w3.org/1999/xhtml" property="schema:accessMode">visual</meta>
<meta xmlns:html="http://www.w3.org/1999/xhtml" property="schema:accessModeSufficient">textual,visual</meta>
<meta xmlns:html="http://www.w3.org/1999/xhtml" property="schema:accessModeSufficient">textual</meta>
<meta xmlns:html="http://www.w3.org/1999/xhtml" property="schema:accessibilityFeature">displayTransformability</meta>
<meta xmlns:html="http://www.w3.org/1999/xhtml" property="schema:accessibilityFeature">resizeText</meta>
<meta xmlns:html="http://www.w3.org/1999/xhtml" property="schema:accessibilityFeature">longDescription</meta>
<meta xmlns:html="http://www.w3.org/1999/xhtml" property="schema:accessibilityFeature">alternativeText</meta>
<meta xmlns:html="http://www.w3.org/1999/xhtml" property="schema:accessibilityHazard">none</meta>
<dc:title>'''+titlecontent2+'''</dc:title>
<dc:date>2021-06-16T13:53:17Z</dc:date>
<dc:language>en-US</dc:language>
<meta property="dcterms:modified">2021-06-16T13:53:17Z</meta>
<dc:identifier id="pub-id">'''+str(ISBN_Path_name)+'''</dc:identifier>
<meta xmlns:html="http://www.w3.org/1999/xhtml" refines="#pub-id" property="identifier-type" scheme="onix:codelist5">01</meta>
<dc:type>Book</dc:type>
<meta property="rendition:spread">none</meta>
<meta property="rendition:flow">scrolled-doc</meta>
</metadata>'''
defaultfront='''<navPoint id="toc_001"><navLabel><text>Cover</text></navLabel><content src="xhtml/cover.xhtml"/></navPoint>
<navPoint id="toc_002"><navLabel><text>Title</text></navLabel><content src="xhtml/title.xhtml"/></navPoint>
<navPoint id="toc_003"><navLabel><text>Copyright</text></navLabel><content src="xhtml/copyright.xhtml"/></navPoint>
<navPoint id="toc_004"><navLabel><text>Contents</text></navLabel><content src="xhtml/contents.xhtml"/></navPoint>
'''
spinecont='''<itemref idref="cover"/>
<itemref idref="title"/>
<itemref idref="copyright"/>
<itemref idref="contents"/>
'''
spinetoc='''<itemref idref="toc" linear="no"/>'''
manifest=[]
stritemref1=[]
if navcontent1:
    for navcontenttopackage in re.finditer(r'<li(?: [^>]*)?>\s*\n*<a(?: [^>]*)? href="([^>]*)">((?:(?!</a>).)*)</a>\s*\n*',navcontent1, re.I | re.S):
        # print(navcontenttopackage.group(1))
        cntname=navcontenttopackage.group(1)
        cntname1=cntname.replace(".xhtml","")
        # print(cntname1)
        str1='<item id="'+cntname1+'" href="xhtml/'+cntname+'" media-type="application/xhtml+xml" properties="mathml scripted remote-resources"/>'
        manifest.append(str1)
        stritemref='<itemref idref="'+cntname1+'"/>'
        stritemref1.append(stritemref)

# print(manifest)

if navcontent1:
    navcontent1=re.sub(r'\n*</li>\n*\s*<li>\n*',r'</li>\n<li>',navcontent1,re.I|re.S)
    navcontent1=re.sub(r'\n*</li>\n*\s*<li(?: [^>]*)?>\n*',r'</li>\n<li>',navcontent1,re.I|re.S)
    navcontent1=re.sub(r'</li><li>\n*',r'</li>\n<li>',navcontent1,re.I|re.S)
    navcontent1=re.sub(r'</li><li(?: [^>]*)?>\n*',r'</li>\n<li>',navcontent1,re.I|re.S)
    navcontent1=re.sub(r'<li>\s*\n*<a(?: [^>]*)? href="([^>]*)">((?:(?!</a>).)*)</a>\s*\n*</li>',r'<navPoint id="toc_001"><navLabel><text>\g<2></text></navLabel><content src="\g<1>"/></navPoint>',navcontent1,0,re.I|re.S)
    navcontent1=re.sub(r'<li(?: [^>]*)?>\s*\n*<a(?: [^>]*)? href="([^>]*)">((?:(?!</a>).)*)</a>\s*\n*</li>',r'<navPoint id="toc_001"><navLabel><text>\g<2></text></navLabel><content src="\g<1>"/></navPoint>',navcontent1,0,re.I|re.S)
    navcontent1=re.sub(r'<li>\s*\n*<a(?: [^>]*)? href="([^>]*)">((?:(?!</a>).)*)</a>\s*\n*<ol>',r'<navPoint id="toc_001"><navLabel><text>\g<2></text></navLabel><content src="\g<1>"/>',navcontent1,0,re.I|re.S)
    navcontent1=re.sub(r'<li(?: [^>]*)?>\s*\n*<a(?: [^>]*)? href="([^>]*)">((?:(?!</a>).)*)</a>\s*\n*<ol>',r'<navPoint id="toc_001"><navLabel><text>\g<2></text></navLabel><content src="\g<1>"/>',navcontent1,0,re.I|re.S)
    navcontent1=re.sub(r'<li(?: [^>]*)?>\s*\n*<a(?: [^>]*)? href="([^>]*)">((?:(?!</a>).)*)</a>\s*\n*<ol(?:[^>]*)?>',r'<navPoint id="toc_001"><navLabel><text>\g<2></text></navLabel><content src="\g<1>"/>',navcontent1,0,re.I|re.S)
    navcontent1=re.sub(r'\n*</ol>\n*\s*</li>\n*',r'</navPoint>\n',navcontent1,re.I|re.S)
    navcontent1=re.sub(r'\n*<ol>\n*\s*',r'\n<navMap id="d1e1">\n',navcontent1,re.I|re.S)
    navcontent1=re.sub(r'\n*<ol(?:[^>]*)?>\n*\s*',r'\n<navMap id="d1e1">',navcontent1,re.I|re.S)
    navcontent1=navcontent1.replace('<navMap id="d1e1">','<navMap id="d1e1">\n'+defaultfront)
    navcontent1=re.sub(r'\n*</ol>\n*\s*',r'\n</navMap>\n',navcontent1,re.I|re.S)
    navcontent1=re.sub(r'<span(?: [^>]*)?>|</span>',r'',navcontent1,re.I|re.S)


# print(xmlfronttext+navcontent1)


with open(OPS_Path+"\\package.opf", "w", encoding="utf-8") as f1:
    f1.write(packagemeta)
    f1.write("\n<manifest>\n")
    f1.write(defaultmanifest)
    f1.write(defaultmanifes)

    for xy in manifest:
        f1.write(xy)
        f1.write("\n")


    for imgtagopf in imgtaglist:
        f1.write(imgtagopf)
        f1.write("\n")
    f1.write(defaultcss)
    f1.write("</manifest>\n")
    f1.write('<spine toc="ncx">\n')
    f1.write(spinecont)
    for spine in stritemref1:
        f1.write(spine)
        f1.write("\n")
    f1.write(spinetoc)
    f1.write("\n</spine>\n")


    f1.close()

with open(OPS_Path+"\\toc.ncx", "w", encoding="utf-8") as f1:
    f1.write(xmlfronttext+navcontent1)
    f1.close()

with open(OPS_Path+"\\check_log.txt", "w", encoding="utf-8") as f1:
    f1.write("1. Title not updated in Opf and Ncx\n2. Check ISBN\n3. Check html files which not included in toc.xhtml\n4. Please change the ID sequence in ncx file")
    f1.close()



# ------ Local tracking ------------------
_local_tracking(tool_id, ToolVersion, Tra_input, _get_file_size(Tra_input), st_time, _get_timestamp());
# -----------------------------------------

print("\nProcess completed...!!!")
sys.exit()
