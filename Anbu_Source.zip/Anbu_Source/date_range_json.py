import json
from datetime import datetime


def date_range_json(outfilename1,start_date,end_date):

    outfilename =outfilename1.replace('.json','_out.json')
    # Your JSON data
    with open(outfilename1) as file:
        json_data = json.load(file)

    # json_data = [
    #     {"id": "16037836", "date": " 07-08-2023 04:15\n", ...},
    #     {"id": "15954890", "date": " 04-08-2023 08.06 PM\n", ...},
    #     # Add more data
    # ]

    # Convert date strings to datetime objects
    for item in json_data:
        item_date = item["date"].strip()
        item_date = item_date.split(' ')[0]
        # Convert date string to datetime object
        item["date"] = datetime.strptime(item_date, "%d-%m-%Y")

    # Define the date range
    start_date= start_date.split('-')
    end_date = end_date.split('-')
    from_date = datetime(int(start_date[2]),int(start_date[1]), int(start_date[0]))  # Example: August 4, 2023
    # from_date = datetime(2023, 8, 4)  # Example: August 4, 2023
    to_date = datetime(int(end_date[2]),int(end_date[1]), int(end_date[0]))    # Example: August 7, 2023

    # Filter data based on the date range
    filtered_data = [
        item for item in json_data if from_date <= item["date"] <= to_date
    ]
    json_string= ""
    # Print the filtered data
    # for item in filtered_data:
    #     print(f"ID: {item['id']}, Date: {item['date']}, From: {item['From']}, Body: {item['body']}")
    #     data = {
    #         "id": item['id'],
    #         "date": item['date'],
    #         "From": item['From'],
    #         "body": item['body']
    #     }
    #
    #     # Convert the dictionary to a JSON string
    #     json_string = json_string + json.dumps(data) + ","
    #
    #
    # json_string = '[' + json_string + ']'
    # json_string = json_string.replace("},]", "}]")
    # with open(outfilename, 'w') as file:
    #     file.write(json_string)
    data_list = []
    for item in filtered_data:  # Replace data_source with your data source
        # Convert datetime objects to strings
        item_date = item['date'].strftime("%Y-%m-%d %H:%M:%S")

        data = {
            "id": item['id'],
            "date": item_date,  # Use the formatted date string
            "From": item['From'],
            "body": item['body']
        }

        data_list.append(data)
    # Serialize the list to a JSON string
    json_string = json.dumps(data_list, indent=4)

    # # Write the JSON string to a file
    # outfilename = outfilename
    with open(outfilename, 'w') as file:
        file.write(json_string)
    return "success"