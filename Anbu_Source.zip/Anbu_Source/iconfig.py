import itertools
import re
import sys
from iModule.Basic import _element_leveling, _open_utf8
from os.path import dirname
import os
InlineIdCount = itertools.count(1);
ToolPath = dirname(sys.argv[0]);
ToolPath = re.sub(r'\/', r'\\', ToolPath, 0)

ASCIIEncoding = str(ToolPath) + r'\\ASCIIEncoding.ini'
FigIdCount = itertools.count(1);
TabIdCount = itertools.count(1);
DispIdCount = itertools.count(1);
InlineIdCount = itertools.count(1);
ImageIdCount = itertools.count(1);
tfnID = {};


static_folder = os.path.join(os.path.dirname(__file__), 'static')
uploads_folder = os.path.join(static_folder, 'uploads')
def RemoveTag(txt, element):
    formating = '|'.join(element.split(','));
    txt = re.sub(r'<\/?(' + str(formating) + r')(?: [^>]+)?>', r'', txt, 0, re.I);
    return txt;


def RemoveA3B2(txt):
    txt = re.sub(r'<\?A3B2[^>]*\?>', '', txt, 0, re.I);
    return txt;

def RemoveCnt(txt, element):
    txt = re.sub(r'<' + str(element) + r'(?: [^>]+)?>(?:(?!</?' + str(element) + r'>).)*</' + str(element) + r'>', r'',
                 txt, 0, re.I | re.S);

    return txt;


def articleTitle(txt):
    txt = re.sub('\n+(<abbrev(?: [^>]+)?>)', r'\g<1>', txt, 0, re.S);
    txt = re.sub('\n+(</abbrev>)', r'\g<1>', txt, 0, re.S);

    return txt

def xrefClean(txt):
    if (re.search(r'</?sup>', txt, re.I)):
        txt = RemoveTag(txt, 'sup');
        txt = r'<sup>' + str(txt) + r'</sup>'
    return (txt);


def _title_caps(txt):
    if (txt == txt.upper()):
        txt = txt.capitalize()
    return txt


def CmtClean(txt):
    txt = RemoveTag(txt, 'comment[2-9]+');

    return (txt);

def ArrayTab(txt):
    txt = RemoveTag(txt, 'table')
    txt = re.sub(r'(<td(?: [^>]+)?>\s*)<p>((?:(?!</?td>).)*)</p>(\s*</td>)', r'\g<1>\g<2>\g<3>', txt, 0, re.I | re.S)
    txt = re.sub(r'(<(td|th)(?: [^>]+)?) align="[^"]*"', r'\g<1>', txt, 0, re.I)
    txt = re.sub(r'(<(td|th)(?: [^>]+)?) valign="[^"]*"', r'\g<1>', txt, 0, re.I)
    txt = re.sub(r'(<(td|th)(?: [^>]+)?)(>((?:(?!</\2>).)*)</\2>)',
                 lambda m: m.group(1) + _tableAlign(m.group(3), m.group(4)), txt, 0, re.I)
    txt = re.sub(r'(<td(?: [^>]+)?) width="[^"]*"', r'\g<1>', txt, 0, re.I);
    return txt


def _tableAlign(txt1, txt2, txt3):
    temp = re.sub(r'(<!--INS-->|<!--DEL-->|<!--/INS-->|<!--/DEL-->|&#x[A-Z0-9]+;|<(?:[^>]*)>|{{\?oins\?}}|{{\?cins\?}}|{{\?odel\?}}|{{\?cdel\?}})', '', txt2, 0, re.I | re.S)
    Num = re.search(r'^(?:&#x(?:[a-f0-9]{4});)?(?:[+|-|_|$|@])?\d+', temp, re.I | re.S)
    col = re.search(r' (?:colspan|rowspan)="([^"]+)"', txt1, re.I | re.S)
    if col:
        if (col.group(1) > '1'):
            txt1 = re.sub(r'(<t[hd](?: [^>]*)?)>', r'\g<1> align="center">', txt1, 0, re.I | re.S)
        else:
            if Num:
                txt1 = re.sub(r'(<t[d](?: [^>]*)?)>', r'\g<1> align="char" char=".">', txt1, 0, re.I | re.S)
                txt1 = re.sub(r'(<t[h](?: [^>]*)?)>', r'\g<1> align="center">', txt1, 0, re.I | re.S)
            else:
                txt1 = re.sub(r'(<t[hd](?: [^>]*)?)>', r'\g<1> align="left">', txt1, 0, re.I | re.S)
    else:
        if Num:
            txt1 = re.sub(r'(<t[d](?: [^>]*)?)>', r'\g<1> align="char" char=".">', txt1, 0, re.I | re.S)
            txt1 = re.sub(r'(<t[h](?: [^>]*)?)>', r'\g<1> align="center">', txt1, 0, re.I | re.S)
        else:
            txt1 = re.sub(r'(<t[hd](?: [^>]*)?)>', r'\g<1> align="left">', txt1, 0, re.I | re.S)

    return f"{txt1}{txt2}{txt3}"



def SpeechSpeaker(txt):
    txt = re.sub(r'<speaker>(?:(?!</?speaker>).)*</speaker>(?:(?!</?(?:speaker)>).)*', r'<speech>\g<0></speech>\n', txt,
                 0, re.I | re.S);
    if not (re.search(r'<speech>', txt, re.I)):
        txt = '<speech>' + str(txt) + '</speech>';

    txt = re.sub(r'\s+</speech>', r'</speech>', txt, 0, re.I);

    return (txt)

def uriLink(txt, uri):
    if not (re.search(r'<uri [^><]*\bcontent-type="orcid"', txt, re.I)):
        txt = re.sub(r'&#x002F;', r'/', txt, 0, re.I | re.S);
        uri = re.sub(r'&#x002F;', r'/', uri, 0, re.I | re.S);

        if (re.search(r'^<[a-z0-9:-]+ [^><]*\b(?:link|xlink:href)="[^"]+"', txt, re.I)):
            txt = re.sub(r'^<([a-z0-9:-]+)( [^><]*)(?:link|xlink:href)(="[^"]+"[^>]*>(?:(?!</\1>).)*</)\1>',
                         r'<ext-link ext-link-type="uri"\g<2>xlink:href\g<3>ext-link>', txt, 0, re.I | re.S);
        else:
            uri = RemoveA3B2(uri);
            uri = RemoveTag(uri, '[a-z0-9:-]+');
            if (re.search(r'^https?://', uri, re.I)):

                if (re.search(r'^https?://www.', uri, re.I)):
                    txt = re.sub(r'^<([a-z0-9:-]+)(?: [^>]+)?>((?:(?!</\1>).)*)</\1>',
                                 r'<ext-link ext-link-type="uri" xlink:href="' + str(uri) + r'">\g<2></ext-link>', txt,
                                 0, re.I | re.S);
                else:
                    uri = re.sub(r'^https?://', r'https://www.', uri, 0);
                    txt = re.sub(r'^<([a-z0-9:-]+)(?: [^>]+)?>((?:(?!</\1>).)*)</\1>',
                                 r'<ext-link ext-link-type="uri" xlink:href="' + str(uri) + r'">\g<2></ext-link>', txt,
                                 0, re.I | re.S);
            elif (re.search(r'^www.', uri, re.I)):
                uri = re.sub(r'^www.', r'https://www.', uri, 0);
                txt = re.sub(r'^<([a-z0-9:-]+)(?: [^>]+)?>((?:(?!</\1>).)*)</\1>',
                             r'<ext-link ext-link-type="uri" xlink:href="' + str(uri) + r'">\g<2></ext-link>', txt, 0,
                             re.I | re.S);
            else:
                txt = re.sub(r'^<([a-z0-9:-]+)(?: [^>]+)?>((?:(?!</\1>).)*)</\1>',
                             r'<ext-link ext-link-type="uri" xlink:href="https://www.' + str(
                                 uri) + r'">\g<2></ext-link>', txt, 0, re.I | re.S);

    return txt


def Abstract(txt):
    # txt = re.sub(r'<abstract(?: [^>]*)?',r'\g<0> xml:lang="en"',txt,0,re.I|re.S)
    txt = re.sub(r'<p>\s*((?:<sec(?: [^>]+)?>(?:(?!</sec>).)*</sec>\s*)+)</p>', r'\g<1>', txt, 0, re.I | re.S)
    txt = re.sub(r'<p>\s*((?:&#\w\d*; ))', '<p>', txt, 0, re.I | re.S)
    txt = re.sub(r'(<sec(?: [^>]+)?) sec-type="[^"]*"', r'\g<1>', txt, 0, re.I)
    txt = re.sub(r'(<sec(?: [^>]*)?>\s*<title)(?: [^>]*)?>', r'\g<1> content-type="abstract-subheading">', txt, 0,
                 re.I | re.S)
    return txt

def _MathAtrib(tag, txt):
    if (tag == 'inline-formula'):
        txt = re.sub(r'<mml:math(?: [^>]*)?>', r'<mml:math display="inline">', txt, 0, re.I | re.S)
        txt = re.sub(r'<graphic((?: [^>]*)?/>)', r'<inline-graphic\g<1>', txt, 0, re.I | re.S)
        # inline-graphic id count for inline
        txt = re.sub(r'<inline-graphic [^><]*xlink:href="[^"]*"[^>]*>',
                     lambda m: Graphic(m.group(), 'inl', next(InlineIdCount), 'eps'), txt, 0, re.I | re.S)

def Graphic(txt, type, no, ext):
    with open(uploads_folder + "\\temp.txt", "r", encoding="utf-8") as f1:
        filenameupload = f1.read()
        filenameupload = filenameupload.replace(".xml", "")
    # no = '{0}'.format(str(no).zfill(2));
    # txt = re.sub(r'(<graphic(?: [^>]+)? xlink:href=")[^"]*("[^>]*>)',r'\g<1>'+str(Jid)+'-'+str(vol)+'-'+str(isu)+'-'+str(fpage)+'-g'+str(no)+r'.eps\g<2>',txt,0,re.I);
    txt = re.sub(r'<((?:inline-)?graphic(?: [^>]+)? xlink:href=")[^"]*("[^>]*>)', r'<&del;\g<1>' + str(filenameupload) + '-' + str(type) + str(no).zfill(3) + r'.' + str(ext) + r'\g<2>', txt,0, re.I)
    return txt


def _ack(txt):
    txt = re.sub(r'<ack(?: [^>]*)?>', '<ack id="ack">', txt, 0, re.I | re.S)
    txt = re.sub(r'<title(?: [^>]*)?>(?:(?!</title>).)*</title>', '', txt, 0, re.I | re.S)
    return txt

def iGraphic(txt, type, no, ext):
    with open(uploads_folder + "\\temp.txt", "r", encoding="utf-8") as f1:
        filenameupload = f1.read()
        filenameupload= filenameupload.replace(".xml", "")
    # no = '{0}'.format(str(no).zfill(2));
    # txt = re.sub(r'(<graphic(?: [^>]+)? xlink:href=")[^"]*("[^>]*>)',r'\g<1>'+str(Jid)+'-'+str(vol)+'-'+str(isu)+'-'+str(fpage)+'-g'+str(no)+r'.eps\g<2>',txt,0,re.I);
    txt = re.sub(r'<((?:inline-)?graphic(?: [^>]+)? xlink:href=")[^"]*("[^>]*>)', r'<&del;\g<1>' + str(filenameupload) + '_' + str(type) + str(no).zfill(3) + r'.' + str(ext) + r'\g<2>', txt,0, re.I)
    return txt

def _AltTitle(txt):
    Tmp = re.search(
        r'<alt-title(?: [^>]*)? alt-title-type="left-running-head"(?: [^>]*)?>((?:(?!</alt-title>).)*)</alt-title>\s*<alt-title(?: [^>]*)? alt-title-type="right-running-head"(?: [^>]*)?>((?:(?!</alt-title>).)*)</alt-title>',
        txt, re.I | re.S)
    if Tmp:
        if (Tmp.group(1) == Tmp.group(2)):
            Tmp = r'<alt-title alt-title-type="running-head">' + str(Tmp.group(1)) + '</alt-title>'
            return Tmp
        else:
            return txt
    else:
        return txt

def _statement(txt):
    txt = re.sub(r'</?p(?: [^>]*)?>', r'', txt, 0, re.I | re.S)
    txt = f'<p>{txt}</p>'
    txt = re.sub(r'<p><label>', r'<label>', txt, 0, re.I)
    txt = re.sub(r'</label>', r'</label><p>', txt, 0, re.I)
    return txt



# add excel

def _Xref(txt):
    txt = re.sub(r'\)</xref>', r'</xref>)', txt, 0, re.I)
    return txt

def _removetagspace(txt):
    txt = re.sub(r'<p>\s+', r'<p>', txt, 0, re.I)
    return txt


def _removeunwantedspace(txt):
    txt = re.sub(r'> ', r'>', txt, 0, re.I)
    return txt
def _removeunwantedtag(txt):
    txt = re.sub(r'</p></p>', r'</p>', txt, 0, re.I)
    return txt
def _removeAttribute(txt):
    txt = re.sub(r' (width|valign)="[^"]*"', r'', txt, 0, re.I)
    return txt

def _removeTableAttribute(txt):
    txt = re.sub(r' (width|style)="[^"]*"', r'', txt, 0, re.I)
    return txt


def _decimal_2_hexcode(decimal_code):
    hex_code = hex(int(decimal_code))
    hex_code = hex_code.replace('0x', '')
    hex_code = '&#x' + hex_code + ';'  # &#x2009;
    return hex_code
xref = {};
def _bio(txt, no):
    id = re.search(r'<bio(?: [^>]*)? id="([^"]+)"(?: [^>]*)?>', txt, re.I)
    if id:
        xref[id.group(1)] = 'bio' + str(no)
    txt = re.sub(r'(<bio(?: [^>]*)? id=")[^"]+("(?: [^>]*)?>)', '\g<1>bio' + str(no) + '\g<2>', txt, 0, re.I | re.S)
    return txt

def _Xref(txt):
    txt = re.sub(r'\)</xref>', r'</xref>)', txt, 0, re.I)
    return txt

def boxed(txt, no):
    bx = re.search(r'<boxed-text(?: [^>]+)? id="((U?BT)0*(\d+[a-z]?))"', txt, re.I);
    txt = re.sub(r'(<boxed-text(?: [^>]+)?) id="[^"]*"', r'\g<1>', txt, 0, re.I);
    if (bx):
        if (bx.group(2) == 'UBT'):
            newId = 'unbox' + bx.group(3)
        else:
            newId = 'box' + bx.group(3)

        xref[bx.group(1)] = newId;
        txt = re.sub(r'(<boxed-text(?: [^>]+)?)>', r'\g<1> id="' + str(newId) + '">', txt, 0, re.I)
        Labelcheck = re.search(r'<boxed-text(?: [^>]*)?>\s*<label(?: [^>]*)?>', txt, re.I | re.S)
        Title = re.search(
            r'<boxed-text(?: [^>]*)?>\s*<label(?: [^>]*)?>(?:(?!</label>).)*</label>\s*<title(?: [^>]*)?>(?:(?!</title>).)*</title>',
            txt, re.I | re.S)
        if (Title):
            txt = re.sub(
                r'(<boxed-text(?: [^>]*)?>\s*<label(?: [^>]*)?>(?:(?!</label>).)*</label>\s*)(<title(?: [^>]*)?>((?:(?!</title>).)*)</title>)',
                r'\g<1><caption>\g<2></caption>', txt, 0, re.I | re.S)
        if (Labelcheck):
            txt = re.sub(r'(<boxed-text(?: [^>]+)?)>', r'\g<1> position="float">', txt, 0, re.I)
        else:
            txt = re.sub(r'(<boxed-text(?: [^>]+)?)>', r'\g<1> position="anchor">', txt, 0, re.I)

    txt = re.sub(r'(<title>)\s*<p>((?:(?!</?title>).)*)</p>\s*(</title>)', r'\g<1>\g<2>\g<3>', txt, 0, re.I | re.S)
    txt = re.sub(r'(</?)sec((?: [^>]+)?>)', r'\g<1>&del;sec\g<2>', txt, 0, re.I | re.S)
    txt = re.sub(r'(</?)fn((?: [^>]+)?>)', r'\g<1>&del;fn\g<2>', txt, 0, re.I | re.S)

    return txt

def sectionID1(txt, lvl):
    newId = 'sec' + str(lvl).zfill(3)
    si = re.search(r'<sec1 [^><]*id="([^"]+)"', txt, re.I);
    if (si):
        xref[si.group(1)] = newId
    txt = re.sub(r'<(sec1)((?: [^>]+)?>(?:(?!</?\1>).)*</\1>)', r'<&del;\g<1> newid="' + str(newId) + r'"\g<2>', txt, 0,re.I | re.S);

    secId2 = itertools.count(1);
    txt = re.sub(r'<sec2(?: [^>]+)?>(?:(?!</?sec2>).)*</sec2>', lambda m: sectionID2(m.group(), newId, next(secId2)),txt, 0, re.I | re.S);

    return (txt);

def Figure(txt):
    fg = re.search(r'<fig [^><]*id="((U?F)0*(\d+[a-z]?))"', txt, re.I);
    if (fg):
        with open(uploads_folder + "\\temp.txt", "r", encoding="utf-8") as f1:
            filenameupload=f1.read()
        newId = fg.group(2).upper() + '_' + str(filenameupload) + fg.group(3).zfill(3)
        xref[fg.group(1)] = newId;
        txt = re.sub(r'(<fig [^><]*id=")U?F0*\d+[a-z]?"', r'\g<1>' + str(newId) + '"', txt, 0, re.I);
    # v1.0.0.9
    # pos = re.search(r'<fig [^><]*position="[^"]*"',txt,re.I);
    # if(pos):
    # txt = re.sub(r'(<fig [^><]*position=")[^"]*"','\g<1>float"',txt,0,re.I);
    # else:
    # txt = re.sub(r'(<fig(?: [^>]+)?)>','\g<1> position="float">',txt,0,re.I);
    # --
    txt = re.sub(r'(<graphic(?: [^>]+)?)/>\s*(<object-id>(?:(?!</?object-id>).)*</object-id>)',
                 r'\g<1>>\g<2></graphic>', txt, 0, re.I | re.S)
    txt = re.sub(r'(<fig [^><]*id="[^"]*")', '\g<1> orientation="portrait"', txt, 0, re.I);
    txt = re.sub(r'(<fig [^><]*fig-type=")[^"]*"', '\g<1>diagram"', txt, 0, re.I);
    txt = re.sub(r'(<graphic(?: [^>]*)? )xlink:type="simple"((?: [^>]*)?/>)', '\g<1>\g<2>', txt, 0, re.I | re.S)
    txt = re.sub(r'(<graphic(?: [^>]*)?)/>', '\g<1> xlink:type="simple"/>', txt, 0, re.I | re.S)

    # graphic id count for fig
    txt = re.sub(r'<graphic [^><]*xlink:href="[^"]*"[^>]*>',
                 lambda m: Graphic(m.group(), 'fig', next(FigIdCount), 'eps'), txt, 0, re.I | re.S)

    alt = re.search(r'<alt-text(?: [^>]+)?>(?:(?!</?alt-text>).)*</alt-text>', txt, re.I | re.S);
    if (alt and re.search(r'<graphic(?: [^>]+)?', txt, re.I)):
        alt_txt = '';
        for m in re.finditer(r'<alt-text(?: [^>]+)?>(?:(?!</?alt-text>).)*</alt-text>', txt, re.I | re.S):
            txt = re.sub(m.group(), r'', txt);
            alt_txt += m.group();
        txt = re.sub(r'<graphic(?: [^>]+)?', alt_txt + '\n' + r'\g<0>', txt, 0, re.I);

    txt = re.sub(r'<p(?: [^>]+)?>\s*(<attrib(?: [^>]+)?>(?:(?!</?attrib>).)*</attrib>)\s*</p>', r'\g<1>', txt, 0,
                 re.I | re.S);

    return (txt);

def DispFormula(txt, tfn):
    tb = re.search(r'<disp-formula [^><]*id="((U?M)0*(\d+[a-z]?))"', txt, re.I)
    if (tb):
        if (tb.group(2) == 'M'):
            newId = 'eqn' + tb.group(3).lower()
        else:
            newId = ('ueqn' + tb.group(3)).lower()
        tfn = tb.group(2)
        xref[tb.group(1)] = newId

        txt = re.sub(r'(<disp-formula [^><]*id=")U?M0*\d+[a-z]?"', '\g<1>' + str(newId) + '"', txt, 0, re.I)

    return (txt)


def Table(txt, tfn):
    tb = re.search(r'<table-wrap [^><]*id="((U?T)0*(\d+[a-z]?))"', txt, re.I)
    if (tb):
        if (tb.group(2) == 'T'):
            newId = 'tbl' + tb.group(3).lower()
        else:
            newId = 'utbl' + tb.group(3).lower()
        tfn = tb.group(2)
        xref[tb.group(1)] = newId

        txt = re.sub(r'(<table-wrap [^><]*id=")U?T0*\d+[a-z]?"', '\g<1>' + str(newId) + '"', txt, 0, re.I)
        txt = re.sub(r'(<table-wrap-foot(?: [^>]+)?>)((?:(?!</table-wrap-foot>).)*)(</table-wrap-foot>)',
                     lambda m: str(m.group(1)) + str(r'<fn-group content-type="footnotes">') + tableFoot(m.group(2),
                                                                                                         newId) + str(
                         '</fn-group>') + str(m.group(3)), txt, 0, re.I | re.S);

    txt = re.sub(r'(<table-wrap [^><]*id="[^"]*")', '\g<1> orientation="portrait"', txt, 0, re.I);
    txt = re.sub(r'</label>\s*<caption>', r'</label><caption>', txt, 0, re.S | re.I);
    txt = re.sub(r'<table(?: [^>]+)?>', r'<alternatives>\n<graphic xlink:href=""/>\n<table frame="hsides">', txt, 0,
                 re.I);
    txt = re.sub(r'</table>', r'</table>\n</alternatives>', txt, 0, re.I);
    txt = re.sub(r'(<tr(?: [^>]+)?) valign="[^"]*"', r'\g<1>', txt, 0, re.I);

    # v1.0.0.9
    txt = re.sub(r'(<(td|th)(?: [^>]+)?) valign="[^"]*"', r'\g<1>', txt, 0, re.I);
    txt = re.sub(r'(<(td|th)(?: [^>]+)?) align="[^"]*"', r'\g<1>', txt, 0, re.I)
    # --

    txt = re.sub(r'(<t[hd](?: [^>]+)?) width="[^"]*"', r'\g<1>', txt, 0, re.I);
    # txt = re.sub(r' align="justify"',r' align="left"',txt,0,re.I);

    txt = _element_leveling(txt, 'list')
    txt = re.sub(r'<(list\d+)(?: [^>]+)?>(?:(?!</?\1>).)+</\1>', lambda m: list(m.group(), '0'), txt, 0, re.I | re.S);
    txt = re.sub(r'<(t[hd])(?: [^>]+)?>(?:(?!</\1>).)*</\1>', lambda m: trow(m.group(), m.group(1)), txt, 0,
                 re.I | re.S);

    # txt = re.sub(r'(<(td|th)(?: [^>]+)?)(>((?:(?!</\2>).)*)</\2>)', lambda m: m.group(1)+_tableAlign(m.group(3),m.group(4)),txt,0,re.I)
    txt = re.sub(r'(<(td|th)(?: [^>]+)?>)((?:(?!</\2>).)*)(</\2>)',
                 lambda m: _tableAlign(m.group(1), m.group(3), m.group(4)), txt, 0, re.I)

    txt = re.sub(r'&del;', r'', txt, 0, re.I);
    txt = re.sub(r'(</?list)\d+', r'\g<1>', txt, 0, re.I)
    # graphic id count for table
    txt = re.sub(r'<graphic [^><]*xlink:href="[^"]*"[^>]*>',
                 lambda m: Graphic(m.group(), 'tbl', next(TabIdCount), 'eps'), txt, 0, re.I | re.S)

    txt = re.sub(r'(<colgroup(?: [^>]*)?) cols="[^"]+"((?: [^>]*)?>)', r'\g<1>\g<2>', txt, 0, re.I | re.S)
    txt = re.sub(r'(<col(?: [^>]*)?) colnum="[^"]+"((?: [^>]*)?>)', r'\g<1>\g<2>', txt, 0, re.I | re.S)

    return txt


def trow(txt, element):
    if (re.match(r'^th$', element, re.I)):
        txt = RemoveTag(txt, 'bold');

    txt = re.sub(r'<\/p>\s*<p(?: [^>]+)?>', r'<break/>', txt, 0, re.S);
    txt = re.sub(r'<\/?p(?: [^>]+)?>', r'', txt, 0, re.S);
    txt = re.sub(r'(<(t[hd])(?: [^>]+)?)>\s*<\/\2>', r'\g<1>/>', txt, 0, re.S);

    return (txt);

def appendix(txt, ano):
    appp = re.search(r'^<app [^><]*id="([^"]+)"', txt, re.I);
    newId = 'app' + str(ano)
    if (appp):
        xref[appp.group(1)] = newId;
        txt = re.sub(r'(<app(?: [^>]*)?) id="[^"]+"', r'\g<1> id="' + str(newId) + '"', txt, re.I);
    else:
        txt = re.sub(r'(<app(?: [^>]+)?) id="[^"]*"', r'\g<1>', txt, 0, re.I);
        txt = re.sub(r'<app((?: [^>]+)?>)', r'<app id="' + str(newId) + '"\g<1>', txt, 0, re.I);

    return (txt);


def Reference(txt, no):
    # Changes req by Stella
    rf = re.search(r'<ref(?: [^>]*)? id="([^"]*)"|<ref>', txt, re.I)
    if rf:
        newId = 'ref' + str(no).zfill(3)
        xref[rf.group(1)] = newId
        txt = re.sub(r'(<ref(?: [^>]*)? id=")[^"]*"', r'\g<1>' + str(newId) + '"', txt, re.I)
        txt = re.sub(r'(<ref)(>)', r'\g<1> id="' + str(newId) + '"\g<2>', txt, re.I)

    # rf = re.search(r'(<ref [^><]*id="([^"]*)"|<ref>)', txt, re.I);
    # if (rf):
    #     newId = 'ref' + str(no).zfill(3)
    #     xref[rf.group(1)] = newId;
    #     txt = re.sub(r'(<ref [^><]*id=")[^"]*"', r'\g<1>' + str(newId) + '"', txt,0, re.I);
    #     txt = re.sub(r'(<ref)(>)', r'\g<1> id="' + str(newId) + '"\g<2>', txt,0, re.I);

    # txt = re.sub(r'(</?)mixed-citation((?: [^>]+)?>)',r'\g<1>citation\g<2>',txt,0,re.I);
    # txt = re.sub(r'(<mixed-citation [^><]*)publication-type(="[^"]*")',r'\g<1>citation-type\g<2>',txt,0,re.I);
    txt = re.sub(r'(<mixed-citation [^><]*publication-type=")conf-proc(")', r'\g<1>confproc\g<2>', txt, 0, re.I);

    txt = re.sub(r'(<mixed-citation [^><]*publication-type=")paper(")', r'\g<1>working-paper\g<2>', txt, 0, re.I);

    txt = re.sub(r'(<ref(?: [^>]+)?>)((?:(?!</?(?:ref|label)>).)*)(<label>(?:(?!</?label>).)*</label>)\s*',
                 r'\g<1>\g<3>\g<2>', txt, 0, re.I | re.S);
    txt = re.sub(r'<author type="([^"]+)">', r'<person-group person-group-type="\g<1>"><string-name>', txt, 0, re.I);
    txt = re.sub(r'<author>', r'<person-group person-group-type="author"><string-name>', txt, 0, re.I);
    txt = re.sub(r'</author>', r'</string-name></person-group>', txt, 0, re.I);
    txt = re.sub(r'<collab(?: [^>]+)?>(?:(?!</collab>).)*</collab>',
                 r'<person-group person-group-type="author">\g<0></person-group>', txt, 0, re.I | re.S);
    txt = re.sub(r'<editor(?: [^>]+)?>(?:(?!</editor>).)*</editor>',
                 r'<person-group person-group-type="editor">\g<0></person-group>', txt, 0, re.I | re.S);
    # txt = re.sub(r'<string-name(?: [^>]+)?>(?:(?!</string-name>).)*</string-name>',r'<person-group person-group-type="author">\g<0></person-group>',txt,0,re.I|re.S);
    txt = re.sub(r'(</?)editor', r'\g<1>string-name', txt, 0, re.I);
    txt = re.sub(
        r'<person-group [^><]*person-group-type="author"[^><]*>(?:(?!<person-group [^><]*person-group-type="editor"[^><]*>).)+$',
        lambda m: PersonGrp(m.group()), txt, 0, re.I | re.S);

    txt = re.sub(
        r'<person-group [^><]*person-group-type="editor"[^><]*>(?:(?!<person-group [^><]*person-group-type="author"[^><]*>).)+$',
        lambda m: PersonGrp(m.group()), txt, 0, re.I | re.S);

    # txt = re.sub(r'(<person-group(?: [^>]+)?>(?:(?!</?person-group[ >]).)*</person-group>)(,\s*<etal>et\s*al\.?</etal>)',r'\g<1><etal/>',txt,0,re.I|re.S);
    txt = re.sub(r'<etal>et\s*al\.?</etal>', r'<etal/>.', txt, 0, re.I | re.S);

    # v1.0.0.9
    # txt = re.sub(r'([ \.,:;\)\(]+)<etal/>',r'<?x-open?>\g<1><?x-close?><etal/>',txt,0,re.I|re.S);
    # txt = re.sub(r'<etal/>([ \.,:;\)\(]+)',r'<etal/><?x-open?>\g<1><?x-close?>',txt,0,re.I|re.S);
    # --

    txt = re.sub(r'(<source(?: [^>]+)?>)((?:(?!</?source>).)+)(</source>)',
                 lambda m: m.group(1) + RemoveFullFormate(m.group(2)) + m.group(3), txt, 0, re.I | re.S);

    txt = re.sub(r'<page-range(?: [^>]+)?>((?:(?!</?page-range[ >]).)+)</page-range>', lambda m: PageRange(m.group(1)),
                 txt, 0, re.I | re.S);

    txt = re.sub(r'(?:\bdoi[ :]*)?\s*<(uri|doi)(?: [^>]*)?>(?:(?!</\1>).)*</\1>', lambda m: _DoiLink(m.group()), txt, 0,
                 re.I | re.S);

    txt = re.sub(r'[ \.]+</label>', r'</label>', txt, 0);

    # v1.0.0.3
    # txt = re.sub(r'[\( ]+(<([a-z0-9:-]+)(?: [^>]+)?>(?:(?!</?\2[ >]).)*</\2>)[ \)]+',r'\g<1>',txt,0,re.I|re.S);
    # if(re.search(r'<citation [^><]*\bcitation-type="(?:journal|book)"',txt,re.I)):
    # while(re.search(r'(</[a-z0-9:-]+>)([ \.,:;\)\(\.\s*[\]]+)(</?[a-z0-9:-]+(?: [^>]+)?>)',txt,re.I)):
    # v1.0.0.9
    # txt = re.sub(r'(</[a-z0-9:-]+>)([ \.,:;\)\(\.\s*[\]]+)(</?[a-z0-9:-]+(?: [^>]+)?>)',r'\g<1><?x-open?>\g<2><?x-close?>\g<3>',txt,0,re.I);
    # ---
    # v1.0.0.7
    # txt = re.sub(r'[\. ]*<etal/>[\. ]*',r'<etal/>',txt,0,re.I);
    # ---
    txt = re.sub(r'<x(?: [^>]+)?>((?:(?!</?x>).)*)</x>', r'<comment>\g<1></comment>', txt, 0, re.I | re.S)

    # shobana#07-06-2022##
    for m in re.finditer(
            r'<ref(?: [^>]*)?>(?:(?!</ref>).)*<mixed-citation(?: [^>]*)? publication-type="[^"]*"[^>]*?>((?:(?!</mixed-citation>).)*)</mixed-citation>((?:(?!</ref>).)*)</ref>',
            txt, re.I | re.S):
        if (
        re.search(r'<chapter-title(?: [^>]*)?>(?:(?!</chapter-title>).)*</chapter-title>', m.group(1), re.I | re.S)):
            txt = re.sub(r'(<mixed-citation(?: [^>]*)? publication-type=")[^"]*("[^>]*?>)', r'\g<1>book-chapter\g<2>',
                         m.group(), 0, re.I | re.S)
    # shobana#07-06-2022#14-06-2022#

    return txt

def PersonGrp1(pre, txt, post):
    txt = re.sub(r'</?person-group(?: [^>]+)?>', r'', txt, 0, re.I | re.S);
    # while (re.search(r'(</[a-z0-9:-]+>)[ \.:;]+(<[a-z0-9:-]+(?: [^>]+)?>)', txt, re.I)):
        # txt = re.sub(r'(</[a-z0-9:-]+>)([ \.,:;\)\(]+)(<[a-z0-9:-]+(?: [^>]+)?>)',r'\g<1><?x-open>\g<2><?x-close?>\g<3>',txt,0,re.I);
        # txt = re.sub(r'(</[a-z0-9:-]+>)([ \.,:;\)\(]+)(<[a-z0-9:-]+(?: [^>]+)?>)', r'\g<1>\g<3>', txt, 0, re.I);
    return (pre + txt + post);

def RemoveFullFormate(txt):
    # txt = RemoveQuery(txt);
    txt = re.sub(r'<!--(?:(?!-->).)*-->', '', txt, 0, re.I | re.S)
    txt = RemoveA3B2(txt)
    txt = re.sub(r'</(italic|i|bold|b|sup|sub|sc|underline|u)>(\s*)<\1(?: [^>]+)?>', '\g<2>', txt, 0, re.I | re.S)
    while (
    re.search(r'^<(italic|i|bold|b|sup|sub|sc|underline|u)(?: [^>]+)?>((?:(?!</?\1[ >]).)*)</\1>$', txt, re.I | re.S)):
        txt = re.sub(r'^<(italic|i|bold|b|sup|sub|sc|underline|u)(?: [^>]+)?>((?:(?!</?\1[ >]).)*)</\1>$', '\g<2>', txt,
                     0, re.I | re.S)
    return txt


def PersonGrp(txt):
    txt = re.sub(
        r'(<person-group(?: [^>]+)? person-group-type="author"[^><]*>)((?:(?!</?(?:year|chapter-title|article-title|source)[ >]).)*)(</person-group>)',
        lambda m: PersonGrp1(m.group(1), m.group(2), m.group(3)), txt, 0, re.I | re.S);
    txt = re.sub(
        r'(<person-group(?: [^>]+)? person-group-type="editor"[^><]*>)((?:(?!</?(?:year|chapter-title|article-title|source)[ >]).)*)(</person-group>)',
        lambda m: PersonGrp1(m.group(1), m.group(2), m.group(3)), txt, 0, re.I | re.S);

    return (txt);

def tableFoot(txt, tabid):
    # txt = RemoveTag(txt,'fn-group');
    tfnNo = itertools.count(1);
    txt = re.sub(r'<fn(?: [^>]+)?>(?:(?!</fn>).)*</fn>', lambda m: tabfn(m.group(), tabid, next(tfnNo)), txt, 0,
                 re.I | re.S);

    return txt


def tabfn(txt, tabid, tno):
    fn = re.search(r'^<fn [^><]*id="([^"]+)"', txt, re.I);
    newId = str(tabid) + '-fn' + str(tno)
    if (fn):
        tfnID[fn.group(1)] = newId;
        txt = re.sub(r'(<fn(?: [^>]*)?) id="[^"]+"', r'\g<1> id="' + str(newId) + '"', txt, re.I);
    else:
        txt = re.sub(r'(<fn(?: [^>]+)?) id="[^"]*"', r'\g<1>', txt, 0, re.I);
        txt = re.sub(r'<fn((?: [^>]+)?>)', r'<fn id="' + str(newId) + '"\g<1>', txt, 0, re.I);

    return txt

def PageRange(txt):
    if (re.search(r'^\s*<(bold|italic)>(?:(?!</?\1>).)+</\1>\s*$', txt, re.I | re.S)):
        frmt = re.search(r'^\s*<(bold|italic)>(?:(?!</?\1>).)+</\1>\s*$', txt, re.I | re.S);
        txt = RemoveTag(txt, 'bold,italic');
        frtag = frmt.group(1);
        txt = re.sub(r'^\s*([0-9a-z]+)[\.\?, ]*(\&\#x\d{4};|\-)\s*([0-9a-z]+)[\.\?,; ]*$',
                     r'<fpage><' + str(frtag) + r'>\g<1><' + str(frtag) + r'></fpage>\g<2><lpage><' + str(
                         frtag) + r'>\g<3><' + str(frtag) + r'></lpage>', txt, 0, re.I | re.S);
        txt = re.sub(r'^\s*(\d+)\s*$', r'<fpage><' + str(frtag) + r'>\g<1><' + str(frtag) + r'></fpage>', txt, 0,
                     re.I | re.S);
        txt = re.sub(r'^\s*([a-z]+\d+|\d+[a-z]+)\s*$',
                     r'<elocation-id><' + str(frtag) + r'>\g<1><' + str(frtag) + r'></elocation-id>', txt, 0,
                     re.I | re.S);
    else:
        txt = RemoveTag(txt, 'bold,italic');
        txt = re.sub(r'^\s*([0-9a-z]+)[\.\?, ]*(\&\#x\d{4};|\-)\s*([0-9a-z]+)[\.\?,; ]*$',
                     r'<fpage>\g<1></fpage>\g<2><lpage>\g<3></lpage>', txt, 0, re.I | re.S);
        txt = re.sub(r'^\s*(\d+)\s*$', r'<fpage>\g<1></fpage>', txt, 0, re.I | re.S);
        txt = re.sub(r'^\s*([a-z]+\d+|\d+[a-z]+)\s*$', r'<elocation-id>\g<1></elocation-id>', txt, 0, re.I | re.S);

    return (txt);

def _DoiLink(txt):
    txt = re.sub(r'&#x002F;', r'/', txt, 0, re.I | re.S);
    txt = re.sub(r'&#x2010;', r'-', txt, 0, re.I | re.S);
    if (re.search(r'<doi(?: [^>]*)?>(?:(?!</doi>).)*</doi>', txt, re.I | re.S)):
        txt = re.sub(r'<doi(?: [^>]*)?>((?:(?!</doi>).)*)</doi>', '<pub-id pub-id-type="doi">\g<1></pub-id>', txt, 0,
                     re.I | re.S)
    else:
        txt = RemoveA3B2(txt)
        uridata = re.search(r'<xref(?: [^>]*)? ref-type="query"(?: [^>]*)?/?>', txt, re.I)
        if uridata:
            uriLinkdata = re.sub(r'<xref(?: [^>]*)? ref-type="query"(?: [^>]*)?/?>', '', txt, 0, re.I)
            uriQuerydata = uridata.group()
        else:
            uriLinkdata = txt
            uriQuerydata = ""

        txt = re.sub(r'<xref(?: [^>]*)? ref-type="query"(?: [^>]*)?/?>', '', txt, 0, re.I)
        txt = re.sub(r'<uri(?: [^>]*)?>((?:(?!</uri>).)*)</uri>',
                     lambda m: '<ext-link ext-link-type="uri" xlink:href="' + str(
                         _url_entity_Conversion(m.group(1))) + '">' + str(m.group(1)) + '</ext-link>' + str(
                         uriQuerydata), txt, 0, re.I | re.S)

    txt = re.sub(r'https?://doi.org/https?://doi.org/', r'https://doi.org/', txt, 0)

    return txt
def _url_entity_Conversion(txtcnt):
    ASCIIEncodingCnt = _open_utf8(ASCIIEncoding);
    r = re.findall(r'((?:(?!\==>).)*)==>((?:(?!\n).)*)\n', ASCIIEncodingCnt, re.I | re.S | re.M)
    ASCII_dict = {a: b for a, b in r}
    for id in ASCII_dict.keys():
        txtcnt = re.sub(id, ASCII_dict[id], txtcnt)
    return txtcnt

def Reference(txt, no):
    # Changes req by Stella
    rf = re.search(r'<ref(?: [^>]*)? id="([^"]*)"|<ref>', txt, re.I)
    if rf:
        newId = 'ref' + str(no).zfill(3)
        xref[rf.group(1)] = newId
        txt = re.sub(r'(<ref(?: [^>]*)? id=")[^"]*"', r'\g<1>' + str(newId) + '"', txt, re.I)
        txt = re.sub(r'(<ref)(>)', r'\g<1> id="' + str(newId) + '"\g<2>', txt, re.I)

    # rf = re.search(r'(<ref [^><]*id="([^"]*)"|<ref>)', txt, re.I);
    # if (rf):
    #     newId = 'ref' + str(no).zfill(3)
    #     xref[rf.group(1)] = newId;
    #     txt = re.sub(r'(<ref [^><]*id=")[^"]*"', r'\g<1>' + str(newId) + '"', txt,0, re.I);
    #     txt = re.sub(r'(<ref)(>)', r'\g<1> id="' + str(newId) + '"\g<2>', txt,0, re.I);

    # txt = re.sub(r'(</?)mixed-citation((?: [^>]+)?>)',r'\g<1>citation\g<2>',txt,0,re.I);
    # txt = re.sub(r'(<mixed-citation [^><]*)publication-type(="[^"]*")',r'\g<1>citation-type\g<2>',txt,0,re.I);
    txt = re.sub(r'(<mixed-citation [^><]*publication-type=")conf-proc(")', r'\g<1>confproc\g<2>', txt, 0, re.I);

    txt = re.sub(r'(<mixed-citation [^><]*publication-type=")paper(")', r'\g<1>working-paper\g<2>', txt, 0, re.I);

    txt = re.sub(r'(<ref(?: [^>]+)?>)((?:(?!</?(?:ref|label)>).)*)(<label>(?:(?!</?label>).)*</label>)\s*',
                 r'\g<1>\g<3>\g<2>', txt, 0, re.I | re.S);
    txt = re.sub(r'<author type="([^"]+)">', r'<person-group person-group-type="\g<1>"><string-name>', txt, 0, re.I);
    txt = re.sub(r'<author>', r'<person-group person-group-type="author"><string-name>', txt, 0, re.I);
    txt = re.sub(r'</author>', r'</string-name></person-group>', txt, 0, re.I);
    txt = re.sub(r'<collab(?: [^>]+)?>(?:(?!</collab>).)*</collab>',
                 r'<person-group person-group-type="author">\g<0></person-group>', txt, 0, re.I | re.S);
    txt = re.sub(r'<editor(?: [^>]+)?>(?:(?!</editor>).)*</editor>',
                 r'<person-group person-group-type="editor">\g<0></person-group>', txt, 0, re.I | re.S);
    # txt = re.sub(r'<string-name(?: [^>]+)?>(?:(?!</string-name>).)*</string-name>',r'<person-group person-group-type="author">\g<0></person-group>',txt,0,re.I|re.S);
    txt = re.sub(r'(</?)editor', r'\g<1>string-name', txt, 0, re.I);
    txt = re.sub(
        r'<person-group [^><]*person-group-type="author"[^><]*>(?:(?!<person-group [^><]*person-group-type="editor"[^><]*>).)+$',
        lambda m: PersonGrp(m.group()), txt, 0, re.I | re.S);

    txt = re.sub(
        r'<person-group [^><]*person-group-type="editor"[^><]*>(?:(?!<person-group [^><]*person-group-type="author"[^><]*>).)+$',
        lambda m: PersonGrp(m.group()), txt, 0, re.I | re.S);

    # txt = re.sub(r'(<person-group(?: [^>]+)?>(?:(?!</?person-group[ >]).)*</person-group>)(,\s*<etal>et\s*al\.?</etal>)',r'\g<1><etal/>',txt,0,re.I|re.S);
    txt = re.sub(r'<etal>et\s*al\.?</etal>', r'<etal/>.', txt, 0, re.I | re.S);

    # v1.0.0.9
    # txt = re.sub(r'([ \.,:;\)\(]+)<etal/>',r'<?x-open?>\g<1><?x-close?><etal/>',txt,0,re.I|re.S);
    # txt = re.sub(r'<etal/>([ \.,:;\)\(]+)',r'<etal/><?x-open?>\g<1><?x-close?>',txt,0,re.I|re.S);
    # --

    txt = re.sub(r'(<source(?: [^>]+)?>)((?:(?!</?source>).)+)(</source>)',
                 lambda m: m.group(1) + RemoveFullFormate(m.group(2)) + m.group(3), txt, 0, re.I | re.S);

    txt = re.sub(r'<page-range(?: [^>]+)?>((?:(?!</?page-range[ >]).)+)</page-range>', lambda m: PageRange(m.group(1)),
                 txt, 0, re.I | re.S);

    txt = re.sub(r'(?:\bdoi[ :]*)?\s*<(uri|doi)(?: [^>]*)?>(?:(?!</\1>).)*</\1>', lambda m: _DoiLink(m.group()), txt, 0,
                 re.I | re.S);

    txt = re.sub(r'[ \.]+</label>', r'</label>', txt, 0);

    # v1.0.0.3
    # txt = re.sub(r'[\( ]+(<([a-z0-9:-]+)(?: [^>]+)?>(?:(?!</?\2[ >]).)*</\2>)[ \)]+',r'\g<1>',txt,0,re.I|re.S);
    # if(re.search(r'<citation [^><]*\bcitation-type="(?:journal|book)"',txt,re.I)):
    # while(re.search(r'(</[a-z0-9:-]+>)([ \.,:;\)\(\.\s*[\]]+)(</?[a-z0-9:-]+(?: [^>]+)?>)',txt,re.I)):
    # v1.0.0.9
    # txt = re.sub(r'(</[a-z0-9:-]+>)([ \.,:;\)\(\.\s*[\]]+)(</?[a-z0-9:-]+(?: [^>]+)?>)',r'\g<1><?x-open?>\g<2><?x-close?>\g<3>',txt,0,re.I);
    # ---
    # v1.0.0.7
    # txt = re.sub(r'[\. ]*<etal/>[\. ]*',r'<etal/>',txt,0,re.I);
    # ---
    txt = re.sub(r'<x(?: [^>]+)?>((?:(?!</?x>).)*)</x>', r'<comment>\g<1></comment>', txt, 0, re.I | re.S)

    # shobana#07-06-2022##
    for m in re.finditer(
            r'<ref(?: [^>]*)?>(?:(?!</ref>).)*<mixed-citation(?: [^>]*)? publication-type="[^"]*"[^>]*?>((?:(?!</mixed-citation>).)*)</mixed-citation>((?:(?!</ref>).)*)</ref>',
            txt, re.I | re.S):
        if (
        re.search(r'<chapter-title(?: [^>]*)?>(?:(?!</chapter-title>).)*</chapter-title>', m.group(1), re.I | re.S)):
            txt = re.sub(r'(<mixed-citation(?: [^>]*)? publication-type=")[^"]*("[^>]*?>)', r'\g<1>book-chapter\g<2>',
                         m.group(), 0, re.I | re.S)
    # shobana#07-06-2022#14-06-2022#

    return txt


def sectionID2(txt, id, lvl1):
    newId = id + '.' + str(lvl1)
    si = re.search(r'<sec2 [^><]*id="([^"]+)"', txt, re.I);
    if (si):
        xref[si.group(1)] = newId;
    txt = re.sub(r'<(sec2)((?: [^>]+)?>(?:(?!</?\1>).)*</\1>)', r'<&del;\g<1> newid="' + str(newId) + r'"\g<2>', txt, 0,
                 re.I | re.S);

    secId3 = itertools.count(1);
    txt = re.sub(r'<sec3(?: [^>]+)?>(?:(?!</?sec3>).)*</sec3>', lambda m: sectionID3(m.group(), newId, next(secId3)),
                 txt, 0, re.I | re.S);

    return (txt)
def sectionID3(txt, id, lvl1):
    newId = id + '.' + str(lvl1)
    si = re.search(r'<sec3 [^><]*id="([^"]+)"', txt, re.I);
    if (si):
        xref[si.group(1)] = newId;
    txt = re.sub(r'<(sec3)((?: [^>]+)?>(?:(?!</?\1>).)*</\1>)', r'<&del;\g<1> newid="' + str(newId) + r'"\g<2>', txt, 0,
                 re.I | re.S);

    secId4 = itertools.count(1);
    txt = re.sub(r'<sec4(?: [^>]+)?>(?:(?!</?sec4>).)*</sec4>', lambda m: sectionID4(m.group(), newId, next(secId4)),
                 txt, 0, re.I | re.S);

    return (txt);

def sectionID4(txt, id, lvl1):
    newId = id + '.' + str(lvl1)
    si = re.search(r'<sec4 [^><]*id="([^"]+)"', txt, re.I);
    if (si):
        xref[si.group(1)] = newId;
    txt = re.sub(r'<(sec4)((?: [^>]+)?>(?:(?!</?\1>).)*</\1>)', r'<&del;\g<1> newid="' + str(newId) + r'"\g<2>', txt, 0,
                 re.I | re.S);

    secId5 = itertools.count(1);
    txt = re.sub(r'<sec5(?: [^>]+)?>(?:(?!</?sec5>).)*</sec5>', lambda m: sectionID5(m.group(), newId, next(secId5)),
                 txt, 0, re.I | re.S);

    return (txt);

def sectionID5(txt, id, lvl1):
    newId = id + '.' + str(lvl1)
    si = re.search(r'<sec5 [^><]*id="([^"]+)"', txt, re.I);
    if (si):
        xref[si.group(1)] = newId;
    txt = re.sub(r'<(sec5)((?: [^>]+)?>(?:(?!</?\1>).)*</\1>)', r'<&del;\g<1> newid="' + str(newId) + r'"\g<2>', txt, 0,
                 re.I | re.S);
    secId6 = itertools.count(1);
    txt = re.sub(r'<sec6(?: [^>]+)?>(?:(?!</?sec6>).)*</sec6>', lambda m: sectionID6(m.group(), newId, next(secId6)),
                 txt, 0, re.I | re.S);

    return (txt);

def sectionID6(txt, id, lvl1):
    newId = id + '.' + str(lvl1)
    si = re.search(r'<sec6 [^><]*id="([^"]+)"', txt, re.I);
    if (si):
        xref[si.group(1)] = newId;
    txt = re.sub(r'<(sec6)((?: [^>]+)?>(?:(?!</?\1>).)*</\1>)', r'<&del;\g<1> newid="' + str(newId) + r'"\g<2>', txt, 0,
                 re.I | re.S);
    secId7 = itertools.count(1);
    txt = re.sub(r'<sec7(?: [^>]+)?>(?:(?!</?sec7>).)*</sec7>', lambda m: sectionID7(m.group(), newId, next(secId7)),
                 txt, 0, re.I | re.S);

    return (txt);

def sectionID7(txt, id, lvl1):
    newId = id + '.' + str(lvl1)
    si = re.search(r'<sec7 [^><]*id="([^"]+)"', txt, re.I);
    if (si):
        xref[si.group(1)] = newId;

    txt = re.sub(r'<(sec7)((?: [^>]+)?>(?:(?!</?\1>).)*</\1>)', r'<&del;\g<1> newid="' + str(newId) + r'"\g<2>', txt, 0,
                 re.I | re.S);
    secId8 = itertools.count(1);
    txt = re.sub(r'<sec8(?: [^>]+)?>(?:(?!</?sec8>).)*</sec8>', lambda m: sectionID8(m.group(), newId, next(secId8)),
                 txt, 0, re.I | re.S);

    return (txt);

def sectionID8(txt, id, lvl1):
    newId = id + '.' + str(lvl1)
    si = re.search(r'<sec8 [^><]*id="([^"]+)"', txt, re.I);
    if (si):
        xref[si.group(1)] = newId;

    txt = re.sub(r'<(sec8)((?: [^>]+)?>(?:(?!</?\1>).)*</\1>)', r'<&del;\g<1> newid="' + str(newId) + r'"\g<2>', txt, 0,
                 re.I | re.S);
    return (txt);



def symbol_to_hex_entity(symbol):
    hex_entity = '&#x{:04x};'.format(ord(symbol))
    return hex_entity

def convert_symbols_to_entities(content):
    converted_content = ""
    for char in content:
        if char.isalpha() or char.isspace():
            converted_content += char
        else:
            converted_content += symbol_to_hex_entity(char)
    return converted_content
