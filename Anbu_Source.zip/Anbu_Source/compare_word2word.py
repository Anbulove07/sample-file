# import sys
#
# import win32com.client as win32
#
# import os
# import platform
#
# word = win32.gencache.EnsureDispatch('Word.Application')  # Start Word application.
# word.Visible = True  # Make it visible.
#
# # Open the two documents.
# doc1 = word.Documents.Open(sys.argv[1])
# doc2 = word.Documents.Open(sys.argv[2])
# doc_path = sys.argv[3]
# # Compare the two documents.
# word.CompareDocuments(doc1, doc2)
#
# # Clean up.
# doc1.Close()
# doc2.Close()
# result = word.ActiveDocument
# result.SaveAs(doc_path)
# result.Close()
#
# # The path to your Word document
#
#
# # Open the document with the default application
# if platform.system() == 'Darwin':       # macOS
#     os.system('open "%s"' % doc_path)
# elif platform.system() == 'Windows':    # Windows
#     os.startfile(doc_path)
# else:                                   # linux variants
#     os.system('xdg-open "%s"' % doc_path)
import sys
import win32com.client as win32
import os
import platform

word = win32.gencache.EnsureDispatch('Word.Application')  # Start Word application.
word.Visible = True  # Make it visible.

# Open the two documents.
doc1 = word.Documents.Open(sys.argv[1])
doc2 = word.Documents.Open(sys.argv[2])
doc_path = sys.argv[3]
html_path = doc_path.replace(".docx", ".html")

# Compare the two documents.
word.CompareDocuments(doc1, doc2)

# Clean up.
doc1.Close()
doc2.Close()

# Save the result as an HTML file.
result = word.ActiveDocument
result.SaveAs(html_path, FileFormat=win32.constants.wdFormatHTML)  # Save as HTML format
result.Close()

# Quit Word application
word.Quit()

# Open the HTML file in the default web browser
if platform.system() == 'Darwin':       # macOS
    os.system('open "%s"' % doc_path)
elif platform.system() == 'Windows':    # Windows
    os.startfile(doc_path)
else:                                   # linux variants
    os.system('xdg-open "%s"' % doc_path)
