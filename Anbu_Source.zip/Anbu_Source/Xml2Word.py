# --------------------------------------------------------------------------
#  Tool Name	: Xml2Word.py
#  Developer	: Sudhakar V
#  Description  : To check hyphen words
#  Client/DU	: Penguin-Random House
#  Syntax		: <EXE> <.XSL_File> <XHTML_Folder_Path>
# --------------------------------------------------------------------------

# ------------ Revision History---------------------------------------------
#  19-12-2022 | v1.0.0.0 | Sudhakar V | Initial Development
# --------------------------------------------------------------------------
import sys
import re
import os
from docx import Document
from iModule.Basic import _open_utf8
import datetime

doc = Document()
ToolVersion = "1.0.0.0"

print(f"\n\n\tXml2Word v{ToolVersion} is Running...")
print("\tCopyright @ Integra Software Services Ltd.\n")

if len(sys.argv) != 2 or not os.path.isfile(sys.argv[1]):
    sys.exit("\n\tSyntax: Xml2Word.exe <XML_File>\n")

xml_cnt = _open_utf8(sys.argv[1])
cnt = "Book and Chapter Keywords and Metadata proof\n"
doc.add_paragraph().add_run(cnt).bold = True
finalstr=''
Input=sys.argv[1]
inputPath=Input.replace('.xml','.docx')

# Get ISBN
if re.search(r'<book-id(?: [^>]*)?book-id-type="hb-isbn"(?: [^>]*)?>(?:(?!</book-id>).)*</book-id>', xml_cnt, re.I|re.S):
    hbisbn1 = re.search(r'<book-id(?: [^>]*)?book-id-type="hb-isbn"(?: [^>]*)?>((?:(?!</book-id>).)*)</book-id>',xml_cnt,re.I|re.S)
    isbn = hbisbn1.group(1)

# doc.add_paragraph(hbisbn, style='List Bullet').add_run("ISBN: ").bold = True
# doc.add_paragraph(hbisbn)

# Get Author Names
author_list = ''
front_matter = re.search(r'<front-matter-part id="[^"]+" book-part-type="title-page">((?:(?!</front-matter-part>).)*)</front-matter-part>',xml_cnt,re.I|re.S)
if front_matter:
    for author in re.finditer(r'<p content-type="title-page-author">((?:(?!</p>).)*)</p>', front_matter.group(1), re.I|re.S):
        author_list += author.group(1) + '/'

# Get Book Title
book_title = re.search(r'<book-title(?: [^>]*)?>((?:(?!</book-title>).)*)</book-title>', xml_cnt, re.I|re.S)
if book_title:
    book_title = book_title.group(1)

# Get current date
current_date = datetime.date.today().strftime('%d/%m/%Y')

# Get Book Keywords
key_str = ''
book_keywords = re.search(r'<kwd-group(?: [^>]*)?>((?:(?!</kwd-group>).)*)</kwd-group', xml_cnt, re.I|re.S)
if book_keywords:
    book_keywords = book_keywords.group(1)
    keywords1 = re.finditer(r'<kwd>((?:(?!</kwd>).)*)</kwd>', book_keywords, re.I | re.S)
    num_keywords = sum(1 for _ in keywords1)  # Count the number of keywords
    keywords = re.finditer(r'<kwd>((?:(?!</kwd>).)*)</kwd>', book_keywords, re.I | re.S)  # Restart the iterator
    for i, key in enumerate(keywords1):
        key_str += key.group(1)
        if i < num_keywords - 1:
            key_str += ', '

# Get Book Abstract
book_abstract = re.search(r'<abstract(?: [^>]*)?>((?:(?!</abstract>).)*)</abstract>', xml_cnt, re.I|re.S)
if book_abstract:
    book_abstract = book_abstract.group(1)
    book_abstract = book_abstract.replace('<p>', '').replace('</p>', '')

finalstr += f'ISBN: {isbn}\n'
finalstr += f'Author: {author_list}\n'
finalstr += f'Title: {book_title}\n'
finalstr += f'Date: {current_date}\n\n'
finalstr += f'Book Keywords: {key_str}\n\n'
finalstr += f'Book abstract: {book_abstract}\n'
finalstr += '_________________________________________________________________________________________________________\n'



# Get Chapter Datails
author_list1 = ''
key_str1 = ''
for chapter in re.finditer(r'<book-part book-part-type="chapter" id="[^"]+">((?:(?!</book-part>).)*)</book-part>', xml_cnt, re.I|re.S):
    chapter_no = re.search(r'<label>((?:(?!</label>).)*)</label>', chapter.group(1), re.I|re.S)
    if chapter_no:
        chapter_no = chapter_no.group(1)
    chapter_title = re.search(r'<title>((?:(?!</title>).)*)</title>', chapter.group(1), re.I|re.S)
    if chapter_title:
        chapter_title = chapter_title.group(1)
    contrib_grp = re.search(r'<contrib-group content-type="contributors"(?: [^>]*)?>((?:(?!</contrib-group>).)*)</contrib-group>', chapter.group(1), re.I|re.S)
    if contrib_grp:
        authors = re.finditer(
            r'<surname>((?:(?!</surname>).)*)</surname><given-names>((?:(?!</given-names>).)*)</given-names>',
            contrib_grp.group(1), re.I | re.S)
        num_authors = sum(1 for _ in authors)  # Count the number of authors

        authors = re.finditer(
            r'<surname>((?:(?!</surname>).)*)</surname><given-names>((?:(?!</given-names>).)*)</given-names>',
            contrib_grp.group(1), re.I | re.S)  # Restart the iterator

        for i, author in enumerate(authors):
            author_list1 += author.group(1) + ' ' + author.group(2)
            if i < num_authors - 1:
                author_list1 += ', '
    chapter_keywords = re.search(r'<kwd-group(?: [^>]*)?>((?:(?!</kwd-group>).)*)</kwd-group', chapter.group(1), re.I|re.S)
    if chapter_keywords:
        chapter_keywords = chapter_keywords.group(1)
        keywords = re.finditer(r'<kwd>((?:(?!</kwd>).)*)</kwd>', chapter_keywords, re.I | re.S)
        num_keywords = sum(1 for _ in keywords)  # Count the number of keywords

        keywords = re.finditer(r'<kwd>((?:(?!</kwd>).)*)</kwd>', chapter_keywords, re.I | re.S)  # Restart the iterator

        for i, key in enumerate(keywords):
            key_str1 += key.group(1)
            if i < num_keywords - 1:
                key_str1 += ', '

    chapter_abstract = re.search(r'<abstract(?: [^>]*)?>((?:(?!</abstract>).)*)</abstract>', chapter.group(1), re.I|re.S)
    if chapter_abstract:
        chapter_abstract = chapter_abstract.group(1)
        chapter_abstract = chapter_abstract.replace('<p>', '').replace('</p>', '')

    finalstr += f"Chapter {chapter_no}:\n\n"
    finalstr += f"Author: {author_list1}\n"
    finalstr += f"Chapter title: {chapter_title}\n\n"
    finalstr += f"Keywords: {key_str1}\n\n"
    finalstr += f"Abstract: {chapter_abstract}\n\n"
    finalstr += '_________________________________________________________________________________________________________\n'



doc.add_paragraph(finalstr)
try:
    doc.save(inputPath)
except:
    sys.exit("Error: Unable to save the document. Please make sure the document is not open and try again.")










# exit()
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT

# Load the original document
original_doc = Document(inputPath)

# Create a new document to store the modified content
modified_doc = Document()

# Define the words to search and the desired style
search_words = ["ISBN:", "Author:", "Title:", "Date:", "Book ", "Book abstract:", "Chapter:", "Author:",
                "Chapter title:", "Abstract:"]
chap=["Chapter 1:","Chapter 2:", "Chapter 3:", "Chapter 4:","Chapter 5:","Chapter 6:", "Chapter 7:", "Chapter 8:", "Chapter 9:", "Chapter 10:", "Chapter 11:", "Chapter 12:", "Chapter 13:", "Chapter 14:", "Chapter 15:", "Chapter 16:", "Chapter 17:", "Chapter 18:", "Chapter 19:", "Chapter 20:", "Chapter 21:", "Chapter 22:", "Chapter 23:", "Chapter 24:", "Chapter 25:", "Chapter 26:", "Chapter 27:", "Chapter 28:", "Chapter 29:", "Chapter 30:", "Chapter 31:", "Chapter 32:", "Chapter 33:", "Chapter 34:", "Chapter 35:", "Chapter 36:", "Chapter 37:", "Chapter 38:", "Chapter 39:", "Chapter 40:", "Chapter 41:", "Chapter 42:", "Chapter 43:", "Chapter 44:", "Chapter 45:", "Chapter 46:", "Chapter 47:", "Chapter 48:", "Chapter 49:", "Chapter 50:", "Chapter 51:", "Chapter 52:", "Chapter 53:", "Chapter 54:", "Chapter 55:", "Chapter 56:", "Chapter 57:", "Chapter 58:", "Chapter 59:", "Chapter 60:", "Chapter 61:", "Chapter 62:", "Chapter 63:", "Chapter 64:", "Chapter 65:", "Chapter 66:", "Chapter 67:", "Chapter 68:", "Chapter 69:", "Chapter 70:", "Chapter 71:", "Chapter 72:", "Chapter 73:", "Chapter 74:", "Chapter 75:", "Chapter 76:", "Chapter 77:", "Chapter 78:", "Chapter 79:", "Chapter 80:", "Chapter 81:", "Chapter 82:", "Chapter 83:", "Chapter 84:", "Chapter 85:", "Chapter 86:", "Chapter 87:", "Chapter 88:", "Chapter 89:", "Chapter 90:", "Chapter 91:", "Chapter 92:", "Chapter 93:", "Chapter 94:", "Chapter 95:", "Chapter 96:", "Chapter 97:", "Chapter 98:", "Chapter 99:", "Chapter 100:"]


# Iterate through all paragraphs in the original document
for paragraph in original_doc.paragraphs:
    for chaplist in chap:
        if chaplist in paragraph.text:
            paragraph.style = "Heading 1"
            if chaplist in paragraph.text:
                # Split the text at "chapter title:" and join with a new line
                new_text = "\nChapter title:".join(paragraph.text.split("Chapter title:"))
                paragraph.text = new_text

    # Create a new paragraph in the modified document
    modified_paragraph = modified_doc.add_paragraph()

    # Check if the paragraph starts with "Author" or "Keywords"
    # if paragraph.text.startswith("Author:") or paragraph.text.startswith("Keywords:"):
        # Add bullet point to the modified paragraph
        # modified_paragraph.style = "List Bullet"

    # Check if the paragraph starts with "Chapter"
    if paragraph.text.startswith("Chapter"):
        # Split the paragraph into words
        words = paragraph.text.split()

        # Iterate through each word in the paragraph
        for i, word in enumerate(words):
            # Check if the word is the chapter number
            if i == 1 and word.isdigit():
                # Create a run for the chapter number
                run = modified_paragraph.add_run()
                run.text = word
                run.bold = True
                run.font.size = Pt(11)
            else:
                # Create a run for the other words
                modified_paragraph.add_run(" " + word)
    else:
        # Iterate through each word in the paragraph
        count = 0
        for word in paragraph.text.split():

            # Check if the word matches any word from the search_words list
            for search_word in search_words:

                if search_word in word:
                    if search_word == "Author:" or search_word == "Chapter":
                        # Add bullet point to the modified paragraph
                        count=count+1
                        if count>1:
                            # modified_paragraph.paragraph_format.left_indent = Pt(15)
                            modified_paragraph.add_run("\n\t")
                            modified_paragraph.add_run(u"\u2022").bold = True
                            modified_paragraph.add_run("  ")
                            # modified_paragraph.style = "List Bullet"
                            run = modified_paragraph.add_run()
                            run.text = word.replace(search_word, f"{search_word}")
                            # run.bold = True
                            # run.font.size = Pt(12)


                            break  # Exit the loop once a match is found


                    # Create a run for the modified word
                    run = modified_paragraph.add_run()
                    run.text = word.replace(search_word, f"\n{search_word}")
                    run.bold = True
                    run.font.size = Pt(11)
                    break  # Exit the loop once a match is found
            else:
                # If no match is found, add the word as is to the modified paragraph
                modified_paragraph.add_run(" " + word)






# Save the modified document
modified_doc.save(inputPath)


sys.exit("Xml2Docx executed successfully")
# except:
#     sys.exit("File is open. Please close the file and run again")
