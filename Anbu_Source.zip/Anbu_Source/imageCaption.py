import docx


def extract_image_captions(docx_path):
    doc = docx.Document(docx_path)
    captions = []

    for paragraph in doc.paragraphs:
        # if paragraph.style.name.startswith('Normal'):
        #     captions.append(paragraph.text)
        if paragraph.text.startswith("Fig.") or paragraph.text.startswith("Figure"):
            captions.append(paragraph.text)

    return captions


if __name__ == "__main__":
    document_path = r"D:\Giventool\karthik\IOPP\IOPP\Input\TRAN_114304\Source\2DMacec58\2DMacec58.docx"  # Replace with the path to your Word document
    figCaptions = extract_image_captions(document_path)

    # for index, caption in enumerate(captions, start=1):
    #     print(f"Image {index} Caption: {caption}")
    print(len(figCaptions))
