#------------------------------------------------------------------
#  Tool Name    : IOPP_word2xml.py
#  Developer    : Shobana B | CTAE XML
#  Description  : create word to xml creation
#  Client/DU    : IOPP
#  Syntax		: <Exe> <Word file>
#------------------------------------------------------------------

#------------ Rivision History  -----------------------------------
#  09-01-2023 | v1.0 | Shobana B | Initial Development | req by Kannika
#  10-01-2023 | v1.0 | Shobana B | Initial Development | req by Kannika
#------------------------------------------------------------------

version = "1.0.0.0"

import os
import sys
import re
from os.path import basename,dirname;
from iModule.Basic import _open_file,_open_utf8,_save_utf8,_save_file,_get_file_list,_make_path
from iModule.ToolTracking import *
import pandas as pd
from datetime import datetime,date
import docx2txt
from datetime import datetime,date
import docx
from docx2python import docx2python
import itertools  # for id sequence
import shutil
from docx.api import Document
Toolpath = dirname(sys.argv[0])
Toolpath = re.sub(r'\/',r'\\',Toolpath,0)

os.system("cls")

# Inline argument checking & File path checking
if (len(sys.argv) != 2 or not os.path.isfile(sys.argv[1])) or not sys.argv[1].endswith('.docx'): sys.exit("\n\tSyntax: <Exe> <Word file(.docx)>\n")

print ("\n\n\tIOPP_word2xml v"+version+" is Running...\n\n")


#------------ Tracking --------------------------------------------
# Tra_input = sys.argv[1];
# tool_id = 505; #TandF_xml2API Tool
# run_size = 0;
# st_time = _get_timestamp();
#------------------------------------------------------------------


# Global variable declaration
Word_file = sys.argv[1]
dir_name =dirname(Word_file)
base_name =basename(Word_file)

word_file_nam=base_name

word_file_nam=re.sub(r'.docx',r'.txt',word_file_nam,0,re.I|re.S)

word_file_xml=re.sub(r'.txt',r'.xml',word_file_nam,0,re.I|re.S)

# aff_list=[]

# # open connection to Word Document
# doc = docx.Document(Word_file)
# # read in each paragraph in file
# result = [p.text for p in doc.paragraphs]
# doc_result = docx2python(Word_file)
#
# title=doc_result.body[1][0][1]
# # print(doc_result.body[1][4][1])
#
# list_doc=doc_result.body
# for i in list_doc:
#     print(i)
#     # for j in i:
#     #     for k in j:
#     #         print(k)
#     #         emp=str(k[0])
#     #         aff_list.append(emp)
#
# exit()
# list_aff=[]
# orcid_list=[]
#
# dict={}
# odd=[]
# even=[]
# # del aff_list[1:26]
# for m in range(26,int(len(aff_list))):
#     orcid = aff_list[m]
#     if re.search(r'\d{4}\-\d{4}\-(\d{4}|\d{3}x)', orcid, re.I | re.S):
#         orcid_list.append(orcid)
#
#     if not re.search(r'\d{4}\-\d{4}\-(\d{4}|\d{3}x)', orcid, re.I | re.S):
#         value=aff_list[m]
#         list_aff.append(value)
#
#
# result = []; result1=[]
# for n in range(len(list_aff)):
#     if(list_aff[n]):
#         if n % 2 == 0:
#             result.append(list_aff[n])
#         else:
#             result1.append(list_aff[n])



###read in word file
word_cnt = docx2txt.process(Word_file)
word_cnt=re.sub(r'\t+',r'',word_cnt,0,re.I|re.S)
word_cnt=re.sub(r'\s{2,}',r' ',word_cnt,0,re.I|re.S)
word_cnt=re.sub(r'\n+',r'\n',word_cnt,0,re.I|re.S)

# word_cnt=re.sub(r'\n+',r'\n',word_cnt,0,re.I|re.S)

###save word to text file
_save_utf8(dir_name+"//"+word_file_nam,word_cnt)

###xml saving file
word_xml='''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE article PUBLIC "-//NLM//DTD Journal Publishing DTD v3.0 20080202//EN" "journalpublishing3.dtd">
<article xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:mml="http://www.w3.org/1998/Math/MathML" article-type="note">
<front>
<journal-meta>
<journal-id journal-id-type="publisher-id">met</journal-id>
<journal-id journal-id-type="coden">MTRGAU</journal-id>
<journal-title-group>
<journal-title>Metrologia</journal-title>
<abbrev-journal-title abbrev-type="IOP">MET</abbrev-journal-title>
<abbrev-journal-title abbrev-type="publisher">Metrologia</abbrev-journal-title>
</journal-title-group>
<issn pub-type="ppub">0026-1394</issn>
<issn pub-type="epub">1681-7575</issn>
<publisher>
<publisher-name>IOP Publishing</publisher-name></publisher>
</journal-meta>
<article-meta>
<article-id pub-id-type="publisher-id"></article-id>
<article-id pub-id-type="doi"></article-id>
<article-id pub-id-type="manuscript"></article-id>
<article-categories>
<subj-group subj-group-type="article-type">
<subject></subject>
</subj-group>
</article-categories>
<title-group>
<article-title></article-title>
<alt-title alt-title-type="ascii"></alt-title>
</title-group>
<contrib-group content-type="all">
<author-comment content-type="short-author-list"></author-comment>
</contrib-group>
<pub-date pub-type="epub"><day></day><month></month><year></year></pub-date>
<volume></volume>
<issue>1A</issue>
<elocation-id content-type="artnum"></elocation-id>
<permissions>
<copyright-statement>&copy; 2023 BIPM &amp; IOP Publishing Ltd</copyright-statement>
<copyright-year>2023</copyright-year>
</permissions>
<abstract>
<title>Main text</title>
</abstract>
</article-meta>
</front>
<body/>
<back/>
</article>
'''


word_txt=_open_file(dir_name+"//"+word_file_nam)


if re.search(r'Title of REPORT((?:(?!Contact Person).)*)Contact Person',word_txt,re.I|re.S):
    title=re.search(r'Title of REPORT((?:(?!Contact Person).)*)Contact Person',word_txt,re.I|re.S)
    word_xml=re.sub(r'(<article-title>)(</article-title>)',r'\g<1>'+title.group(1)+r'\g<2>',word_xml,0,re.I|re.S)
    word_xml=re.sub(r'(<alt-title alt-title-type="ascii">)(</alt-title>)',r'\g<1>'+title.group(1)+r'\g<2>',word_xml,0,re.I|re.S)


today = date.today()
date_split=re.split('-',str(today))

cur_dt=today.strftime('%d')
cur_mon=today.strftime('%m')
cur_yr=today.strftime('%Y')


if re.search(r'Title of REPORT((?:(?!Contact Person).)*)Contact Person',word_txt,re.I|re.S):
    word_xml=re.sub(r'(<pub-date pub-type="epub"><day>)(</day><month>)(</month><year>)(</year></pub-date>)',r'\g<1>'+str(cur_dt)+r'\g<2>'+str(cur_mon)+r'\g<3>'+str(cur_yr)+r'\g<4>',word_xml,0,re.I|re.S)

if re.search(r'COMPARISON TYPE((?:(?!COMPARISON identifier).)*)COMPARISON identifier',word_txt,re.I|re.S):
    compare = re.search(r'COMPARISON TYPE((?:(?!COMPARISON identifier).)*)COMPARISON identifier',word_txt,re.I|re.S)
    word_xml=re.sub(r'(<subject>)(</subject>)',r'\g<1>'+compare.group(1)+r'\g<2>',word_xml,0,re.I|re.S)


abs_std_txt='''<p>To reach the main text of this paper, click on <ext-link xlink:href="">Final Report</ext-link>. Note that this text is that which appears in Appendix B of the BIPM key comparison database <ext-link xlink:href="http://kcdb.bipm.org/">kcdb.bipm.org/</ext-link>.</p>
<p>The final report has been peer-reviewed and approved for publication by the CCRI, according to the provisions of the CIPM Mutual Recognition Arrangement (CIPM MRA).</p>'''

if re.search(r'ABSTRACT((?:(?!KEY WORDS FOR SEARCH).)*)KEY WORDS FOR SEARCH',word_txt,re.I|re.S):
    abst = re.search(r'ABSTRACT((?:(?!KEY WORDS FOR SEARCH).)*)KEY WORDS FOR SEARCH',word_txt,re.I|re.S)
    word_xml=re.sub(r'(</abstract>)',r'<p>'+abst.group(1)+r'</p>\n'+abs_std_txt+r'\n\g<1>',word_xml,0,re.I|re.S)

if re.search(r'final report URL((?:(?!ABSTRACT).)*)ABSTRACT',word_txt,re.I|re.S):
    rep = re.search(r'final report URL((?:(?!ABSTRACT).)*)ABSTRACT',word_txt,re.I|re.S)
    word_xml=re.sub(r'(<ext-link xlink:href=")(">Final Report</ext-link>)',r'\g<1>'+rep.group(1)+r'\g<2>',word_xml,0,re.I|re.S)

remov_ext=re.sub(r'.docx',r'',base_name,0,re.I|re.S)
remov_met=re.sub(r'^met_',r'',remov_ext,0,re.I|re.S)
remov_met=re.sub(r'\_',r'/',remov_met,0,re.I|re.S)

word_xml=re.sub(r'(<article-id pub-id-type="publisher-id">)(</article-id>)',r'\g<1>'+str(remov_ext)+'\g<2>',word_xml,0,re.I|re.S)
word_xml=re.sub(r'(<article-id pub-id-type="manuscript">)(</article-id>)',r'\g<1>'+str(remov_ext)+'\g<2>',word_xml,0,re.I|re.S)
word_xml=re.sub(r'(<article-id pub-id-type="doi">)(</article-id>)',r'\g<1>10.1088/0026-1394/'+str(remov_met)+'\g<2>',word_xml,0,re.I|re.S)


idseq = itertools.count(1);

# word_xml=re.sub(r'<aff id=""><label>1</label></aff>',r'<aff id="'+str(remov_ext)+r'_af1"><label>1</label>Institute of Nuclear Energy Research, Longtan, Taiwan</aff>',word_xml,0,re.I|re.S)
# word_xml=re.sub(r'(<xref ref-type="aff" rid=")(">)(</xref>)',r'\g<1>'+str(remov_ext)+r'_af1\g<2>1\g<3>',word_xml,0,re.I|re.S)

get_met_vol=re.sub(r'^met_(\d+)_\w+_\w+',r'\g<1>',remov_ext,0,re.I|re.S)
get_met_iss=re.sub(r'^met_\d+_(\w+)_\w+',r'\g<1>',remov_ext,0,re.I|re.S)
get_met_eloc=re.sub(r'^met_\d+_\w+_(\w+)',r'\g<1>',remov_ext,0,re.I|re.S)

word_xml=re.sub(r'(<volume>)(</volume>)',r'\g<1>'+str(get_met_vol)+'\g<2>',word_xml,0,re.I|re.S)
word_xml=re.sub(r'(<issue>)1A(</issue>)',r'\g<1>'+str(get_met_iss)+'\g<2>',word_xml,0,re.I|re.S)
word_xml=re.sub(r'(<elocation-id content-type="artnum">)(</elocation-id>)',r'\g<1>'+str(get_met_eloc)+'\g<2>',word_xml,0,re.I|re.S)

# word_xml=re.sub(r'<subject>\s+',r'<subject>',word_xml,0,re.I|re.S)
# word_xml=re.sub(r'\s+</subject>',r'</subject>',word_xml,0,re.I|re.S)
# word_xml=re.sub(r'<article-title>\s+',r'<article-title>',word_xml,0,re.I|re.S)
# word_xml=re.sub(r'\s+</article-title>',r'</article-title>',word_xml,0,re.I|re.S)
# word_xml=re.sub(r'(<alt-title(?: [^>]*)?>)\s+',r'\g<1>',word_xml,0,re.I|re.S)
# word_xml=re.sub(r'\s+</alt-title>',r'</alt-title>',word_xml,0,re.I|re.S)


# word_xml=re.sub(r'\n+',r'\n',word_xml,0,re.I|re.S)

# anbu

document = Document(Word_file)
table = document.tables[2]
data = []
keys = None
for i, row in enumerate(table.rows):
    text = (cell.text for cell in row.cells)

    if i == 0:
        keys = tuple(text)
        continue
    row_data = dict(zip(keys, text))
    data.append(row_data)

cont1=1
mkstr=''
aff = ''
link=''
for x in data:

    if len(x.items())==3:
        cont=0
        srname=''
        gname=''
        xref=''

        for key, value in x.items():
            # print(value)
            if cont==0:
                if re.search(r'\s([a-z-0-9\.\,\:\;\–]+)$',value,re.I|re.S):
                    val=re.search(r'\s([a-z-0-9\.\,\:\;\–]+)$',value,re.I|re.S)
                    srname="<surname>"+str(val.group(1))+"</surname>"
                    cont=cont+1
                    val1 = re.sub(r'\s([a-z-0-9\.\,\:\;\–]+)$', r'', value, 0, re.I | re.S)
                    gname = "<given-names>" + str(val1) + "</given-names>"

            elif cont==1:
                aff=aff+"\n<aff id=\""+str(remov_ext)+"_af"+str(cont1)+"\"><label>"+str(cont1)+"</label> "+str(value)+"</aff>"
                cont = cont + 1
            elif cont==2:
                link = '<ext-link ext-link-type="orcid">'+str(value)+'</ext-link>'

        xref='\n<xref ref-type="aff" rid="'+str(remov_ext)+'_af'+str(cont1)+'">'+str(cont1)+'</xref>'
        cont1=cont1+1



        if srname!='' and gname!='' and  xref != '':
            mkstr=mkstr+'\n<contrib contrib-type="author">\n<name>'+str(srname)+''+str(gname)+'</name>'+str(link)+str(xref)+'\n</contrib>'
        # elif not srname=='' and gname=='':
        #     mkstr = '<contrib contrib-type="author">\n<name>\n' + str(srname) + '\n' + str(gname) + '</name>\n' + str(xref) + '\n</contrib>'


authorname=''
for x in data:
    for key, value in x.items():
        authorname=authorname+"--"+value
        break

if cont1>1:
    val3='<author-comment content-type="short-author-list"><p>'+str(authorname.split('--')[1])+'<italic>et al</italic></p></author-comment>'
else:
    val3 = '<author-comment content-type="short-author-list"><p>' + str(authorname.split('--')[1]) + '</p></author-comment>'

word_xml=word_xml.replace(r'<contrib-group content-type="all">','<contrib-group content-type="all">'+mkstr+aff)
word_xml=word_xml.replace(r'<author-comment content-type="short-author-list"></author-comment>',val3)

word_xml=re.sub(r'<ext-link ext-link-type="orcid">\s*</ext-link>',r'',word_xml,0,re.I|re.S)


_save_utf8(dir_name+"//"+word_file_xml,word_xml)

if not os.path.isdir(dir_name+"\\"+remov_ext):
    _make_path(dir_name+"\\"+remov_ext)

_save_utf8(dir_name+"//"+remov_ext+"//"+word_file_xml,word_xml)
shutil.make_archive(dir_name+"//"+remov_ext, "zip", dir_name+"//"+remov_ext)
shutil.rmtree(dir_name+"//"+remov_ext)


#------ Local tracking -------------
# _local_tracking(tool_id,ToolVersion,Tra_input,_get_file_size(Tra_input),st_time, _get_timestamp());
#-----------------------------------

print("Word2XML converted successfully...!")
sys.exit(0)