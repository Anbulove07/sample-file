import os
import sys
from os.path import basename, dirname
import docx
import re
from docx import Document
from lxml import etree
from docx.shared import Pt
from docx.oxml import OxmlElement
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from iModule.Basic import _save_file

Toolpath = dirname(sys.argv[0])
Toolpath = re.sub(r'\/', r'\\', Toolpath, 0)

os.system("cls")

version = '1.0.0.0'

if len(sys.argv) != 3:
    sys.exit("\n\tSyntax: <Exe> <input word> <output word> \n")

print("\n\n\t Index id  v" + version + " is Running...\n\n")


def save_file(file_path, content):
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(content)


source_doc_path = sys.argv[1]
log = dirname(source_doc_path)
output_doc_path = sys.argv[2]

source_doc = Document(source_doc_path)
output_doc = Document(output_doc_path)

index_contents = []
index_id = {}

index_pattern = r'<w:pStyle w:val="Index\d+"\/>'

total_id = ""

for paragraph in source_doc.paragraphs:
    xml = paragraph._p.xml

    if not any(run.font.hidden for run in paragraph.runs):
        for m in re.finditer(r'<w:p(?: [^>]*)>(?:(?!</w:p>).)*</w:p>', xml, re.I | re.S):
            para = m.group()
            if re.search(index_pattern, para, re.I):
                output_paragraph = output_doc.add_paragraph()
                index_contents.append(para)
            else:
                for id in re.finditer(r'((?:\w+)?(?:\W+)?(?:\w+)(?:\W+)?\s*)(<(?:i|is|ie|ist|it|isn|ien|ief|iet|ip|isf|ii|isi|iei|iep|in|if|it),[0-9.]+>)(\s*(?:\W+)?(?:\w+)(?:\W+)?(?:\w+)?)',paragraph.text, re.I | re.S):
                    index_id[id.group(2)]=id.group(1)+'#dell#'+id.group(3)
                for cnt_id in re.finditer(r'(<(?:i|is|ie|ist|it|isn|ien|ief|iet|ip|isf|ii|isi|iei|iep|in|if|it),\d+\.\d+>(?:\,?|\s+?|\.|-?)?)+',paragraph.text, re.I | re.S):
                    total_id += cnt_id.group() + '\n'

if total_id!='':
    save_file(log + "\\Total_id.txt", total_id)

inserted_keys = set()
for paragraph_out in output_doc.paragraphs:
    if not any(run.font.hidden for run in paragraph_out.runs):
        updated_paragraph_text = paragraph_out.text
        for key, value in index_id.items():
            key1 = key
            key1 = key1.replace(r'>, ', r'>')
            val = value.split('#dell#')
            value1 = value
            value1 = value1.replace(r'#dell#', r' ')
            if value1 in paragraph_out.text and key1 not in inserted_keys:
                # updated_paragraph_text = re.sub(r'\b(' + val[0]+'(?:\,|.|:|;|-)?)((\s*)?'+val[1] + r')\b', r'\g<1>'+ key1+r'\g<2>',updated_paragraph_text, 1, re.I)
                try:
                    print(key1)
                    if val[0] != '' and val[1] != '':
                        updated_paragraph_text = re.sub(r'\b(' + val[0]+'(?:\,|.|:|;|-)?)((\s*)?'+val[1] + r')\b', r'\g<1>'+ key1+r'\g<2>', updated_paragraph_text,1,re.I|re.S)
                except:
                    pass
                inserted_keys.add(key1)
        output_doc.add_paragraph(updated_paragraph_text, style=paragraph_out.style)

# for key, value in index_id.items():
#     key1 = key.replace(r'>, ',r'>')
#     if key1 in inserted_keys:
#         continue
#     inserted_keys.add(key1)
#     val = value.split('#dell#')
#     value1 = value.replace(r'#dell#',r' ')
#     for paragraph in output_doc.paragraphs:
#         try:
#             print(key1)
#             if val[0] != '' and val[1] != '':
#                 paragraph.text = re.sub(r'\b(' + val[0]+'(?:\,|.|:|;|-)?)((\s*)?'+val[1] + r')\b', r'\g<1>'+ key1+r'\g<2>', paragraph.text,1,re.I|re.S)
#         except:
#             pass
#     output_doc.add_paragraph(updated_paragraph_text, style=paragraph_out.style)

# Index Content
for index_content in index_contents:
    if index_content.strip():
        output_doc._body._body.append(etree.fromstring(index_content))
# index content#

output_doc.save(output_doc_path)

print("Index id inserted successfully..!")
