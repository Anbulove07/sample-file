import docx

def get_reference_content(doc, reference_heading):
    reference_found = False
    reference_content = []

    for paragraph in doc.paragraphs:
        if reference_found:
            reference_content.append(paragraph.text)
        if paragraph.text.strip() == reference_heading:
            reference_found = True

    return reference_content

def reference_count():
    document_path = r"D:\Giventool\karthik\IOPP\IOPP\Input\TRAN_114304\Source\2DMacec58\2DMacec58.docx"  # Replace with the actual path
    reference_heading = "References"  # Replace with the actual reference heading

    doc = docx.Document(document_path)
    reference_content = get_reference_content(doc, reference_heading)

    if reference_content:
        reference_lines = "\n".join(reference_content).split("\n")
        line_count = len(reference_lines)

        print("Reference content:")
        for line in reference_lines:
            print(line)

        print("\nTotal lines in reference content:", line_count)
    else:
        print("Reference heading not found in the document.")

if __name__ == "__main__":
    reference_count()
