###################################################################
# 																  #
#  Project Name : WordCount_v1_2.py  	    					  #
#  Version      : 1.0.0.0                                         #
#  Developed    : ANBU .G |                                       #
#  Purpose		:  Conversion for Journel             			  #
#  Syntax 		:  <EXE>                     					  #
#                                                                 #
###################################################################


###################################################################
#
# Run  		  : Double click on <Exe>
# Note		  : -
# Description : Create Excel log report based on input folder contains PDF, Docx, file
###################################################################


###################################################################
# Updation History
#=================================================================
#	20-07-2022 | v1.0.0.0 | ANBU .G	Initial Development
#	08-08-2022 | v1.0.0.0 | ANBU .G	Update request by Thangam
#	09-11-2022 | v1.0.0.0 | ANBU .G	UI Update request by Thangam
#	23-11-2022 | v1.0.0.0 | ANBU .G	Improve Bug clear and imrpove efficiency Count Update request by Thangam
#	02-01-2023 | v1.0.0.0 | ANBU .G	Imrpovement points update request by Thangam
###################################################################



from iModule.ToolTracking import _get_timestamp, _local_tracking, _get_file_size

from docx_utils.flatten import opc_to_flat_opc

import re
import os
import sys
import docx2txt
from docx2pdf import convert
import xlsxwriter

from io import StringIO

from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfdocument import PDFDocument
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.pdfpage import PDFPage
from pdfminer.pdfparser import PDFParser
from pdfminer.pdfinterp import resolve1

import PySimpleGUI as sg

ToolVersion = "1.0.0.0";

print("\n\n\tWord_Count_Tool v" + ToolVersion + " is Running...");
print("\tCopyright @ Integra Software Services Ltd.\n");

sg.theme('Default1')  # please make your windows colorful

layout = [[sg.Text("Word_Count_Tool v" + ToolVersion + " is Running...")],
      [sg.Text('Source for Folders', size=(15, 1)), sg.InputText(), sg.FolderBrowse()],
      [sg.Submit(), sg.Cancel()]]

window = sg.Window('Word_Count_Tool', layout)

event, values = window.read()
window.close()
folder_path= values[0]    # get the data from the values dictionary
# print(folder_path)

# exit()
# ------------ Tracking --------------------------------------------
Tra_input = folder_path;
tool_id = 472;  # Word Count
run_size = 0;
st_time = _get_timestamp();
# ------------------------------------------------------------------
if not (os.path.isdir(folder_path)):
    print("Please Enter PDF/Docx file location")
    sys.exit()
_filedirname = folder_path
# try :
#     _filedirname = folder_path
#
# except :
#     # src = r'D:\Anbu\XML\pdftest.pdf'
#     print("Please Enter PDF/Docx file location")
#     sys.exit()
arr_sheet=[]

# Get list of pdf and docx file in inpurt directory
_filename1 = [x for x in os.listdir(_filedirname) if x.endswith((".docx",".Docx",".pdf",".Pdf",".PDF",".txt"))]
_dirname=_filedirname

apppath = os.path.dirname(sys.argv[0]);
apppath = re.sub(r'\/', r'\\', apppath, 0)

pdfcount=0
wordcount=0
txtcount=0


tot_byte_in_docx=0
tot_byte_in_pdf=0
tot_byte_in_excel=0
tot_byte_in_txt=0

tot_word_in_docx=0
tot_word_in_pdf=0
tot_word_in_excel=0
tot_word_in_txt=0

tot_page_count_pdf=0
tot_page_count_docx=0
tot_page_count_txt=0


reffilename=[]
for _filename in _filename1:
    try:
        reffilename.append(_filename)
        # _dirname = os.path.dirname(_filename)
        print("File Processing : "+_filename)
        Filename=(os.path.basename(_filename)).split('.')
        FilenameFormat=Filename[len(Filename)-1]
        processFunction=''
        filesize= os.path.getsize(_dirname+r'\\'+_filename)
        if(FilenameFormat=='pdf'):
            # print("PDF File ")
            processFunction="Format_1"
            pdfcount=pdfcount+1
        elif FilenameFormat=='docx':
            # print("Docx File")
            processFunction = "Format_2"
            wordcount=wordcount+1
        elif FilenameFormat=='txt':
            # print("Docx File")
            processFunction = "Format_3"
            txtcount=txtcount+1
        # exit()
        _endnoteStr = ""
        _footnoteStr = ""
        pdfPagecount=''
        xe_word_count = 0
        Endnotelength=''
        Footnotelength=''
        count_footnote = 0
        num_words_foot = 0
        count_endnote = 0
        num_words_end = 0
        words=''
        wordstxt=''
        if processFunction=="Format_1":
            filenamepdf = _dirname + r'\\' + _filename
            output_string = StringIO()
            with open(filenamepdf, 'rb') as in_file:
                parser = PDFParser(in_file)
                doc = PDFDocument(parser)
                pdfPagecount=resolve1(doc.catalog['Pages'])['Count']
                rsrcmgr = PDFResourceManager()
                device = TextConverter(rsrcmgr, output_string, laparams=LAParams())
                interpreter = PDFPageInterpreter(rsrcmgr, device)
                for page in PDFPage.create_pages(doc):
                    interpreter.process_page(page)

            myString = output_string.getvalue()
            words1 = myString.split()
            r = re.compile(r'[\w,.:;\'\"\(\[\]\-\“\‘]{2,}|[Ai]',re.I)
            words = list(filter(r.match, words1))

        if processFunction=="Format_2":
            # Passing docx file to process function
            filenamedocx=_dirname + r'\\' + _filename
            text = docx2txt.process(filenamedocx)
            outtextpath = apppath + r"\text.txt"
            opc_to_flat_opc(filenamedocx, apppath+r'\test.xml')
            file = open( apppath+r'\test.xml', "rt",encoding='utf8')
            xml_data = file.read()
            # convert(filenamedocx)
            convert(filenamedocx, _dirname + r'\\output.pdf')
            # convert(_dirname)
            filenamepdf =_dirname + r'\\output.pdf'
            output_string = StringIO()
            with open(filenamepdf, 'rb') as in_file:
                parser = PDFParser(in_file)
                doc = PDFDocument(parser)
                pdfPagecount = resolve1(doc.catalog['Pages'])['Count']
            os.remove(_dirname + r'\\output.pdf')

            for findendnotetag in re.finditer(r'<w:endnote(?: [^>]*)?>((?:(?!</w:endnote>).)*)</w:endnote>',xml_data, re.I | re.S):
                for val in re.finditer(r'<w:t(?: [^>]*)?>((?:(?!</w:t>).)*)</w:t>',findendnotetag.group(1),re.I|re.S):
                    if re.search(r'[a-z0-9]+',val.group(1),re.I|re.S):
                        # print(val.group())
                        num_words_split = (val.group(1)).split()
                        num_words_end=num_words_end+len(num_words_split)


            # for findfootnotetag in re.finditer(r'(?<=<w:footnote w:id=\")(\d+)(?=\">)(?:(?!<w:t>).)*<w:t>((?:(?!<\/w:t>).)*)<\/w:t>', xml_data, re.I | re.S):
            for findendnotetag in re.finditer(r'<w:footnote(?: [^>]*)?>((?:(?!</w:footnote>).)*)</w:footnote>',xml_data, re.I | re.S):
                for val in re.finditer(r'<w:t(?: [^>]*)?>((?:(?!</w:t>).)*)</w:t>', findendnotetag.group(1),re.I | re.S):
                    if re.search(r'[a-z0-9]+', val.group(1), re.I | re.S):
                        # print(val.group())
                        num_words_split=(val.group(1)).split()
                        num_words_foot = num_words_foot + len(num_words_split)

            for findendnotetag in re.finditer(r'<w:instrText>((?:(?!</w:instrText>).)*)</w:instrText>',xml_data, re.I | re.S):
                for val in re.finditer(r'(\w+)',findendnotetag.group(1), re.I | re.S):
                    xe_word_count=xe_word_count+1
            # Saving content inside docx file into output.txt file
            with open(outtextpath, "w",encoding='utf8') as text_file:
                # print(text, file=text_file)
                print(text, file=text_file)

            file = open(outtextpath, "rt",encoding='utf8')
            data = file.read()
            words = data.split()
            file.close()

        if processFunction == "Format_2":
            _endnoteStr1=_endnoteStr.split(',')
            Endnotelength = (sys.getsizeof(_endnoteStr))-49
            # Footnotelength = len(_footnoteStr.encode('utf-8'))
            _footnoteStr1 = _footnoteStr.split(',')
            Footnotelength = (sys.getsizeof(_footnoteStr))-49

        if processFunction == "Format_3":
            file = open(_dirname + r'\\' + _filename, "rt", encoding='utf8')
            data = file.read()
            words = data.split()
            file.close()
            pdfPagecount=1

        # Sheet_update=''
        arr=[]

        Sheet_update=_filename
        arr.append(Sheet_update)
        if processFunction == "Format_2":
            Sheet_update=Endnotelength
            arr.append(Sheet_update)
        else:
            Sheet_update = 0
            arr.append(Sheet_update)
        if processFunction == "Format_2":
            Sheet_update=Footnotelength
            arr.append(Sheet_update)
        else:
            Sheet_update = 0
            arr.append(Sheet_update)
        megabytes=filesize / 1024
        format_float = "{:.0f}".format(megabytes)
        Sheet_update=format_float
        arr.append(Sheet_update)
        if processFunction == "Format_2":
            Sheet_update=num_words_foot
            arr.append(Sheet_update)
        else:
            Sheet_update = 0
            arr.append(Sheet_update)
        if processFunction == "Format_2":
            Sheet_update=num_words_end
            arr.append(Sheet_update)
        else:
            Sheet_update = 0
            arr.append(Sheet_update)
        Sheet_update=len(words)
        arr.append(Sheet_update)
        Sheet_update=pdfPagecount
        arr.append(Sheet_update)

        if processFunction == "Format_2":
            Sheet_update=xe_word_count
            arr.append(Sheet_update)
        else:
            Sheet_update = 0
            arr.append(Sheet_update)

        arr_sheet.append(arr)
        # print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    except:
        pass


try:
    # _dirname = os.path.dirname(_filename)
    workbook = xlsxwriter.Workbook(_dirname+'_Log_Report.xlsx')
    # The workbook object is then used to add new
    # worksheet via the add_worksheet() method.
    merge_format = workbook.add_format({'bold': 1,'border': 1,'align': 'center','valign': 'vcenter','fg_color': '#c7ffc7'})
    merge_format6 = workbook.add_format({'bold': 1,'border': 1,'align': 'center','valign': 'vcenter','fg_color': '#df9958'})
    merge_format7 = workbook.add_format({'bold': 1,'border': 1,'align': 'left','valign': 'vcenter','fg_color': '#df9958'})
    merge_format1 = workbook.add_format({'bold': 0,'border': 0,'align': 'center','valign': 'vcenter','fg_color': 'white'})
    merge_format5 = workbook.add_format({'bold': 0,'border': 1,'align': 'center','valign': 'vcenter','fg_color': 'white'})
    merge_format8 = workbook.add_format({'bold': 0,'border': 1,'align': 'left','valign': 'vcenter','fg_color': 'white'})
    merge_format2 = workbook.add_format({'bold': 1,'border': 1,'align': 'left','valign': 'vcenter','fg_color': '#c7ffc7'})
    merge_format3 = workbook.add_format({'bold': 1,'border': 1,'align': 'center','valign': 'vcenter','fg_color': '#63afff'})
    merge_format4 = workbook.add_format({'bold': 1,'border': 1,'align': 'left','valign': 'vcenter','fg_color': '#c7ffc7'})
    worksheet = workbook.add_worksheet('Sample1')
    worksheet.set_column('B:B', 40)
    worksheet.set_column('C:E', 10)
    worksheet.set_column('G:I', 10)
    worksheet.set_column('J:K', 10)
    worksheet.merge_range('A1:L1', '', merge_format1)
    worksheet.merge_range('A2:L2', 'Words & Bytes Count', merge_format)
    worksheet.merge_range('A3:L3', '', merge_format1)
    worksheet.merge_range('A4:L4', _filedirname, merge_format2)
    worksheet.merge_range('A5:L5', '', merge_format1)
    worksheet.merge_range('A6:L6', '', merge_format1)
    worksheet.merge_range('A7:L7', '', merge_format1)
    worksheet.merge_range('A8:L8', 'Word Files', merge_format)
    worksheet.merge_range('A9:L9', '', merge_format1)
    worksheet.merge_range('A10:A11', 'Sr. No.', merge_format3)
    worksheet.merge_range('B10:B11', 'Chapters', merge_format3)
    worksheet.merge_range('C10:E10', 'Bytes', merge_format3)
    worksheet.merge_range('F10:F11', 'Total', merge_format3)
    worksheet.merge_range('G10:I10', 'Word Count', merge_format3)
    worksheet.merge_range('J10:J11', 'Total', merge_format3)
    worksheet.merge_range('K10:K11', 'Total Pages', merge_format3)
    worksheet.merge_range('L10:L11', 'XE count', merge_format3)
    worksheet.write('C11','Footnotes',merge_format3)
    worksheet.write('D11','Endnotes',merge_format3)
    worksheet.write('E11','Text Pages',merge_format3)
    worksheet.write('G11','Footnotes',merge_format3)
    worksheet.write('H11','Endnotes',merge_format3)
    worksheet.write('I11','Text Pages',merge_format3)

    x1=0
    for x in range(len(arr_sheet)):
        # print(arr_sheet[x])
        row_no=x+1+11
        index_A = "A" + str(row_no)
        worksheet.write(index_A, (x+1),merge_format5)
        index_B="B"+str(row_no)
        worksheet.write(index_B, _filedirname+r'/'+arr_sheet[x][0],merge_format8)
        index_C="C"+str(row_no)
        worksheet.write(index_C, arr_sheet[x][1],merge_format5)
        index_D="D"+str(row_no)
        worksheet.write(index_D, arr_sheet[x][2],merge_format5)
        index_E="E"+str(row_no)
        worksheet.write(index_E, int(arr_sheet[x][3]),merge_format5)
        index_F="F"+str(row_no)
        worksheet.write(index_F, int(arr_sheet[x][1])+int(arr_sheet[x][2])+int(arr_sheet[x][3]),merge_format5)
        index_G="G"+str(row_no)
        worksheet.write(index_G, arr_sheet[x][4],merge_format5)
        index_H="H"+str(row_no)
        worksheet.write(index_H, arr_sheet[x][5],merge_format5)
        index_I="I"+str(row_no)
        worksheet.write(index_I, arr_sheet[x][6],merge_format5)
        index_J="J"+str(row_no)
        worksheet.write(index_J, int(arr_sheet[x][4])+int(arr_sheet[x][5])+int(arr_sheet[x][6]),merge_format5)
        index_K = "K" + str(row_no)
        worksheet.write(index_K, arr_sheet[x][7], merge_format5)
        index_L = "L" + str(row_no)
        worksheet.write(index_L, arr_sheet[x][8],merge_format5)
        x1=x
        if (os.path.basename(reffilename[x])).split('.')[-1]=='pdf':
            tot_byte_in_pdf=int(tot_byte_in_pdf)+int(arr_sheet[x][1])+int(arr_sheet[x][2])+int(arr_sheet[x][3])
            # print(tot_word_in_pdf)
            tot_page_count_pdf=tot_page_count_pdf+arr_sheet[x][7]
        if (os.path.basename(reffilename[x])).split('.')[-1]=='docx':
            tot_byte_in_docx=int(tot_byte_in_docx)+int(arr_sheet[x][1])+int(arr_sheet[x][2])+int(arr_sheet[x][3])
            # print((tot_word_in_docx))
            tot_page_count_docx = tot_page_count_docx+arr_sheet[x][7]
        if (os.path.basename(reffilename[x])).split('.')[-1]=='txt':
            tot_byte_in_txt=int(tot_byte_in_txt)+int(arr_sheet[x][1])+int(arr_sheet[x][2])+int(arr_sheet[x][3])
            # print(tot_word_in_txt)
            tot_page_count_txt = tot_page_count_txt+arr_sheet[x][7]

        if (os.path.basename(reffilename[x])).split('.')[-1]=='pdf':
            tot_word_in_pdf=int(tot_word_in_pdf)+int(arr_sheet[x][4])+int(arr_sheet[x][5])+int(arr_sheet[x][6])
            # print(tot_word_in_pdf)
        if (os.path.basename(reffilename[x])).split('.')[-1]=='docx':
            tot_word_in_docx=int(tot_word_in_docx)+int(arr_sheet[x][4])+int(arr_sheet[x][5])+int(arr_sheet[x][6])
            # print((tot_word_in_docx))
        if (os.path.basename(reffilename[x])).split('.')[-1]=='txt':
            tot_word_in_txt=int(tot_word_in_txt)+int(arr_sheet[x][4])+int(arr_sheet[x][5])+int(arr_sheet[x][6])
            # print(tot_word_in_txt)

    #df9958
    row_no_start=0+1+11
    row_no_end=x1+row_no_start
    endstart=x1+2+row_no_start
    index_result0="B"+str(endstart)
    worksheet.write(index_result0, 'Total',merge_format7)
    index_result="C"+str(endstart)
    formulasum="SUM(C"+str(row_no_start)+":C"+str(row_no_end)+")"
    worksheet.write_formula(index_result, formulasum,merge_format6)
    index_result1="D"+str(endstart)
    formulasum1="SUM(D"+str(row_no_start)+":D"+str(row_no_end)+")"
    worksheet.write_formula(index_result1, formulasum1,merge_format6)
    index_result2="E"+str(endstart)
    formulasum2="SUM(E"+str(row_no_start)+":E"+str(row_no_end)+")"
    worksheet.write_formula(index_result2, formulasum2,merge_format6)
    index_result3="F"+str(endstart)
    formulasum3="SUM(F"+str(row_no_start)+":F"+str(row_no_end)+")"
    worksheet.write_formula(index_result3, formulasum3,merge_format6)
    index_result4="G"+str(endstart)
    formulasum4="SUM(G"+str(row_no_start)+":G"+str(row_no_end)+")"
    worksheet.write_formula(index_result4, formulasum4,merge_format6)
    index_result5="H"+str(endstart)
    formulasum5="SUM(H"+str(row_no_start)+":H"+str(row_no_end)+")"
    worksheet.write_formula(index_result5, formulasum5,merge_format6)
    index_result6="I"+str(endstart)
    formulasum6="SUM(I"+str(row_no_start)+":I"+str(row_no_end)+")"
    worksheet.write_formula(index_result6, formulasum6,merge_format6)
    index_result7="J"+str(endstart)
    formulasum7="SUM(J"+str(row_no_start)+":J"+str(row_no_end)+")"
    worksheet.write_formula(index_result7, formulasum7,merge_format6)
    index_result8="K"+str(endstart)
    formulasum8="SUM(K"+str(row_no_start)+":K"+str(row_no_end)+")"
    worksheet.write_formula(index_result8, formulasum8,merge_format6)
    index_result9="L"+str(endstart)
    formulasum9="SUM(L"+str(row_no_start)+":L"+str(row_no_end)+")"
    worksheet.write_formula(index_result9, formulasum9,merge_format6)


    worksheet = workbook.add_worksheet('Consolidated')
    worksheet.merge_range('A1:G1', '', merge_format1)
    worksheet.merge_range('A2:G2', 'Integra Word Count Tool', merge_format)
    worksheet.merge_range('A3:G3', '', merge_format1)
    worksheet.merge_range('A4:G4', str(_filedirname), merge_format4)
    # worksheet.merge_range('C7:D8', "", merge_format5)

    worksheet.write('G7', "(Including Footnotes and Endnotes)",merge_format5)
    worksheet.write('A6', 'Sr. No.', merge_format)
    worksheet.write('B6', 'File Format', merge_format)
    worksheet.write('C6', 'Total No. of Files', merge_format)
    worksheet.write('D6', 'Total Bytes', merge_format)
    worksheet.write('E6', 'Total Words', merge_format)
    worksheet.write('F6', 'Total Pages', merge_format)
    worksheet.write('G6', 'Remarks', merge_format)
    worksheet.write_number('A7', 1, merge_format)
    worksheet.write_number('A8', 2, merge_format)
    worksheet.write_number('A9', 3, merge_format)
    worksheet.write_number('A10', 4, merge_format)
    worksheet.write('B7', 'Word', merge_format4)
    worksheet.write('B8', 'PDF', merge_format4)
    worksheet.write('B9', 'Excel', merge_format4)
    worksheet.write('B10', 'Text', merge_format4)
    worksheet.write('C7', wordcount, merge_format5)
    worksheet.write('D7', tot_byte_in_docx, merge_format5)
    worksheet.write('D8', tot_byte_in_pdf, merge_format5)
    worksheet.write('D10', tot_byte_in_txt, merge_format5)
    worksheet.write('C8', pdfcount, merge_format5)
    worksheet.write('C9', "", merge_format5)
    worksheet.write('C10',txtcount, merge_format5)
    worksheet.write('D9', "", merge_format5)
    worksheet.write('E9', "", merge_format5)
    worksheet.write('F9', "", merge_format5)
    worksheet.write('G9', "", merge_format5)
    worksheet.write('E7', tot_word_in_docx, merge_format5)
    worksheet.write('E8', tot_word_in_pdf, merge_format5)
    worksheet.write('E10', tot_word_in_txt, merge_format5)
    worksheet.write('G8', "", merge_format5)
    worksheet.write('G10', "", merge_format5)
    consolidateformula1='=Sample1!'+index_result8
    worksheet.write('F7',tot_page_count_docx,merge_format5)
    worksheet.write('F8',tot_page_count_pdf,merge_format5)
    worksheet.write('F10',tot_page_count_txt,merge_format5)
    worksheet.set_column('G:G', 40)
    worksheet.set_column('A:F', 15)
    workbook.close()
# except:

except Exception as e:
    exception_type, exception_object, exception_traceback = sys.exc_info()
    filename = exception_traceback.tb_frame.f_code.co_filename
    line_number = exception_traceback.tb_lineno
    print("Exception type: ", exception_type)
    print("File name: ", filename)
    print("Line number: ", line_number)
    pass
    os.remove(apppath + r'\test.xml')
    os.remove(apppath + r'\text.txt')
    sg.popup("\nPlease close the Xlsx file and All other Word/PDF/Excel re-run the tool!!!")
    # print("\nPlease close the Xlsx file and All other Word/PDF/Excel re-run the tool!!!")
    sys.exit()

# ------ Local tracking -------------
_local_tracking(tool_id, ToolVersion, Tra_input, _get_file_size(Tra_input), st_time, _get_timestamp())
# -----------------------------------
# print(tot_word_in_pdf)
# print(tot_word_in_docx)
# print(tot_word_in_txt)

os.remove(apppath + r'\test.xml')
os.remove(apppath + r'\text.txt')

sg.popup('Word Count Tool v1\n\n\n------------------------------------------------------------\n\nProcess completed!!!\n\n\n------------------------------------------------------------\n\n')



