from moviepy.editor import VideoFileClip

def extract_audio(video_file_path, output_audio_file):
    video_clip = VideoFileClip(video_file_path)
    audio_clip = video_clip.audio
    audio_clip.write_audiofile(output_audio_file)
    audio_clip.close()
    video_clip.close()

if __name__ == "__main__":
    video_file_path = r"D:\Giventool\Pradeep\New_Translation_Project\Input_new\Vie\Vie\ricET1e6121_Main.mp4" # Change this to the path of your video file
    output_audio_file = r"D:\Giventool\Pradeep\New_Translation_Project\Input_new\Vie\Vie\ricET1e6121_Main_output_audio.wav"  # Change this to the desired name of the extracted audio file

    extract_audio(video_file_path, output_audio_file)
