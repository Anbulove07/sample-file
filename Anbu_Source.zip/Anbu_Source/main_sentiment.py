import json
import time
import flask
from flask import render_template, request, redirect,jsonify, flash, send_file, send_from_directory, abort, url_for
import os.path

from flask import Flask, session
from docx import Document

from Email_scrap import _list_content_process
from date_range_json import date_range_json
from getDate import get_date_range
from sentiment_analysis_msg_5__225_edited_1815_ import sentiment_analysis
doc = Document()
app = Flask(__name__,static_folder='./templates')
from xml.etree.ElementTree import XML, fromstring
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'

UPLOAD_FOLDER = os.path.join('static', 'uploads')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


static_folder = os.path.join(os.path.dirname(__file__), 'static')
uploads_folder = os.path.join(static_folder, 'uploads')
list_content_process=[]

@app.route("/", methods=["GET", "POST"])
def home():
    return render_template("Date_picker.html")



@app.route('/start_date', methods=['GET', 'POST'])
def start_date():
    if request.method == "POST":
        # print(flask.request.json["JSONOuput"])
        datajson = flask.request.json["JSONOuput"]
        _startdate = (datajson["start"])
    print("Selected Start Date: ", _startdate)
    with open(uploads_folder + "\\startdate.txt", "w", encoding="utf-8") as f1:
        f1.write(_startdate)
    return jsonify({'status': 'success', 'message': 'Start Date updated...'})


@app.route('/end_date', methods=['GET', 'POST'])
def end_date():
    if request.method == "POST":
        # print(flask.request.json["JSONOuput"])
        datajson = flask.request.json["JSONOuput"]
        _startdate = (datajson["end"])
    print("Selected End Date: ", _startdate)
    with open(uploads_folder + "\\enddate.txt", "w", encoding="utf-8") as f1:
        f1.write(_startdate)
    return jsonify({'status': 'success', 'message': 'End Date updated...'})

@app.route('/analyse', methods=['GET', 'POST'])
def analyse():
    if request.method == "POST":
        # print(flask.request.json["JSONOuput"])
        datajson = flask.request.json["JSONOuput"]
        _analyse = (datajson["journal"])
    print("Selected List: ", _analyse)
    with open(uploads_folder + "\\enddate.txt", "r", encoding="utf-8") as f1:
        end_date=f1.read()
    with open(uploads_folder + "\\startdate.txt", "r", encoding="utf-8") as f1:
        start_date=f1.read()

    # # list_content_process.append(_analyse)
    # status=_list_content_process(_analyse)
    # if status=="success":
    #     # return jsonify({'status': 'success', 'message': 'Mail scrapping completed...'})
    #     print('Mail scrapping completed...')
    #
    # statusdate=date_range_json(_analyse+".json",start_date,end_date)
    # if statusdate=="success":
    #     # return jsonify({'status': 'success', 'message': 'Date Range splitted completed...'})
    #     print('Date Range splitted completed...')

    jsonsavedaterange=get_date_range(_analyse,start_date,end_date)
    print(uploads_folder + "\\"+_analyse+"_out.json")
    with open(uploads_folder + "\\"+_analyse+"_out.json", "w", encoding="utf-8") as f1:
        f1.write(jsonsavedaterange)

    returnvalue,label,count,negative,critical = sentiment_analysis(uploads_folder + "\\"+_analyse+"_out.json")
    print("negative is",negative)
    print("critical is",critical)
    if returnvalue=="success":
        graph_data = {
            'labels': label,
            'data': count,
            'colors': ['#00FF00', '#FFFF00', '#FFA07A', '#FF0000'],
            'negative': negative,
            'critical': critical
        }
        print("graph_data success is running")
        return jsonify({'status': 'success', 'message': 'Mail scrapping completed...', 'graph_data': graph_data})

    #     return render_template('graph.html', graph_data=graph_data)
    # return render_template('graph.html')
        # return jsonify({'status': 'success', 'message': 'Sentiment Analysis completed...'})
        # print('Sentiment Analysis completed...')


    # return jsonify({'status': 'success', 'message': 'Mail scrapping completed...'})



if __name__ == "__main__":
    app.run(host='IS-S2505', port=80)
