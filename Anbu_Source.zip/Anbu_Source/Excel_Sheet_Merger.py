# ------------------------------------------------------------------
#  Tool Name    : Excel2Excel_Merge.py
#  Developer    : Anbu G | CTAE
#  Description  : To Merge the Excel files
#  Client/DU    : Pearson
#  Syntax		: <EXE> <XML Folder>
# ------------------------------------------------------------------
import glob
import os
import sys

import pandas as pd


os.system("cls")

# Inline argument checking
if (len(sys.argv) != 2 or not os.path.isdir(sys.argv[1])):
    sys.exit("\n\tSyntax: Excel2Excel_Merge.exe <Excel Folder>\n")
Inputpath = sys.argv[1]
csv_files = glob.glob(os.path.join(Inputpath, "*.xlsx"))

list=[]
for x in range(len(csv_files)):
    # print(x)
    df1 = pd.read_excel(csv_files[x])
    list.append(df1)

#
# # Load the three Excel files into dataframes
# df1 = pd.read_excel(r'D:\Giventool\Siva\Excel Merge\New folder\WIP-Bharath.xlsx')
# df2 = pd.read_excel(r'D:\Giventool\Siva\Excel Merge\New folder\WIP-Geetha.xlsx')
# df3 = pd.read_excel(r'D:\Giventool\Siva\Excel Merge\New folder\WIP-Preethika.xlsx')

# Concatenate the dataframes vertically
merged_df = pd.concat(list, axis=0)

# Save the merged dataframe to a new Excel file
merged_df.to_excel(Inputpath+'\\merged_file.xlsx', index=False)

sys.exit("Merged file created successfully!!!")
