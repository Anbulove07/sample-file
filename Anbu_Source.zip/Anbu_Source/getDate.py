import pandas as pd


def get_date_range(_analyse,start_date,end_date):
    # Load the Excel file into a DataFrame
    excel_file = 'output.xlsx'  # Replace with your Excel file path
    df = pd.read_excel(excel_file, engine='openpyxl')

    # Define the file name and date range
    # file_name = 'FINT'  # Replace with the file name you want to filter
    file_name = _analyse  # Replace with the file name you want to filter
    start_date = start_date
    end_date = end_date

    # Convert the 'date' column to a datetime format
    df['date'] = pd.to_datetime(df['date'], format='%d-%m-%Y %H:%M')

    # Filter the DataFrame by both file name and date range
    filtered_df = df[(df['file_name'] == file_name) & (df['date'] >= start_date) & (df['date'] <= end_date)]

    # Print or further process the filtered DataFrame
    # print(filtered_df)

    filtered_json = filtered_df.to_json(orient='records')

    # Print or further process the JSON object
    # print(filtered_json)

    # with open("temp_final.json", 'w', encoding='utf-8') as json_file:
    #     json_file.write(filtered_json)
    return filtered_json

#
# for index, row in filtered_df.iterrows():
#     mail_id = row['From']
#     body_content = row['body']
#
#     print(f"Mail ID: {mail_id}")
#     print(f"Body Content: {body_content}")
#     print("------")

