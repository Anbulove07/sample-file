from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from PIL import Image
from io import BytesIO


def extract_images(docx_path):
    doc = Document(docx_path)
    images = []
    for rel in doc.part.rels:
        part = doc.part.rels[rel].target_part
        if "image/" in part.content_type:
            images.append(part)
    return images


def resize_image(image_blob, max_width=576, max_height=576):
    img = Image.open(BytesIO(image_blob))
    img.thumbnail((max_width, max_height))
    img_buffer = BytesIO()
    img.save(img_buffer, format="PNG")
    return img_buffer.getvalue()


def save_images_with_alt_text(images, output_path):
    new_doc = Document()
    center_alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    for i, image in enumerate(images):
        alt_text = f"Image {i + 1}"
        image_blob = image.blob
        resized_image_blob = resize_image(image_blob)
        img_width, img_height = Image.open(BytesIO(resized_image_blob)).size
        new_doc.add_paragraph().add_run().add_picture(BytesIO(resized_image_blob), width=Inches(img_width / 96),
                                                      height=Inches(img_height / 96))
        new_doc.paragraphs[-1].alignment = center_alignment
        new_doc.add_paragraph(alt_text).alignment = center_alignment

    # Add the count of images to the output filename
    count_images = len(images)
    output_path_with_count = output_path.replace('.docx', f'_Figure 1-{count_images}.docx')

    new_doc.save(output_path_with_count)


if __name__ == "__main__":
    input_docx_path = r"D:\Giventool\karthik\IOPP\IOPP\Input\TRAN_114304\Source\2DMacec58\2DMacec58.docx"
    output_docx_path = r"D:\Giventool\karthik\IOPP\IOPP\Input\TRAN_114304\Source\2DMacec58\2DMacec58_output.docx"

    images = extract_images(input_docx_path)
    save_images_with_alt_text(images, output_docx_path)



