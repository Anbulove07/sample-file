

import zipfile
import xml.etree.ElementTree as ET
import base64
import docx2txt
def extract_images_and_captions(docx_path):
    text_content = docx2txt.process(docx_path)
    images_with_captions = []

    lines = text_content.split("\n")
    image_data = None
    caption = None

    for line in lines:
        if line.startswith("[Image]"):
            if image_data and caption:
                images_with_captions.append((image_data, caption))
            image_data = None
            caption = None
        elif line.startswith("[Caption]"):
            caption = line.replace("[Caption]", "").strip()
        else:
            image_data = line

    return images_with_captions
def main():
    document_path = r"D:\Giventool\karthik\IOPP\IOPP\Input\TRAN_114304\Source\2DMacec58\2DMacec58.docx"  # Replace with the actual path

    images_with_captions = extract_images_and_captions(document_path)

    for idx, (img_data, img_caption) in enumerate(images_with_captions, start=1):
        img_filename = f"image_{idx}.png"  # You can modify the filename pattern

        with open(img_filename, "wb") as img_file:
            img_file.write(base64.b64decode(img_data))

        print(f"Image {idx} saved with caption: {img_caption}")
if __name__ == "__main__":
    main()
