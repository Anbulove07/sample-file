# D:\Giventool\Thangaprakasam\EPS_JPEG\Bagavathy\CCIDE_I_11_0_J
from iModule.Basic import _get_file_list
import re
from PIL.Image import Image

inputdir='D:\Giventool\Thangaprakasam\EPS_JPEG\Bagavathy\CCIDE_I_11_0_J'
#EPS to jpg conversion
from PIL import EpsImagePlugin
EpsImagePlugin.gs_windows_binary =  r'C:\Program Files\gs\gs9.52\bin\gswin64c'
EPS = _get_file_list(inputdir,1,1,r'\.eps')
print(EPS)

for img in EPS:
	im = Image.open(img)
	Out_Image = img.split('\\')[-1]
	Out_Image = re.sub(r'\.eps','',Out_Image,re.I|re.S)
	try:
		im.load(scale=3)
		im.save(imageFolder+'\\'+Out_Image+'.jpg')
	except:
		print("\nEPS image \""+str(Out_Image)+"\" not inserted in excel")
