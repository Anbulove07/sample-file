import nltk
from nltk.sentiment import SentimentIntensityAnalyzer
import matplotlib.pyplot as plt

nltk.download('vader_lexicon')  # Download the necessary lexicon for SentimentIntensityAnalyzer

# Initialize the SentimentIntensityAnalyzer
sia = SentimentIntensityAnalyzer()

# Sample content for analysis
content = [
    "I love Python. It's such a powerful language!",
    "This movie is fantastic. I highly recommend it.",
    "I'm feeling neutral about this situation.",
    "I'm really disappointed with their customer service.",
    "The product is okay, but it could be better.",
]

# Analyze the sentiment of each piece of content
sentiments = []
for sentence in content:
    sentiment_score = sia.polarity_scores(sentence)
    sentiments.append(sentiment_score['compound'])

# Define threshold values for sentiment classification
threshold_good = 0.3
threshold_bad = -0.3

# Classify the sentiment into good, average, or bad
sentiment_labels = []
for sentiment in sentiments:
    if sentiment >= threshold_good:
        sentiment_labels.append('Good')
    elif sentiment <= threshold_bad:
        sentiment_labels.append('Bad')
    else:
        sentiment_labels.append('Average')

# Define colors for each sentiment label
colors = {'Good': 'green', 'Average': 'blue', 'Bad': 'red'}

# Plot the sentiment analysis graph with colored bars
plt.figure(figsize=(8, 6))
bars = plt.bar(range(len(sentiments)), sentiments, tick_label=content)

# Set the color of each bar based on the sentiment label
for i, label in enumerate(sentiment_labels):
    bars[i].set_color(colors[label])

plt.xlabel('Content')
plt.ylabel('Sentiment Score')
plt.title('Sentiment Analysis')
plt.axhline(y=0, color='gray', linestyle='--', linewidth=1)

# Add a legend for the colors
legend_colors = [plt.Rectangle((0, 0), 1, 1, fc=color) for color in colors.values()]
plt.legend(legend_colors, colors.keys())

plt.show()
