#------------------------------------------------------------------
#  Tool Name    : OUP_ATLAS_Package.py
#  Developer    : Anbu G | CTAE XML
#  Description  : Validate the folder structure and xml graphics
#  Client/DU    : OUP
#  Syntax		: <EXE> <ZIP file>
#------------------------------------------------------------------

#------------ Rivision History  -----------------------------------
#  12-10-2022 | v1.0.0.0 | Anbu G | Initial Development
#------------------------------------------------------------------

ToolVersion = "1.0.0.0";

import os
from os.path import basename,dirname
import shutil
import ctypes
import sys 
import re
import subprocess
from iPython.Basic import*
from iPython.ErrorLog import *
from glob import glob
from iPython.ToolTracking import *
from zipfile import ZipFile

# Toolpath = dirname(sys.argv[0]);
# Toolpath = re.sub(r'\/',r'\\',Toolpath,0)

os.system("cls")


# Inline argument checking & File path checking
if (len(sys.argv) != 2 or not os.path.isfile(sys.argv[1])): sys.exit("\n\tSyntax: OUP_ATLAS_Package.exe <FolderPath>\n")

print ("\n\n\tOUP_Package v"+str(ToolVersion)+" is Running...\n\n")

#------------ Tracking --------------------------------------------
Tra_input = sys.argv[1];
tool_id = 463; #OUP_ATLAS_Package Tool
run_size = 0;
st_time = _get_timestamp();
#------------------------------------------------------------------

# Global variable declaration
_extract_zip(sys.argv[1])

InputDir = ((sys.argv[1]).replace('.zip',''))
osoISBN = ""

errfile = InputDir+"\\"+(os.path.basename(InputDir))+r'_err.htm'
if os.path.isfile(errfile): os.remove(errfile)
# Difference Subroutine:
def Difference(First, Second):
	return (list(set(First) - set(Second)))
	
def _FileCheck():
	global osoISBN
	global ZipFileList
	global xmlfile
	ErrStr = ""
	AllFiles = os.listdir(InputDir)
	if 'cover' not in AllFiles:
		ErrStr +="[1:1]: Error: [OUP-1000]: 'cover' folder is missing in input path.\n"
	if 'print pdf' not in AllFiles:
		ErrStr +="[1:1]: Error: [OUP-1001]: 'print pdf' folder is missing in input path.\n"
	if 'MARC' not in AllFiles:
		ErrStr +="[1:1]: Error: [OUP-1002]: 'MARC' folder is missing in input path.\n"
	if 'chunked pdf' not in AllFiles:
		ErrStr +="[1:1]: Error: [OUP-1003]: 'chunked pdf' folder is missing in input path.\n"
	if 'assets' not in AllFiles:
		ErrStr +="[1:1]: Error: [OUP-1004]: 'assets' folder is missing in input path.\n"
	ZipFileList = list(filter(re.compile(r'(oso-[\d]{13})-[A-Z]+.xml').match, AllFiles))

	if not(ZipFileList):

		# ZipFileList1 = list(filter(re.compile(r'\.xml').match, AllFiles))
		ErrStr +="[1:1]: Error: [OUP-1005]:  Incorrect xml filename in input path.\n"
	else:
		if re.search(r'(oso-[\d]{13})-\w+.xml', ZipFileList[0], re.I | re.S):
			ZipFileList1 = re.search(r'(oso-[\d]{13})-\w+.xml', ZipFileList[0], re.I | re.S)
			osoISBN = ZipFileList1.group(1)
	return ErrStr


def _ATLAS_PackageCreation():
	ErrStr = ""
	# ISBN = re.sub(r'oso-([\d]{13}).zip',r'\g<1>',osoISBN,0,re.I|re.S)
	ISBN = osoISBN
	ISBN1 = osoISBN.replace('oso-','')
	if not(os.path.isfile(InputDir+f'\\cover\\{ISBN1}.jpg')):
		ErrStr +=f"[1:1]: Error: [OUP-1006]: '{ISBN1}.jpg' file is missing in cover folder.\n"
	if not(os.path.isfile(InputDir+f'\\print pdf\\{ISBN}.pdf')):
		ErrStr +=f"[1:1]: Error: [OUP-1007]: '{ISBN}.pdf' file is missing in print pdf folder.\n"
	# PDFISBN = re.sub(r'.zip$',r'',osoISBN,0,re.I|re.S)
	# if not(os.path.isfile(InputDir+f'\\print pdf\\{PDFISBN}.pdf')):
	# 	ErrStr +=f"[1:1]: Error: [OUP-1005]: '{PDFISBN}.pdf' file is missing in 'print pdf' folder.\n"
	if(os.path.isfile(InputDir+f'\\MARC\\{ISBN}.marc')):
		ErrStr +=f"[1:1]: Error: [OUP-1008]: '{ISBN}.marc' file is not allowed in 'MARC' folder.\n"
	CoverFiles = os.listdir(InputDir+f'\\cover')
	if(len(CoverFiles) > 1):
		ErrStr +="[1:1]: Error: [OUP-1009]: Extra files present in 'cover' folder.\n"
	PDFFiles = os.listdir(InputDir+f'\\print pdf')
	if(len(PDFFiles) > 1):
		ErrStr +="[1:1]: Error: [OUP-1010]: Extra files present in 'print pdf' folder.\n"
	MARCFiles = os.listdir(InputDir+f'\\MARC')
	if not(re.search(r'.marc$',MARCFiles[0],re.I)):
		ErrStr +="[1:1]: Error: [OUP-1011]: '.marc' file is missing in 'MARC' folder.\n"
	if(len(MARCFiles) > 1):
		ErrStr +="[1:1]: Error: [OUP-1012]: Extra files present in 'MARC' folder.\n"

	#unzip	
	# _extract_zip(InputDir+f'\\{osoISBN}')
	# xmlfile = _get_file_list(InputDir+f'\\{PDFISBN}',1,0,r'.xml$')

	xmlfile =InputDir+"\\"+ZipFileList[0]
	if not(os.path.isfile(xmlfile)):
		ErrStr +=f"[1:1]: Error: [OUP-1013]: xml file is missing in zip file.\n"
	else:
		xmlcnt = _open_utf8(xmlfile)
		FileImage = re.findall(r'<graphic(?: [^>]*)? sysId="([^"]+)"(?: [^>]*)?/>',xmlcnt,re.I|re.S)
		FolderImage = os.listdir(InputDir+f'\\assets')
		FileValid = Difference(FileImage,FolderImage)
		if(FileValid):
			ErrStr +="[1:1]: Error: [OUP-1014]: '"+', '.join(map(str,FileValid))+"' image files missing in image folder.\n"
		FolderValid = Difference(FolderImage,FileImage)
		if(FolderValid):
			ErrStr +="[1:1]: Error: [OUP-1015]: Extra images '"+', '.join(map(str,FolderValid))+"' present in xml file.\n"

		chuckpdf = os.listdir(InputDir + "\\chunked pdf")
		for pdffile in chuckpdf:
			pdffile1=pdffile.replace('.pdf','')
			if re.search(r'indexList',pdffile1,re.I|re.S):
				if not re.search(r'<indexList(?: [^>]*)? id=\"'+pdffile1+'\"',xmlcnt,re.I|re.S):
					ErrStr += "[1:1]: Error: [OUP-1016a]: "+pdffile1+" not present in xml file.\n"
			if re.search(r'chapter',pdffile1,re.I|re.S):
				if not re.search(r'<chapter(?: [^>]*)? id=\"'+pdffile1+'\"',xmlcnt,re.I|re.S):
					ErrStr += "[1:1]: Error: [OUP-1016b]: "+pdffile1+" not present in xml file.\n"
			if re.search(r'miscMatter',pdffile1,re.I|re.S):
				if not re.search(r'<miscMatter(?: [^>]*)? id=\"'+pdffile1+'\"',xmlcnt,re.I|re.S):
					ErrStr += "[1:1]: Error: [OUP-1016c]: "+pdffile1+" not present in xml file.\n"

		if re.search(r'<miscMatter(?: [^>]*)? class="foreword"(?: [^>]*)?>.*',xmlcnt,re.I|re.S):
			xmlcnt1=re.search(r'<miscMatter(?: [^>]*)? class="foreword"(?: [^>]*)?>.*',xmlcnt,re.I|re.S)
			# xmlcnt11=xmlcnt1.group()
			for misc in re.finditer(r'<miscMatter(?: [^>]*)? id="([^"]*)" (?:[^>]*)>',xmlcnt1.group(),re.I|re.S):
				# print(misc.group(1))
				# for pdffile in chuckpdf:
				# 	pdffile1 = pdffile.replace('.pdf', '')
				if str(misc.group(1))+".pdf" not in chuckpdf:
				# if not re.search(misc.group(1), pdffile1, re.I | re.S):
					ErrStr += "[1:1]: Error: [OUP-1017a]: " + misc.group(1) + " not present in chunked pdf folder.\n"

			xmlcnt1 = re.sub(r'<miscMatter(?: [^>]*)? class="foreword"(?: [^>]*)?>.*','', xmlcnt,0, re.I | re.S)
			if re.search(r'<miscMatter(?: [^>]*)? id="([^"]*)" (?:[^>]*)>',xmlcnt1,re.I|re.S):
				xmlcnt2=re.search(r'<miscMatter(?: [^>]*)? id="([^"]*)" (?:[^>]*)>',xmlcnt1,re.I|re.S)
				# for pdffile in chuckpdf:
				# 	pdffile1 = pdffile.replace('.pdf', '')
				if str(xmlcnt2.group(1))+".pdf" not in chuckpdf:
				# if not re.search(xmlcnt2.group(1), pdffile1, re.I | re.S):
					ErrStr += "[1:1]: Error: [OUP-1017b]: " + xmlcnt2.group(1) + " not present in chunked pdf folder.\n"

	
	if ErrStr:
		shutil.rmtree(InputDir)
		CreateErrorLog(InputDir,"OUP ATLAS Package Ver "+str(ToolVersion),ErrStr,0)
		print ("\n\tPlease clear the validation error!!!\n")
		sys.exit(0)
		
	# _make_path(InputDir+f'\\10.1093_oso_{ISBN}.001.0001')
	
	# shutil.copytree(InputDir+f'\\{PDFISBN}\\figures\\inline', InputDir+f'\\10.1093_oso_{ISBN}.001.0001\\assets')
	# shutil.copytree(InputDir+f'\\{PDFISBN}\\pdf', InputDir+f'\\10.1093_oso_{ISBN}.001.0001\\chunked pdf')
	# shutil.copytree(InputDir+f'\\cover', InputDir+f'\\10.1093_oso_{ISBN}.001.0001\\cover')
	# shutil.copytree(InputDir+f'\\print pdf', InputDir+f'\\10.1093_oso_{ISBN}.001.0001\\print pdf')
	# shutil.copytree(InputDir+f'\\MARC', InputDir+f'\\10.1093_oso_{ISBN}.001.0001\\MARC')
	# shutil.copy(xmlfile[0], InputDir+f'\\10.1093_oso_{ISBN}.001.0001')
	#
	# shutil.make_archive(InputDir+f'\\10.1093_oso_{ISBN}.001.0001', "zip", InputDir+f'\\10.1093_oso_{ISBN}.001.0001')
	# shutil.rmtree(InputDir+f'\\10.1093_oso_{ISBN}.001.0001')
	#
	return ""


ErrCnt = _FileCheck()
if ErrCnt:
	shutil.rmtree(InputDir)
	CreateErrorLog(InputDir,"OUP ATLAS Package Ver "+str(ToolVersion),ErrCnt,0)
	print ("\n\tPlease clear the validation error!!!\n")
	sys.exit(0)
else:
	_ATLAS_PackageCreation()

if not ErrCnt:
	ErrCnt='No errors'
	CreateErrorLog(InputDir,"OUP ATLAS Package Ver "+str(ToolVersion),ErrCnt,0)

#------ Local tracking -------------
_local_tracking(tool_id, ToolVersion, Tra_input,_get_file_size(Tra_input),st_time, _get_timestamp())
#-----------------------------------
shutil.rmtree(InputDir)
print ("\n\tProcess completed successfully!!!\n");
sys.exit(0)