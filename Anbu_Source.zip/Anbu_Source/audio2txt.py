import os
import speech_recognition as sr


def audio_to_text(audio_file_path):
    recognizer = sr.Recognizer()

    with sr.AudioFile(audio_file_path) as source:
        audio_data = recognizer.record(source)
        try:
            recognized = recognizer.recognize_sphinx(audio_data)
            return recognized
        except sr.UnknownValueError:
            return "Unknown"
        except sr.RequestError as e:
            return "Error"


if __name__ == "__main__":
    audio_file_path = r"D:\Giventool\Pradeep\New_Translation_Project\Input_new\Martin-Gay\Martin-Gay\mgia8eSL1001_Main_output_audio.wav"  # Change this to the path of your audio file
    text = audio_to_text(audio_file_path)
    with open(r"D:\Giventool\Pradeep\New_Translation_Project\Input_new\Martin-Gay\Martin-Gay\mgia8eSL1001_Main_output_text.txt", "w") as text_file:
        text_file.write(text)
