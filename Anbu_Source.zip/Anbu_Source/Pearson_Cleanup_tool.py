
# ---------------------------------------------------------------------
#  Tool Name	: Cleanup_tool_v1.py
#  Developer	: Anbu G
#  Description  : To Clean Html tags
#  Client/DU	: Pearson
#  Syntax		: <EXE> <Epub Folder location>
# -----------------------------------------------------------------------



# ------------ Rivision History  -------------------------------------------
#  15-09-2022 | v1.0.0.0 | Anbu G | Initial Development
# --------------------------------------------------------------------------



import itertools
import re
import os
import sys
from iModule.ToolTracking import _get_timestamp, _local_tracking, _get_file_size
# from itertools import count
import collections
ToolVersion = "1.0.0.0";
import codecs
print("\n\n\tCleanUp Tool v" + ToolVersion + " is Running...");
print("\tCopyright @ Integra Software Services Ltd.\n");


try :
    _filedirname = sys.argv[1]

except :
    # src = r'D:\Anbu\XML\pdftest.pdf'
    print("Please Enter XML file location")
    sys.exit()

# ------------ Tracking --------------------------------------------
Tra_input = sys.argv[1];
tool_id = 485;  # Pearson_Cleanup_tool
run_size = 0;
st_time = _get_timestamp();
# ------------------------------------------------------------------


# go to OPS path
# D:\Giventool\Thangaprakasam\Cleanuptool\Cleanup\9780137699728\OPS
# Make OPS Path
OPS_Path=_filedirname+"\\OPS"

#Make Xhtml path
xhtml_Path=OPS_Path+"\\xhtml"

#Make Images Path
images_Path=OPS_Path+"\\images"


list_image = [x for x in os.listdir(images_Path) if x.endswith((".jpg",".png"))]
# print(len(list_image))
imglistnamecln=[]
for oneimg in list_image:
    # print(oneimg)
    # oneimg0=oneimg.split('_')
    oneimg1 = (''.join(oneimg.split('_')[0:2]))
    oneimg2 = ('_'.join(oneimg.split('_')[2:]))
    # print(oneimg2)

    old_name = images_Path+"\\"+oneimg
    new_name = images_Path+"\\"+oneimg2
    try:
        os.rename(old_name, new_name)
        imglistnamecln.append(oneimg+"<-*->"+oneimg2)
    except:
        pass

# print(imglistnamecln)


# OPS_Path
with open(OPS_Path+"\\package.opf", "r", encoding="utf-8") as f1:
    opfcontent=f1.read()
    f1.close()
for xym in imglistnamecln:
    oldnameimg=xym.split('<-*->')
    opfcontent=opfcontent.replace(oldnameimg[0],oldnameimg[1])

with open(OPS_Path+"\\package.opf", "w", encoding="utf-8") as f1:
    f1.write(opfcontent)
    f1.close()



_filename1 = [x for x in os.listdir(xhtml_Path) if x.endswith((".xhtml"))]
# print(_filedirname)

pathtofile1 = xhtml_Path + "\\output"

if not os.path.isdir(xhtml_Path + "\\output"):  # line A
    os.mkdir(xhtml_Path + "\\output")

# os.mkdir(xhtml_Path + "\\output")
arr101={}
arr1012={}
arr1012_fin={}
arr1022={}
arr10222={}
for x in range (len(_filename1)):
    pathtofile=xhtml_Path+"\\"+_filename1[x]
    matchedfile=re.search(r'(_GLOS.xhtml)$',_filename1[x],re.I|re.S)
    if matchedfile:
        # print(_filename1[x])
        with codecs.open(pathtofile, "r", encoding='utf8', errors='ignore') as file1:
            xml_data_1 = file1.read()
            count1=1
            for glossid in re.finditer(r'<dt(?: [^>]*)? class="glossterm"[^>]*? id="([^"]*)"[^>]*?>',xml_data_1,re.I|re.S):

                arr101[glossid.group(1)]=_filename1[x]+'#pxid_gloss'+str(count1).zfill(4)
                arr1012[glossid.group(1)]='#pxid_gloss'+str(count1).zfill(4)
                count1=count1+1
                # arr101.append()

for x in range(len(_filename1)):
    pathtofile = xhtml_Path + "\\" + _filename1[x]
    matchedfile = re.search(r'(_NOTE.xhtml)$', _filename1[x], re.I | re.S)
    if matchedfile:
        # print(_filename1[x])
        with codecs.open(pathtofile, "r", encoding='utf8', errors='ignore') as file1:
            xml_data_1 = file1.read()
            count1 = 1
            for glossid in re.finditer(r'<li(?: [^>]*)? id="([^"]*)"[^>]*?>', xml_data_1,re.I | re.S):
            # for glossid in re.finditer(r'(<a(?: [^>]*)? href=")([^"]*.xhtml#[^"]*)("[^>]*>)(.*)(</a[^>]*>)', xml_data_1,re.I | re.S):
                arr1022[glossid.group(1)] = '#ch'
                # arr10222[glossid.group(2)] = '#pxid_gloss' + str(count1).zfill(4)
                count1 = count1 + 1
                # arr101.append()

    # print(_filename1[x])
    # pathtofile1=xhtml_Path+"\\output"+"\\"+_filename1[x]
    # <dd(?: [^>]*)? class="glossdef"[^>]*? id="([^"]*)"[^>]*?>
# print(arr1022)
# exit()
for x in range (len(_filename1)):
    pathtofile=xhtml_Path+"\\"+_filename1[x]
    pathtofilenameonly=_filename1[x]
    pathtofile1=xhtml_Path+"\\output"+"\\"+_filename1[x]


    with codecs.open(pathtofile, "r", encoding='utf-8',errors='ignore') as file:
        xml_data = file.read()
    # print(xml_data)
    # try:
        xml_data=xml_data.replace("</p><p>","</p>\n<p>")
        xml_data=xml_data.replace('\t',' ')
        xml_data=xml_data.replace('�',' ')
        xml_data=xml_data.replace('  ',' ')
        xml_data = xml_data.replace('\"  >', '\">')
        xml_data = xml_data.replace('\"> ', '\">')
        xml_data = xml_data.replace(' </', '</')
        xml_data = xml_data.replace("</li><li>", "</li>\n<li>")
        xml_data = xml_data.replace("\n</p>", "</p>")
        xml_data = xml_data.replace("</h2></div>", "</h2>\n</div>")
        xml_data = xml_data.replace("\n</h", "</h")
        xml_data = xml_data.replace("\n<strong>", " <strong>")
        xml_data = xml_data.replace("\n<em>", " <em>")
        xml_data = xml_data.replace("\n<a ", " <a ")
        xml_data = xml_data.replace("\n<span>", " <span>")
        xml_data = re.sub(r'<strong>\s+\n+', '<strong>',xml_data,0,re.I|re.S)
        xml_data = re.sub(r'<em>\s+\n+', '<em>',xml_data,0,re.I|re.S)
        xml_data = re.sub(r'<td>\s+\n+', '<td>',xml_data,0,re.I|re.S)
        xml_data = re.sub(r'<th>\s+\n+', '<th>',xml_data,0,re.I|re.S)
        xml_data = re.sub(r'<span((?: [^>]*)?)>\s+\n+', ' <span\g<1>>',xml_data,0,re.I|re.S)
        xml_data = re.sub(r'<a((?: [^>]*)?)>\s+\n+', ' <a\g<1>>',xml_data,0,re.I|re.S)
        xml_data = re.sub(r'</p><p((?: [^>]*)?)>', '</p>\n<p>',xml_data,0,re.I|re.S)
        xml_data = re.sub(r'</li><li((?: [^>]*)?)>', '</li>\n<li>',xml_data,0,re.I|re.S)
        xml_data = re.sub(r'</strong>\s+\n+', '</strong>',xml_data,0,re.I|re.S)
        xml_data = re.sub(r'</em>\s+\n+', '</em>',xml_data,0,re.I|re.S)
        xml_data = re.sub(r'</span>\s+\n+', '</span>',xml_data,0,re.I|re.S)
        xml_data = re.sub(r'</a>\s+\n+', '</a>',xml_data,0,re.I|re.S)
        xml_data = re.sub(r'\s+\n+</a>', '</a>',xml_data,0,re.I|re.S)
        xml_data = re.sub(r'\s+\n+</span>', '</span>',xml_data,0,re.I|re.S)
        xml_data = re.sub(r'" >"', '">"',xml_data,0,re.I|re.S)
        xml_data = xml_data.replace("</div> <div", "</div>\n<div")
        xml_data2 = '''<?xml version="1.0" encoding="utf-8"?>\n<html xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/1999/xhtml" xmlns:m="http://www.w3.org/1998/Math/MathML" xml:lang="en" lang="en">\n<head>\n<title data-profile-deliveryformat="digital">temp_title_temp_temp_temp</title>\n<meta name="PXID_XML_Styler" content="v3023"/><meta charset="UTF-8"/>\n<meta name="dcterms.conformsTo" content="PXE 1.39 ProductLevelReuse"/>\n<meta name="generator" content="PXE Tools version 1.39.158"/>
<link rel="alternate stylesheet" type="text/css" title="night" href="file:///C:\itools\PXID_Integrated/redserif/css/theme/redserif/night.css"/><link rel="alternate stylesheet" type="text/css" title="sepia" href="file:///C:\itools\PXID_Integrated/redserif/css/theme/redserif/sepia.css"/><link rel="alternate stylesheet" type="text/css" title="print" href="file:///C:\itools\PXID_Integrated/redserif/css/theme/redserif/print.css"/><link rel="alternate stylesheet" type="text/css" title="default" href="file:///C:\itools\PXID_Integrated/redserif/css/theme/redserif/default.css"/><link rel="stylesheet" type="text/css" title="main" href="file:///C:\itools\PXID_Integrated/redserif/css/main.css"/><link rel="stylesheet" type="text/css" title="night" href="file:///C:\itools\PXID_Integrated/redserif/css/night.css"/><link rel="stylesheet" type="text/css" title="sepia" href="file:///C:\itools\PXID_Integrated/redserif/css/sepia.css"/><script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"/><script src="file:///C:\itools\PXID_Integrated/ELDS/css/theme/redserif/refviiew.js"/><link rel="stylesheet" type="text/css" href="../css/local.css"/><script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.4/MathJax.js?config=MML_HTMLorMML"/>
</head>'''

        xml_data_temp=re.search(r'<\?xml(?: [^>]*)?>(?:(?!</head>).)*</head>',xml_data,re.I|re.S)
        if xml_data_temp.group():
            xml_data=xml_data.replace(xml_data_temp.group(),xml_data2)
        # xml_data = re.sub(r'<div(?: [^>]*)? class="container"[^>]*?>((?:(?!</div>).)*)</div>', r'\g<1>', xml_data, 0,re.I | re.S)

        xml_data=re.sub(r'<li(?: [^>]*)','<li',xml_data,0,re.I|re.S)
        xml_data=re.sub(r'<li>\s*</li>','',xml_data,0,re.I|re.S)
        xml_data=re.sub(r'<\!--(?:(?!-->).)*-->','',xml_data,0,re.I|re.S)
        xml_data=re.sub(r'<\!--(?:(?!-->).)*--">','',xml_data,0,re.I|re.S)

        xml_data=re.sub(r'data-versionUrn="[^"]*"','',xml_data,0,re.I|re.S)
        xml_data=re.sub(r'<strong id="[^>]*>','<strong>',xml_data,0,re.I|re.S)
        xml_data=re.sub(r'<em id="[^>]*>','<em>',xml_data,0,re.I|re.S)

        xml_data=re.sub(r'<div(?: [^>]*)?>\s+</div>','',xml_data,0,re.I|re.S)
        xml_data=re.sub(r'<li(?: [^>]*)?>\s*</li>','',xml_data,0,re.I|re.S)
        xml_data=re.sub(r'\n+\s+','\n',xml_data,0,re.I|re.S)

        for xym in imglistnamecln:
            oldnameimg = xym.split('<-*->')
            xml_data = xml_data.replace(oldnameimg[0], oldnameimg[1])

        for key, value in arr101.items():
            # xml_data=xml_data.replace(key,value)
            xml_data=re.sub(r'(<a(?: [^>]*)? href=")[^"]*.xhtml#'+key+r'("[^>]*>)',r'\g<1>'+arr101[key]+r'">',xml_data,0,re.I|re.S)
        for key, value in arr1022.items():
            # xml_data=xml_data.replace(key,value)
            chapnumberfilename=_filename1[x].split("_")
            chapnumberfilename1=(chapnumberfilename[len(chapnumberfilename)-1]).replace("C","").replace(".xhtml","")

            for xml_data_serch in re.finditer(r'(<a(?: [^>]*)? href=")[^"]*.xhtml#'+key+r'("[^>]*>)((?:(?!</a>).)*)</a>', xml_data, re.I | re.S):

                xml_data = re.sub(xml_data_serch.group(),xml_data_serch.group(1)+arr1022[key]+str(chapnumberfilename1)+'en'+xml_data_serch.group(3)+xml_data_serch.group(2)+'<span class="number">'+xml_data_serch.group(3)+'</span></a>', xml_data,0, re.I | re.S)
                try:
                    arr1012_fin[key] = arr1022[key]+str(chapnumberfilename1)+'en'+xml_data_serch.group(3)

                except:
                    pass

        for xml_data_fig in re.finditer(r'(Figures([\w&.\-]+)?)\s((\d+).)(\d+)?\sand\s((\d+).)(\d+)?',xml_data):
            digmatchap=xml_data_fig.group(4)
            digmatfig=xml_data_fig.group(5)
            if 0 < int(digmatchap) <= 9:
                val1="ch0"+str(digmatchap)
            else:
                val1 = "ch" + str(digmatchap)
            if 0 < int(digmatfig) <= 9:
                val2 = "fig0" + str(digmatfig)
            else:
                val2 = "fig" + str(digmatfig)
            val0=val1+val2
            str1='<a class="xref" href="#'+val0+'"><span class="label">'+xml_data_fig.group(1)+'</span><span class="number"><span data-profile-product="core">'+xml_data_fig.group(3)+'</span>'+xml_data_fig.group(5)+'</span></a>'
            digmatchap = xml_data_fig.group(7)
            digmatfig = xml_data_fig.group(8)
            if 0 < int(digmatchap) <= 9:
                val11 = "ch0" + str(digmatchap)
            else:
                val11 = "ch" + str(digmatchap)
            if 0 < int(digmatfig) <= 9:
                val22 = "fig0" + str(digmatfig)
            else:
                val22 = "fig" + str(digmatfig)
            val00 = val11 + val22
            str2 = '<a class="xref" href="#' + val00 + '"><span class="label">' + xml_data_fig.group(1) + '</span><span class="number"><span data-profile-product="core">' + xml_data_fig.group(7) + '</span>' + xml_data_fig.group(8) + '</span></a>'
            finstr=str1+" and "+str2
            xml_data=xml_data.replace(xml_data_fig.group(),finstr)
        for xml_data_fig in re.finditer(r'(Tables([\w&.\-]+)?)\s((\d+).)(\d+)?\sand\s((\d+).)(\d+)?',xml_data):
            digmatchap=xml_data_fig.group(4)
            digmatfig=xml_data_fig.group(5)
            if 0 < int(digmatchap) <= 9:
                val1="ch0"+str(digmatchap)
            else:
                val1 = "ch" + str(digmatchap)
            if 0 < int(digmatfig) <= 9:
                val2 = "tab0" + str(digmatfig)
            else:
                val2 = "tab" + str(digmatfig)
            val0=val1+val2
            str1='<a class="xref" href="#'+val0+'"><span class="label">'+xml_data_fig.group(1)+'</span><span class="number"><span data-profile-product="core">'+xml_data_fig.group(3)+'</span>'+xml_data_fig.group(5)+'</span></a>'
            digmatchap = xml_data_fig.group(7)
            digmatfig = xml_data_fig.group(8)
            if 0 < int(digmatchap) <= 9:
                val11 = "ch0" + str(digmatchap)
            else:
                val11 = "ch" + str(digmatchap)
            if 0 < int(digmatfig) <= 9:
                val22 = "tab0" + str(digmatfig)
            else:
                val22 = "tab" + str(digmatfig)
            val00 = val11 + val22
            str2 = '<a class="xref" href="#' + val00 + '"><span class="label">' + xml_data_fig.group(1) + '</span><span class="number"><span data-profile-product="core">' + xml_data_fig.group(7) + '</span>' + xml_data_fig.group(8) + '</span></a>'
            finstr=str1+" and "+str2
            xml_data=xml_data.replace(xml_data_fig.group(),finstr)

        for xml_data_fig in re.finditer(r'(Figure([\w&.\-]+)?)\s*((\d+).)(\d+)?',xml_data):
            digmatchap=xml_data_fig.group(4)
            digmatfig=xml_data_fig.group(5)
            if 0 < int(digmatchap) <= 9:
                val1="ch0"+str(digmatchap)
            else:
                val1 = "ch" + str(digmatchap)
            if 0 < int(digmatfig) <= 9:
                val2 = "fig0" + str(digmatfig)
            else:
                val2 = "fig" + str(digmatfig)
            val=val1+val2
            xml_data=xml_data.replace(xml_data_fig.group(),'<a class="xref" href="#'+val+'"><span class="label">'+xml_data_fig.group(1)+'</span><span class="number"><span data-profile-product="core">'+xml_data_fig.group(3)+'</span>'+xml_data_fig.group(5)+'</span></a>')

        for xml_data_tab in re.finditer(r'(Table([\w&.\-]+)?)\s*((\d+).)(\d+)?',xml_data):
            digmatchap=xml_data_tab.group(4)
            digmatfig=xml_data_tab.group(5)
            if 0 < int(digmatchap) <= 9:
                val1="ch0"+str(digmatchap)
            else:
                val1 = "ch" + str(digmatchap)
            if 0 < int(digmatfig) <= 9:
                val2 = "tab0" + str(digmatfig)
            else:
                val2 = "tab" + str(digmatfig)
            val=val1+val2
            xml_data=xml_data.replace(xml_data_tab.group(),'<a class="xref" href="#'+val+'"><span class="label">'+xml_data_tab.group(1)+'</span><span class="number"><span data-profile-product="core">'+xml_data_tab.group(3)+'</span>'+xml_data_tab.group(5)+'</span></a>')

        
        xml_data=re.sub(r'(<a(?: [^>]*)?) data-uri="[^"]*"([^>]*?>)',r'\1\2',xml_data,0,re.I|re.S)


        for xml_data_chapter in re.finditer(r'(chapter)\s+(\d+)',xml_data,re.I|re.S):
            if xml_data_chapter.group():
                chapname=xml_data_chapter.group(1)
                chapnum=xml_data_chapter.group(2)


                # chapternumber=re.search(r'\d+',chapnum,re.I|re.S)
                if 0 < int(chapnum) <= 9:
                    _filename1[x] = re.sub(r'M\d+',r'M0'+chapnum,_filename1[x],0,re.I|re.S)
                    _filename1[x] = re.sub(r'C\d+',r'C0'+chapnum,_filename1[x],0,re.I|re.S)
                    # if chapternumber.group():
                    xml_data=xml_data.replace(xml_data_chapter.group(),'<a href="'+_filename1[x]+'#ch0'+chapnum+'" class="xref"><span class="label">'+chapname+' </span><span class="number"><span data-profile-product="core">'+chapnum+'</span></span></a>')
                else:
                    _filename1[x] = re.sub(r'C\d+', r'C' + chapnum, _filename1[x], 0, re.I | re.S)
                    _filename1[x] = re.sub(r'M\d+',r'M'+chapnum,_filename1[x],0,re.I|re.S)
                    # if chapternumber.group():
                    xml_data=xml_data.replace(xml_data_chapter.group(),'<a href="'+_filename1[x]+'#ch'+chapnum+'" class="xref"><span class="label">'+chapname+' </span><span class="number"><span data-profile-product="core">'+chapnum+'</span></span></a>')


        for xml_data_chapter in re.finditer(r'(Chapters)\s(\d+)\sand\s(\d+)', xml_data, re.I | re.S):
            if xml_data_chapter.group():
                chapname = xml_data_chapter.group(1)
                chapnum = xml_data_chapter.group(2)
                chapnum1 = xml_data_chapter.group(3)

                # chapternumber=re.search(r'\d+',chapnum,re.I|re.S)
                if 0 < int(chapnum) <= 9:
                    _filename10 = re.sub(r'M\d+', r'M0' + chapnum, _filename1[x], 0, re.I | re.S)
                    _filename10 = re.sub(r'C\d+', r'C0' + chapnum, _filename10, 0, re.I | re.S)
                    # if chapternumber.group():
                    # xml_data = xml_data.replace(xml_data_chapter.group(), '<a href="' + _filename1[x] + '#ch0' + chapnum + '" class="xref"><span class="label">' + chapname + ' </span><span class="number"><span data-profile-product="core">' + chapnum + '</span></span></a>')
                    xml_data_str_val1='<a href="' + _filename10 + '#ch0' + chapnum + '" class="xref"><span class="label">' + chapname + ' </span><span class="number"><span data-profile-product="core">' + chapnum + '</span></span></a>'
                else:
                    _filename10 = re.sub(r'C\d+', r'C' + chapnum, _filename1[x], 0, re.I | re.S)
                    _filename10 = re.sub(r'M\d+', r'M' + chapnum, _filename10, 0, re.I | re.S)
                    # if chapternumber.group():
                    # xml_data = xml_data.replace(xml_data_chapter.group(), '<a href="' + _filename1[x] + '#ch' + chapnum + '" class="xref"><span class="label">' + chapname + ' </span><span class="number"><span data-profile-product="core">' + chapnum + '</span></span></a>')
                    xml_data_str_val1 = '<a href="' + _filename10 + '#ch' + chapnum + '" class="xref"><span class="label">' + chapname + ' </span><span class="number"><span data-profile-product="core">' + chapnum + '</span></span></a>'

                if 0 < int(chapnum1) <= 9:
                    _filename12 = re.sub(r'M\d+', r'M0' + chapnum1, _filename1[x], 0, re.I | re.S)
                    _filename12 = re.sub(r'C\d+', r'C0' + chapnum1, _filename12, 0, re.I | re.S)
                    # if chapternumber.group():
                    # xml_data = xml_data.replace(xml_data_chapter.group(), '<a href="' + _filename1[x] + '#ch0' + chapnum + '" class="xref"><span class="label">' + chapname + ' </span><span class="number"><span data-profile-product="core">' + chapnum + '</span></span></a>')
                    xml_data_str_val2 = '<a href="' + _filename12 + '#ch0' + chapnum1 + '" class="xref"><span class="label">' + chapname + ' </span><span class="number"><span data-profile-product="core">' + chapnum1 + '</span></span></a>'
                else:
                    _filename12 = re.sub(r'C\d+', r'C' + chapnum1, _filename1[x], 0, re.I | re.S)
                    _filename12 = re.sub(r'M\d+', r'M' + chapnum1, _filename12, 0, re.I | re.S)
                    # if chapternumber.group():
                    # xml_data = xml_data.replace(xml_data_chapter.group(), '<a href="' + _filename1[x] + '#ch' + chapnum + '" class="xref"><span class="label">' + chapname + ' </span><span class="number"><span data-profile-product="core">' + chapnum + '</span></span></a>')
                    xml_data_str_val2 = '<a href="' + _filename12 + '#ch' + chapnum1 + '" class="xref"><span class="label">' + chapname + ' </span><span class="number"><span data-profile-product="core">' + chapnum1 + '</span></span></a>'
                xml_data=xml_data.replace(xml_data_chapter.group(),xml_data_str_val1+" and "+xml_data_str_val2)

        xml_data2 = '<?xml version="1.0" encoding="utf-8"?><html xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/1999/xhtml" xmlns:m="http://www.w3.org/1998/Math/MathML" xml:lang="en" lang="en"><head><title data-profile-deliveryformat="digital">' +"temp title"+ '</title><meta name="PXID_XML_Styler" content="v3023"/><meta charset="UTF-8"/><meta name="dcterms.conformsTo" content="PXE 1.39 ProductLevelReuse"/><meta name="generator" content="PXE Tools version 1.39.158"/><link rel="alternate stylesheet" type="text/css" title="night" href="file:///C:\itools\PXID_Integrated/redserif/css/theme/redserif/night.css"/><link rel="alternate stylesheet" type="text/css" title="sepia" href="file:///C:\itools\PXID_Integrated/redserif/css/theme/redserif/sepia.css"/><link rel="alternate stylesheet" type="text/css" title="print" href="file:///C:\itools\PXID_Integrated/redserif/css/theme/redserif/print.css"/><link rel="alternate stylesheet" type="text/css" title="default" href="file:///C:\itools\PXID_Integrated/redserif/css/theme/redserif/default.css"/><link rel="stylesheet" type="text/css" title="main" href="file:///C:\itools\PXID_Integrated/redserif/css/main.css"/><link rel="stylesheet" type="text/css" title="night" href="file:///C:\itools\PXID_Integrated/redserif/css/night.css"/><link rel="stylesheet" type="text/css" title="sepia" href="file:///C:\itools\PXID_Integrated/redserif/css/sepia.css"/><script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"/><script src="file:///C:\itools\PXID_Integrated/ELDS/css/theme/redserif/refviiew.js"/><link rel="stylesheet" type="text/css" href="../css/local.css"/><script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.4/MathJax.js?config=MML_HTMLorMML"/></head>'
        # xml_data = xml_data.replace(xml_data3.group(), xml_data2)
        # if xml_data3.group():
        #     # xml_data = re.sub(xml_data3.group(), xml_data2, xml_data, 0, re.I | re.S)
        #     xml_data = xml_data.replace(xml_data3.group(), xml_data2)

        try:
            xml_data010=re.search(r'<h1(?: [^>]*)? class="titleOption1"[^>]*?>((?:(?!</h1>).)*)</h1>',xml_data,re.I|re.S)
            if xml_data010.group():
                xml_data0100 = re.search(r'<h1(?: [^>]*)?>(?:(?![^>]$).)*</(?:[^>]*)?>((?:(?!</h1>).)*)</h1>', xml_data010.group(),re.I | re.S)
                if xml_data0100.group():
                    titilechap=xml_data0100.group(1)
                    xml_data=re.sub(r'(<title(?: [^>]*)?>)((?:(?!</title>).)*)(</title>)',r'\1'+titilechap+r'\3',xml_data,0,re.I|re.S)
                    xml_data=re.sub(r'temp_title_temp_temp_temp',titilechap,xml_data,0,re.I|re.S)

        except:
            pass

        count=0
        try:
            for xml_data15 in re.finditer(r'<p(?: [^>]*)? class="paragraphLearningObjective"[^>]*?>((?:(?!</p>).)*)</p>',xml_data,re.I|re.S):
                # finalliststring=""
                # finalliststring1=""
                if xml_data15:
                    listtagadd=re.search(r'<span(?: [^>]*)?>(?:(?!</span>).)*</span>\s*((?:[^<]*)*)',xml_data15.group(1),re.I|re.S)
                    if listtagadd:
                        listtagadd1=listtagadd.group()
                        listtagadd1=re.sub(r'<span(?: [^>]*)?>(?:(?!</span>).)*</span>',r'',listtagadd1,0,re.I|re.S)
                        finalliststring="<ol id=\"ch01ol01\" class=\"objectivelist\"><li class=\"objective\">"+listtagadd1+"</li></ol>"
                    else:

                        xml_data156=xml_data15.group(1)
                        xml_data156 = re.sub(r'• ', '', xml_data156,0, re.I | re.S)
                        finalliststring="<ul><li>"+xml_data156+"</li></ul>"

                if xml_data15:
                    xml_data150=xml_data15.group()
                    xml_data=xml_data.replace(xml_data150,finalliststring)
        except Exception as e:
            pass
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)
            print(e)

        for xml_data4 in re.finditer(r'<body(?: [^>]*)?>(?:(?!</body>).)*</body>', xml_data, re.I | re.S):
            try:
                sectionupdate1=xml_data4.group()
                sectionupdate2=re.search(r'<span(?: [^>]*)? class="chapterLabelOption1"[^>]*?>((?:(?!</span>).)*)</span>',sectionupdate1,re.I|re.S)
                sectionupdate22=sectionupdate2.group(1)
                sectionupdate3 = re.search(r'<span(?: [^>]*)? class="chapterNumberOption1"[^>]*?>((?:(?!</span>).)*)</span>',sectionupdate1, re.I | re.S)
                sectionupdate33 = sectionupdate3.group(1)
                sectionupdate4=re.search(r'<h1(?: [^>]*)? class="titleOption1"[^>]*?>((?:(?!</h1>).)*)</h1>',sectionupdate1,re.I|re.S)
                sectionupdate4=re.sub(r'<span(?:[^>])?(?:(?!</span>).)*</span>','',sectionupdate4.group(1),0,re.I|re.S)
                sectionupdate44 = sectionupdate4


                string5="<section id=\"ch0"+sectionupdate33+" class=\"chapter\" data-chunk=\"1\">\n<header>\n<h1 class=\"title\"><span class=\"label\">"+sectionupdate22+"</span><span class=\"number\">"+sectionupdate33+"</span>"+sectionupdate44+"</h1>\n</header>"
                # xml_data = re.sub(r'<header(?: [^>]*)?>(?:(?!<h1 >).)*<h1(?: [^>]*)>.*</header>',string5,xml_data,0, re.I|re.S)
                xml_data = re.sub(r'<header(?: [^>]*)?>(?:(?!</header>).)*</header>',string5,xml_data,0, re.I|re.S)
            except:
                pass

        for figurecontent in re.finditer(r'<figure(?: [^>]*)? class="figureImageTextWidth"[^>]*?>((?:(?!</figure>).)*)</figure>\s*<details(?: [^>]*)?>((?:(?!</details>).)*)</details>',xml_data,re.I|re.S):

            genlablecnt0=re.search(r'<img(?: [^>]*)? src=("[^"]*")?(?: [^>]*) alt=("[^"]*")?([^>]*?>)',figurecontent.group(),re.I|re.S)
            if genlablecnt0:
                src01=genlablecnt0.group(1)
                alt01=genlablecnt0.group(2)
                imgstring010="<img src="+src01+" data-profile-deliveryformat=\"digital\" height=\"0\" width=\"0\" alt="+alt01+" aria-describedby=\"ch01fig01-desc\"/>"
                # print(src01)
                # print(alt01)
            else:
                imgstring010=""
            genlablecnt=re.search(r'<span(?: [^>]*)? class="genericLabel"[^>]*?>((?:(?!</span>).)*)</span>',figurecontent.group(),re.I|re.S)
            if genlablecnt:
                v=genlablecnt.group(1)
                v=re.sub(r'<(?:[^>]*)?>',r'',v,0,re.I|re.S)
                v=re.sub(r'\r ','',v,re.I|re.S)
            else:
                v=""
            for genlablecnt2 in re.finditer(r'<strong(?: [^>]*)?>((?:(?!</strong>).)*)</strong>',figurecontent.group(),re.I|re.S):
                genlablecnt22 = genlablecnt2.group(1)
            if genlablecnt:
                genlablecnt1=v
            else:
                genlablecnt1=""
            if not genlablecnt2:
                # genlablecnt22 = genlablecnt2.group(1)
                genlablecnt22 = ""
            # else:
            #     genlablecnt22=""

            if not genlablecnt1=="":
                genlablecnt1_0=genlablecnt1.split(" ")[0]
            else:
                genlablecnt1_0=""

            names = genlablecnt1
            delims = [",", "-", "."]
            num1=[]
            dotvalue="."
            try:
                for x in delims[1:]:
                    if x in names:
                        names = names.replace(x, delims[0])
                        dotvalue=x
                num = names.split(" ")[1]
                num1 = num.split(",")
            except Exception as e:
                pass
                
                num1.append("")
                num1.append("")
            # print(num1[1])
            if len(num1)==2:
                finfiglabstring="<figure id=\"ch01fig01\" class=\"figure\"><header><h1 class=\"title\"><span class=\"label\">"+genlablecnt1_0+" </span><span class=\"number\"><span data-profile-product=\"core\">"+num1[0]+str(dotvalue)+"</span>"+num1[1]+" </span>"+genlablecnt22+"</h1></header>"
            elif len(num1)==1:
                num1.append("")
                finfiglabstring = "<figure id=\"ch01fig01\" class=\"figure\"><header><h1 class=\"title\"><span class=\"label\">" + genlablecnt1_0 + " </span><span class=\"number\"><span data-profile-product=\"core\">" + num1[0] +str(dotvalue)+"</span>" + num1[1] + " </span>" + genlablecnt22 + "</h1></header>"
            else:
                finfiglabstring = "<figure id=\"ch01fig01\" class=\"figure\"><header><h1 class=\"title\"><span class=\"label\">" + genlablecnt1_0 + " </span><span class=\"number\"><span data-profile-product=\"core\">" + num1[0] +str(dotvalue)+"</span>" + num1[1] + " </span>" + genlablecnt22 + "</h1></header>"


            detailscont=re.search(r'<summary(?: [^>]*)?>((?:(?!</summary>).)*)</summary>',figurecontent.group(2),re.I|re.S)
            detailscont1=re.search(r'<div(?: [^>]*)?>((?:(?!</div>).)*)</div>',figurecontent.group(2),re.I|re.S)

            if detailscont:
                summarycont=detailscont.group(1)
            else:
                summarycont=""

            if detailscont1:
                summarycont1=detailscont1.group(1)
            else:
                summarycont1=""

            uptcontdetails="<figcaption>\n<details class=\"longdesc\" id=\"ch01fig01-desc\">\n<summary><span class=\"label\">"+summarycont+"</span></summary>\n<p>"+summarycont1+"</p></details>\n</figcaption>\n</figure>"

            xml_data = xml_data.replace(figurecontent.group(), finfiglabstring+imgstring010+uptcontdetails)
            

        xml_data = re.sub(r'<aside(?: [^>]*)? class="divLearningObjectives"[^>]*?>', r'', xml_data, 0, re.I | re.S)

        xml_data = re.sub(r'<p(?: [^>]*)>', '<p>', xml_data,0, re.I | re.S)
        xml_data = re.sub(r'</li>\s*</ol>\s*<ol id="ch01ol01" class="objectivelist">\s*<li class="objective">', '</li>\n<li class="objective">', xml_data,0, re.I | re.S)
        xml_data = re.sub(r'</li>\s*</ol>\s*<ul>\s*<li>', '</p>\n<ul>\n<li><p>', xml_data,0, re.I | re.S)
        xml_data = re.sub(r'</li>\s*</ul>\s*<ul>\s*<li>', '</li>\n<li>', xml_data,0, re.I | re.S)
        xml_data = re.sub(r'</li>\s*</ul>\s*<ol id="ch01ol01" class="objectivelist">\s*<li class="objective">', '</li>\n</ul></li>\n<li class="objective">', xml_data,0, re.I | re.S)
        xml_data = re.sub(r'<li>• ', '<li>', xml_data,0, re.I | re.S)

        xml_data = re.sub(r'<li(?: [^>]*)?>', '<li>', xml_data,0, re.I | re.S)
        xml_data = re.sub(r'data-versionUrn=("[^"]*")?(?: [^>]*)*', '', xml_data,0, re.I | re.S)
        xml_data = re.sub(r'data-uri=("[^"]*")?(?: [^>]*)*', '', xml_data,0, re.I | re.S)
        xml_data = re.sub(r'>• ', '>', xml_data,0, re.I | re.S)
        xml_data = re.sub(r'>>', '>', xml_data,0, re.I | re.S)
        xml_data = re.sub(r'<<', '<', xml_data,0, re.I | re.S)

        chapnumberfilename001 = pathtofilenameonly.split("_")
        chapnumberfilename100 = (chapnumberfilename001[len(chapnumberfilename001) - 1]).replace("C", "").replace(".xhtml", "")
        chapnumberfilename1000=str(chapnumberfilename100).zfill(2)
        BsecId = 1
        BsecId1 = 1
        id=itertools.count(1)
        id12=itertools.count(1)
       

        xml_data = re.sub(r'<h1(?: [^>]*)? class="heading1NummerEins"[^>]*?>((?:(?!</h1>).)*)</h1>', r'<section id="ch'+chapnumberfilename1000+'lvl2sec'+str(BsecId)+r'" data-chunk="1">\n<header>\n<h1 class="title">\g<1></h1>\n</header>', xml_data,0, re.I | re.S)
        xml_data=re.sub(r'(<section id="[^"]*)sec1(")',lambda x: x.group(1)+'sec'+str(next(id))+"\"",xml_data,0,re.I|re.S)

        xml_data = re.sub(r'<h2(?: [^>]*)? class="heading2learningObjectiveItem"[^>]*?>((?:(?!</h2>).)*)</h2>', r'<section id="ch'+chapnumberfilename1000+'lvl3sec'+str(BsecId)+r'" data-chunk="1">\n<header>\n<h1 class="title">\g<1></h1>\n</header>', xml_data,0, re.I | re.S)
        xml_data=re.sub(r'(<section id="[^"]*)sec1(")',lambda x: x.group(1)+'sec'+str(next(id12))+"\"",xml_data,0,re.I|re.S)

        xml_data = re.sub(r'(<li(?: [^>]*)?>)((?:(?!</li>).)*)(</li>)', r'\1<p>\2</p>\3', xml_data, 0, re.I | re.S)
        xml_data = re.sub(r'(<div(?: [^>]*)? class="divLearningObjectiveListHeaderLabel"[^>]*?>\s*<h2(?: [^>]*)>)((?:(?!</h2[^>]*).)*)(\s*</h2>\s*</div>)',r'<section class="objectiveset"><header><h1 class="title"><span class="label">\2</span></h1></header>',xml_data, 0, re.I | re.S)
        xml_data = re.sub(r'\n\n+', '\n', xml_data, 0, re.I | re.S)
        xml_data = re.sub(r'</aside></div>', '</div>', xml_data, 0, re.I | re.S)
        xml_data = re.sub(r'<p>\n<p>', '<p>', xml_data, 0, re.I | re.S)
       
        xml_data = re.sub(r' style="[^"]*"((?: [^>]*)?)', r'', xml_data, 0, re.I | re.S)
        xml_data = re.sub(r' data-mce-style="[^"]*"', r'', xml_data, 0, re.I | re.S)
      
        xml_data = re.sub(r'<div(?: [^>]*)? class="container"[^>]*?>((?:(?!</div>).)*)</div>', r'\g<1>', xml_data, 0,re.I | re.S)

        count = 1
        for xml_data_ul in re.finditer(r'<ul(?: [^>]*)? id=("[^"]*")?(?: [^>]*)>', xml_data, re.I | re.S):
            # ch01ul01 .zfill(4)

            chapnumberfilename=pathtofilenameonly.split("_")
            chapnumberfilename1=(chapnumberfilename[len(chapnumberfilename)-1]).replace("C","").replace(".xhtml","")
            stringfinalul="ch"+str(chapnumberfilename1).zfill(2)+"ul"+str(count).zfill(2)
            xml_data = re.sub(xml_data_ul.group(1),"\""+stringfinalul+"\"", xml_data, 0, re.I | re.S)
            count=count+1
        for xml_data_ul in re.finditer(r'<ol(?: [^>]*)? id=("[^"]*")?(?: [^>]*)>', xml_data, re.I | re.S):
            # ch01ul01 .zfill(4)

            chapnumberfilename = pathtofilenameonly.split("_")
            chapnumberfilename1 = (chapnumberfilename[len(chapnumberfilename) - 1]).replace("C", "").replace(".xhtml", "")
            stringfinalul = "ch" + str(chapnumberfilename1).zfill(2) + "ol" + str(count).zfill(2)
            xml_data = re.sub(xml_data_ul.group(1), "\"" + stringfinalul + "\"", xml_data, 0, re.I | re.S)
            count = count + 1
        
        xml_data = re.sub(r'data-versionUrn="[^"]*"', '', xml_data, re.I | re.S)
        xml_data = re.sub(r'<strong id="[^>]*>', '<strong>', xml_data, re.I | re.S)
        xml_data = re.sub(r'<em id="[^>]*>', '<em>', xml_data, re.I | re.S)
        xml_data = re.sub(r'<div[^>]*>\s+\n</div>', '', xml_data, re.I | re.S)
        xml_data = re.sub(r'<li(?: [^>]*)?>\s*</li>', '', xml_data, 0, re.I | re.S)
        xml_data = re.sub(r'  ', ' ',xml_data,0,re.I|re.S)
        xml_data = re.sub(r'\" +>', '\">',xml_data,0,re.I|re.S)

        xml_data = re.sub(r'</li><li>', '</li>\n<li>', xml_data, 0, re.I | re.S)
        xml_data = re.sub(r'\n+\s+', '\n', xml_data, 0, re.I | re.S)
        xml_data = re.sub(r'\s+<strong>', ' <strong>', xml_data, 0, re.I | re.S)
        xml_data = re.sub(r'\s+<em>', ' <em>', xml_data, 0, re.I | re.S)
        xml_data = re.sub(r'<p>\s+', '<p>', xml_data, 0, re.I | re.S)
        xml_data = re.sub(r'\s+<a', ' <a', xml_data, 0, re.I | re.S)
        xml_data = re.sub(r'\s+<span', ' <span', xml_data, 0, re.I | re.S)
        xml_data = re.sub(r'\s\s</span>', ' </span>', xml_data, 0, re.I | re.S)
        xml_data = re.sub(r'\n+</em>', '</em>', xml_data, 0, re.I | re.S)
        xml_data = re.sub(r'\n+</strong>', '</strong>', xml_data, 0, re.I | re.S)
        xml_data = re.sub(r'<td>\s+\n+', '<td>',xml_data,0,re.I|re.S)
        xml_data = re.sub(r'<td>\s+\n+<span', '<td><span',xml_data,0,re.I|re.S)
        xml_data = re.sub(r'<th>\s+\n+', '<th>',xml_data,0,re.I|re.S)
        xml_data = re.sub(r'<td>\s+', '<td>', xml_data, 0, re.I | re.S)
        xml_data = re.sub(r'<th>\s+', '<th>', xml_data, 0, re.I | re.S)
        # xml_data = re.sub(r'<p>\s+\n+', '<p>', xml_data, 0, re.I | re.S)
        # # xml_data = re.sub(r'<p>\s+\n+', '<p>', xml_data, 0, re.I | re.S)
        xml_data = xml_data.replace('\r', '')

        # with open(pathtofile1, "w", encoding="utf-8") as f1:
        with codecs.open(pathtofile1, "w", encoding='utf-8', errors='ignore') as f1:
            f1.write(xml_data)
            f1.close()


   
try:
    with open(xhtml_Path+"\\toc.xhtml", "r", encoding="utf-8") as f1:
        xml_data_toc=f1.read()
        f1.close()
except:
    pass

for x in range (len(_filename1)):
    pathtofile=xhtml_Path+"\\"+_filename1[x]
    pathtofileoutput=xhtml_Path+"\\output\\"+_filename1[x]
    matchedfile=re.search(r'(_GLOS.xhtml)$',_filename1[x],re.I|re.S)
    if matchedfile:
        with codecs.open(pathtofile, "r", encoding='utf8', errors='ignore') as file1:
            xml_data_101101 = file1.read()

        for key, value in arr1012.items():
            xml_data_101101=xml_data_101101.replace(key,value)
        # print(xml_data_1)
        with open(pathtofileoutput, "w", encoding="utf-8") as f1:
            f1.write(xml_data_101101)
            f1.close()

for x in range (len(_filename1)):
    pathtofile=xhtml_Path+"\\"+_filename1[x]
    pathtofileoutput=xhtml_Path+"\\output\\"+_filename1[x]
    matchedfile=re.search(r'(_NOTE.xhtml)$',_filename1[x],re.I|re.S)
    if matchedfile:
        with codecs.open(pathtofile, "r", encoding='utf8', errors='ignore') as file1:
            xml_data_1 = file1.read()

        for key, value in arr1012_fin.items():
            xml_data_1=xml_data_1.replace(key,value)
        # print(xml_data_1)
        with open(pathtofileoutput, "w", encoding="utf-8") as f1:
            f1.write(xml_data_1)
            f1.close()


xml_data_toc1=re.findall(r'<a(?: [^>]*)?>(?:(?!</a>).)*</a>',xml_data_toc,re.I|re.S)
# print(len(xml_data_toc1))

a = xml_data_toc1
duplicatelist=[]

duplicatelist=([item for item, count in collections.Counter(a).items() if count > 1])
# print(len(duplicatelist))
for xm in duplicatelist:
    xm1=xm.replace("<a","<amdup")
    xm1=xm1.replace("</a","</amdup")
    xml_data_toc=xml_data_toc.replace(xm,xm1,1)

for xm10 in duplicatelist:
    xml_data_toc=xml_data_toc.replace(xm10,"",1)

for xm110 in duplicatelist:
    xm12=xm110.replace("<a","<amdup")
    xm12=xm12.replace("</a","</amdup")
    xml_data_toc=xml_data_toc.replace(xm12,xm110,1)

# ------ Local tracking ------------------
_local_tracking(tool_id, ToolVersion, Tra_input, _get_file_size(Tra_input), st_time, _get_timestamp());
# -----------------------------------------

print("\nProcess completed...!!!")
sys.exit()
