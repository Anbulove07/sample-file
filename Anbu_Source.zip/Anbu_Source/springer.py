import itertools
import re
import sys
from iModule.Basic import _open_utf8
from os.path import dirname
import os

from iconfig import _url_entity_Conversion, convert_symbols_to_entities

ToolPath = dirname(sys.argv[0]);
static_folder = os.path.join(os.path.dirname(__file__), 'static')
uploads_folder = os.path.join(static_folder, 'uploads')

folder_path = uploads_folder
files = os.listdir(folder_path)

for file in files:
    if re.search(r'_JobSheet_', file):
        jobsheetpath = uploads_folder + "\\" + file
        jobsheetcnt = _open_utf8(jobsheetpath)


# def _body_conversion(bodycnt):
#     bodycnt=re.sub(r'<body>','<Body>',cnt,0,re.I|re.S)
#
InlineIdCount = itertools.count(1);

def front_conversion(cnt):
    # print(files)
    # if re.search(r'<\?xml(?: [^>]*)?>\s*<!DOCTYPE(?: [^>]*)?>', jobsheetcnt,re.I|re.S):
    #     xmlDoctype=re.search(r'<\?xml(?: [^>]*)?>\s*<!DOCTYPE(?: [^>]*)?>', jobsheetcnt,re.I|re.S).group()
    xmlDoctype='''<?xml version="1.0" encoding="UTF-8" standalone="no"?>\n<!DOCTYPE Article PUBLIC "-//Springer-Verlag//DTD A++ V2.4//EN" "http://devel.springer.de/A++/V2.4/DTD/A++V2.4.dtd"[]>"'''
    cnt=re.sub(r'<\?xml(?: [^>]*)?>\s*<!DOCTYPE(?: [^>]*)?>',xmlDoctype,cnt,0,re.I|re.S)
    article=''
    if re.search(r'<JournalDOI(?: [^>]*)?>((?:(?!</JournalDOI>).)*)</JournalDOI>', jobsheetcnt,re.I|re.S):
        doi1=re.search(r'<JournalDOI(?: [^>]*)?>((?:(?!</JournalDOI>).)*)</JournalDOI>', jobsheetcnt,re.I|re.S).group(1)
        doi=doi1.split('/')[1]
        article=f'<Article ID="{doi}" OutputMedium="All">\n<?Info PoweredbyACDC?>\n<ArticleInfo ArticleType="OriginalPaper" ContainsESM="Yes" NumberingStyle="Unnumbered" TocLevels="0" OutputMedium="All" Language="En">'
    if re.search(r'<ArticleID(?: [^>]*)?>((?:(?!</ArticleID>).)*)</ArticleID>',jobsheetcnt,re.I|re.S):
        articleID=re.search(r'<ArticleID(?: [^>]*)?>((?:(?!</ArticleID>).)*)</ArticleID>',jobsheetcnt,re.I|re.S).group(1)
        article=article+f'\n<ArticleID>{articleID}</ArticleID>'
        article=article+f'\n<ArticleDOI>{doi1}</ArticleDOI>'
        article=article+f'\n<ArticleSequenceNumber>0</ArticleSequenceNumber>'
    if re.search(r'<article-meta(?: [^>]*)?>((?:(?!</article-meta>).)*)</article-meta>',cnt,re.I|re.S):
        articleMeta=re.search(r'<article-meta(?: [^>]*)?>((?:(?!</article-meta>).)*)</article-meta>',cnt,re.I|re.S).group(1)
        if re.search(r'<article-title(?: [^>]*)?>((?:(?!</article-title>).)*)</article-title>',articleMeta,re.I|re.S):
            articleMetatitle=re.search(r'<article-title(?: [^>]*)?>((?:(?!</article-title>).)*)</article-title>',articleMeta,re.I|re.S).group(1)
            article=article+f'\n<ArticleTitle Language="En" OutputMedium="All">{articleMetatitle}</ArticleTitle>'

    if re.search(r'<fpage(?: [^>]*)?>((?:(?!</fpage>).)*)</fpage>',cnt,re.I|re.S):
        fpage=re.search(r'<fpage(?: [^>]*)?>((?:(?!</fpage>).)*)</fpage>',cnt,re.I|re.S).group(1)
        article=article+f'\n<ArticleFirstPage>{fpage}</ArticleFirstPage>'
    if re.search(r'<lpage(?: [^>]*)?>((?:(?!</lpage>).)*)</lpage>',cnt,re.I|re.S):
        lpage=re.search(r'<lpage(?: [^>]*)?>((?:(?!</lpage>).)*)</lpage>',cnt,re.I|re.S).group(1)
        article=article+f'\n<ArticleLastPage>{lpage}</ArticleLastPage>'
    if re.search(r'<history(?: [^>]*)?>((?:(?!</history>).)*)</history>',cnt,re.I|re.S):
        history=re.search(r'<history(?: [^>]*)?>((?:(?!</history>).)*)</history>',cnt,re.I|re.S).group(1)
        for date in re.finditer(r'<p(?: [^>]*)?>((?:(?!</p>).)*)</p>',history,re.I|re.S):
            if re.search(r'Received\s\d+\s\w+\s\d+',date.group(1),re.I|re.S):
                received=re.search(r'Received\s(\d+)\s(\w+)\s(\d+)',date.group(1),re.I|re.S)
                historytag =f'\n<Received>\n<Year>{received.group(3)}</Year>\n<Month>{received.group(2)}</Month>\n<Day>{received.group(1)}</Day>\n</Received>'
            if re.search(r'Accepted\s\d+\s\w+\s\d+',date.group(1),re.I|re.S):
                accepted=re.search(r'Accepted\s(\d+)\s(\w+)\s(\d+)',date.group(1),re.I|re.S)
                historytag =historytag+ f'\n<Accepted>\n<Year>{accepted.group(3)}</Year>\n<Month>{accepted.group(2)}</Month>\n<Day>{accepted.group(1)}</Day>\n</Accepted>'
            if re.search(r'RegistrationDate\s\d+\s\w+\s\d+',date.group(1),re.I|re.S):
                registration=re.search(r'RegistrationDate\s(\d+)\s(\w+)\s(\d+)',date.group(1),re.I|re.S)
                historytag =historytag+f'\n<RegistrationDate>\n<Year>{registration.group(3)}</Year>\n<Month>{registration.group(2)}</Month>\n<Day>{registration.group(1)}</Day>\n</RegistrationDate>'
            if re.search(r'Revised\s\d+\s\w+\s\d+',date.group(1),re.I|re.S):
                revised=re.search(r'Revised\s(\d+)\s(\w+)\s(\d+)',date.group(1),re.I|re.S)
                historytag =historytag+f'\n<Revised>\n<Year>{revised.group(3)}</Year>\n<Month>{revised.group(2)}</Month>\n<Day>{revised.group(1)}</Day>\n</Revised>'

            onlinedate=f'\n<OnlineDate>\n<Year>\n<?InsertOnreleaseOF OFYear?>\n</Year>\n<Month>\n<?InsertOnreleaseOF OFMonth?>\n</Month>\n<Day>\n<?InsertOnreleaseOF OFDay?>\n</Day>\n</OnlineDate>'

        ArticleHistory='\n<ArticleHistory>'+historytag+onlinedate+'\n</ArticleHistory>'
        article=article+ArticleHistory
    if re.search(r'<contrib(?: [^>]*)?contrib-type="editor"(?: [^>]*)?>((?:(?!</contrib>).)*)</contrib>',cnt,re.I|re.S):
        editor=re.search(r'<contrib(?: [^>]*)?contrib-type="editor"(?: [^>]*)?>((?:(?!</contrib>).)*)</contrib>',cnt,re.I|re.S).group(1)
        if re.search(r'<surname(?: [^>]*)?>((?:(?!</surname>).)*)</surname>',editor,re.I|re.S):
            editor_surname=re.search(r'<surname(?: [^>]*)?>((?:(?!</surname>).)*)</surname>',editor,re.I|re.S).group(1)
        if re.search(r'<given-names(?: [^>]*)?>((?:(?!</given-names>).)*)</given-names>',editor,re.I|re.S):
            editor_given=re.search(r'<given-names(?: [^>]*)?>((?:(?!</given-names>).)*)</given-names>',editor,re.I|re.S).group(1)
        contrib_name=editor_surname+' '+editor_given
        article=article+f'\n<ArticleEditorialResponsibility>{contrib_name}</ArticleEditorialResponsibility>'

    if re.search(r'<funding-group(?: [^>]*)?>((?:(?!</funding-group>).)*)</funding-group>',cnt,re.I|re.S):
        funding=re.search(r'<funding-group(?: [^>]*)?>((?:(?!</funding-group>).)*)</funding-group>',cnt,re.I|re.S).group(1)
        funding=re.sub(r'<p>',r'',funding)
        funding=re.sub(r'</p>',r'',funding)
        article=article+f'\n<ArticleFundingInformation>\n<Fund>\n<FunderName>{funding}</FunderName>\n</Fund>\n</ArticleFundingInformation>'
        cnt=re.sub(r'<funding-group(?: [^>]*)?>((?:(?!</funding-group>).)*)</funding-group>',r'',cnt,re.I|re.S)
    if re.search(r'<ArticleCopyright(?: [^>]*)?>((?:(?!</ArticleCopyright>).)*)</ArticleCopyright>',jobsheetcnt,re.I|re.S):
        copy=re.search(r'<ArticleCopyright(?: [^>]*)?>((?:(?!</ArticleCopyright>).)*)</ArticleCopyright>',jobsheetcnt,re.I|re.S)
        copy=copy.group()
        copy=re.sub(r'\n\s*',r'\n',copy)
        article=article+f'\n{copy}'
    if re.search(r'<ArticleGrants(?: [^>]*)?>((?:(?!</ArticleGrants>).)*)</ArticleGrants>',jobsheetcnt,re.I|re.S):
        grant=re.search(r'<ArticleGrants(?: [^>]*)?>((?:(?!</ArticleGrants>).)*)</ArticleGrants>',jobsheetcnt,re.I|re.S)
        grant=grant.group()
        grant=re.sub(r'\n\s*',r'\n',grant)
        article=article+f'\n{grant}'

    Articlecontext=f'\n<ArticleContext>\n<JournalID>{articleID}</JournalID>\n<VolumeIDStart>\n<?InsertByIssueBuilding VolumeIDStart?>\n</VolumeIDStart>\n<VolumeIDEnd>\n<?InsertByIssueBuilding VolumeIDEnd?>\n</VolumeIDEnd>\n<IssueIDStart>\n<?InsertByIssueBuilding IssueIDStart?>\n</IssueIDStart>\n<IssueIDEnd>\n<?InsertByIssueBuilding IssueIDEnd?>\n</IssueIDEnd>\n</ArticleContext>\n</ArticleInfo>'
    article=article+f'\n{Articlecontext}'

    if re.search(r'<contrib-group(?: [^>]*)?>((?:(?!</contrib-group>).)*)</contrib-group>',cnt,re.I|re.S):
        grant=re.search(r'<contrib-group(?: [^>]*)?>((?:(?!</contrib-group>).)*)</contrib-group>',cnt,re.I|re.S)
        author_name=''
        for contrib in re.finditer(r'<contrib(?: [^>]*)?>((?:(?!</contrib>).)*)</contrib>',grant.group(1),re.I|re.S):
            count=1
            aff=''
            for aff1 in re.finditer(r'<xref(?: [^>]*)?ref-type="aff"(?: [^>]*)?>((?:(?!</xref>).)*)</xref>',contrib.group(1),re.I|re.S):
                count1=str(count)
                if count==1:
                    aff=f'Aff{count1}'
                else:
                    aff=aff+f' Aff{count1}'
                count = count + 1
            author_aff = f'<Author AffiliationIDS="{aff}" ID="Au1">'
            if re.search(r'<author(?: [^>]*)?>((?:(?!</author>).)*)</author>',contrib.group(1),re.I|re.S):
                author=re.search(r'<author(?: [^>]*)?>((?:(?!</author>).)*)</author>',contrib.group(1),re.I|re.S)
                if re.search(r'<surname(?: [^>]*)?>((?:(?!</surname>).)*)</surname>',author.group(1),re.I|re.S):
                    author_surname=re.search(r'<surname(?: [^>]*)?>((?:(?!</surname>).)*)</surname>',author.group(1),re.I|re.S).group(1)
                if re.search(r'<given-names(?: [^>]*)?>((?:(?!</given-names>).)*)</given-names>',author.group(1),re.I|re.S):
                    author_given=re.search(r'<given-names(?: [^>]*)?>((?:(?!</given-names>).)*)</given-names>',author.group(1),re.I|re.S).group(1)


                if author_surname and author_given and author_aff:
                    author_name=author_name+f'{author_aff}\n<AuthorName>\n<GivenName>{author_given}</GivenName>\n<FamilyName>{author_surname}</FamilyName>\n</AuthorName>\n</Author>\n'
        affiliation=''
        for aff in re.finditer(r'<aff(?: [^>]*)?id="([^>]*)"(?: [^>]*)?>((?:(?!</aff>).)*)</aff>',grant.group(1),re.I|re.S):
            aff_id=aff.group(1)
            idnum=''
            if re.search(r'[1-9]+',aff_id):
                idnum=re.search(r'([1-9]+)',aff_id)
            aff_name=aff.group(2)
            if re.search(r'<institution(?: [^>]*)?>((?:(?!</institution>).)*)</institution>',aff_name,re.I|re.S):
                institution=re.search(r'<institution(?: [^>]*)?>((?:(?!</institution>).)*)</institution>',aff_name,re.I|re.S).group(1)
                if re.search(r'<department(?: [^>]*)?>((?:(?!</department>).)*)</department>',institution,re.I|re.S):
                    department=re.search(r'<department(?: [^>]*)?>((?:(?!</department>).)*)</department>',institution,re.I|re.S).group(1)
                    affiliation = affiliation + f'\n<Affiliation ID="Aff{idnum.group(1)}">\n<OrgDivision>{department}</OrgDivision>'
                else:
                    affiliation = affiliation + f'\n<Affiliation ID="Aff{idnum.group(1)}">'
                if re.search(r'<institution-name(?: [^>]*)?>((?:(?!</institution-name>).)*)</institution-name>',institution,re.I|re.S):
                    instu_name=re.search(r'<institution-name(?: [^>]*)?>((?:(?!</institution-name>).)*)</institution-name>',institution,re.I|re.S).group(1)
                    affiliation=affiliation+f'\n<OrgName>{instu_name}</OrgName>'

            affiliation=affiliation+f'\n</Affiliation>'
            # affiliation=affiliation+f'\n<Affiliation ID="Aff{idnum.group(1)}"><OrgDivision>{aff_name}</OrgDivision>\n<OrgName></OrgName>\n<OrgAddress>\n<City></City>\n<State>West Bengal</State>\n<Country Code="IN">India</Country>\n</OrgAddress>\n</Affiliation>'

        authorgroup=f'\n<ArticleHeader>\n<AuthorGroup>\n{author_name+affiliation}\n</AuthorGroup>'
    abstractfin=''
    countabstract=1
    for abstract in re.finditer(r'<abstract(?: [^>]*)?>((?:(?!</abstract>).)*)</abstract>', cnt, re.I | re.S):
        # abstract = re.search(r'<abstract(?: [^>]*)?>((?:(?!</abstract>).)*)</abstract>', cnt, re.I | re.S)
        abst = abstract.group(1)
        if re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>', abst, re.I | re.S):
            abst_title = re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>', abst, re.I | re.S).group(1)
            abstpara = ''
            countpara=1
            for para in re.finditer(r'<p(?: [^>]*)?>(.*?)</p>', abst, re.I | re.S):
                abst_para = para.group(1)
                abstpara=abstpara+f'<Para ID="Par{str(countpara)}">{abst_para}</Para>\n'
                countpara=countpara+1

        abstractfin =abstractfin+f'\n<Abstract ID="Abs{countabstract}" Language="En" OutputMedium="All">\n<Title>{abst_title}</Title>\n{abstpara}</Abstract>'
        countabstract=countabstract+1

    keywordfin=''
    if re.search(r'<kwd-group(?: [^>]*)?>((?:(?!</kwd-group>).)*)</kwd-group>', cnt, re.I | re.S):
        keywordgroup=re.search(r'<kwd-group(?: [^>]*)?>((?:(?!</kwd-group>).)*)</kwd-group>', cnt, re.I | re.S)
        keyword=''
        keywordtitlefin=''
        if re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>', keywordgroup.group(1), re.I | re.S):
            keywordtitle=re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>', keywordgroup.group(1), re.I | re.S).group(1)
            keywordtitlefin=f'\n<Heading>{keywordtitle}</Heading>\n'
        for kwd in re.finditer(r'<kwd(?: [^>]*)?>(.*?)</kwd>', keywordgroup.group(1), re.I | re.S):
            keywd=kwd.group(1)
            keywd=re.sub(r'sup','Superscript',keywd,0,re.I|re.S)
            keywd=re.sub(r'<Superscript(?: [^>]*)?>(.*?)</Superscript>',lambda m:r'<Superscript>'+(convert_symbols_to_entities(m.group(1)))+r'</Superscript>',keywd,0,re.I|re.S)
            keyword=keyword+f'<Keyword>{keywd}</Keyword>\n'
        keywordfin=f'\n<KeywordGroup Language="En" OutputMedium="All">{keywordtitlefin}{keyword}</KeywordGroup>'
    abbrevtitlefin=''
    if re.search(r'<Abbrev(?: [^>]*)?>((?:(?!</Abbrev>).)*)</Abbrev>', cnt, re.I | re.S):
        abbrev=re.search(r'<Abbrev(?: [^>]*)?>((?:(?!</Abbrev>).)*)</Abbrev>', cnt, re.I | re.S).group(1)
        if re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>', abbrev, re.I | re.S):
            abbrevtitle=re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>', abbrev, re.I | re.S).group(1)
            abbrevtitlefin=f'\n<Heading>{abbrevtitle}</Heading>'

        if re.search(r'<def-list(?: [^>]*)?>((?:(?!</def-list>).)*)</def-list>', abbrev, re.I | re.S):
            abbrevdeflist=re.search(r'<def-list(?: [^>]*)?>((?:(?!</def-list>).)*)</def-list>', abbrev, re.I | re.S).group(1)
            countabbrev=1
            for defitem in re.finditer(r'<def-item(?: [^>]*)?>(.*?)</def-item>', abbrevdeflist, re.I | re.S):
                defitem=defitem.group(1)
                if re.search(r'<term(?: [^>]*)?>(.*?)</term>', defitem, re.I | re.S):
                    term=re.search(r'<term(?: [^>]*)?>(.*?)</term>', defitem, re.I | re.S).group(1)
                if re.search(r'<def(?: [^>]*)?>(.*?)</def>', defitem, re.I | re.S):
                    defi=re.search(r'<def(?: [^>]*)?>(.*?)</def>', defitem, re.I | re.S).group(1)

                abbrevtitlefin=abbrevtitlefin+f'\n<DefinitionListEntry>\n<Term>{term}</Term>\n<Description>\n<Para ID="Par0{countabbrev}">{defi}</Para>\n</Description>\n</DefinitionListEntry>'
                countabbrev=countabbrev+1
            abbrevtitlefin=f'\n<AbbreviationGroup>{abbrevtitlefin}\n</AbbreviationGroup>'
        cnt=re.sub(r'<Abbrev(?: [^>]*)?>((?:(?!</Abbrev>).)*)</Abbrev>',r'',cnt,0,re.I|re.S)

    supplementfinal=''
    if re.search(r'<supplement(?: [^>]*)?>((?:(?!</supplement>).)*)</supplement>', cnt, re.I | re.S):
        supplement=re.search(r'<supplement(?: [^>]*)?>((?:(?!</supplement>).)*)</supplement>', cnt, re.I | re.S).group(1)
        if re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>', supplement, re.I | re.S):
            supptitle=re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>', supplement, re.I | re.S).group(1)
            supptitlefin=f'\n<Heading>{supptitle}</Heading>'
        if re.search(r'<supplementary-material(?: [^>]*)?>((?:(?!</supplementary-material>).)*)</supplementary-material>', supplement, re.I | re.S):
            supplement1=re.search(r'<supplementary-material(?: [^>]*)?>((?:(?!</supplementary-material>).)*)</supplementary-material>', supplement, re.I | re.S).group()
            supplement1=re.sub(r'supplementary-material',r'SimplePara',supplement1,0,re.I|re.S)
            supplement1=re.sub(r'<SimplePara>',r'\n<SimplePara>',supplement1,0,re.I|re.S)
            supplement1=re.sub(r'<doi>','\n<ExternalRef>\n<RefSource>',supplement1,0,re.I|re.S)
            supplement1=re.sub(r'</doi>',f'\n</RefSource>\n<RefTarget TargetType="DOI" Address="{doi1}" />\n</ExternalRef>',supplement1,0,re.I|re.S)
        supplementfinal=f'\n<ArticleNote Type="ESMHint">{supptitlefin+supplement1}\n</ArticleNote>'
        cnt=re.sub(r'<supplement(?: [^>]*)?>((?:(?!</supplement>).)*)</supplement>',r'',cnt,0,re.I|re.S)
    fngroup=''
    if re.search(r'<fn-group(?: [^>]*)?>((?:(?!</fn-group>).)*)</fn-group>', cnt, re.I | re.S):
        fngroup=re.search(r'<fn-group(?: [^>]*)?>((?:(?!</fn-group>).)*)</fn-group>', cnt, re.I | re.S).group()
        fngroup=re.sub(r'<fn-group>',r'\n<ArticleNote Type="CommunicatedBy">',fngroup,0,re.I|re.S)
        fngroup=re.sub(r'</fn-group>',r'\n</ArticleNote>',fngroup,0,re.I|re.S)
        fngroup=re.sub(r'<fn>',r'\n<SimplePara>',fngroup,0,re.I|re.S)
        fngroup=re.sub(r'</fn>',r'</SimplePara>',fngroup,0,re.I|re.S)
        cnt=re.sub(r'<fn-group(?: [^>]*)?>((?:(?!</fn-group>).)*)</fn-group>',r'',cnt,0,re.I|re.S)
    # print(abbrevtitlefin)
    article=article+authorgroup+abstractfin+keywordfin+abbrevtitlefin+supplementfinal+fngroup+"\n</ArticleHeader>"
    # print(article)
    cnt=re.sub(r'<front(?: [^>]*)?>((?:(?!</front>).)*)</front>',article,cnt,0,re.I|re.S)
    cnt=re.sub(r'\n\n',r'\n',cnt,0,re.I|re.S)
    cnt=re.sub(r'</article>',r'</Article>',cnt,0,re.I|re.S)

    # body=''
    # if re.search(r'<body(?: [^>]*)?>((?:(?!</body>).)*)</body>', cnt, re.I | re.S):
    #     body=re.search(r'<body(?: [^>]*)?>((?:(?!</body>).)*)</body>', cnt, re.I | re.S).group()
    #     body=_body_conversion(body)

    # print(body)
    return cnt



def general_conversion(cnt):
    # print(cnt)
    cnt=re.sub(r'<body>',r'<Body>',cnt,0,re.I|re.S)
    cnt=re.sub(r'</body>',r'</Body>',cnt,0,re.I|re.S)
    cnt=re.sub(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',r'<Heading>\g<1></Heading>',cnt,0,re.I|re.S)

    if re.search(r'<Body(?: [^>]*)?>((?:(?!</Body>).)*)</Body>', cnt, re.I | re.S):
        bodycnt=re.search(r'<Body(?: [^>]*)?>((?:(?!</Body>).)*)</Body>', cnt, re.I | re.S).group(1)
        no=1
        bodycnt=re.sub(r'<p>',r'<Para  id="Par'+str(next(InlineIdCount))+'">',bodycnt,0,re.I|re.S)
        bodycnt=re.sub(r'</p>',r'</Para>',bodycnt,0,re.I|re.S)

        cnt = re.sub(r'<Body(?: [^>]*)?>((?:(?!</Body>).)*)</Body>', r'<Body>' + bodycnt + r'</Body>', cnt, 0,
                     re.I | re.S)
        # print(bodycnt)
    cnt=re.sub(r'<bold(?: [^>]*)?>((?:(?!</bold>).)*)</bold>',r'<Emphasis Type="Bold">\g<1></Emphasis>',cnt,0,re.I|re.S)
    cnt=re.sub(r'<italic(?: [^>]*)?>((?:(?!</italic>).)*)</italic>',r'<Emphasis Type="italic">\g<1></Emphasis>',cnt,0,re.I|re.S)
    cnt=re.sub(r'<sup(?: [^>]*)?>((?:(?!</sup>).)*)</sup>',r'<Superscript>\g<1></Superscript>',cnt,0,re.I|re.S)
    cnt=re.sub(r'<sub(?: [^>]*)?>((?:(?!</sub>).)*)</sub>',r'<Subscript>\g<1></Subscript>',cnt,0,re.I|re.S)
    cnt=re.sub(r'<sub(?: [^>]*)?>((?:(?!</sub>).)*)</sub>',r'<Subscript>\g<1></Subscript>',cnt,0,re.I|re.S)
    cnt=re.sub(r'<sec(?: [^>]*)? id="S2\d+"(?: [^>]*)?>((?:(?!</sec>).)*)</sec>',r'<Section2 ID="Sec02">\g<1></Section2>',cnt,0,re.I|re.S)
    cnt=re.sub(r'<sec(?: [^>]*)? id="S3\d+"(?: [^>]*)?>((?:(?!</sec>).)*)</sec>',r'<Section3 ID="Sec01">\g<1></Section3>',cnt,0,re.I|re.S)
    cnt=re.sub(r'<sec(?: [^>]*)? id="S4\d+"(?: [^>]*)?>((?:(?!</sec>).)*)</sec>',r'<Section4 ID="Sec01">\g<1></Section4>',cnt,0,re.I|re.S)
    cnt=re.sub(r'<ref-list(?: [^>]*)?>((?:(?!</ref-list>).)*)</ref-list>',r'<Bibliography ID="Bib1">\g<1></Bibliography>',cnt,0,re.I|re.S)


    return cnt




filename=_open_utf8(uploads_folder + "/temp.txt")
filepath=uploads_folder + "\\" + filename
cnt=_open_utf8(filepath)
cnt=front_conversion(cnt)
cnt=general_conversion(cnt)

# print(cnt)
