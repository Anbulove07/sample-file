from docx import Document
import openai
import sys

openai.api_key = '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'

def translate_text(text, target_language):
    response = openai.Completion.create(
        engine='text-davinci-003',
        prompt=f"Translate the following English text to {target_language}: \"{text}\"",
        max_tokens=100,
        temperature=0.7,
        top_p=1.0,
        frequency_penalty=0.0,
        presence_penalty=0.0
    )
    translation = response.choices[0].text.strip()
    print("Processing...")
    return translation

def translate_word_file(input_file, output_file, target_language):
    # Read the contents from the input Word file
    doc = Document(input_file)

    # Translate and replace the text in each paragraph
    for paragraph in doc.paragraphs:
        original_text = paragraph.text
        translated_text = translate_text(original_text, target_language)
        paragraph.text = translated_text

    # Save the modified document to the output Word file
    doc.save(output_file)

# Example usage
input_file_path = sys.argv[1]
outputpath = sys.argv[1].split(".")[0]+"_translated.docx"
output_file_path = outputpath
target_language = "de" # German

translate_word_file(input_file_path, output_file_path, target_language)

print("Translation complete!")