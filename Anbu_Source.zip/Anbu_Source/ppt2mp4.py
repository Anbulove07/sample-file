import os
import time
import pythoncom
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import win32com.client


class PPTHandler(FileSystemEventHandler):
    def on_created(self, event):  # when file is created
        pythoncom.CoInitialize()  # Initialize COM library

        # Check if the new file is a pptx or ppt file and not a temp file
        if (event.src_path.endswith('.pptx') or event.src_path.endswith('.ppt')) and not os.path.basename(event.src_path).startswith("~$"):
            powerpoint = win32com.client.Dispatch("Powerpoint.Application")
            try:
                presentation = powerpoint.Presentations.Open(FileName=event.src_path, WithWindow=False)
            except Exception as e:
                error_message = f'Unable to open file {event.src_path}. Error: {e}\n'
                print(error_message)
                with open(os.path.splitext(event.src_path)[0] + '.txt', 'a') as f:
                    f.write(error_message)
                return

            try:
                output_dir = "\\\\intsezfs2\\PPT_To_Video\\output\\"  # Predefined output directory
                output_path = os.path.join(output_dir, os.path.splitext(os.path.basename(event.src_path))[0] + '.mp4')

                print(f'Processing file: {event.src_path}')

                start_time = time.time()

                presentation.CreateVideo(output_path, VertResolution=1080, FramesPerSecond=24, Quality=100)
                while presentation.CreateVideoStatus == 1:
                    time.sleep(1)
                presentation.Close()

                end_time = time.time()

                print('Done')
                print(f'Time taken: {end_time - start_time} seconds')
            except Exception as e:
                error_message = f'Unable to export to video. Error: {e}\n'
                print(error_message)
                with open(os.path.splitext(event.src_path)[0] + '.txt', 'a') as f:
                    f.write(error_message)

            try:
                os.remove(event.src_path)
                print(f'Deleted file: {event.src_path}')
            except Exception as e:
                error_message = f'Unable to delete file {event.src_path}. Error: {e}\n'
                print(error_message)
                with open(os.path.splitext(event.src_path)[0] + '.txt', 'a') as f:
                    f.write(error_message)

        pythoncom.CoUninitialize()  # Uninitialize COM library


if __name__ == "__main__":
    path = "\\\\intsezfs2\\PPT_To_Video\\Input"  # folder to be monitored
    event_handler = PPTHandler()
    observer = Observer()
    observer.schedule(event_handler, path, recursive=False)
    observer.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
