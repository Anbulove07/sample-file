# Replace with your directory path

import os
import pandas as pd

# Create an empty list to store DataFrames from each JSON file
dataframes = []

# Create an empty list to store corresponding file names
file_names = []

# Define the directory where your JSON files are located
json_dir =  r'C:\Users\is9626\PycharmProjects\Translation_MP3_UI\jsonoutput'  # Replace with your directory path

# Loop through each JSON file in the directory
for filename in os.listdir(json_dir):
    if filename.endswith('.json'):
        # Read the JSON file into a DataFrame
        json_file_path = os.path.join(json_dir, filename)
        json_df = pd.read_json(json_file_path)

        # Append the DataFrame to the list
        dataframes.append(json_df)

        # Append the corresponding file name to the list
        file_names.extend([filename] * len(json_df))  # Repeat the filename for each row

# Concatenate all DataFrames into a single DataFrame
consolidated_df = pd.concat(dataframes, ignore_index=True)

# Add a new column 'file_name' and populate it with the file names
consolidated_df['file_name'] = file_names

# Update 'file_name' column to include the corresponding file name in each row
consolidated_df['file_name'] = consolidated_df['file_name'].apply(lambda x: x.split('.json')[0])

# Define the output Excel file path
output_excel_file =  r'C:\Users\is9626\PycharmProjects\Translation_MP3_UI\jsonoutput\output.xlsx'

# Save the consolidated data to a single Excel sheet
consolidated_df.to_excel(output_excel_file, index=False, engine='openpyxl')

print(f'Consolidated data saved to {output_excel_file}')
