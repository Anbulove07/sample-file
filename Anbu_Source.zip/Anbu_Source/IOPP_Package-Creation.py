###################################################################
# 																  #
#  Project Name : IOPP_Package-Creation							  #
#  Version      : 1.0                                             #
#  Developed    : Bubalan .V | Programmer.                        #
#  Guided       : ArulkumaraN .A | Parthiban .U                   #
#  Completed    : 10-01-2020         							  # #                                                                 #
###################################################################

###################################################################
#
# Run  : IOPP_Package-Creation.py <Folder_Path> 
# Note : Supporting file <apppath/journaldatabase.ini>
#
###################################################################

###################################################################
# Updation History
#=================================================================
#	10-01-2020 | v1.0 | Bubalan .V   Initial Development
#	02-06-2020 | v1.1 | Bubalan .V   Individual Development(req by Dwarakesh)
#	16-10-2020 | v1.2 | Bubalan .V   Individual Development(req by Dwarakesh)
#	07-11-2020 | v1.3 | Janaki.G  Individual Development(req by Dwarakesh)
#	01-12-2020 | v1.4 | Bubalan .V  Individual Development(req by Dwarakesh)
#	13-04-2021 | v1.0.0.1 | Bubalan .V  Individual Development(req by Kannika)
#	13-04-2021 | v1.0.1.1 | Bubalan .V  Individual Development(req by Kannika)
#	15-07-2021 | v1.0.1.2 | Bubalan .V  Individual Development(req by Kannika)
#	23-12-2021 | V1.0.1.3 | Bubalan .V  Individual Development(req by Kannika)[V1.0.2.0 Live ExE]
#
###################################################################
version = "1.0.2.0";


### Module declaration
import os
from os.path import basename,dirname
import shutil
import ctypes
import sys
import re
import subprocess
# from iModule.Basic import*
from iModule.Basic import _get_file_list, _open_file, _open_utf8, _make_path, _package_zip
from iModule.ErrorLog import *

# Application path
apppath = dirname(sys.argv[0]);
apppath = re.sub(r'\/',r'\\',apppath,0)

	
os.system("cls");


print ("\n\n\tIOPP_Package-Creation v"+version+"is Running...");
print ("\tCopyright @ Integra Software Services Ltd.\n");
	
###---------Inline argument checking & File path checking------------###
if (len(sys.argv) != 2 or not os.path.isdir(sys.argv[1])): sys.exit("\n\tSyntax: IOPP_Package-Creation.exe <FolderPath> \n")
if (not os.path.isfile(apppath+'\\journaldatabase.ini')): sys.exit("\n\tSyntax: IOPP_Package-Creation.exe <journaldatabase.ini> file missing in apppath. \n")

### Global variable declaration
Input_Folder = sys.argv[1]
directory = os.path.dirname(Input_Folder)
# print(directory)
# input base:
base = os.path.basename(Input_Folder)
(ErrStr, tmErrs, tmWars, pub_id_manuscript) = ("", "", "", "");
myErrs = AddLabel("IOPP_Package-Creation")
ErrFile = directory+'\\'+base;
# ErrFileremov = ErrFile+'_err.htm';
if (os.path.isfile(ErrFile+'_err.htm')): os.remove(ErrFile+'_err.htm');


###---- Sub Functions -----------------------------------	
def Diff(First, Second):
	return (list(set(First) - set(Second)))
	
def _parsing_process(file_name):
	xmlvalidpath = r"C:\itools\WMS\IOPP\Tools\xmlvalid.exe"
	errfile = file_name
	err_cnt = "";
	errfile = re.sub(r'\.xml$','_err.htm',errfile,re.I)
	dtd = r"C:\itools\WMS\IOPP\Tools\DTD\journal-publishing-dtd-3.0\publishing\journalpublishing3.dtd"
	
	if os.path.isfile(errfile):
		os.remove(errfile)
	if not os.path.isfile(file_name):
		err_cnt = AddFolderErr("[IOPP_PC-1012]: Invalid or not exist file "+file_name+" to parse.",Input_Folder);
		# return err_cnt
	if not os.path.exists(dtd):
		err_cnt += AddFolderErr("[IOPP_PC-1013]: Invalid or not exist dtd file "+basename(dtd)+" to parse.",dirname(dtd));
		# return err_cnt
	if not os.path.isfile(xmlvalidpath):
		err_cnt += AddFolderErr("[IOPP_PC-1014]: Invalid or not exist xmlvalid.exe to parse.",dirname(xmlvalidpath));
		# return err_cnt
	if(err_cnt):
		return err_cnt;
	else:
		# tmp = r""+xmlvalidpath+" --dtd="+dtd+" "+file+" >"+errfile+""
		tmp = '"\"'+xmlvalidpath+'\" --dtd="'+dtd+'\" "'+file_name+'\" >"'+errfile+'"\"'
		os.system(tmp)
		parseFile =_open_file(errfile)
		os.remove(errfile) # remove the Error log File.
		if not re.match(re.escape(file_name)+' is valid',parseFile,re.I|re.S):
			mytm = file_name
			mytm = re.sub(r'\\','\/',mytm,0,re.S)
			parseFile = re.sub(r'^'+mytm+' *','',parseFile,0,re.M|re.I)
			# print(mytm,parseFile,'==============================');
			parseFile = re.sub(r" *(?:Fatal )?(Error\: )element content invalid\. *",'\g<1>',parseFile,0,re.S|re.I)
			parseFile = re.sub(r' *(?:Fatal )?(Error\: *)',r'\1',parseFile,0,re.S|re.I)
			# print(parseFile,'==============================');exit()
			parseFile = re.sub(r'\s*\[([0-9]+)\:([0-9]+)\] ?\: ?Error\: ?(.*?)$',lambda x:AddErrWarn("[IOPP_PC-1015]: "+x.group(3),x.group(1),x.group(2),file_name),parseFile,0,re.M|re.I)
			return parseFile
		else:
			return "";
	
###---- Sub Functions End ----------------------------
### Main Process
#-----------------------------------------------------------------------------------------------------#	

(info_xml) = _get_file_list(Input_Folder,1,0,'jobsheet.xml$')
# (metafile) = _get_file_list(Input,1,0,'^'+base+'(?:-|_)metadata.xml$')

# print(info_xml)
if not len(info_xml):
	tmErrs = AddFolderErr("[IOPP_PC-1001]: 'jobsheet.xml' file not found in input path",Input_Folder);
	# print(tmErrs+"in")
	
	#======= Error Formating ====================
	(tmp, errcnt, Errors) = ErrorReturn(tmErrs)
	myErrs += AddSubLabel("Errors&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"red\">Errors: "+str(errcnt)+"("+str(tmp)+")</font>");	
	myErrs += Errors
	#======= Error Formating End====================
	CreateErrorLog4ErrorReturn(ErrFile,"IOPP_Package-Creation #customer:#IOPP# Ver "+str(version), myErrs,1);sys.exit(0)
else:
	info_cnt = _open_utf8(info_xml[0]);
	if(re.search(r'<journal-id(?: [^>]*)? journal-id-type="publisher-id"[^>]*>((?:(?!</journal-id>).)*)</journal-id>', info_cnt, re.I|re.S)):
		m = re.search(r'<journal-id(?: [^>]*)? journal-id-type="publisher-id"[^>]*>((?:(?!</journal-id>).)*)</journal-id>', info_cnt, re.I|re.S)
		filename = m.group(1).lower(); jrl_code = m.group(1).lower()
	if(re.search(r'<volume>((?:(?!</volume>).)*)</volume>', info_cnt, re.I|re.S)):
		m = re.search(r'<volume>((?:(?!</volume>).)*)</volume>', info_cnt, re.I|re.S)
		# filename += '_'+('%02d' % int(m.group(1)))
		filename += '_' + m.group(1)
	elif(re.search(r'<volume/>', info_cnt, re.I|re.S)):
		filename += '_0'
	if(re.search(r'<issue>((?:(?!</issue>).)*)</issue>', info_cnt, re.I|re.S)):
		m = re.search(r'<issue>((?:(?!</issue>).)*)</issue>', info_cnt, re.I|re.S)
		# filename += '_'+('%02d' % int(m.group(1)))
		filename += '_' + m.group(1);
	elif(re.search(r'<issue/>', info_cnt, re.I|re.S)):
		filename += '_0'
	if(re.search(r'<elocation-id(?: [^>]*)? content-type="artnum"[^>]*>((?:(?!</elocation-id>).)*)</elocation-id>', info_cnt, re.I|re.S)):
		m = re.search(r'<elocation-id(?: [^>]*)? content-type="artnum"[^>]*>((?:(?!</elocation-id>).)*)</elocation-id>', info_cnt, re.I|re.S)
		filename += '_'+m.group(1)
	elif(re.search(r'<fpage>((?:(?!</fpage>).)*)</fpage>', info_cnt, re.I|re.S)):
		m = re.search(r'<fpage>((?:(?!</fpage>).)*)</fpage>', info_cnt, re.I|re.S)
		filename += '_'+m.group(1)
	# print(filename)
	# print(Input_Folder+'\\'+filename+'.xml');exit()
	if(re.search(r'<article-id(?: [^>]*)? pub-id-type="manuscript"[^>]*>((?:(?!</article-id>).)*)</article-id>',info_cnt,re.I|re.S)):
		m = re.search(r'<article-id(?: [^>]*)? pub-id-type="manuscript"[^>]*>((?:(?!</article-id>).)*)</article-id>',info_cnt,re.I|re.S)
		pub_id_manuscript = m.group(1);
		
	if(not os.path.isfile(Input_Folder+'\\'+filename+'.xml')):	
		tmErrs = AddFolderErr("[IOPP_PC-1002]: '"+filename+".xml' file not found in input path",Input_Folder);
	if(not os.path.isfile(Input_Folder+'\\'+filename+'.pdf')):	
		tmErrs += AddFolderErr("[IOPP_PC-1003]: '"+filename+".pdf' file not found in input path",Input_Folder);
	if(not os.path.isfile(Input_Folder+'\\'+filename+'am.pdf')):	
		tmErrs += AddFolderErr("[IOPP_PC-1004]: '"+filename+"am.pdf' file not found in input path",Input_Folder);
	if(not os.path.isfile(Input_Folder+'\\'+filename+'info.xml')):	
		tmErrs += AddFolderErr("[IOPP_PC-1004]: '"+filename+"info.xml' file not found in input path",Input_Folder);
	else:
		info_xml_cnt = _open_file(Input_Folder+'\\'+filename+'info.xml')
		if(re.search(r'<contact-author(?: [^>]*)?>(?:(?!</contact-author>).)*</contact-author>',info_xml_cnt,re.I|re.S)):
			tmErrs += AddErrWarn("[IOPP_PC-1018]: Contact-author information is not allowed inside info xml. Please check and remove author details in info xml",1,1, Input_Folder+'\\'+filename+'info.xml') # @ V1.0.1.1
#-- @ V1.0.0.1 ----	
	supp_xml_files = "";
	# AllFiles = map(lambda x:x.lower(), _get_file_list(Input_Folder,1,0,'.*')); # V1.0.1.3
	if(re.search(r'<file(?: [^>]*)? content-type="SupplementaryData"[^>]*>(?:(?!</file>).)*</file>',info_cnt,re.I|re.S)):
		job_file_supp = re.findall(r'<file(?: [^>]*)? content-type="SupplementaryData"[^>]*>((?:(?!</file>).)*)</file>',info_cnt,re.I|re.S)
		
		#--- # V1.0.1.3---
		for item in job_file_supp:
			if(not os.path.isfile(Input_Folder+"\\"+item)):	
				tmErrs += AddFolderErr("[IOPP_PC-1020]: '"+item+"' file present in \"jobsheet.xml\", but file missing in input path.",Input_Folder);

		if(tmErrs):
		#======= Error Formating ====================
			(tmp, errcnt, Errors) = ErrorReturn(tmErrs)
			myErrs += AddSubLabel("Errors&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"red\">Errors: "+str(errcnt)+"("+str(tmp)+")</font>");	
			myErrs += Errors
			#======= Error Formating End====================
			CreateErrorLog4ErrorReturn(ErrFile,"IOPP_Package-Creation #customer:#IOPP# Ver "+str(version), myErrs,1);sys.exit(0)
		#--- # V1.0.1.3 End---
		xml_cnt = _open_file(Input_Folder+'\\'+filename+'.xml');
		
		#--- # V1.0.1.3---
		m = re.search(r'<article-id(?: [^>]*)? pub-id-type="publisher-id"[^>]*>((?:(?!</article-id>).)*)</article-id>',xml_cnt,re.I|re.S)
		# if(m):
		art_id = m.group(1); art_id = re.sub(r'^tdm','2dm',art_id,re.I)
		seq_no = 1;
		for file in job_file_supp:
			(tmp_file, ext) = os.path.splitext(file);
			if(not os.path.isfile(Input_Folder+"\\"+art_id+'supp'+str(seq_no)+ext)):
				os.rename(Input_Folder+"\\"+file, Input_Folder+"\\"+art_id+'supp'+str(seq_no)+ext )
			seq_no += 1;
		
		#--- # V1.0.1.3 End---
			
		if(re.search(r'<supplementary-material(?: [^>]*)? xlink:href="[^"]*"[^>]*>(?:(?!</supplementary-material>).)*</supplementary-material>',xml_cnt,re.I|re.S)):
			supp_xml_file = re.findall(r'<supplementary-material(?: [^>]*)? xlink:href="([^"]*)"[^>]*>(?:(?!</supplementary-material>).)*</supplementary-material>',xml_cnt,re.I|re.S)
			if(len(supp_xml_file) != len(job_file_supp)):
				tmErrs += AddFolderErr("[IOPP_PC-1011]: 'supplementary file' missmatch between xml file and jobsheet file",Input_Folder);
				
			for file in supp_xml_file:
				supp_xml_files += file+'|';
				if(not os.path.isfile(Input_Folder+'\\'+file)):	
					tmErrs += AddFolderErr("[IOPP_PC-1016]: '"+file+"' file name found in xml file, but missing in input path",Input_Folder);
					
				count = WordCount(file,'.')
				if(count != 1):
					tmErrs += AddErrWarn("[IOPP_PC-1019]:\""+file+"\" More than one dot is present at \"supplementary-material\" tag in \""+filename+'.xml" file, please check and update',1,1, Input_Folder+'\\'+filename+'.xml')
			supp_xml_files = re.sub(r'\|$','',supp_xml_files)

		else:
			tmErrs += AddErrWarn("[IOPP_PC-1017]:\"SupplementaryData\" file present in jobsheet.xml file, but missing in \""+filename+'.xml" file',1,1, Input_Folder+'\\'+filename+'.xml')
			# print("@ supplementary-material not found in the xml file.... ");exit();
			
		# print(len(job_file_supp));exit();
#-- @ V1.0.0.1 End---
	
	# if(re.match(r'^(JMM|JOPT|JPD|JRP|LPL?|MET|MST|NANO|NF|PED|PPCF|PST|SMS|SST|SUST)$',jrl_code,re.I)):
		# if(not os.path.isfile(Input_Folder+'\\'+filename+'p.pdf')):	
			# tmErrs += AddFolderErr("[IOPP_PC-1005]: '"+filename+"p.pdf' file not found in input path",Input_Folder);
	# else:
		# if(os.path.isfile(Input_Folder+'\\'+filename+'p.pdf')):	
			# tmErrs += AddFolderErr("[IOPP_PC-1005]: Unwated file '"+filename+"p.pdf' found in input path",Input_Folder);
	
	jrl_cnt = _open_file(apppath+'\\journaldatabase.ini');

	if(re.search(r'<journal>\s*<code>\s*'+jrl_code+r'\s*</code>(?:(?!(?:<print_method>|</journal>)).)*<print_method>\s*</print_method>(?:(?!</journal>).)*</journal>',jrl_cnt,re.I|re.S)):
		if(os.path.isfile(Input_Folder+'\\'+filename+'p.pdf')):	
			tmErrs += AddFolderErr("[IOPP_PC-1005]: Unwated file '"+filename+"p.pdf' found in input path",Input_Folder);
	else:
		if(not os.path.isfile(Input_Folder+'\\'+filename+'p.pdf')):	
			tmErrs += AddFolderErr("[IOPP_PC-1005]: '"+filename+"p.pdf' file not found in input path",Input_Folder);
			
	if(re.search(r'<journal>\s*<code>\s*'+jrl_code+r'\s*</code>(?:(?!(?:<epub>|</journal>)).)*<epub>\s*yes\s*</epub>(?:(?!</journal>).)*</journal>',jrl_cnt,re.I|re.S)):
		# print("jrl_cnt");
		if(not os.path.isfile(Input_Folder+'\\'+filename+'.epub')):	
			tmErrs += AddFolderErr("[IOPP_PC-1006]: '"+filename+".epub' file not found in input path",Input_Folder);
	else:
		if(os.path.isfile(Input_Folder+'\\'+filename+'.epub')):	
			tmErrs += AddFolderErr("[IOPP_PC-1006]: Unwated file '"+filename+".epub' found in input path",Input_Folder);
	
	AllFiles = map(lambda x:x.lower(), _get_file_list(Input_Folder,0,0,'.*'))
	# AllFiles = _get_file_list(Input_Folder,0,0,'.*')
	# print(AllFiles, "bubalan");exit();
	Wanted_files = [Input_Folder+'\\'+filename+'.xml', Input_Folder+'\\'+filename+'.pdf', Input_Folder+'\\'+filename+'.epub', Input_Folder+'\\'+filename+'am.pdf', Input_Folder+'\\'+filename+'p.pdf', Input_Folder+'\\images', Input_Folder+'\\jobsheet.xml', Input_Folder+'\\'+filename+'info.xml', Input_Folder+'\\'+pub_id_manuscript+'.pdf', Input_Folder+'\\'+jrl_code+pub_id_manuscript+'CorrectedPDF.pdf'] # add Input_Folder+'\\'+filename+'info.xml'

	# Wanted_files += filter(lambda x: regex.search(jrl_code+pub_id_manuscript+r'supp\d+\.', x), _get_file_list(Input_Folder,0,0,'.*')) #version v1.4
	Wanted_files += filter(lambda x: re.search(r'('+supp_xml_files+r')', x), _get_file_list(Input_Folder,0,0,'.*')) #version v1.0.0.1
	# print(filename, Wanted_files);exit;
	Wanted_files = map(lambda x:x.lower(), Wanted_files);

	Err_files =Diff(AllFiles, Wanted_files)
	if(Err_files):
		Err_file = ', '.join(map(os.path.basename, Err_files))
		tmErrs += AddFolderErr("[IOPP_PC-1007]: \""+Err_file+"\" Unwated file found in input path",Input_Folder);
	# print("else")
	if(tmErrs):
		#======= Error Formating ====================
		(tmp, errcnt, Errors) = ErrorReturn(tmErrs)
		myErrs += AddSubLabel("Errors&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"red\">Errors: "+str(errcnt)+"("+str(tmp)+")</font>");	
		myErrs += Errors
		#======= Error Formating End====================
		CreateErrorLog4ErrorReturn(ErrFile,"IOPP_Package-Creation #customer:#IOPP# Ver "+str(version), myErrs,1);
		sys.exit(0)

tmErrs = _parsing_process(Input_Folder+'\\'+filename+'.xml');# parsing XML File.
# print(tmErrs,'bubalan');#exit()
xml_cnt = _open_file(Input_Folder+'\\'+filename+'.xml');
xmlGraphic = re.findall('<(?:inline-)?graphic(?: [^>]+)? xlink:href="([^\"]+)"',xml_cnt,re.I|re.S)

if(xmlGraphic):
	if(not os.path.isdir(Input_Folder+'\\images')):
		tmErrs += AddFolderErr("[IOPP_PC-1008]: 'images' Folder not found in input path",Input_Folder);
	else:
		AllImageFile = list(map(os.path.basename, _get_file_list(Input_Folder+'\\images',1,0,'.*')))
# print(set(xmlGraphic))
		
		NotInFolder = Diff(xmlGraphic, AllImageFile)
		NotInFile = Diff(AllImageFile, xmlGraphic)
		# print(NotInFolder, NotInFile)
		if(NotInFolder):
			Err_file = ', '.join(map(str, NotInFolder))
			tmErrs += AddFolderErr("[IOPP_PC-1009]: \""+Err_file+"\" file Missing in \"images\" folder",Input_Folder+r"\images");
		if(NotInFile):
			Err_file = ', '.join(map(str, NotInFile))
			tmErrs += AddErrWarn("[IOPP_PC-1010]: \""+Err_file+"\" file present in images folder, but missing in \""+filename+'.xml" file',1,1, Input_Folder+'\\'+filename+'.xml')
else:
	if(os.path.isdir(Input_Folder+'\\images')):
		os.rmdir(Input_Folder+r'\\images')
	
if(tmErrs):
	#======= Error Formating ====================
	(tmp, errcnt, Errors) = ErrorReturn(tmErrs)
	myErrs += AddSubLabel("Errors&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=\"red\">Errors: "+str(errcnt)+"("+str(tmp)+")</font>");	
	myErrs += Errors
	#======= Error Formating End====================
	CreateErrorLog4ErrorReturn(ErrFile,"IOPP_Package-Creation #customer:#IOPP# Ver "+str(version), myErrs);sys.exit(0)
else:
	# AllSaveFiles = _get_file_list(Input_Folder,0,0,".*")
	AllSaveFiles = map(lambda x: re.sub(filename,filename,x,0,re.I) ,_get_file_list(Input_Folder,0,0,".*"))
	Output = Input_Folder+'//'+filename
	_make_path(Output)
	Out_ej = Output+'//'+filename+'ej'
	_make_path(Out_ej)
	# exit("hi")
	for F in AllSaveFiles :
		# print("==>"+F,filename)
		if(re.search(filename+r'info\.xml$',F,re.I)):
			shutil.move(F,Output)
		# elif(re.search('((?:'+filename+r'(\.xml|.epub|(?:am)?\.pdf)|images)$',F,re.I)):version v1.4 
		elif(re.search('((?:'+filename+r'(\.xml|.epub|(?:am)?\.pdf)|images)$|'+jrl_code+pub_id_manuscript+r'supp\d+\.'+')',F,re.I)): 
			# print(F)
			shutil.move(F,Out_ej)
		elif(re.search(filename+r'p\.pdf$',F,re.I)):
			_make_path(Output+'//'+filename+'p')
			shutil.move(F,Output+'//'+filename+'p')
			_package_zip(Output+'//'+filename+'p')
			shutil.rmtree(Output+'//'+filename+'p')
	_package_zip(Out_ej)
	shutil.rmtree(Out_ej)
	os.remove(Input_Folder+"//jobsheet.xml")
	_package_zip(Output)
	shutil.rmtree(Output)
	
	# exit("hi")
	myErrs += '<tr bgcolor="#C0C5B4"><td><font size="3" face="Verdana" color="darkbrown"><b>Errors: 0</b></font></td></tr><tr><td align="center"><font size="5" face="Arial Black" color="green">Folder "'+os.path.basename(Input_Folder)+'" has No Errors!!!</font></td></tr><td align="center"><font size="5" face="Arial Black" color="green">\nPackage Created...</font></td>'
	CreateErrorLog4ErrorReturn(ErrFile,"IOPP_Package-Creation #customer:#IOPP# Ver "+str(version), myErrs,1);
print("\t\tProcess Completed!!!!");sys.exit(0);