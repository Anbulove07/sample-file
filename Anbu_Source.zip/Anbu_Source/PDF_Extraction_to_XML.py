
# ---------------------------------------------------------------------
#  Tool Name	: PDF_Extraction_to_XML.py
#  Developer	: Anbu G
#  Description  : To Extract the content in PDF and update the Page id in XML file
#  Client/DU	: OUP Books
#  Syntax		: <EXE> <XML_Folder_Path> <PDF_Path>
# -----------------------------------------------------------------------



# ------------ Rivision History  -------------------------------------------
#  23-08-2022 | v1.0.0.0 | Anbu G | Initial Development
# --------------------------------------------------------------------------




from __future__ import print_function
from iModule.Basic import _open_utf8, _save_file
from iModule.ToolTracking import _get_timestamp, _local_tracking, _get_file_size
import zipfile
import os
import glob
import itertools #for id sequence
import re
import sys
import shutil

from namedentities import *
import re

import re
import unicodedata
import io

# pdfFileObj = open(r'D:\Anbu\Page-Number-insert_PDF_to_XML\OUP_Book_Main-out.pdf', 'rb')

from io import StringIO

from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfdocument import PDFDocument
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.pdfpage import PDFPage
from pdfminer.pdfparser import PDFParser

from pdfrw import PdfReader, PdfWriter

from pagelabels import PageLabels, PageLabelScheme



ToolVersion = "1.0.0.0";

print("\n\n\tPDF_Extraction_Data_to_XML_Updation v" + ToolVersion + " is Running...");
print("\tCopyright @ Integra Software Services Ltd.\n");


try :
    xml_filename1 = sys.argv[1]
    PDF_filename = sys.argv[2]
except :
    # src = r'D:\Anbu\XML\pdftest.pdf'
    print("Please Enter XML file location")
    exit()
try:
    os.mkdir(xml_filename1+r'\Output')
except:
    pass
pathtofolder=xml_filename1+r'\Output'
src_files = os.listdir(xml_filename1)
for file_name in src_files:
    full_file_name = os.path.join(xml_filename1, file_name)
    if os.path.isfile(full_file_name):
        shutil.copy(full_file_name,  pathtofolder)

# shutil.copyfile(xml_filename1, xml_filename1+r'\output')
xml_filename=xml_filename1+r'\output'
def Pagenumberfinding(firstpagenumber):
    reader = PdfReader(firstpagenumber)
    labels = PageLabels.from_pdf(reader)
    NlabelFinder = str(labels)
    findfirstpage=re.search(r'startpage=(\d+), style=\'arabic\'',NlabelFinder,re.I|re.S)
    try:
        firstpagenumber=int((findfirstpage.group(1)))
    except:
    # print(firstpagenumber)
        print("PDF Page Label Mismatched!!! Please update and Re-run...")
        exit()
    return firstpagenumber


# print(PDFFirstPgno)
# exit()


output_string = StringIO()
with open(PDF_filename, 'rb') as in_file:
    parser = PDFParser(in_file)
    doc = PDFDocument(parser)
    rsrcmgr = PDFResourceManager()
    device = TextConverter(rsrcmgr, output_string, laparams=LAParams())
    interpreter = PDFPageInterpreter(rsrcmgr, device)
    for page in PDFPage.create_pages(doc):
        interpreter.process_page(page)

# print(output_string.getvalue())
myString = output_string.getvalue()

myString = myString.replace(u"\u000C", "Page_start\n")
myString1 = myString.split("Page_start\n")
# print(myString1)
# exit()
count = 0


getline0 = []
arr=[]

for y in range(len(myString1)):
    firstline = myString1[y].split("\n")

    m=0
    Pageno_Txt = []

    try:

        # print(getline1)
        Pageno_Txt.append(firstline[2])

    except:
        pass

    try:

        Pageno_Txt.append(firstline[4])

        # print(getline3)
    except:
        pass
    try:

        Pageno_Txt.append(firstline[5])

        # print(getline3)
    except:
        pass
    try:

        Pageno_Txt.append(firstline[6])
        # print(getline3)
    except:
        pass
    try:

        Pageno_Txt.append(firstline[(len(firstline)-3)])
        # print(getline3)
    except:
        pass
    arr.append(Pageno_Txt)
    m=m+1
    # try:
    #
    #     getline2=firstline[3]
    #     getline0.append(firstline[3])
    #     print(getline2)
    #
    #
    #
    # except:
    #     pass


# print(arr)
#
# exit()
PDFFirstPgno=Pagenumberfinding(PDF_filename)
arr_txt = [x for x in os.listdir(xml_filename) if x.endswith(".xml")]
_err=[]

def _hexa(tmp):
		test = hex(ord(tmp)).split('x')[-1];
		test = '&#x'+test.zfill(4).upper()+';';
		return test;



# txt = re.sub(r'[^\x00-\x7F]',lambda m : _hexa(m.group()),txt);


patternmatch=0
patternmatch1=0

for a in range(PDFFirstPgno,len(arr)-1):
    if len(arr[a]) == 5:
        # if patternmatch1==0:
            getPgno=re.search(r'(?!^[0-9_-]$(?=\s))^[\d+]{1,6}$',arr[a][0],re.I|re.S)
            try:
                findpg=getPgno.group()
                # print(findpg)
                # exit()
                if findpg!='null':
                    counter = 0
                    # for xy in range(len(arr)):
                        # numCheck = len(getline00[xy]) - 1

                    # print(getline00[xy][numCheck])
                    # if int(getline00[xy][numCheck]) >= int(findpg):
                    for mn in range(len(arr_txt)):
                        # if counter == 0:
                            # print("Match file index value",xy+1)
                            matchedfile = arr_txt[mn]
                            # counter = counter + 1

                            data=_open_utf8(xml_filename+"\\"+matchedfile)
                            serchtext=re.search(r'(^((?:\S+\s+){5}))',arr[a][1],re.I|re.S)
                            srch=serchtext.group(2)
                            srch = re.sub(r'[^\x00-\x7F]', lambda m: _hexa(m.group()), srch);

                            # contentserch.group()
                            # milestone=contentserch.group(2)
                            # data=re.sub(r'<\?Page pageId="([^>]*)"\?><milestone(?: [^>]*)>'+srch,r'<\?Page id="'+findpg+'" pageId="'+findpg+'"\?><milestone(?: [^>]*)>'+srch,data,0,re.I|re.S)
                            data=data.replace(srch,r'<?Page id="'+findpg+'" pageId="'+findpg+'"?><milestone id="oso-9780198833512-chapter-1-milestone-1" num="'+findpg+'" unit="page"/>'+srch)
                            # print("ok point")
                            data = re.sub(r'<\?Page pageId="' + findpg + r'"\?>\s*(<milestone(?: [^>]*)>)', r'', data, 0,re.I | re.S)
                            data = re.sub(r'(<\?Page) id="[^"]*" (pageId="([^"]*)"\?>\s*<milestone(?: [^>]*)>)', r'\1 \2', data,0, re.I | re.S)
                            # contentserch.group()
                            # _save_file(xml_filename+"\\"+matchedfile,data)
                            _err.append(int(findpg))
                            with open(xml_filename+"\\"+matchedfile, "w", encoding="utf-8") as f1:
                                f1.write(data)
                                f1.close()
                            counter = counter + 1
                            # patternmatch1=patternmatch1+1
                            # patternmatch=10

    #
                #
            except:
                pass
                getPgno = re.search(r'(?!^[0-9_-]$(?=\s))^[\d+]{1,6}$', arr[a][0], re.I | re.S)

                try:
                    findpg = getPgno.group()
                    # print(findpg)
                    # exit()
                    if findpg != 'null':
                        counter = 0
                        # for xy in range(len(arr)):
                        # numCheck = len(getline00[xy]) - 1

                        # print(getline00[xy][numCheck])
                        # if int(getline00[xy][numCheck]) >= int(findpg):
                        for mn in range(len(arr_txt)):
                            # if counter == 0:
                                # print("Match file index value",xy+1)
                                matchedfile = arr_txt[mn]
                                # counter = counter + 1

                                data = _open_utf8(xml_filename + "\\" + matchedfile)
                                serchtext = re.search(r'(^((?:\S+\s+){5}))', arr[a][3], re.I | re.S)
                                srch = serchtext.group(2)
                                srch = re.sub(r'[^\x00-\x7F]', lambda m: _hexa(m.group()), srch);

                                # contentserch.group()
                                # milestone=contentserch.group(2)
                                # data=re.sub(r'<\?Page pageId="([^>]*)"\?><milestone(?: [^>]*)>'+srch,r'<\?Page id="'+findpg+'" pageId="'+findpg+'"\?><milestone(?: [^>]*)>'+srch,data,0,re.I|re.S)
                                data = data.replace(srch,r'<?Page id="' + findpg + '" pageId="' + findpg + '"?><milestone id="oso-9780198833512-chapter-1-milestone-1" num="' + findpg + '" unit="page"/>' + srch)
                                # print("ok point")
                                data = re.sub(r'<\?Page pageId="' + findpg + r'"\?>\s*(<milestone(?: [^>]*)>)', r'', data, 0,re.I | re.S)
                                data = re.sub(r'(<\?Page) id="[^"]*" (pageId="([^"]*)"\?>\s*<milestone(?: [^>]*)>)', r'\1 \2',data, 0, re.I | re.S)
                                # contentserch.group()
                                # _save_file(xml_filename+"\\"+matchedfile,data)
                                _err.append(int(findpg))
                                with open(xml_filename + "\\" + matchedfile, "w", encoding="utf-8") as f1:
                                    f1.write(data)
                                    f1.close()
                                counter = counter + 1
                                # patternmatch1 = patternmatch1 + 1
                                # patternmatch = 10
                except:
                    pass
                    getPgno = re.search(r'(?!^[0-9_-]$(?=\s))^[\d+]{1,6}$', arr[a][1], re.I | re.S)

                    try:
                        findpg = getPgno.group()
                        # print(findpg)
                        # exit()
                        if findpg != 'null':
                            counter = 0
                            # for xy in range(len(arr)):
                            # numCheck = len(getline00[xy]) - 1

                            # print(getline00[xy][numCheck])
                            # if int(getline00[xy][numCheck]) >= int(findpg):
                            # if counter == 0:
                            for mn in range(len(arr_txt)):
                                # if counter == 0:

                                    # print("Match file index value",xy+1)
                                    matchedfile = arr_txt[mn]
                                    # counter = counter + 1

                                    data = _open_utf8(xml_filename + "\\" + matchedfile)
                                    serchtext = re.search(r'(^((?:\S+\s+){5}))', arr[a][3], re.I | re.S)
                                    srch = serchtext.group(2)
                                    srch = re.sub(r'[^\x00-\x7F]', lambda m: _hexa(m.group()), srch);
                                    # contentserch.group()
                                    # milestone=contentserch.group(2)
                                    # data=re.sub(r'<\?Page pageId="([^>]*)"\?><milestone(?: [^>]*)>'+srch,r'<\?Page id="'+findpg+'" pageId="'+findpg+'"\?><milestone(?: [^>]*)>'+srch,data,0,re.I|re.S)
                                    data = data.replace(srch,r'<?Page id="' + findpg + '" pageId="' + findpg + '"?><milestone id="oso-9780198833512-chapter-1-milestone-1" num="' + findpg + '" unit="page"/>' + srch)
                                    # print("ok point")
                                    data = re.sub(r'<\?Page pageId="' + findpg + r'"\?>\s*(<milestone(?: [^>]*)>)', r'', data,0, re.I | re.S)
                                    data = re.sub(r'(<\?Page) id="[^"]*" (pageId="([^"]*)"\?>\s*<milestone(?: [^>]*)>)',r'\1 \2', data, 0, re.I | re.S)
                                    # contentserch.group()
                                    # _save_file(xml_filename+"\\"+matchedfile,data)
                                    _err.append(int(findpg))
                                    # counter = counter + 1
                                    with open(xml_filename + "\\" + matchedfile, "w", encoding="utf-8") as f1:
                                        f1.write(data)
                                        f1.close()
                                    counter = counter + 1
                                    # patternmatch1 = patternmatch1 + 1
                                    # patternmatch = 10
                    except:
                        pass
                        getPgno = re.search(r'(?!^[0-9_-]$(?=\s))^[\d+]{1,6}$', arr[a][1], re.I | re.S)

                        try:
                            findpg = getPgno.group()
                            # print(findpg)
                            # exit()
                            if findpg != 'null':
                                counter = 0
                                # for xy in range(len(arr)):
                                # numCheck = len(getline00[xy]) - 1

                                # print(getline00[xy][numCheck])
                                # if int(getline00[xy][numCheck]) >= int(findpg):
                                # if counter == 0:
                                for mn in range(len(arr_txt)):
                                    # if counter == 0:

                                        # print("Match file index value",xy+1)
                                        matchedfile = arr_txt[mn]
                                        # counter = counter + 1

                                        data = _open_utf8(xml_filename + "\\" + matchedfile)
                                        serchtext = re.search(r'(^((?:\S+\s+){5}))', arr[a][2], re.I | re.S)
                                        srch = serchtext.group(2)
                                        srch = re.sub(r'[^\x00-\x7F]', lambda m: _hexa(m.group()), srch);
                                        # contentserch.group()
                                        # milestone=contentserch.group(2)
                                        # data=re.sub(r'<\?Page pageId="([^>]*)"\?><milestone(?: [^>]*)>'+srch,r'<\?Page id="'+findpg+'" pageId="'+findpg+'"\?><milestone(?: [^>]*)>'+srch,data,0,re.I|re.S)
                                        data = data.replace(srch,r'<?Page id="' + findpg + '" pageId="' + findpg + '"?><milestone id="oso-9780198833512-chapter-1-milestone-1" num="' + findpg + '" unit="page"/>' + srch)
                                        # print("ok point")
                                        data = re.sub(r'<\?Page pageId="'+findpg+r'"\?>\s*(<milestone(?: [^>]*)>)', r'',data, 0, re.I | re.S)
                                        data = re.sub(r'(<\?Page) id="[^"]*" (pageId="([^"]*)"\?>\s*<milestone(?: [^>]*)>)',r'\1 \2', data, 0, re.I | re.S)
                                        # contentserch.group()
                                        # _save_file(xml_filename+"\\"+matchedfile,data)
                                        _err.append(int(findpg))
                                        # counter = counter + 1
                                        with open(xml_filename + "\\" + matchedfile, "w", encoding="utf-8") as f1:
                                            f1.write(data)
                                            f1.close()
                                        counter = counter + 1
                                        # patternmatch1 = patternmatch1 + 1
                                        # patternmatch = 10
                        except:
                            pass
                            getPgno = re.search(r'([\d.]+$)', arr[a][4], re.I | re.S)

                            try:
                                findpg = getPgno.group(1)
                                findpg1=re.search(r'.|-',findpg,re.I|re.S)
                                try:
                                    findpg1.group()

                                # print(findpg)
                                # exit()
                                #     if findpg != 'null':
                                    counter = 0
                                    # for xy in range(len(arr)):
                                    # numCheck = len(getline00[xy]) - 1

                                    # print(getline00[xy][numCheck])
                                    # if int(getline00[xy][numCheck]) >= int(findpg):
                                    # if counter == 0:
                                    for mn in range(len(arr_txt)):
                                        # if counter == 0:

                                            # print("Match file index value",xy+1)
                                            matchedfile = arr_txt[mn]


                                            data = _open_utf8(xml_filename + "\\" + matchedfile)
                                            serchtext = re.search(r'(^((?:\S+\s+){5}))', arr[a][0], re.I | re.S)
                                            srch = serchtext.group(2)
                                            srch = re.sub(r'[^\x00-\x7F]', lambda m: _hexa(m.group()), srch);
                                            # contentserch.group()
                                            # milestone=contentserch.group(2)
                                            # data=re.sub(r'<\?Page pageId="([^>]*)"\?><milestone(?: [^>]*)>'+srch,r'<\?Page id="'+findpg+'" pageId="'+findpg+'"\?><milestone(?: [^>]*)>'+srch,data,0,re.I|re.S)
                                            data = data.replace(srch,r'<?Page id="' + findpg + '" pageId="' + findpg + '"?><milestone id="oso-9780198833512-chapter-1-milestone-1" num="' + findpg + '" unit="page"/>' + srch)
                                            # print("ok point")
                                            data = re.sub(r'<\?Page pageId="' + findpg + r'"\?>\s*(<milestone(?: [^>]*)>)', r'',data, 0, re.I | re.S)
                                            data = re.sub(r'(<\?Page) id="[^"]*" (pageId="([^"]*)"\?>\s*<milestone(?: [^>]*)>)',r'\1 \2', data, 0, re.I | re.S)
                                            # contentserch.group()
                                            # _save_file(xml_filename+"\\"+matchedfile,data)
                                            _err.append(int(findpg))
                                            # counter = counter + 1
                                            with open(xml_filename + "\\" + matchedfile, "w", encoding="utf-8") as f1:
                                                f1.write(data)
                                                f1.close()
                                            counter = counter + 1
                                            # patternmatch1 = patternmatch1 + 1
                                            # patternmatch = 50
                                except:
                                    pass
                            except:
                                pass


# print(patternmatch)
# print(patternmatch1)
# for a in range(PDFFirstPgno, len(arr) - 1):
#     if len(arr[a]) == 5:
#         if patternmatch1 != 0:
#             getPgno = re.search(r'(?!^[0-9_-]$(?=\s))^[\d+]{1,6}$', arr[a][0], re.I | re.S)
#             try:
#                 findpg = getPgno.group()
#                 # print(findpg)
#                 # exit()
#                 if findpg != 'null' and patternmatch==10:
#
#                     counter = 0
#                     # for xy in range(len(arr)):
#                     # numCheck = len(getline00[xy]) - 1
#
#                     # print(getline00[xy][numCheck])
#                     # if int(getline00[xy][numCheck]) >= int(findpg):
#                     for mn in range(len(arr_txt)):
#
#                         # print("Match file index value",xy+1)
#                         matchedfile = arr_txt[mn]
#                         # counter = counter + 1
#
#                         data = _open_utf8(xml_filename + "\\" + matchedfile)
#                         serchtext = re.search(r'(^((?:\S+\s+){5}))', arr[a][1], re.I | re.S)
#                         srch = serchtext.group(2)
#                         srch = re.sub(r'[^\x00-\x7F]', lambda m: _hexa(m.group()), srch);
#
#                         # contentserch.group()
#                         # milestone=contentserch.group(2)
#                         # data=re.sub(r'<\?Page pageId="([^>]*)"\?><milestone(?: [^>]*)>'+srch,r'<\?Page id="'+findpg+'" pageId="'+findpg+'"\?><milestone(?: [^>]*)>'+srch,data,0,re.I|re.S)
#                         data = data.replace(srch,
#                                             r'<?Page id="' + findpg + '" pageId="' + findpg + '"?><milestone id="oso-9780198833512-chapter-1-milestone-1" num="' + findpg + '" unit="page"/>' + srch)
#                         # print("ok point")
#                         data = re.sub(r'<\?Page pageId="' + findpg + r'"\?>\s*(<milestone(?: [^>]*)>)', r'', data,
#                                       0, re.I | re.S)
#                         data = re.sub(r'(<\?Page) id="[^"]*" (pageId="([^"]*)"\?>\s*<milestone(?: [^>]*)>)',
#                                       r'\1 \2', data, 0, re.I | re.S)
#                         # contentserch.group()
#                         # _save_file(xml_filename+"\\"+matchedfile,data)
#                         _err.append(int(findpg))
#                         with open(xml_filename + "\\" + matchedfile, "w", encoding="utf-8") as f1:
#                             f1.write(data)
#                             f1.close()
#                         counter = counter + 1
#                         # patternmatch1 = patternmatch1 + 1
#                         # patternmatch = 10
#
#         #
#             #
#             except:
#                 pass
#                 getPgno = re.search(r'(?!^[0-9_-]$(?=\s))^[\d+]{1,6}$', arr[a][0], re.I | re.S)
#
#                 try:
#                     findpg = getPgno.group()
#                     # print(findpg)
#                     # exit()
#                     if findpg != 'null'and patternmatch==10:
#                         counter = 0
#                         # for xy in range(len(arr)):
#                         # numCheck = len(getline00[xy]) - 1
#
#                         # print(getline00[xy][numCheck])
#                         # if int(getline00[xy][numCheck]) >= int(findpg):
#                         for mn in range(len(arr_txt)):
#
#                             # print("Match file index value",xy+1)
#                             matchedfile = arr_txt[mn]
#                             # counter = counter + 1
#
#                             data = _open_utf8(xml_filename + "\\" + matchedfile)
#                             serchtext = re.search(r'(^((?:\S+\s+){5}))', arr[a][3], re.I | re.S)
#                             srch = serchtext.group(2)
#                             srch = re.sub(r'[^\x00-\x7F]', lambda m: _hexa(m.group()), srch);
#
#                             # contentserch.group()
#                             # milestone=contentserch.group(2)
#                             # data=re.sub(r'<\?Page pageId="([^>]*)"\?><milestone(?: [^>]*)>'+srch,r'<\?Page id="'+findpg+'" pageId="'+findpg+'"\?><milestone(?: [^>]*)>'+srch,data,0,re.I|re.S)
#                             data = data.replace(srch,
#                                                 r'<?Page id="' + findpg + '" pageId="' + findpg + '"?><milestone id="oso-9780198833512-chapter-1-milestone-1" num="' + findpg + '" unit="page"/>' + srch)
#                             # print("ok point")
#                             data = re.sub(r'<\?Page pageId="' + findpg + r'"\?>\s*(<milestone(?: [^>]*)>)', r'',
#                                           data, 0, re.I | re.S)
#                             data = re.sub(r'(<\?Page) id="[^"]*" (pageId="([^"]*)"\?>\s*<milestone(?: [^>]*)>)',
#                                           r'\1 \2', data, 0, re.I | re.S)
#                             # contentserch.group()
#                             # _save_file(xml_filename+"\\"+matchedfile,data)
#                             _err.append(int(findpg))
#                             with open(xml_filename + "\\" + matchedfile, "w", encoding="utf-8") as f1:
#                                 f1.write(data)
#                                 f1.close()
#                             counter = counter + 1
#                             # patternmatch1 = patternmatch1 + 1
#                             # patternmatch = 20
#                 except:
#                     pass
#                     getPgno = re.search(r'(?!^[0-9_-]$(?=\s))^[\d+]{1,6}$', arr[a][1], re.I | re.S)
#
#                     try:
#                         findpg = getPgno.group()
#                         # print(findpg)
#                         # exit()
#                         if findpg != 'null'and patternmatch==10:
#                             counter = 0
#                             # for xy in range(len(arr)):
#                             # numCheck = len(getline00[xy]) - 1
#
#                             # print(getline00[xy][numCheck])
#                             # if int(getline00[xy][numCheck]) >= int(findpg):
#                             # if counter == 0:
#                             for mn in range(len(arr_txt)):
#
#                                 # print("Match file index value",xy+1)
#                                 matchedfile = arr_txt[mn]
#                                 # counter = counter + 1
#
#                                 data = _open_utf8(xml_filename + "\\" + matchedfile)
#                                 serchtext = re.search(r'(^((?:\S+\s+){5}))', arr[a][3], re.I | re.S)
#                                 srch = serchtext.group(2)
#                                 srch = re.sub(r'[^\x00-\x7F]', lambda m: _hexa(m.group()), srch);
#                                 # contentserch.group()
#                                 # milestone=contentserch.group(2)
#                                 # data=re.sub(r'<\?Page pageId="([^>]*)"\?><milestone(?: [^>]*)>'+srch,r'<\?Page id="'+findpg+'" pageId="'+findpg+'"\?><milestone(?: [^>]*)>'+srch,data,0,re.I|re.S)
#                                 data = data.replace(srch,
#                                                     r'<?Page id="' + findpg + '" pageId="' + findpg + '"?><milestone id="oso-9780198833512-chapter-1-milestone-1" num="' + findpg + '" unit="page"/>' + srch)
#                                 # print("ok point")
#                                 data = re.sub(r'<\?Page pageId="' + findpg + r'"\?>\s*(<milestone(?: [^>]*)>)', r'',
#                                               data, 0, re.I | re.S)
#                                 data = re.sub(r'(<\?Page) id="[^"]*" (pageId="([^"]*)"\?>\s*<milestone(?: [^>]*)>)',
#                                               r'\1 \2', data, 0, re.I | re.S)
#                                 # contentserch.group()
#                                 # _save_file(xml_filename+"\\"+matchedfile,data)
#                                 _err.append(int(findpg))
#                                 # counter = counter + 1
#                                 with open(xml_filename + "\\" + matchedfile, "w", encoding="utf-8") as f1:
#                                     f1.write(data)
#                                     f1.close()
#                                 counter = counter + 1
#                                 # patternmatch1 = patternmatch1 + 1
#                                 # patternmatch = 30
#                     except:
#                         pass
#                         getPgno = re.search(r'(?!^[0-9_-]$(?=\s))^[\d+]{1,6}$', arr[a][1], re.I | re.S)
#
#                         try:
#                             findpg = getPgno.group()
#                             # print(findpg)
#                             # exit()
#                             if findpg != 'null'and patternmatch==10:
#                                 counter = 0
#                                 # for xy in range(len(arr)):
#                                 # numCheck = len(getline00[xy]) - 1
#
#                                 # print(getline00[xy][numCheck])
#                                 # if int(getline00[xy][numCheck]) >= int(findpg):
#                                 # if counter == 0:
#                                 for mn in range(len(arr_txt)):
#
#                                     # print("Match file index value",xy+1)
#                                     matchedfile = arr_txt[mn]
#                                     # counter = counter + 1
#
#                                     data = _open_utf8(xml_filename + "\\" + matchedfile)
#                                     serchtext = re.search(r'(^((?:\S+\s+){5}))', arr[a][2], re.I | re.S)
#                                     srch = serchtext.group(2)
#                                     srch = re.sub(r'[^\x00-\x7F]', lambda m: _hexa(m.group()), srch);
#                                     # contentserch.group()
#                                     # milestone=contentserch.group(2)
#                                     # data=re.sub(r'<\?Page pageId="([^>]*)"\?><milestone(?: [^>]*)>'+srch,r'<\?Page id="'+findpg+'" pageId="'+findpg+'"\?><milestone(?: [^>]*)>'+srch,data,0,re.I|re.S)
#                                     data = data.replace(srch,
#                                                         r'<?Page id="' + findpg + '" pageId="' + findpg + '"?><milestone id="oso-9780198833512-chapter-1-milestone-1" num="' + findpg + '" unit="page"/>' + srch)
#                                     # print("ok point")
#                                     data = re.sub(r'<\?Page pageId="' + findpg + r'"\?>\s*(<milestone(?: [^>]*)>)',
#                                                   r'', data, 0, re.I | re.S)
#                                     data = re.sub(
#                                         r'(<\?Page) id="[^"]*" (pageId="([^"]*)"\?>\s*<milestone(?: [^>]*)>)',
#                                         r'\1 \2', data, 0, re.I | re.S)
#                                     # contentserch.group()
#                                     # _save_file(xml_filename+"\\"+matchedfile,data)
#                                     _err.append(int(findpg))
#                                     # counter = counter + 1
#                                     with open(xml_filename + "\\" + matchedfile, "w", encoding="utf-8") as f1:
#                                         f1.write(data)
#                                         f1.close()
#                                     counter = counter + 1
#                                     # patternmatch1 = patternmatch1 + 1
#                                     # patternmatch = 40
#                         except:
#                             pass
#                             getPgno = re.search(r'([\d.]+$)', arr[a][4], re.I | re.S)
#
#                             try:
#                                 findpg = getPgno.group(1)
#                                 findpg1 = re.search(r'.|-', findpg, re.I | re.S)
#                                 try:
#                                     findpg1.group()
#                                 except:
#                                     # print(findpg)
#                                     # exit()
#                                     if findpg != 'null'and patternmatch==50:
#                                         counter = 0
#                                         # for xy in range(len(arr)):
#                                         # numCheck = len(getline00[xy]) - 1
#
#                                         # print(getline00[xy][numCheck])
#                                         # if int(getline00[xy][numCheck]) >= int(findpg):
#                                         # if counter == 0:
#                                         for mn in range(len(arr_txt)):
#
#                                             # print("Match file index value",xy+1)
#                                             matchedfile = arr_txt[mn]
#
#                                             data = _open_utf8(xml_filename + "\\" + matchedfile)
#                                             serchtext = re.search(r'(^((?:\S+\s+){5}))', arr[a][0], re.I | re.S)
#                                             srch = serchtext.group(2)
#                                             srch = re.sub(r'[^\x00-\x7F]', lambda m: _hexa(m.group()), srch);
#                                             # contentserch.group()
#                                             # milestone=contentserch.group(2)
#                                             # data=re.sub(r'<\?Page pageId="([^>]*)"\?><milestone(?: [^>]*)>'+srch,r'<\?Page id="'+findpg+'" pageId="'+findpg+'"\?><milestone(?: [^>]*)>'+srch,data,0,re.I|re.S)
#                                             data = data.replace(srch,
#                                                                 r'<?Page id="' + findpg + '" pageId="' + findpg + '"?><milestone id="oso-9780198833512-chapter-1-milestone-1" num="' + findpg + '" unit="page"/>' + srch)
#                                             # print("ok point")
#                                             data = re.sub(
#                                                 r'<\?Page pageId="' + findpg + r'"\?>\s*(<milestone(?: [^>]*)>)',
#                                                 r'', data, 0, re.I | re.S)
#                                             data = re.sub(
#                                                 r'(<\?Page) id="[^"]*" (pageId="([^"]*)"\?>\s*<milestone(?: [^>]*)>)',
#                                                 r'\1 \2', data, 0, re.I | re.S)
#                                             # contentserch.group()
#                                             # _save_file(xml_filename+"\\"+matchedfile,data)
#                                             _err.append(int(findpg))
#                                             # counter = counter + 1
#                                             with open(xml_filename + "\\" + matchedfile, "w",
#                                                       encoding="utf-8") as f1:
#                                                 f1.write(data)
#                                                 f1.close()
#                                             counter = counter + 1
#                                             # patternmatch1 = patternmatch1 + 1
#                                             # patternmatch = 50
#                             except:
#                                 pass

F=[]
P=[]
res = [*set(_err)]
for xml in range(len(res)):
    if len(arr)<res[xml]:
        F.append(res[xml])
    else:
        P.append(res[xml])
# print("Pass\n")
# print(len(P))
# print("\n")
# print(P)
# print("Fail\n")
# print(F)
# F1=F.split()
# P1=P.split()
stringreport="Updated PageID\n"
stringreport1="\n\nPlease Update The below PageID Manually\n"
for l in range(len(P)):
    if l!='null':
        stringreport=stringreport+"\n"+"Page ID: "+str(P[l])
    else:
        stringreport = stringreport + "Page ID: -"
for l in range(len(F)):
    if l != 'null':
        stringreport1=stringreport1+"\n"+"Page ID: "+str(F[l])
    else:
        stringreport1 = stringreport1 + "Page ID: -"
with open(xml_filename + "_Log.txt", "w", encoding="utf-8") as f1:
    f1.write(stringreport)
    f1.write(stringreport1)
    f1.close()


print("Process completed!!!")



