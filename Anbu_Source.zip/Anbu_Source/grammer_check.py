import language_tool_python
tool = language_tool_python.LanguageTool('es')

# correctedspell = '''Trate la muestra como una muestra aleatoria simple de todos los automóviles Honda Accord Hybrid 2019. Construya un intervalo de confianza del 95% para la media de millas por galón de un Honda Accord Híbrido 2019 usando una muestra Bootstrap. Interprete el intervalo. Entonces los datos son 42,3, 43,6, 48,2, 40, 39, 42,9, 44,8, 43, 40,7, 38,6, 39, 44,5, 35,5, 45,1, 35,4 y 42,2.'''

def grammercheck(correctedspell):
    matches = tool.check(correctedspell)
    # print(matches)
    is_bad_rule = lambda rule: rule.message == 'Possible spelling mistake found.' and len(rule.replacements) and rule.replacements[0][0].isupper()
    matches = [rule for rule in matches if not is_bad_rule(rule)]
    matches1=language_tool_python.utils.correct(correctedspell, matches)
    # print(matches1)
    return matches1