from transformers import MarianMTModel, MarianTokenizer

def offline_translate(text, src_lang, tgt_lang):
    # Load pre-trained model and tokenizer
    model_name = f'Helsinki-NLP/opus-mt-{src_lang}-{tgt_lang}'
    model = MarianMTModel.from_pretrained(model_name)
    tokenizer = MarianTokenizer.from_pretrained(model_name)

    # Split the text into smaller segments
    max_length = model.config.max_position_embeddings - 2  # Account for special tokens
    segments = [text[i:i+max_length] for i in range(0, len(text), max_length)]

    translated_segments = []
    for segment in segments:
        # Tokenize the segment
        src_tokens = tokenizer.encode(segment, add_special_tokens=True, return_tensors='pt')

        # Translate the segment
        translated = model.generate(src_tokens, max_length=1024)

        # Decode the translated tokens
        translated_text = tokenizer.decode(translated[0], skip_special_tokens=True)
        translated_segments.append(translated_text)

    # Join the translated segments into a single text
    translated_text = '\n\n'.join(translated_segments)

    return translated_text

# Example usage
source_text = """
PROFESOR: En este ejemplo, vamos a usar el comando de muestra de StatCrunch y la applet Bootstrap para construir un intervalo de confianza del 95%. El sitio web fueleconomy.gov permite a los conductores reportar las millas por galón de su vehículo. Los datos en la tabla muestran las millas reportadas por galón de los automóviles híbridos Honda Accord 2019 para 16 propietarios diferentes."""
source_lang = "es"
target_lang = "en"

translation = offline_translate(source_text, source_lang, target_lang)
print(f"Translation: {translation}")
