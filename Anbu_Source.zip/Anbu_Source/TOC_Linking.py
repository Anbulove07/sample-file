import sys
import re

from iModule.Basic import*
from iModule.ToolTracking import *


# xml_file=''
try :
    xml_file = sys.argv[1]

except :
    # src = r'D:\Anbu\XML\pdftest.pdf'
    print("Please Enter Correct input \n\tSyntax    :   <EXE> <XML> ")
    sys.exit()

# xml_file = sys.argv[1]
# print(sys.argv[1])
ToolVersion = "1.0.0.0";

#------------ Tracking --------------------------------------------
Tra_input = sys.argv[1];
tool_id = 398; #TOClinking Tool
run_size = 0;
st_time = _get_timestamp();
#------------------------------------------------------------------

#
# with open(xml_file, "r", encoding="utf-8") as f1:
#     xml_cnt = f1.read()
#     f1.close()

xml_cnt=_open_file(xml_file)
# print(xml_cnt)
# exit()

hash={}

if re.search(r'<miscMatter(?: [^>]*)? class="contents">(?:(?!</miscMatter>).)*</miscMatter>',xml_cnt,re.I|re.S):
    misc_matt = re.search(r'<miscMatter(?: [^>]*)? class="contents">((?:(?!</miscMatter>).)*)</miscMatter>', xml_cnt, re.I | re.S)

    for m in re.finditer(r'<item\d+(?: [^>]*)?>\s*<p>((?:(?!</p>).)*)</p>',misc_matt.group(1),re.I|re.S):
        rem_tag=m.group(1)

        rem_tag=re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'',rem_tag,0,re.I|re.S)
        rem_tag=re.sub(r'^(\s*)|(\s*)$',r'',rem_tag,0,re.I|re.S)
        # print(rem_tag)
        for misck in re.finditer(r'<miscMatter(?: [^>]*)? id="([^"]*)"[^>]*?>(?:(?!</miscMatter>).)*</miscMatter>',xml_cnt,re.I|re.S):
            for titlegr in re.finditer(r'<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>',misck.group(),re.I|re.S):
                if re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S):
                    titcnt=re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S)
                    rem_tag1 = re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'', titcnt.group(), 0, re.I | re.S)
                    # print(rem_tag,"------",rem_tag1)
                    # print()
                    # print(titlegr.group(1))
                    if re.search(rem_tag,rem_tag1,re.I|re.S):
                        # print(rem_tag)
                        hash[rem_tag]=misck.group(1)

        for misck in re.finditer(r'<chapter(?: [^>]*)? id="([^"]*)"[^>]*?>(?:(?!</chapter>).)*</chapter>',xml_cnt,re.I|re.S):
            for titlegr in re.finditer(r'<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>',misck.group(),re.I|re.S):
                if re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S):
                    titcnt=re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S)
                    rem_tag1 = re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'', titcnt.group(), 0, re.I | re.S)
                    # print(rem_tag,"------",rem_tag1)
                    # print()
                    # print(titlegr.group(1))
                    if re.search(rem_tag,rem_tag1,re.I|re.S):
                        # print(rem_tag)
                        hash[rem_tag]=misck.group(1)

        for misck in re.finditer(r'<div(?: [^>]*)? id="([^"]*)"[^>]*?>(?:(?!</div>).)*</div>',xml_cnt,re.I|re.S):
            for titlegr in re.finditer(r'<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>',misck.group(),re.I|re.S):
                if re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S):
                    titcnt=re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S)
                    rem_tag1 = re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'', titcnt.group(), 0, re.I | re.S)
                    # print(rem_tag,"------",rem_tag1)
                    # print()
                    # print(titlegr.group(1))
                    if re.search(rem_tag,rem_tag1,re.I|re.S):
                        # print(rem_tag)
                        hash[rem_tag]=misck.group(1)

        for misck in re.finditer(r'<figureGroup(?: [^>]*)? id="([^"]*)"[^>]*?>(?:(?!</figureGroup>).)*</figureGroup>',xml_cnt,re.I|re.S):
            for titlegr in re.finditer(r'<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>',misck.group(),re.I|re.S):
                if re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S):
                    titcnt=re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S)
                    rem_tag1 = re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'', titcnt.group(), 0, re.I | re.S)
                    # print(rem_tag,"------",rem_tag1)
                    # print()
                    # print(titlegr.group(1))
                    if re.search(rem_tag,rem_tag1,re.I|re.S):
                        # print(rem_tag)
                        hash[rem_tag]=misck.group(1)

        for misck in re.finditer(r'<tableGroup(?: [^>]*)? id="([^"]*)"[^>]*?>(?:(?!</tableGroup>).)*</tableGroup>',xml_cnt,re.I|re.S):
            for titlegr in re.finditer(r'<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>',misck.group(),re.I|re.S):
                if re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S):
                    titcnt=re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S)
                    rem_tag1 = re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'', titcnt.group(), 0, re.I | re.S)
                    # print(rem_tag,"------",rem_tag1)
                    # print()
                    # print(titlegr.group(1))
                    if re.search(rem_tag,rem_tag1,re.I|re.S):
                        # print(rem_tag)
                        hash[rem_tag]=misck.group(1)

        for misck in re.finditer(r'<appendix(?: [^>]*)? id="([^"]*)"[^>]*?>(?:(?!</appendix>).)*</appendix>',xml_cnt,re.I|re.S):
            for titlegr in re.finditer(r'<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>',misck.group(),re.I|re.S):
                if re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S):
                    titcnt=re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S)
                    rem_tag1 = re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'', titcnt.group(), 0, re.I | re.S)
                    # print(rem_tag,"------",rem_tag1)
                    # print()
                    # print(titlegr.group(1))
                    if re.search(rem_tag,rem_tag1,re.I|re.S):
                        # print(rem_tag)
                        hash[rem_tag]=misck.group(1)

# print(len(hash))





# print(hash)

def _tmpfunc(txt):
    for key,value in hash.items():
        txt = re.sub(r'(<item(\d+)(?: [^>]*)?>(?:(?!</?item\2|i>).)*)(<i>)?'+key+r'(</i>)?((?:(?!</item\2>).)*</item\2>)',r'\g<1><xrefGrp><xref ref="'+value+'">\g<3>'+key+r'\g<4></xref></xrefGrp>\g<5>',txt,0,re.I|re.S)
    # print(txt)
    return txt

xml_cnt = re.sub(r'<miscMatter(?: [^>]*)? class="contents">(?:(?!</miscMatter>).)*</miscMatter>',lambda m: _tmpfunc(m.group()) ,xml_cnt,0,re.I | re.S)

_save_file(xml_file,xml_cnt)

# print(xml_cnt)


# if re.search(r'<miscMatter(?: [^>]*)? class="contents">(?:(?!</miscMatter>).)*</miscMatter>',xml_cnt,re.I|re.S):
#     misc_matt = re.search(r'<miscMatter(?: [^>]*)? class="contents">((?:(?!</miscMatter>).)*)</miscMatter>', xml_cnt, re.I | re.S)
#
#     for m in re.finditer(r'<item\d+(?: [^>]*)?>\s*<p>((?:(?!</p>).)*)</p>',misc_matt.group(1),re.I|re.S):
#         rem_tag=m.group(1)
#
#         rem_tag=re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'',rem_tag,0,re.I|re.S)
#         rem_tag=re.sub(r'^(\s*)|(\s*)$',r'',rem_tag,0,re.I|re.S)
#         for key, value in hash.items():
#             if rem_tag==key:
#                 xml_cnt=re.sub(r'<miscMatter(?: [^>]*)? class="contents">(?:(?!</miscMatter>).)*</miscMatter>',lambda m: _href(m.group(),key,value),xml_cnt,0,re.I|re.S)


                    # xml_cnt = re.search(r'<miscMatter(?: [^>]*)? class="contents">((?:(?!</miscMatter>).)*)</miscMatter>', xml_cnt,re.I | re.S)

# <miscMatter(?: [^>]*)? class="contents">(?:(?!</miscMatter>).)*</miscMatter>

#------ Local tracking -------------
_local_tracking(tool_id, ToolVersion, Tra_input,_get_file_size(Tra_input),st_time, _get_timestamp())
#-----------------------------------
print ("\n\tPackage Created successfully!!!\n");
sys.exit(0)
