###################################################################
# 																  #
#  Project Name : Consistency.py	    					      #
#  Version      : 1.0.0.0                                         #
#  Developed    : ANBU .G |                                       #
#  Purpose		: Content Creation for XML to Excel               #
#  Syntax 		:  <EXE> <XML>  					              #
#                                                                 #
###################################################################

###################################################################
#
# Run  		  : Consistency.py <XML>
# Description : Create Excel file from input Xml Content
###################################################################

###################################################################
# Updation History
#=================================================================
#	28-12-2022 | v1.0.0.0 | ANBU .G	Initial Development
###################################################################

ToolVersion = "1.0.0.0";

import os
from os.path import basename, dirname
import sys
import re

import xlsxwriter


# Tool path
# ToolPath = dirname(sys.argv[0]);
# ToolPath = re.sub(r'\/', r'\\', ToolPath, 0)

# os.system("cls")
#
# # Inline argument checking
# if (len(sys.argv) != 2 or not os.path.isfile(sys.argv[1]) or not sys.argv[1].endswith('.xml')): sys.exit("\n\tSyntax: Consistency_tool.py <XML>\n")

print("\n\n\tConsistency_tool v" + str(ToolVersion) + "...\n")
print("\tCopyright @ Integra Software Services Ltd.\n")


# Global variable declaration
Input = sys.argv[1]
filename = basename(Input)
InPath = dirname(Input)

with open(Input, "r", encoding="utf-8") as f1:
    xmlcnt = f1.read()
    f1.close()

updtval=[]
updtval1=[]
updtval2=[]
updtval3=[]
updtval4=[]
updtval5=[]
updtval6=[]
updtval7=[]
updtval8=[]
updtval9=[]
updtval10=[]
updtval111=[]
updtval11=[]
updtval12=[]
updtval13=[]
updtval14=[]
updtval15=[]
updtval16=[]
updtval17=[]
updtval18=[]
updtval19=[]
updtval20=[]
updtval21=[]
updtval22=[]
updtval23=[]
updtval24=[]
updtval25=[]
workbook = xlsxwriter.Workbook(InPath+"\\"+filename+'_Log_Report.xlsx')

merge_format = workbook.add_format({'bold': 1,'border': 1,'align': 'center','valign': 'vcenter','fg_color': '#c7ffc7'})
merge_format_highlight = workbook.add_format({'bold': 1,'border': 1,'align': 'left','valign': 'vcenter','fg_color': '#f5f542'})
# index_A = "A" + str(row_no)
# worksheet.write(index_A, (x+1),merge_format5)

for xrefcnt in re.finditer(r'<xrefGrp(?: [^>]*)?((?:(?!</xrefGrp>).)*)</xrefGrp>',xmlcnt,re.I|re.S):
    temp=[]
    if re.search(r'<xref(?: [^>]*)? ref="([^"]*)"[^>]*?>((?:(?!</xref>).)*)</xref>',xrefcnt.group(),re.I|re.S):
        xref=re.search(r'<xref(?: [^>]*)? ref="([^"]*)"[^>]*?>((?:(?!</xref>).)*)</xref>',xrefcnt.group(),re.I|re.S)
        if re.search(r'-figureGroup-',xref.group(1),re.I|re.S):
            figGrpcnt=re.sub(r'<(?:[^>]*)?>',r'',xrefcnt.group(),0,re.I|re.S)
            # print("ID :"+xref.group(1)+"\txrefGrp :"+figGrpcnt)
            temp.append(xref.group(1))
            temp.append(figGrpcnt)
            if re.search(r'<figureGroup(?: [^>]*)? id="'+xref.group(1)+r'"[^>]*?>((?:(?!</figureGroup>).)*)</figureGroup>',xmlcnt,re.I|re.S):
                enum=re.search(r'<figureGroup(?: [^>]*)? id="'+xref.group(1)+'"[^>]*?>((?:(?!</figureGroup>).)*)</figureGroup>',xmlcnt,re.I|re.S)
                if re.search(r'<enumerator(?: [^>]*)?>((?:(?!</enumerator>).)*)</enumerator>',enum.group(),re.I|re.S):
                    figgrpenum=re.search(r'<enumerator(?: [^>]*)?>((?:(?!</enumerator>).)*)</enumerator>', enum.group(),re.I | re.S)
                    # print(figgrpenum.group(1))
                    temp.append(figgrpenum.group(1))
    if len(temp)>1:
        updtval.append(temp)


for xrefcnt in re.finditer(r'<xrefGrp(?: [^>]*)?((?:(?!</xrefGrp>).)*)</xrefGrp>',xmlcnt,re.I|re.S):
    temp=[]
    if re.search(r'<xref(?: [^>]*)? ref="([^"]*)"[^>]*?>((?:(?!</xref>).)*)</xref>',xrefcnt.group(),re.I|re.S):
        xref=re.search(r'<xref(?: [^>]*)? ref="([^"]*)"[^>]*?>((?:(?!</xref>).)*)</xref>',xrefcnt.group(),re.I|re.S)
        if re.search(r'-tableGroup-',xref.group(1),re.I|re.S):
            figGrpcnt=re.sub(r'<(?:[^>]*)?>',r'',xrefcnt.group(),0,re.I|re.S)
            # print("ID :"+xref.group(1)+"\txrefGrp :"+figGrpcnt)
            temp.append(xref.group(1))
            temp.append(figGrpcnt)
            if re.search(r'<tableGroup(?: [^>]*)? id="'+xref.group(1)+r'"[^>]*?>((?:(?!</tableGroup>).)*)</tableGroup>',xmlcnt,re.I|re.S):
                enum=re.search(r'<tableGroup(?: [^>]*)? id="'+xref.group(1)+'"[^>]*?>((?:(?!</tableGroup>).)*)</tableGroup>',xmlcnt,re.I|re.S)
                if re.search(r'<enumerator(?: [^>]*)?>((?:(?!</enumerator>).)*)</enumerator>',enum.group(),re.I|re.S):
                    figgrpenum=re.search(r'<enumerator(?: [^>]*)?>((?:(?!</enumerator>).)*)</enumerator>', enum.group(),re.I | re.S)
                    # print(figgrpenum.group(1))
                    temp.append(figgrpenum.group(1))
    if len(temp)>1:
        updtval1.append(temp)


for xrefcnt in re.finditer(r'<xrefGrp(?: [^>]*)?((?:(?!</xrefGrp>).)*)</xrefGrp>',xmlcnt,re.I|re.S):
    temp=[]
    if re.search(r'<xref(?: [^>]*)? ref="([^"]*)"[^>]*?>((?:(?!</xref>).)*)</xref>',xrefcnt.group(),re.I|re.S):
        xref=re.search(r'<xref(?: [^>]*)? ref="([^"]*)"[^>]*?>((?:(?!</xref>).)*)</xref>',xrefcnt.group(),re.I|re.S)
        if re.search(r'-bibItem-',xref.group(1),re.I|re.S):
            figGrpcnt=re.sub(r'<(?:[^>]*)?>',r'',xrefcnt.group(),0,re.I|re.S)
            # print("ID :"+xref.group(1)+"\txrefGrp :"+figGrpcnt)
            temp.append(xref.group(1))
            temp.append(figGrpcnt)
            if re.search(r'<bibItem(?: [^>]*)? id="'+xref.group(1)+r'"[^>]*?>((?:(?!</bibItem>).)*)</bibItem>',xmlcnt,re.I|re.S):
                enum=re.search(r'<bibItem(?: [^>]*)? id="'+xref.group(1)+'"[^>]*?>((?:(?!</bibItem>).)*)</bibItem>',xmlcnt,re.I|re.S)
                bibcnt = re.sub(r'<(?:[^>]*)?>', r'', enum.group(), 0, re.I | re.S)
                temp.append(bibcnt)
    if len(temp)>1:
        updtval2.append(temp)



for xrefcnt in re.finditer(r'(<enumerator(?: [^>]*)?>((?:(?!</enumerator>).)*)</enumerator>)?\s*<xrefGrp(?: [^>]*)?((?:(?!</xrefGrp>).)*)</xrefGrp>',xmlcnt,re.I|re.S):
    temp=[]
    if re.search(r'<xref(?: [^>]*)? ref="([^"]*)"[^>]*?>((?:(?!</xref>).)*)</xref>',xrefcnt.group(),re.I|re.S):
        xref=re.search(r'<xref(?: [^>]*)? ref="([^"]*)"[^>]*?>((?:(?!</xref>).)*)</xref>',xrefcnt.group(),re.I|re.S)
        if re.search(r'-div',xref.group(1),re.I|re.S):
            figGrpcnt1=re.sub(r'<pageNum(?: [^>]*)?>((?:(?!</pageNum>).)*)</pageNum>',r'',xrefcnt.group(),0,re.I|re.S)
            figGrpcnt=re.sub(r'<(?:[^>]*)?>',r'',figGrpcnt1,0,re.I|re.S)
            # print("ID :"+xref.group(1)+"\txrefGrp :"+figGrpcnt)
            temp.append(xref.group(1))
            # if xrefcnt.group(2):
            #     temp.append(xrefcnt.group(2)+" "+figGrpcnt)
            # else:
            temp.append(figGrpcnt)
            # print(temp)
            if re.search(r'<div\w(?: [^>]*)? id="'+xref.group(1)+r'"(?: [^>]*)?>((?:(?!</titleGroup>).)*</titleGroup>)',xmlcnt,re.I|re.S):
                # print("temp")
                enum=re.search(r'<div\w(?: [^>]*)? id="'+xref.group(1)+r'"(?: [^>]*)?>((?:(?!</titleGroup>).)*</titleGroup>)',xmlcnt,re.I|re.S)
                if re.search(r'<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>', enum.group(),re.I | re.S):
                    figgrpenum = re.search(r'<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>',enum.group(), re.I | re.S)
                    secGrpcnt = re.sub(r'<(?:[^>]*)?>', r'', figgrpenum.group(), 0, re.I | re.S)
                    # print(figgrpenum.group(1))
                    temp.append(secGrpcnt)
    if len(temp)>1:
        updtval3.append(temp)


for xrefcnt in re.finditer(r'<xrefGrp(?: [^>]*)?((?:(?!</xrefGrp>).)*)</xrefGrp>',xmlcnt,re.I|re.S):
    temp=[]
    if re.search(r'<xref(?: [^>]*)? ref="([^"]*)"[^>]*?>((?:(?!</xref>).)*)</xref>',xrefcnt.group(),re.I|re.S):
        xref=re.search(r'<xref(?: [^>]*)? ref="([^"]*)"[^>]*?>((?:(?!</xref>).)*)</xref>',xrefcnt.group(),re.I|re.S)
        if re.search(r'-displayMaths-',xref.group(1),re.I|re.S):
            figGrpcnt=re.sub(r'<(?:[^>]*)?>',r'',xrefcnt.group(),0,re.I|re.S)
            # print("ID :"+xref.group(1)+"\txrefGrp :"+figGrpcnt)
            temp.append(xref.group(1))
            temp.append(figGrpcnt)
            if re.search(r'<displayMaths(?: [^>]*)? id="'+xref.group(1)+r'"[^>]*?>((?:(?!</displayMaths>).)*)</displayMaths>',xmlcnt,re.I|re.S):
                enum=re.search(r'<displayMaths(?: [^>]*)? id="'+xref.group(1)+'"[^>]*?>((?:(?!</displayMaths>).)*)</displayMaths>',xmlcnt,re.I|re.S)
                if re.search(r'<enumerator(?: [^>]*)?>((?:(?!</enumerator>).)*)</enumerator>', enum.group(),re.I | re.S):
                    figgrpenum = re.search(r'<enumerator(?: [^>]*)?>((?:(?!</enumerator>).)*)</enumerator>',enum.group(), re.I | re.S)
                    # print(figgrpenum.group(1))
                    temp.append(figgrpenum.group(1))
            else:
                temp.append(" ")
    if len(temp)>1:
        updtval4.append(temp)


for xrefcnt in re.finditer(r'<xrefGrp(?: [^>]*)?((?:(?!</xrefGrp>).)*)</xrefGrp>',xmlcnt,re.I|re.S):
    temp=[]
    if re.search(r'<xref(?: [^>]*)? ref="([^"]*)"[^>]*?>((?:(?!</xref>).)*)</xref>',xrefcnt.group(),re.I|re.S):
        xref=re.search(r'<xref(?: [^>]*)? ref="([^"]*)"[^>]*?>((?:(?!</xref>).)*)</xref>',xrefcnt.group(),re.I|re.S)
        if re.search(r'-displayText-',xref.group(1),re.I|re.S):
            figGrpcnt=re.sub(r'<(?:[^>]*)?>',r'',xrefcnt.group(),0,re.I|re.S)
            # print("ID :"+xref.group(1)+"\txrefGrp :"+figGrpcnt)
            temp.append(xref.group(1))
            temp.append(figGrpcnt)
            if re.search(r'<displayText(?: [^>]*)? id="'+xref.group(1)+r'"[^>]*?>((?:(?!</displayText>).)*)</displayText>',xmlcnt,re.I|re.S):
                enum=re.search(r'<displayText(?: [^>]*)? id="'+xref.group(1)+'"[^>]*?>((?:(?!</displayText>).)*)</displayText>',xmlcnt,re.I|re.S)
                if re.search(r'<enumerator(?: [^>]*)?>((?:(?!</enumerator>).)*)</enumerator>',enum.group(),re.I|re.S):
                    figgrpenum=re.search(r'<enumerator(?: [^>]*)?>((?:(?!</enumerator>).)*)</enumerator>', enum.group(),re.I | re.S)
                    # print(figgrpenum.group(1))
                    temp.append(figgrpenum.group(1))
    if len(temp)>1:
        updtval5.append(temp)

for xrefcnt in re.finditer(r'<xrefGrp(?: [^>]*)?((?:(?!</xrefGrp>).)*)</xrefGrp>',xmlcnt,re.I|re.S):
    temp=[]
    if re.search(r'<xref(?: [^>]*)? ref="([^"]*)"[^>]*?>((?:(?!</xref>).)*)</xref>',xrefcnt.group(),re.I|re.S):
        xref=re.search(r'<xref(?: [^>]*)? ref="([^"]*)"[^>]*?>((?:(?!</xref>).)*)</xref>',xrefcnt.group(),re.I|re.S)
        if re.search(r'-note-',xref.group(1),re.I|re.S):
            figGrpcnt=re.sub(r'<(?:[^>]*)?>',r'',xrefcnt.group(),0,re.I|re.S)
            # print("ID :"+xref.group(1)+"\txrefGrp :"+figGrpcnt)
            temp.append(xref.group(1))
            temp.append(figGrpcnt)
            if re.search(r'<note(?: [^>]*)? id="'+xref.group(1)+r'"[^>]*?>((?:(?!</note>).)*)</note>',xmlcnt,re.I|re.S):
                enum=re.search(r'<note(?: [^>]*)? id="'+xref.group(1)+'"[^>]*?>((?:(?!</note>).)*)</note>',xmlcnt,re.I|re.S)
                if re.search(r'<enumerator(?: [^>]*)?>((?:(?!</enumerator>).)*)</enumerator>',enum.group(),re.I|re.S):
                    figgrpenum=re.search(r'<enumerator(?: [^>]*)?>((?:(?!</enumerator>).)*)</enumerator>', enum.group(),re.I | re.S)
                    # print(figgrpenum.group(1))
                    temp.append(figgrpenum.group(1))
    if len(temp)>1:
        updtval6.append(temp)

for xrefcnt in re.finditer(r'(<enumerator(?: [^>]*)?>((?:(?!</enumerator>).)*)</enumerator>)?\s*<xrefGrp(?: [^>]*)?((?:(?!</xrefGrp>).)*)</xrefGrp>',xmlcnt,re.I|re.S):
    temp=[]
    if re.search(r'<xref(?: [^>]*)? ref="([^"]*)"[^>]*?>((?:(?!</xref>).)*)</xref>',xrefcnt.group(),re.I|re.S):
        xref=re.search(r'<xref(?: [^>]*)? ref=([^>]*)(?: [^>]*)?>((?:(?!</xref>).)*)</xref>',xrefcnt.group(),re.I|re.S)
        if re.search(r'oso-\d+-(chapter|appendix)-(\d+|\w)\"',xref.group(1),re.I|re.S):
            figGrpcnt=re.sub(r'<(?:[^>]*)?>',r'',xrefcnt.group(),0,re.I|re.S)
            # print("ID :"+xref.group(1)+"\txrefGrp :"+figGrpcnt)
            temp.append(xref.group(1))
            serchid=xref.group(1)
            serchid=re.sub(r'\"$',r'',serchid,0,re.I|re.S)
            temp.append(figGrpcnt)
            if re.search(r'<titleGroup(?: [^>]*)? id='+serchid+r'-titleGroup-\d+"[^>]*?>((?:(?!</titleGroup>).)*)</titleGroup>',xmlcnt,re.I|re.S):
                enum=re.search(r'<titleGroup(?: [^>]*)? id='+serchid+'-titleGroup-\d+"[^>]*?>((?:(?!</titleGroup>).)*)</titleGroup>',xmlcnt,re.I|re.S)
                if re.search(r'<enumerator(?: [^>]*)?>((?:(?!</enumerator>).)*)</enumerator>',enum.group(),re.I|re.S):
                    figgrpenum=re.search(r'<enumerator(?: [^>]*)?>((?:(?!</enumerator>).)*)</enumerator>', enum.group(),re.I | re.S)
                    # print(figgrpenum.group(1))
                    temp.append(figgrpenum.group(1))
    if len(temp)>1:
        updtval7.append(temp)


for xrefcnt in re.finditer(r'<sdCode(?: [^>]*)?>((?:(?!</sdCode>).)*)</sdCode>',xmlcnt,re.I|re.S):
    updtval8.append(xrefcnt.group(1))

for xrefcnt in re.finditer(r'<sdExpansion(?: [^>]*)?>((?:(?!</sdExpansion>).)*)</sdExpansion>', xmlcnt, re.I | re.S):
    updtval9.append(xrefcnt.group(1))

for xrefcnt in re.finditer(r'<creator(?: [^>]*)?>((?:(?!</creator>).)*)</creator>', xmlcnt, re.I | re.S):
    # updtval9.append(xrefcnt.group(1))
    temp=[]
    if re.search(r'class="([^"]*)"',xrefcnt.group(),re.I|re.S):
        clas=re.search(r'class="([^"]*)"',xrefcnt.group(),re.I|re.S)
        temp.append(clas.group(1))
    if re.search(r'invertedForm="([^"]*)"',xrefcnt.group(),re.I|re.S):
        invertedForm=re.search(r'invertedForm="([^"]*)"',xrefcnt.group(),re.I|re.S)
        temp.append(invertedForm.group(1))
    if re.search(r'<forenames(?: [^>]*)?>((?:(?!</forenames>).)*)</forenames>',xrefcnt.group(),re.I|re.S):
        forename=re.search(r'<forenames(?: [^>]*)?>((?:(?!</forenames>).)*)</forenames>',xrefcnt.group(),re.I|re.S)
        temp.append(forename.group(1))
    if re.search(r'<surname(?: [^>]*)?>((?:(?!</surname>).)*)</surname>',xrefcnt.group(),re.I|re.S):
        surname=re.search(r'<surname(?: [^>]*)?>((?:(?!</surname>).)*)</surname>',xrefcnt.group(),re.I|re.S)
        temp.append(surname.group(1))

    updtval10.append(temp)

for xrefcnt in re.finditer(r'<metaDescribes(?: [^>]*)? predicate="DTDname"(?: [^>]*)?>((?:(?!</metaDescribes>).)*)</metaDescribes>', xmlcnt, re.I | re.S):
    updtval111.append(xrefcnt.group(1))

for xrefcnt in re.finditer(r'<metaDescribes(?: [^>]*)? predicate="TCIname"(?: [^>]*)?>((?:(?!</metaDescribes>).)*)</metaDescribes>', xmlcnt, re.I | re.S):
    updtval11.append(xrefcnt.group(1))

for xrefcnt in re.finditer(r'<metaDescribes(?: [^>]*)? predicate="version"(?: [^>]*)?>((?:(?!</metaDescribes>).)*)</metaDescribes>', xmlcnt, re.I | re.S):
    updtval12.append(xrefcnt.group(1))

for xrefcnt in re.finditer(r'<metaDescribes(?: [^>]*)? predicate="product"(?: [^>]*)?>((?:(?!</metaDescribes>).)*)</metaDescribes>', xmlcnt, re.I | re.S):
    updtval13.append(xrefcnt.group(1))

for xrefcnt in re.finditer(r'<metaDescribes(?: [^>]*)? predicate="colour-figures-for-online"(?: [^>]*)?>((?:(?!</metaDescribes>).)*)</metaDescribes>', xmlcnt, re.I | re.S):
    updtval14.append(xrefcnt.group(1))

for xrefcnt in re.finditer(r'<metaDescribes(?: [^>]*)? predicate="publishing-group"(?: [^>]*)?>((?:(?!</metaDescribes>).)*)</metaDescribes>', xmlcnt, re.I | re.S):
    updtval15.append(xrefcnt.group(1))

for xrefcnt in re.finditer(r'<metaDescribes(?: [^>]*)? predicate="captured-by"(?: [^>]*)?>((?:(?!</metaDescribes>).)*)</metaDescribes>', xmlcnt, re.I | re.S):
    updtval16.append(xrefcnt.group(1))

for xrefcnt in re.finditer(r'<div1(?: [^>]*)?>\s*<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>', xmlcnt, re.I | re.S):
    tmepval = re.sub(r'<(?:[^>]*)?>', r'', xrefcnt.group(), 0, re.I | re.S)
    updtval17.append(tmepval)

for xrefcnt in re.finditer(r'<div2(?: [^>]*)?>\s*<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>', xmlcnt, re.I | re.S):
    tmepval = re.sub(r'<(?:[^>]*)?>', r'', xrefcnt.group(), 0, re.I | re.S)
    updtval18.append(tmepval)

for xrefcnt in re.finditer(r'<div3(?: [^>]*)?>\s*<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>', xmlcnt, re.I | re.S):
    tmepval = re.sub(r'<(?:[^>]*)?>', r'', xrefcnt.group(), 0, re.I | re.S)
    updtval19.append(tmepval)

for xrefcnt in re.finditer(r'<div4(?: [^>]*)?>\s*<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>', xmlcnt, re.I | re.S):
    tmepval = re.sub(r'<(?:[^>]*)?>', r'', xrefcnt.group(), 0, re.I | re.S)
    updtval20.append(tmepval)

for xrefcnt in re.finditer(r'<divN(?: [^>]*)?>\s*<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>', xmlcnt, re.I | re.S):
    tmepval = re.sub(r'<(?:[^>]*)?>', r'', xrefcnt.group(), 0, re.I | re.S)
    updtval21.append(tmepval)

for xrefcnt in re.finditer(r'<indexItem1(?: [^>]*)?>((?:(?!</indexItem1>).)*)</indexItem1>', xmlcnt, re.I | re.S):
    tmepval2=''
    tmepval = re.sub(r'<indexItem(2|3|4|N)?(?: [^>]*)?>((?:(?!</indexItem(2|3|4|N)?>).)*)</indexItem(2|3|4|N)?>', r'', xrefcnt.group(), 0, re.I | re.S)
    for xrefcnt1 in re.finditer(r'<pageNum(?: [^>]*)?>\s*<xref(?: [^>]*)?>((?:(?!</xref>).)*)</xref></pageNum>', tmepval,re.I | re.S):
        tmepval2 =tmepval2+ "," +(re.sub(r'<(?:[^>]*)?>', r'', xrefcnt1.group(1), 0, re.I | re.S))

    updtval22.append(tmepval2)

for xrefcnt in re.finditer(r'<indexItem2(?: [^>]*)?>((?:(?!</indexItem2>).)*)</indexItem2>', xmlcnt, re.I | re.S):
    tmepval2 = ''
    tmepval = re.sub(r'<indexItem(3|4|N)?(?: [^>]*)?>((?:(?!</indexItem(3|4|N)?>).)*)</indexItem(3|4|N)?>', r'', xrefcnt.group(), 0, re.I | re.S)
    for xrefcnt1 in re.finditer(r'<pageNum(?: [^>]*)?>\s*<xref(?: [^>]*)?>((?:(?!</xref>).)*)</xref></pageNum>', tmepval,re.I | re.S):
        tmepval2 = tmepval2+ "," +(re.sub(r'<(?:[^>]*)?>', r'', xrefcnt1.group(1), 0, re.I | re.S))

    updtval23.append(tmepval2)

for xrefcnt in re.finditer(r'<indexItem3(?: [^>]*)?>((?:(?!</indexItem3>).)*)</indexItem3>', xmlcnt, re.I | re.S):
    tmepval2 = ''
    tmepval = re.sub(r'<indexItem(4|N)?(?: [^>]*)?>((?:(?!</indexItem(4|N)?>).)*)</indexItem(4|N)?>', r'', xrefcnt.group(), 0, re.I | re.S)
    for xrefcnt1 in re.finditer(r'<pageNum(?: [^>]*)?>\s*<xref(?: [^>]*)?>((?:(?!</xref>).)*)</xref></pageNum>', tmepval,re.I | re.S):
        mepval2 = tmepval2+ "," +(re.sub(r'<(?:[^>]*)?>', r'', xrefcnt1.group(1), 0, re.I | re.S))

    updtval24.append(tmepval2)

for xrefcnt in re.finditer(r'<indexItem4(?: [^>]*)?>((?:(?!</indexItem4>).)*)</indexItem4>', xmlcnt, re.I | re.S):
    tmepval = re.sub(r'<indexItemN(?: [^>]*)?>((?:(?!</indexItemN>).)*)</indexItemN>', r'', xrefcnt.group(), 0, re.I | re.S)
    for xrefcnt1 in re.finditer(r'<pageNum(?: [^>]*)?>\s*<xref(?: [^>]*)?>((?:(?!</xref>).)*)</xref></pageNum>', tmepval,re.I | re.S):
        mepval2 =tmepval2+ "," +(re.sub(r'<(?:[^>]*)?>', r'', xrefcnt1.group(1), 0, re.I | re.S))

    updtval25.append(tmepval2)

# print(updtval2)


worksheet = workbook.add_worksheet('Ref_Id_Checking')

for x in range(len(updtval2)):
    # print(len(updtval))
    if len(updtval2[x]) > 2:
        worksheet.write("A1", "Ref_id",merge_format)
        worksheet.write("B1", "Corresponding Author_Name",merge_format)
        worksheet.write("C1", "BibItem",merge_format)
        worksheet.write("D1", "Condition", merge_format)
        # print(updtval[x][2])
        index_A = "A" + str(x+2)
        worksheet.write(index_A, (updtval2[x][0]))
        index_B = "B" + str(x+2)
        worksheet.write(index_B, (updtval2[x][1]))
        index_C = "C" + str(x+2)
        worksheet.write(index_C, (updtval2[x][2]))

        updtval2[x][1] = re.sub(r'(\w+\s*)?\(', r'\g<1>', updtval2[x][1], 0, re.I | re.S)
        updtval2[x][2] = re.sub(r'(\w+\s*)?\(', r'\g<1>', updtval2[x][2], 0, re.I | re.S)
        updtval2[x][1] = re.sub(r'(\d+)?\)', r'\g<1>', updtval2[x][1], 0, re.I | re.S)
        updtval2[x][2] = re.sub(r'(\d+)?\)', r'\g<1>', updtval2[x][2], 0, re.I | re.S)

        index_D = "D" + str(x + 2)
        if re.search(r'(^[\d.]+|[\d.]+\w?$)', updtval2[x][1], re.I | re.S):
            checkvalue1 = re.search(r'(^[\d.]+|[\d.]+\w?$)', updtval2[x][1], re.I | re.S)
            if re.search(checkvalue1.group(), updtval2[x][2], re.I | re.S):
                if re.search(r'(^[\w\d.]+|[\d.]+$)', updtval2[x][1], re.I | re.S):
                    checkvalue2 = re.search(r'(^[\w\d.]+|[\d.]+$)', updtval2[x][1], re.I | re.S)
                    if re.search(checkvalue1.group(), updtval2[x][2], re.I | re.S):

                        # formulatrue1=index_B+"="+index_C
                        # formulatrue="=IF("+formulatrue1+", \"True\", \"False\")"
                        worksheet.write(index_D, "True")
                    else:
                        worksheet.write(index_D, "False", merge_format_highlight)

                else:
                    worksheet.write(index_D, "False", merge_format_highlight)
            else:
                worksheet.write(index_D, "False", merge_format_highlight)
        else:
            worksheet.write(index_D, "False", merge_format_highlight)

worksheet = workbook.add_worksheet('Fig_Id_Checking')

for x in range(len(updtval)):
    # print(len(updtval))
    if len(updtval[x]) > 2:
        worksheet.write("A1", "Fig_Id",merge_format)
        worksheet.write("B1", "xrefGrp",merge_format)
        worksheet.write("C1", "FigureGroup_Enumerator",merge_format)
        worksheet.write("D1", "Condition",merge_format)
        # print(updtval[x][2])
        index_A = "A" + str(x+2)
        worksheet.write(index_A, (updtval[x][0]))
        index_B = "B" + str(x+2)
        worksheet.write(index_B, (updtval[x][1]))
        index_C = "C" + str(x+2)
        worksheet.write(index_C, (updtval[x][2]))
        index_D = "D" + str(x + 2)
        if re.search(r'(^[\d.]+|[\d.]+$)', updtval[x][1], re.I | re.S):
            checkvalue1 = re.search(r'(^[\d.]+|[\d.]+$)', updtval[x][1], re.I | re.S)
            if re.search(checkvalue1.group(), updtval[x][2], re.I | re.S):

                # formulatrue1=index_B+"="+index_C
                # formulatrue="=IF("+formulatrue1+", \"True\", \"False\")"
                worksheet.write(index_D, "True")
            else:
                worksheet.write(index_D, "False", merge_format_highlight)
        elif re.search(r'(^[\w\d.]+|[\d.]+$)', updtval[x][1], re.I | re.S):
            checkvalue1 = re.search(r'(^[\w\d.]+|[\d.]+$)', updtval[x][1], re.I | re.S)
            if re.search(checkvalue1.group(), updtval[x][2], re.I | re.S):

                # formulatrue1=index_B+"="+index_C
                # formulatrue="=IF("+formulatrue1+", \"True\", \"False\")"
                worksheet.write(index_D, "True")
            else:
                worksheet.write(index_D, "False", merge_format_highlight)

worksheet = workbook.add_worksheet('Tab_Id_Checking')
for x in range(len(updtval1)):
    # print(len(updtval))
    if len(updtval1[x]) > 2:
        worksheet.write("A1", "Table_Id",merge_format)
        worksheet.write("B1", "xrefGrp",merge_format)
        worksheet.write("C1", "tableGroup_Enumerator",merge_format)
        worksheet.write("D1", "Condition", merge_format)
        # print(updtval[x][2])
        index_A = "A" + str(x+2)
        worksheet.write(index_A, (updtval1[x][0]))
        index_B = "B" + str(x+2)
        worksheet.write(index_B, (updtval1[x][1]))
        index_C = "C" + str(x+2)
        worksheet.write(index_C, (updtval1[x][2]))
        index_D = "D" + str(x + 2)
        if re.search(r'(^[\d.]+|[\d.]+$)', updtval1[x][1], re.I | re.S):
            checkvalue1 = re.search(r'(^[\d.]+|[\d.]+$)', updtval1[x][1], re.I | re.S)
            if re.search(checkvalue1.group(), updtval1[x][2], re.I | re.S):

                # formulatrue1=index_B+"="+index_C
                # formulatrue="=IF("+formulatrue1+", \"True\", \"False\")"
                worksheet.write(index_D, "True")
            else:
                worksheet.write(index_D, "False", merge_format_highlight)
        elif re.search(r'(^[\w\d.]+|[\d.]+$)', updtval1[x][1], re.I | re.S):
            checkvalue1 = re.search(r'(^[\w\d.]+|[\d.]+$)', updtval1[x][1], re.I | re.S)
            if re.search(checkvalue1.group(), updtval1[x][2], re.I | re.S):

                # formulatrue1=index_B+"="+index_C
                # formulatrue="=IF("+formulatrue1+", \"True\", \"False\")"
                worksheet.write(index_D, "True")
            else:
                worksheet.write(index_D, "False", merge_format_highlight)

worksheet = workbook.add_worksheet('Sec_Id_Checking')

for x in range(len(updtval3)):
    # print(len(updtval))
    if len(updtval3[x]) > 2:
        worksheet.write("A1", "Section_Id",merge_format)
        worksheet.write("B1", "xrefGrp",merge_format)
        worksheet.write("C1", "TitleGroup",merge_format)
        worksheet.write("D1", "Condition", merge_format)
        # print(updtval[x][2])
        index_A = "A" + str(x+2)
        worksheet.write(index_A, (updtval3[x][0]))
        index_B = "B" + str(x+2)
        worksheet.write(index_B, (updtval3[x][1]))
        index_C = "C" + str(x+2)
        worksheet.write(index_C, (updtval3[x][2]))
        index_D = "D" + str(x + 2)
        # if updtval3[x][1] == updtval3[x][2]:
        if re.search(r'(^[\d.]+|[\d.]+$)',updtval3[x][1],re.I|re.S):
            checkvalue1=re.search(r'(^[\d.]+|[\d.]+$)',updtval3[x][1],re.I|re.S)
            if re.search(checkvalue1.group(),updtval3[x][2],re.I|re.S):

            # formulatrue1=index_B+"="+index_C
            # formulatrue="=IF("+formulatrue1+", \"True\", \"False\")"
                worksheet.write(index_D,"True" )
            else:
                worksheet.write(index_D, "False",merge_format_highlight)
        elif re.search(r'(^[\w\d.]+|[\d.]+$)', updtval3[x][1], re.I | re.S):
            checkvalue1 = re.search(r'(^[\w\d.]+|[\d.]+$)', updtval3[x][1], re.I | re.S)
            if re.search(checkvalue1.group(), updtval3[x][2], re.I | re.S):

                # formulatrue1=index_B+"="+index_C
                # formulatrue="=IF("+formulatrue1+", \"True\", \"False\")"
                worksheet.write(index_D, "True")
            else:
                worksheet.write(index_D, "False", merge_format_highlight)

worksheet = workbook.add_worksheet('displayMath_Id_Checking')


for x in range(len(updtval4)):
    # print(len(updtval4[x]),"-",x,"-",updtval4[x])
    if len(updtval4[x])>2:
        worksheet.write("A1", "displayMath_Id",merge_format)
        worksheet.write("B1", "xrefGrp",merge_format)
        worksheet.write("C1", "displayMath_Enumerator",merge_format)
        worksheet.write("D1", "Condition", merge_format)
        # print(updtval[x][2])
        index_A = "A" + str(x+2)
        worksheet.write(index_A, (updtval4[x][0]))
        index_B = "B" + str(x+2)
        worksheet.write(index_B, (updtval4[x][1]))
        index_C = "C" + str(x+2)
        worksheet.write(index_C, (updtval4[x][2]))
        index_D = "D" + str(x + 2)
        updtval4[x][1]=re.sub(r'(\w+\s*)?\(',r'\g<1>',updtval4[x][1],0,re.I|re.S)
        updtval4[x][2]=re.sub(r'(\w+\s*)?\(',r'\g<1>',updtval4[x][2],0,re.I|re.S)
        updtval4[x][1]=re.sub(r'(\d+)?\)',r'\g<1>',updtval4[x][1],0,re.I|re.S)
        updtval4[x][2]=re.sub(r'(\d+)?\)',r'\g<1>',updtval4[x][2],0,re.I|re.S)
        if re.search(r'(^[\d.]+|[\d.]+$)', updtval4[x][1], re.I | re.S):
            checkvalue1 = re.search(r'(^[\d.]+|[\d.]+$)', updtval4[x][1], re.I | re.S)
            if re.search(checkvalue1.group(), updtval4[x][2], re.I | re.S):

                # formulatrue1=index_B+"="+index_C
                # formulatrue="=IF("+formulatrue1+", \"True\", \"False\")"
                worksheet.write(index_D, "True")
            else:
                worksheet.write(index_D, "False", merge_format_highlight)
        elif re.search(r'(^[\w\d.]+|[\d.]+$)', updtval4[x][1], re.I | re.S):
            checkvalue1 = re.search(r'(^[\w\d.]+|[\d.]+$)', updtval4[x][1], re.I | re.S)
            if re.search(checkvalue1.group(), updtval4[x][2], re.I | re.S):

                # formulatrue1=index_B+"="+index_C
                # formulatrue="=IF("+formulatrue1+", \"True\", \"False\")"
                worksheet.write(index_D, "True")
            else:
                worksheet.write(index_D, "False", merge_format_highlight)


worksheet = workbook.add_worksheet('displayText_Id_Checking')

for x in range(len(updtval5)):
    # print(len(updtval))
    if len(updtval5[x]) > 2:
        worksheet.write("A1", "displayText_Id",merge_format)
        worksheet.write("B1", "xrefGrp",merge_format)
        worksheet.write("C1", "displayText_Enumerator",merge_format)
        worksheet.write("D1", "Condition",merge_format)
        # print(updtval[x][2])
        index_A = "A" + str(x+2)
        worksheet.write(index_A, (updtval5[x][0]))
        index_B = "B" + str(x+2)
        worksheet.write(index_B, (updtval5[x][1]))
        index_C = "C" + str(x+2)
        worksheet.write(index_C, (updtval5[x][2]))
        index_D = "D" + str(x + 2)
        if re.search(r'(^[\d.]+|[\d.]+$)', updtval5[x][1], re.I | re.S):
            checkvalue1 = re.search(r'(^[\d.]+|[\d.]+$)', updtval5[x][1], re.I | re.S)
            if re.search(checkvalue1.group(), updtval5[x][2], re.I | re.S):

                # formulatrue1=index_B+"="+index_C
                # formulatrue="=IF("+formulatrue1+", \"True\", \"False\")"
                worksheet.write(index_D, "True")
            else:
                worksheet.write(index_D, "False", merge_format_highlight)
        elif re.search(r'(^[\w\d.]+|[\d.]+$)', updtval5[x][1], re.I | re.S):
            checkvalue1 = re.search(r'(^[\w\d.]+|[\d.]+$)', updtval5[x][1], re.I | re.S)
            if re.search(checkvalue1.group(), updtval5[x][2], re.I | re.S):

                # formulatrue1=index_B+"="+index_C
                # formulatrue="=IF("+formulatrue1+", \"True\", \"False\")"
                worksheet.write(index_D, "True")
            else:
                worksheet.write(index_D, "False", merge_format_highlight)


worksheet = workbook.add_worksheet('Footnote_Id_Checking')

for x in range(len(updtval6)):
    # print(len(updtval))
    if len(updtval6[x]) > 2:
        worksheet.write("A1", "displayText_Id",merge_format)
        worksheet.write("B1", "xrefGrp",merge_format)
        worksheet.write("C1", "displayText_Enumerator",merge_format)
        worksheet.write("D1", "Condition",merge_format)
        # print(updtval[x][2])
        index_A = "A" + str(x+2)
        worksheet.write(index_A, (updtval6[x][0]))
        index_B = "B" + str(x+2)
        worksheet.write(index_B, (updtval6[x][1]))
        index_C = "C" + str(x+2)
        worksheet.write(index_C, (updtval6[x][2]))
        index_D = "D" + str(x + 2)
        if re.search(r'(^[\d.]+|[\d.]+$)', updtval6[x][1], re.I | re.S):
            checkvalue1 = re.search(r'(^[\d.]+|[\d.]+$)', updtval6[x][1], re.I | re.S)
            if re.search(checkvalue1.group(), updtval6[x][2], re.I | re.S):

                # formulatrue1=index_B+"="+index_C
                # formulatrue="=IF("+formulatrue1+", \"True\", \"False\")"
                worksheet.write(index_D, "True")
            else:
                worksheet.write(index_D, "False", merge_format_highlight)
        elif re.search(r'(^[\w\d.]+|[\d.]+$)', updtval6[x][1], re.I | re.S):
            checkvalue1 = re.search(r'(^[\w\d.]+|[\d.]+$)', updtval6[x][1], re.I | re.S)
            if re.search(checkvalue1.group(), updtval6[x][2], re.I | re.S):

                # formulatrue1=index_B+"="+index_C
                # formulatrue="=IF("+formulatrue1+", \"True\", \"False\")"
                worksheet.write(index_D, "True")
            else:
                worksheet.write(index_D, "False", merge_format_highlight)


worksheet = workbook.add_worksheet('Chapter_Appendix_Id_Checking')

for x in range(len(updtval7)):
    # print(len(updtval))
    if len(updtval7[x]) > 2:
        worksheet.write("A1", "Chapter/Appendix_Id",merge_format)
        worksheet.write("B1", "xrefGrp",merge_format)
        worksheet.write("C1", "Chapter/Appendix_Enumerator",merge_format)
        worksheet.write("D1", "Condition",merge_format)
        # print(updtval[x][2])
        index_A = "A" + str(x+2)
        worksheet.write(index_A, (updtval7[x][0]))
        index_B = "B" + str(x+2)
        worksheet.write(index_B, (updtval7[x][1]))
        index_C = "C" + str(x+2)
        worksheet.write(index_C, (updtval7[x][2]))
        index_D = "D" + str(x + 2)
        if re.search(r'(^[\d.]+|[\d.]+$)', updtval7[x][1], re.I | re.S):
            checkvalue1 = re.search(r'(^[\d.]+|[\d.]+$)', updtval7[x][1], re.I | re.S)
            if re.search(checkvalue1.group(), updtval7[x][2], re.I | re.S):

                # formulatrue1=index_B+"="+index_C
                # formulatrue="=IF("+formulatrue1+", \"True\", \"False\")"
                worksheet.write(index_D, "True")
            else:
                worksheet.write(index_D, "False", merge_format_highlight)
        elif re.search(r'(^[\w\d.]+|[\d.]+$) (\w+)?', updtval7[x][1], re.I | re.S):
            checkvalue1 = re.search(r'(^[\w\d.]+|[\d.]+$) (\w+)?', updtval7[x][1], re.I | re.S)
            if re.search(checkvalue1.group(), updtval7[x][2], re.I | re.S):

                # formulatrue1=index_B+"="+index_C
                # formulatrue="=IF("+formulatrue1+", \"True\", \"False\")"
                worksheet.write(index_D, "True")
            elif re.search(checkvalue1.group(2), updtval7[x][2], re.I | re.S):
                worksheet.write(index_D, "True")
            else:
                worksheet.write(index_D, "False", merge_format_highlight)


worksheet = workbook.add_worksheet('OSOsubdiscipline')

for x in range(len(updtval8)):
    # print(len(updtval))
    if len(updtval8) > 0:
        worksheet.write("A1", "SD_CODE",merge_format)
        worksheet.write("C1", "Condition_SD_CODE", merge_format)
        index_A = "A" + str(x+2)
        worksheet.write(index_A, (updtval8[x]))
        index_D = "C" + str(x + 2)
        if updtval8[0] != updtval8[x]:
            worksheet.write(index_D, "False", merge_format_highlight)
        else:
            worksheet.write(index_D, "True")
for x in range(len(updtval9)):
    # print(len(updtval))
    if len(updtval9) > 0:
        worksheet.write("B1", "SD_EXPANSION", merge_format)
        worksheet.write("D1", "Condition_SD_EXPANSION", merge_format)
        index_B = "B" + str(x+2)
        worksheet.write(index_B, (updtval9[x]))
        index_E = "D" + str(x + 2)
        if updtval9[0] != updtval9[x]:
            worksheet.write(index_E, "False", merge_format_highlight)
        else:
            worksheet.write(index_E, "True")



worksheet = workbook.add_worksheet('CreatorGroup')

for x in range(len(updtval10)):
    # print(len(updtval))
    if len(updtval10) > 3:
        worksheet.write("A1", "CLASS",merge_format)
        worksheet.write("B1", "InvertedForm", merge_format)
        worksheet.write("C1", "forenames", merge_format)
        worksheet.write("D1", "surname", merge_format)
        worksheet.write("E1", "InvertedForm_Condition", merge_format)
        index_A = "A" + str(x+2)
        worksheet.write(index_A, (updtval10[x][0]))
        index_B = "B" + str(x + 2)
        worksheet.write(index_B, (updtval10[x][1]))
        index_C = "C" + str(x + 2)
        worksheet.write(index_C, (updtval10[x][2]))
        index_D = "D" + str(x + 2)
        worksheet.write(index_D, (updtval10[x][3]))
        index_E = "E" + str(x + 2)
        checkvalue3=updtval10[x][3]+", "+updtval10[x][2]
        if checkvalue3==updtval10[x][1]:

            worksheet.write(index_E, "True")
        else:
            worksheet.write(index_E, "False", merge_format_highlight)


for x in range(len(updtval10)):
    countn=0
    worksheet.write("F1", "Condition_forenames", merge_format)
    index_E = "F" + str(x + 2)
    for y in range(x+1,len(updtval10)):
        if updtval10[x][2]==updtval10[y][2]:
            if countn == 2:
                break
            countn=countn+1
        if countn>0:
            worksheet.write(index_E, "True")
        else:
            worksheet.write(index_E, "False", merge_format_highlight)





worksheet = workbook.add_worksheet('metaItem')

for x in range(len(updtval111)):
    # print(len(updtval))
    if len(updtval111) > 0:
        worksheet.write("A1", "DTDname",merge_format)
        worksheet.write("H1", "Condition_DTDname",merge_format)
        index_A = "A" + str(x + 2)
        worksheet.write(index_A, str(updtval111[x]))
        index_chk = "H" + str(x + 2)
        if updtval111[0] != updtval111[x]:
            worksheet.write(index_chk, "False", merge_format_highlight)
        else:
            worksheet.write(index_chk, "True")


for x in range(len(updtval11)):
    # print(len(updtval))
    if len(updtval11) > 0:
        worksheet.write("B1", "TCIname", merge_format)
        worksheet.write("I1", "Condition_TCIname", merge_format)
        index_B = "B" + str(x + 2)
        worksheet.write(index_B, str(updtval11[x]))

        index_chk = "I" + str(x + 2)
        if updtval11[0] != updtval11[x]:
            worksheet.write(index_chk, "False", merge_format_highlight)
        else:
            worksheet.write(index_chk, "True")

for x in range(len(updtval12)):
    # print(len(updtval))
    if len(updtval12) > 0:
        worksheet.write("C1", "version", merge_format)
        worksheet.write("J1", "Condition_version", merge_format)
        index_C = "C" + str(x + 2)
        worksheet.write(index_C, str(updtval12[x]))

        index_chk = "J" + str(x + 2)
        if updtval12[0] != updtval12[x]:
            worksheet.write(index_chk, "False", merge_format_highlight)
        else:
            worksheet.write(index_chk, "True")

for x in range(len(updtval13)):
    # print(len(updtval))
    if len(updtval13) > 0:
        worksheet.write("D1", "Product", merge_format)
        worksheet.write("K1", "Condition_Product", merge_format)
        index_D = "D" + str(x + 2)
        worksheet.write(index_D, str(updtval13[x]))

        index_chk = "K" + str(x + 2)
        if updtval13[0] != updtval13[x]:
            worksheet.write(index_chk, "False", merge_format_highlight)
        else:
            worksheet.write(index_chk, "True")

for x in range(len(updtval14)):
    # print(len(updtval))
    if len(updtval14) > 0:
        worksheet.write("E1", "Colour-Figures-for-Online", merge_format)
        worksheet.write("L1", "Condition_Colour-Figures-for-Online", merge_format)
        index_E = "E" + str(x + 2)
        worksheet.write(index_E, str(updtval14[x]))

        index_chk = "L" + str(x + 2)
        if updtval14[0] != updtval14[x]:
            worksheet.write(index_chk, "False", merge_format_highlight)
        else:
            worksheet.write(index_chk, "True")

for x in range(len(updtval15)):
    # print(len(updtval))
    if len(updtval15) > 0:
        worksheet.write("F1", "Publishing-Group", merge_format)
        worksheet.write("M1", "Condition_Publishing-Group", merge_format)
        index_F = "F" + str(x + 2)
        worksheet.write(index_F, str(updtval15[x]))

        index_chk = "M" + str(x + 2)
        if updtval15[0] != updtval15[x]:
            worksheet.write(index_chk, "False", merge_format_highlight)
        else:
            worksheet.write(index_chk, "True")

for x in range(len(updtval16)):
    # print(len(updtval))
    if len(updtval16) > 0:
        worksheet.write("G1", "Captured-by", merge_format)
        worksheet.write("N1", "Condition_Captured-by", merge_format)
        index_G = "G" + str(x + 2)
        worksheet.write(index_G, str(updtval16[x]))

        index_chk = "N" + str(x + 2)
        if updtval16[0] != updtval16[x]:
            worksheet.write(index_chk, "False", merge_format_highlight)
        else:
            worksheet.write(index_chk, "True")


worksheet = workbook.add_worksheet('Div_Checking')

for x in range(len(updtval17)):
    # print(len(updtval))
    if len(updtval17) > 0:
        worksheet.write("A1", "Div1",merge_format)
        index_A = "A" + str(x + 2)
        worksheet.write(index_A, str(updtval17[x]))
        # index_chk = "H" + str(x + 2)
        # if updtval111[0] != updtval111[x]:
        #     worksheet.write(index_chk, "False", merge_format_highlight)
        # else:
        #     worksheet.write(index_chk, "True")

for x in range(len(updtval18)):
    if len(updtval18) > 0:
        worksheet.write("B1", "Div2",merge_format)
        index_A = "B" + str(x + 2)
        worksheet.write(index_A, str(updtval18[x]))

for x in range(len(updtval19)):
    if len(updtval19) > 0:
        worksheet.write("C1", "Div3", merge_format)
        index_A = "C" + str(x + 2)
        worksheet.write(index_A, str(updtval19[x]))

for x in range(len(updtval20)):
    if len(updtval20) > 0:
        worksheet.write("D1", "Div4", merge_format)
        index_A = "D" + str(x + 2)
        worksheet.write(index_A, str(updtval20[x]))

for x in range(len(updtval21)):
    if len(updtval21) > 0:
        worksheet.write("D1", "DivN", merge_format)
        index_A = "D" + str(x + 2)
        worksheet.write(index_A, str(updtval21[x]))


worksheet = workbook.add_worksheet('indexItem_Checking')

for x in range(len(updtval22)):
    # print(len(updtval))
    if len(updtval22) > 0:
        worksheet.write("A1", "indexItem1",merge_format)
        worksheet.write("E1", "indexItem1_Condition",merge_format)
        index_A = "A" + str(x + 2)
        index_chk = "E" + str(x + 2)
        upt=re.sub(r'^,',r'',str(updtval22[x]),0,re.I|re.S)
        worksheet.write(index_A, str(upt))
        upt1=upt.split(',')
        upt12=upt.split(',')
        try:
            for i in range(0, len(upt1)):
                upt1[i] = int(upt1[i])
            res1 = [eval(i) for i in upt12]
            res1.sort()
            if len(upt1)>1:
                if upt1==res1:
                    worksheet.write(index_chk, "True")
                else:
                    worksheet.write(index_chk, "False", merge_format_highlight)
            else:
                worksheet.write(index_chk, "Single Page")
        except:
            pass
            worksheet.write(index_chk, "Entity Present")

for x in range(len(updtval23)):
    # print(len(updtval))
    if len(updtval23) > 0:
        worksheet.write("B1", "indexItem2",merge_format)
        worksheet.write("F1", "indexItem2_Condition",merge_format)
        index_A = "B" + str(x + 2)
        index_chk = "F" + str(x + 2)
        upt = re.sub(r'^,', r'', str(updtval23[x]), 0, re.I | re.S)
        worksheet.write(index_A, str(upt))
        upt1 = upt.split(',')
        upt12 = upt.split(',')
        try:
            for i in range(0, len(upt1)):
                upt1[i] = int(upt1[i])
            res1 = [eval(i) for i in upt12]
            res1.sort()
            if len(upt1) > 1:
                if upt1 == res1:
                    worksheet.write(index_chk, "True")
                else:
                    worksheet.write(index_chk, "False", merge_format_highlight)
            else:
                worksheet.write(index_chk, "Single Page")
        except:
            pass
            worksheet.write(index_chk, "Entity Present")

for x in range(len(updtval24)):
    # print(len(updtval))
    if len(updtval24) > 0:
        worksheet.write("C1", "indexItem3",merge_format)
        worksheet.write("G1", "indexItem3_Condition",merge_format)
        index_A = "C" + str(x + 2)
        index_chk = "G" + str(x + 2)
        upt = re.sub(r'^,', r'', str(updtval24[x]), 0, re.I | re.S)
        worksheet.write(index_A, str(upt))
        upt1 = upt.split(',')
        upt12 = upt.split(',')
        try:
            for i in range(0, len(upt1)):
                upt1[i] = int(upt1[i])
            res1 = [eval(i) for i in upt12]
            res1.sort()
            if len(upt1) > 1:
                if upt1 == res1:
                    worksheet.write(index_chk, "True")
                else:
                    worksheet.write(index_chk, "False", merge_format_highlight)
            else:
                worksheet.write(index_chk, "Single Page")
        except:
            pass
            worksheet.write(index_chk, "Entity Present")

for x in range(len(updtval25)):
    # print(len(updtval))
    if len(updtval25) > 0:
        worksheet.write("D1", "indexItem4",merge_format)
        worksheet.write("H1", "indexItem4_Condition",merge_format)
        index_A = "D" + str(x + 2)
        index_chk = "H" + str(x + 2)
        upt = re.sub(r'^,', r'', str(updtval24[x]), 0, re.I | re.S)
        worksheet.write(index_A, str(upt))
        upt1 = upt.split(',')
        upt12 = upt.split(',')
        try:
            for i in range(0, len(upt1)):
                upt1[i] = int(upt1[i])
            res1 = [eval(i) for i in upt12]
            res1.sort()
            if len(upt1) > 1:
                if upt1 == res1:
                    worksheet.write(index_chk, "True")
                else:
                    worksheet.write(index_chk, "False", merge_format_highlight)
            else:
                worksheet.write(index_chk, "Single Page")
        except:
            pass
            worksheet.write(index_chk, "Entity Present")
workbook.close()

