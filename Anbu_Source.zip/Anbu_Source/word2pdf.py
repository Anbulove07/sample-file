import os

from docx import Document
from docx2pdf import convert

def word_to_pdf_with_docx2pdf(input_docx_path, output_pdf_path):
    # Ensure absolute file paths are used
    input_docx_path = os.path.abspath(input_docx_path)
    output_pdf_path = os.path.abspath(output_pdf_path)

    try:
        # Convert Word document to PDF using docx2pdf
        convert(input_docx_path, output_pdf_path)
        print(f"Conversion successful. PDF saved to {output_pdf_path}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    input_docx_path = r"D:\Giventool\karthik\IOPP\IOPP\Input\TRAN_114304\Source\2DMacec58\2DMacec58.docx"
    output_pdf_path = r"D:\Giventool\karthik\IOPP\IOPP\Input\TRAN_114304\Source\2DMacec58\2DMacec58.pdf"

    word_to_pdf_with_docx2pdf(input_docx_path, output_pdf_path)
