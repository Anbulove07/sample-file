import pyttsx3
from pydub import AudioSegment
from moviepy.editor import VideoFileClip
import os

# def extract_max_time(mp4_file):
#     video = VideoFileClip(mp4_file)
#     duration = video.duration
#     video.close()
#     return duration

def tts_to_audio(input_text, output_file, duration_ms):
    # Configure pyttsx3
    engine = pyttsx3.init()
    engine.setProperty("rate", 150)  # Adjust the speech rate as desired

    # Convert text to speech and save as WAV file
    engine.save_to_file(input_text, output_file)
    engine.runAndWait()

    # Open the audio file and match the duration
    audio = AudioSegment.from_file(output_file, format="wav")
    audio = audio[:duration_ms]  # Truncate or pad the audio to match the desired duration
    audio.export(output_file, format="wav")  # Export the modified audio as WAV


# Initialize the pyttsx3 engine
engine = pyttsx3.init()

# List all available voices
voices = engine.getProperty('voices')
for voice in voices:
    print("Voice: %s" % voice.name)

# Select a voice (index 2 in this case)
selected_voice = voices[1]
print(f"Selected voice: {selected_voice.name}")
engine.setProperty('voice', selected_voice.id)

# Define the input file path
# input_file_path = "mp3\\translated_files\\sample_translated_to_es.txt"
#
# # Read the text from the input file
# with open(input_file_path, 'r') as file:
#     text = file.read()
#     file_name = os.path.splitext(os.path.basename(file.name))[0]
# def txt2aud(text):
#
#     # Calculate the required rate of speech to fit the text into the desired duration
#     duration_in_seconds = 4 * 60 + 15  # 4 minutes and 15 seconds
#     words_per_minute = len(text.split()) / 142  # Assuming an average reading speed of 4 words per second
#     required_rate = int(engine.getProperty('rate') * (words_per_minute / (duration_in_seconds / 60)))
#
#     # Set the adjusted rate of speech
#     engine.setProperty('rate', required_rate)
#
#     # Define the audio file path
#     # audio_file_path = f"mp3\\translated_audios\\{file_name}_translated_audio_file_to_es.mp3"
#     audio_file_path = r"C:\Users\is9626\PycharmProjects\Translation_MP3_UI\templates\assest\output.mp3"
#
#     # Save the text as an audio file
#     engine.save_to_file(text, audio_file_path)
#
#     # Run the engine to convert text to speech and save as an audio file
#     engine.runAndWait()
#
#     # Confirm the generation of the audio file
#     print(f"Audio file '{audio_file_path}' generated successfully.")


def txt2aud(text):
    # Create a TTS engine
    engine = pyttsx3.init()

    # Set the engine properties for Spanish language
    engine.setProperty('rate', 120)  # Adjust the speech rate as needed (e.g., 150 words per minute)
    engine.setProperty('voice', 'spanish')  # Use a Spanish voice

    # Define the audio file path
    audio_file_path = r"C:\Users\is9626\PycharmProjects\Translation_MP3_UI\templates\assest\output_spanish.mp3"

    # Save the text as an audio file
    engine.save_to_file(text, audio_file_path)

    # Run the engine to convert text to speech and save as an audio file
    engine.runAndWait()

    # Confirm the generation of the audio file
    print(f"Audio file '{audio_file_path}' generated successfully.")


txt2aud('''PROFESOR: En este ejemplo, vamos a usar el comando de remuestreo de StatCrunch y el subprograma Bootstrap para construir un intervalo de confianza del 95 %. El sitio web fueleconomy.gov permite a los conductores informar de las millas por galón de su vehículo. Los datos de la tabla muestran las millas por galón informadas por 16 propietarios diferentes de  automóviles Honda Accord Hybrid 2019. 
Considere la muestra como una muestra aleatoria simple de todos los automóviles Honda Accord Hybrid 2019. Construya un intervalo de confianza del 95 % para el promedio de millas por galón de un Honda Accord Híbrido 2019 utilizando una muestra Bootstrap. Proceda a interpretar el intervalo. Así que los datos son 42,3, 43,6, 48,2, 40, 39, 42,9, 44,8, 43, 40,7, 38,6, 39, 44,5, 35,5, 45,1, 35,4 y 42,2. 
Entonces, primero tenemos que ingresar estos datos en una hoja de cálculo de StatCrunch. Puede ver que la primera columna es MPG, es decir las millas por galón para los 16 automóviles. Ahora seleccione Stat [Estad], Resample [Remuestreo], Statistic [Estadística]. La columna es Millas por galón. Luego, en Statistic [Estadística], escribirá el promedio de millas por galón. El método de muestreo es el Bootstrap. El tipo de remuestreo es univariado. Buscamos obtener 2.000 remuestreos. 
A continuación, asegúrese de que se incluyan los percentiles 2,5 y 97,5 porque tenemos un intervalo de confianza del 95 %. Si quisiera un intervalo de confianza del 90 %, necesitaría los percentiles 5 y 95. En cambio, si deseara un intervalo de confianza del 99 %,  los percentiles serían 0,5 y 99,5. 
Al resolver este problema, usaremos una semilla fija de 9382 para que pueda confirmar nuestros resultados. Haga clic en Compute [Calcular]. Observe que el percentil 2,5 es 39,84 y el percentil 97,5 es 43,21. Por lo tanto, estamos 95 % seguros de que el promedio de millas por galón de un Honda Accord Hybrid 2019 está entre 39,84 millas por galón y 43,21 millas por galón. 
En lugar de usar el comando de remuestreo, también podemos usar el subprograma de remuestreo. Con los datos en la hoja de cálculo de StatCrunch, seleccione Applets [Subprogramas], Resampling [Remuestreo], Bootstrap a Statistic [Bootstrap a Estadística]. Vamos a seleccionar los datos de la columna Millas por galón en Samples [Muestras]. La estadística es el promedio. Además, usaremos una semilla fija de 3892 para que pueda confirmar nuestros resultados. 
Haga clic en Compute [Calcular]. Lo que vamos a hacer es seleccionar 1.000 veces dos veces para obtener 2.000 muestras de Bootstrap. El percentil 2,5 es 39,96 mientras que el percentil 97,5 es 43,25. Por lo tanto, estamos un 95 % seguros de que el promedio de millas por galón de un Honda Accord Hybrid 2019 está entre 39,96 millas por galón y 43,25 millas por galón. 
Sírvase notar que el intervalo de confianza Bootstrap con el subprograma difiere del intervalo de confianza con el comando de remuestreo. Esto se debe a que tenemos diferentes muestras de Bootstrap en cada ejemplo. Esto ilustra un punto importante: diferentes muestras de Bootstrap conducen a diferentes intervalos de confianza. Sin embargo, los resultados deberían ser similares siempre que obtenga al menos 2.000 muestras de Bootstrap.
''')