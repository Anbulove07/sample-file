import glob
from skimage.metrics import structural_similarity as ssim
from skimage.io import imread
from skimage.transform import resize
def compare_images(image1_path, image2_path):
    # Load the images
    image1 = imread(image1_path)
    image2 = imread(image2_path)

    # Resize the images to a common size
    max_height = max(image1.shape[0], image2.shape[0])
    max_width = max(image1.shape[1], image2.shape[1])

    image1 = resize(image1, (max_height, max_width), preserve_range=True)
    image2 = resize(image2, (max_height, max_width), preserve_range=True)

    # Calculate the structural similarity index with an appropriate win_size and data_range
    min_dim = min(max_height, max_width)
    win_size = min(3, min_dim - 1) if min_dim >= 3 else 1
    data_range = max(image1.max(), image2.max()) - min(image1.min(), image2.min())
    structural_similarity = ssim(image1, image2, win_size=win_size, data_range=data_range, multichannel=True)

    return structural_similarity

folder_path = r"D:\Test\test\Input\images"
image_files = glob.glob(f"{folder_path}/*.png") + glob.glob(f"{folder_path}/*.jpg") + glob.glob(f"{folder_path}/*.jpeg")

rangevalue=[]

for image_file in image_files:
    # print(image_file)
    temp=[]
    # Usage
    image1_path = image_file
    image2_path = r"D:\Test\test\Input\images.jpg"

    similarity = compare_images(image1_path, image2_path)
    # print(f"Maximum match: {similarity}")
    rounded_similarity = round(similarity, 2)
    temp.append(image1_path)
    temp.append(rounded_similarity)
    rangevalue.append(temp)


# print(rangevalue)
data=rangevalue
highest_number = max(data, key=lambda x: x[1])
print(highest_number)
