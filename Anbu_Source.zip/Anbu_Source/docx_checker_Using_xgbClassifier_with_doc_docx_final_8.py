############# Note - This model can only be used for docx files classification  : BY Subodh And Gaurav ########################################


############# Note - Please specify the path of executable Libreoffice or soffice_exe_path for propertly working of this model ################

# soffice_exe_path = r"C:\Program Files\LibreOffice\program\soffice.exe"

#########################################################################################################################
from __future__ import print_function
import PySimpleGUI as sg
import numpy as np
import os
from os.path import dirname, basename
import glob
# import docx2txt
from sklearn.feature_extraction.text import TfidfVectorizer
import re
import nltk
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
import pickle
from docx import Document
# from docx.opc.coreprops import CoreProperties
# from docx.opc.exceptions import PackageNotFoundError
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')


sg.theme('Dark Blue 3')          # please make your windows colorful
layout = [[sg.Text('Recognize files in folders')],
    [sg.Text('Choose Docx Folder for checking files categories', size=(15, 1)), sg.InputText(), sg.FolderBrowse()],
      [sg.Submit(), sg.Cancel()]]
window = sg.Window('ML Recognize Files', layout)
event, values = window.read()
window.close()



test_folder_path = values[0]       # get the data from the values dictionary     # action_option is either merge or split
print(test_folder_path)

train_folder = r'D:\Docx classifier'    #'d:\Task to do\21-03-23 ML material\python files\dataset_for_document_classification_4'    


classifier_path = r"\\"
# r"D:\Docx classifier\classifier xgboost_created on 28_June_2023_Using 13 labels@14.56" 
#r"D:\Docx classifier\classifier xgboost_created on 27_June_2023_Using 13 labels@18.20"
label_file_path = classifier_path

##### ======================== Global Function ====================== ########
##############################################################################
labels_map = []
# labels_map file to be called           
with open(r'labels.txt', 'r', encoding= 'utf-8') as f:       ## featureslist file name to be read
    labels_map_str = f.read()
f.close()
# inside {} it traet variable as variable value as code not only as value, so it is treated as string as code to execute in exec function.
exec(f"labels_map = {labels_map_str}")                    
# print("\n\n new labels_map  : ",labels_map)

labels_map = list(labels_map)
# print("labels_map  : ",labels_map)


"""
def stem_words(text):
     lemmatizer = WordNetLemmatizer()
     stemmed_words = []
     words = nltk.word_tokenize(text)
     for word in words:
         stemmed_words.append(lemmatizer.lemmatize(word))
     return ' '.join(stemmed_words)
"""

"""
def read_wordfile(file_path):
    def read_doc(file):
        f = open(file,'r', encoding='latin1')
        text = f.readline()
        f.close()
        return text
    try:
        new_text = docx2txt.process(file_path)
        print("\nThe file was properly read as having no KeyError")
    except:
        print("\nThe file was having KeyError or other exception")
        new_text = read_doc(file_path)
    return new_text

def read_text_4_classification(new_text):
    # Here paragraphs can also be used to classify
    # new_text = re.sub('[^A-Za-z0-9]+', ' ', new_text)
    new_text = preprocess_text(new_text)  # stem_words(new_text)
    return new_text

"""










#########################################
# NEW   read_wordfile  (file_path):
def read_wordfile_new(file_path):
    docx = Document(file_path)

    def extract_text_from_paragraphs(paragraphs):
        text = ""
        for paragraph in paragraphs:
            text += paragraph.text.strip() + " "
        return text

    # Extract text content from paragraphs, tables, text boxes, and headers/footers
    metadata = {}
    object_metadata = []

    for paragraph in docx.paragraphs:
        text =""
        text = paragraph.text.strip()
        object_metadata.append({
            'type': 'Paragraph',
            'text': text,
        })

    for section in docx.sections:
        header = section.header
        if header:
            text_list = extract_text_from_paragraphs(header.paragraphs)
            if text_list:
                object_metadata.append({
                    'type': 'Header',
                    'text': text_list
                })
        footer = section.footer
        if footer:
            text_list = extract_text_from_paragraphs(footer.paragraphs)
            if text_list:
                object_metadata.append({
                    'type': 'Footer',
                    'text': text_list
                })

    for table in docx.tables:
        text_row = ""
        try:
            for row in table.rows:
                text_list = ""
                try:
                    for cell in row.cells:
                        cell_text = extract_text_from_paragraphs(cell.paragraphs)
                        # if cell_text:
                        text_list += cell_text+ " "
                except IndexError:
                    continue
                text_row += text_list+ " "
        except IndexError:
            continue
        if text_row:
            object_metadata.append({
                'type': 'Table',
                'text_row': text_row
            })

    for image in docx.inline_shapes:
        object_metadata.append({
            'type': 'Image',
            'width': image.width,
            'height': image.height
        })

    metadata['objects'] = object_metadata
    # print("metadata    :::::::::::::::::::::::\n", metadata)
    return metadata
######################################





###### function to clean and preprocess data for classification #
# NEW   read_text_4_classification (text):
def read_text_4_classification_new(text):
    # Convert to string if the input is not already a string
    if not isinstance(text, str):
        text = str(text)
    # Define the allowed characters and regex pattern
    allowed_characters = r"A-Za-z0-9!?@.$%\s"  #r"A-Za-z0-9!@.,:\"\"\'\'\?$%\s"  #  # r"A-Za-z0-9,!?@._$%\s"   #  r"A-Za-z0-9(),!?@._}{\s" 
    pattern = f'[^{allowed_characters}]'
    # Remove characters that are not in the allowed set
    text = re.sub(pattern, '', text)
    # Convert to lowercase
    text = text.lower()
    # Remove extra whitespaces
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'\n+', '\n', text)
    text = re.sub(r'\t+', '\t', text)
    # Tokenization
    tokens = nltk.word_tokenize(text)
    # Remove special characters and convert to lowercase
    # tokens = [re.sub(r'[^a-zA-Z0-9]', '', token.lower()) for token in tokens if token.isalnum()]
    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    tokens = [token for token in tokens if token not in stop_words]
    # Lemmatization
    lemmatizer = WordNetLemmatizer()
    tokens = [lemmatizer.lemmatize(token) for token in tokens]
    # Join tokens back to a single string
    cleaned_text = ' '.join(tokens)
    return cleaned_text
###################################################################



########### Create & Delete temp folder for keeping .docx file created from .doc file  ###################################
########### Create temp folder for keeping .docx file created ####################
def create_temporary_docx(doc_file, folder_path):
    ###### doc to docx conversion for reading metadata  ####
    def convert_doc_to_docx(doc_file_path, docx_file_path):
        import subprocess
        soffice_exe_path = r"C:\Program Files\LibreOffice\program\soffice.exe"
        # Define the command to convert the file using LibreOffice
        command = [
        soffice_exe_path,            # soffice.exe inside "libreoffice"  exe file,
        "--headless",
        "--convert-to",
        "docx",
        "--outdir",
        docx_file_path,    # docx path to save without name
        doc_file_path     # doc path with filename to make a copy in docx
        ]
        # Execute the command to convert the file
        subprocess.run(command)
    #######################################################


    if not os.path.exists(folder_path):
        os.mkdir(folder_path)
    else:
        pass
        # delete_temporary_docx(folder_path)
    print("temp_docx_dir   ", folder_path)
    try:
        # Generate a temporary DOCX file path
        # temp_docx_path = os.path.join(folder_path, 'temp_file.docx')
        temp_docx_path = folder_path
        convert_doc_to_docx(doc_file, temp_docx_path)
    finally:
        # Delete the temporary folder and its contents
        # delete_temporary_docx(temp_docx_dir)
        pass
    return temp_docx_path+fr"\{basename(doc_file)[:-4]}.docx"
################################################################################


###### temp docx file delete   #################################
def delete_temporary_docx(temp_docx_dir):
    try:
        # Delete the temporary folder and its contents
        if os.path.exists(temp_docx_dir):
            for file_name in os.listdir(temp_docx_dir):
                file_path = os.path.join(temp_docx_dir, file_name)
                os.remove(file_path)
            os.rmdir(temp_docx_dir)
            print("Temporary DOCX directory deleted successfully.")
        else:
            print("Temporary DOCX directory does not exist.")
    except Exception as e:
        pass
        # print(f"Error deleting temporary DOCX directory: {e}")
##################################################################
#######################################################################################################################

##### ======================== Global Function End ====================== ############################################
#######################################################################################################################




##############################################################################
#============================================================================#
# classifier_path = dirname(train_folder)+r'\classifier'     # path for the classifier file and for vectoriser featureslist file
# print("classifier_path for pkl and features file              :   ", classifier_path)
# Load the classifier from the file
with open(r'xgb_classifier.pkl', 'rb') as f:
    xgb_clf = pickle.load(f)
f.close()

features_list_list =[]   
# featureList file to be called           #  features_list_file    
with open(r'features_list_file.txt', 'r', encoding= 'utf-8') as f:       ## featureslist file name to be read
    for i in f.readlines():
        features_list_list.append(i)
f.close()
# print("length of features_list", len(features_list_list))

# Load the tf-idf vectorizer
tfidf_vect = TfidfVectorizer(lowercase=True, stop_words='english', min_df=10)    
tfidf_vect = tfidf_vect.fit(features_list_list)

###################################################################################################
#=================================================================================================#



# ============================== For folder testing   ========================================##
#################################################################################################
path = test_folder_path                 # # path given as input
path = re.sub(r'\/', r'\\', path)

temp_docx_dir = dirname(classifier_path) + r'\temp_docx_dir'


new_folder_files = []       
for i in ['docx', 'doc']:   
    new_folder_files.extend(glob.glob(f'{path}/*.{i}'))
# new_folder_files = re.sub(r'\/', r'\\', new_folder_files)
update_list = {}
for file_name in new_folder_files:
    # file_name = re.sub(r'\/', r'\\', file_name)
    if file_name.endswith('doc'):
        # print("\\n\n\n\n ::::::::   doc   file")
        temp_docx_file_path = create_temporary_docx(file_name, temp_docx_dir)        # NEW Lines added  On 29 June 2023    
        new_text = read_wordfile_new(temp_docx_file_path)
    else:
        new_text = read_wordfile_new(file_name)
    new_text = read_text_4_classification_new(new_text)        
    # print("\n\nfile_name ",file_name)
    # Convert the preprocessed text into a tf-idf vector
    new_tfidf = tfidf_vect.transform([new_text])
    
    # Predict the category of the new document
    category = xgb_clf.predict(new_tfidf)[0]
    y_pred_proba = xgb_clf.predict_proba(new_tfidf)
    
    # Calculate the maximum probability and use it as the confidence score
    confidence_scores = np.max(y_pred_proba, axis=1)[0]
    confidence_scores = np.round(confidence_scores*100,2)
    if labels_map[category] == '_07_Manuscript':
        print("Category manuscript File : ", file_name)
        exit()

    ctg = {"category": f'{labels_map[category]}', "confidence_scores": f'{confidence_scores}'}
    
    update_list.update({f'{file_name}':ctg}) 
    delete_temporary_docx(temp_docx_dir)
# exit()
print("\nfiles in the given list  :   ", new_folder_files)
# print("\nclassifcation done for all files in the given list As   :     ", update_list)
############################################################################################
print("\nclassifcation done for all files in the given list As   :     ")
for i in update_list:
    print(f"update_list Using Xgb :   {i}   :    ", update_list[i])

    # sg.popup(f"File :  \n\n'{i}', \n\nRecognized as  :\n\n {update_list[i]}", title="Reconized files are : ", button_type=0, custom_text=(None, None), no_titlebar=False, grab_anywhere=False, keep_on_top=False)


# sg.popup(f"All file Recognized as   \n\n:   {update_list}", title="Reconized files are : ", button_type=0, custom_text=(None, None), no_titlebar=False, grab_anywhere=False, keep_on_top=False)

