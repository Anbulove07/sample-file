#---------------------------------------------------------------=----
#  Tool Name    : TandF_xml2TEm.py
#  Developer    : Janaki G | CTAE XML
#  Description  : create ini file with article information
#  Client/DU    : TandF / TandF
#  Syntax		: <EXE> <XML>
#------------------------------------------------------------------

#------------ Revision History  ------------------------------------
#  20-07-2021 | v1.0 | Janaki G | Initial Development
#  06-08-2021 | v1.0 | vijay R |  updates and bug fix.
#  01-07-2021 | v1.0 | Deepika P | change error to warning in Article-history-date
#------------------------------------------------------------------

ToolVersion = "1.0.0.0";
 
import os;
import sys;
import re;
from os.path import basename,dirname;
from iPython.Basic import _open_file,_open_utf8,_save_file;
import glob;
from iPython.ToolTracking import *;

Toolpath = dirname(sys.argv[0]);
Toolpath = re.sub(r'\/',r'\\',Toolpath,0);

os.system("cls");


# Inline argument checking & File path checking
if (len(sys.argv) != 2 or not os.path.isfile(sys.argv[1])): sys.exit("\n\tSyntax: <exe> <xml>\n");


print ("\n\n\tTandF_xml2API_TME v"+ToolVersion+"is Running...\n\n");

# ------------ Tracking ---------------------------------------------
Tra_input = sys.argv[1];
tool_id = 399; #TandF_xml2API_TME Tool
run_size = 0;
st_time = _get_timestamp();
# ------------------------------------------------------------------

# Global variable declaration
Input = sys.argv[1];

Output = Input[:-4]+'_API.ini';
Icore = Input[:-4]+'_icore.xml';
xml = _open_file(Input);
InPath = dirname(Input)

InPath = InPath+"\\cats.xml";
# supporting file
if not os.path.isfile(InPath):
	sys.exit(r"'cats.xml' is missing in "+dirname(Input)+".");
    

if not os.path.isfile(Icore):
	sys.exit(r"'icore.xml' is missing in "+dirname(Input)+".");

cats_cnt = _open_utf8(InPath);
icore_cnt = _open_utf8(Icore);


Jid = ''; ArtID = ''; Manuscript = '';trans_id ='';

j = re.search(r'<journal-id [^><]*\bjournal-id-type="publisher-acronym"[^>]*>((?:(?!</?journal-id[ >]).)+)</journal-id>',xml,re.I|re.S);
a = re.search(r'<article-id [^><]*\bpub-id-type="publisher-id"[^>]*>((?:(?!</?article-id[ >]).)+)</article-id>',xml,re.I|re.S);
tr_id = re.search(r'<transmittal(?: [^>]*)?transmittalid="([^"]+)"',cats_cnt,re.I|re.S);

if(j): Jid = j.group(1);
if(a): ArtID = a.group(1);
if(tr_id): trans_id = tr_id.group(1);

# API structure:
API = '''<API>
<EntryStatus></EntryStatus>
<transmittalid></transmittalid>
<Acronym></Acronym>
<Title></Title>
<Secondary-article-id></Secondary-article-id>
<Article-history-date>
<Accepted-Date></Accepted-Date>
<Received-Date></Received-Date>
<Revised-Date></Revised-Date>
</Article-history-date>
<Section-heading></Section-heading>
<Article-type></Article-type>
<Open-Science-Badges>
<Databadge></Databadge>
<Open-Materials-Badge></Open-Materials-Badge>
<Pre-Registered-Data-badge></Pre-Registered-Data-badge>
</Open-Science-Badges>								
<FundingDetails>
</FundingDetails>
<AuthorDetails>
</AuthorDetails>
</API>''';

# subroutine:

def RemoveTag(txt,element):
	
	formating = '|'.join(element.split(','));
	txt = re.sub(r'<\/?('+str(formating)+r')(?: [^>]+)?>',r'',txt,0,re.I);
	
	return txt;

def _Removetag(txt):
	txt = re.sub(r'<!--(?:(?!-->).)*-->','',txt,0,re.I);
	txt = re.sub(r'<xref(?: [^>]+)?>(?:(?!</?xref>).)*</xref>','',txt,0,re.I|re.S);
	txt = re.sub(r'<xref(?: [^>]+)?\/>','',txt,0,re.I);
	txt = re.sub(r'<\?A3B2[^>]*\?>','',txt,0,re.I);
	txt = re.sub(r'<\?odel\?>(?:(?!<\?cdel\?>).)*<\?cdel\?>','',txt,0,re.I);
	txt = re.sub(r'<\?(?:oins|cins)\?>','',txt,0,re.I);
	txt = re.sub(r'</?subject>','',txt,0,re.I);
	return txt;


# title:
tit = re.search(r'<front>(?:(?!</?(?:front|article-title)[ >]).)*<article-title>((?:(?!</?article-title>).)+)</article-title>', xml, re.I|re.S);
if tit:
	API = re.sub(r'<Title></Title>',r'<Title>'+RemoveTag(tit.group(1),'[a-z0-9:-]+')+'</Title>',API,0);

jd = re.search(r'<journal-meta>(?:(?!</?(?:journal-meta|journal-title-group)[ >]).)*journal-id-type="publisher-acronym"[^>]*>((?:(?!</?/journal-id>).)+)</journal-id>',xml, re.I | re.S);
if jd:
	API = re.sub(r'<Acronym></Acronym>', r'<Acronym>'+RemoveTag(jd.group(1),'[a-z0-9:-]+')+'</Acronym>', API, 0);

if trans_id:
	API = re.sub(r'<transmittalid></transmittalid>', r'<transmittalid>'+trans_id+'</transmittalid>', API, 0);    
# submission-id:
sid = re.search(r'<front>(?:(?!</?(?:front|article-id [^><]*pub-id-type="submission-id")[ >]).)*<article-id [^><]*pub-id-type="submission-id"[^>]*>((?:(?!</?article-id>).)+)</article-id>', xml, re.I|re.S);
if sid:
	API = re.sub(r'<Secondary-article-id></Secondary-article-id>',r'<Secondary-article-id>'+_Removetag(sid.group(1))+'</Secondary-article-id>',API,0);

# accepted date:
acp = re.search(r'<front>(?:(?!</?(?:front|event [^><]*event-type="accepted")[ >]).)*<event [^><]*event-type="accepted"[^>]*><date><day>(\d+)</day><month>(\d+)</month><year>(\d+)</year>', xml, re.I|re.S);
acp1 = re.search(r'<front>(?:(?!</?(?:front|date [^><]*date-type="accepted")[ >]).)*<date [^><]*date-type="accepted"[^><]*iso-8601-date="([^"]+)"\/>', xml, re.I|re.S);
if acp:
	API = re.sub(r'<Accepted-Date></Accepted-Date>',r'<Accepted-Date>'+acp.group(3)+'-'+acp.group(2)+'-'+acp.group(1)+'</Accepted-Date>',API,0);
elif acp1:
	API = re.sub(r'<Accepted-Date></Accepted-Date>',r'<Accepted-Date>'+acp1.group(1)+'</Accepted-Date>',API,0);

# received date:
rec = re.search(r'<front>(?:(?!</?(?:front|event [^><]*event-type="received")[ >]).)*<event [^><]*event-type="received"[^>]*><date><day>(\d+)</day><month>(\d+)</month><year>(\d+)</year>', xml, re.I|re.S);
rec1 = re.search(r'<front>(?:(?!</?(?:front|date [^><]*date-type="received")[ >]).)*<date [^><]*date-type="received"[^><]*iso-8601-date="([^"]+)"\/>', xml, re.I|re.S);
if rec:
	API = re.sub(r'<Received-Date></Received-Date>',r'<Received-Date>'+rec.group(3)+'-'+rec.group(2)+'-'+rec.group(1)+'</Received-Date>',API,0);
elif rec1:
	API = re.sub(r'<Received-Date></Received-Date>',r'<Received-Date>'+rec1.group(1)+'</Received-Date>',API,0);

# revised date:
rev = re.search(r'<front>(?:(?!</?(?:front|event [^><]*event-type="revised")[ >]).)*<event [^><]*event-type="revised"[^>]*><date><day>(\d+)</day><month>(\d+)</month><year>(\d+)</year>', xml, re.I|re.S);
rev1 = re.search(r'<front>(?:(?!</?(?:front|date [^><]*date-type="revised")[ >]).)*<date [^><]*date-type="revised"[^><]*iso-8601-date="([^"]+)"\/>', xml, re.I|re.S);
if rev:
	API = re.sub(r'<Revised-Date></Revised-Date>',r'<Revised-Date>'+rev.group(3)+'-'+rev.group(2)+'-'+rev.group(1)+'</Revised-Date>',API,0);
elif rev1:
	API = re.sub(r'<Revised-Date></Revised-Date>',r'<Revised-Date>'+rev1.group(1)+'</Revised-Date>',API,0);

# heading:
head = re.search(r'<front>(?:(?!</?(?:front|subj-group [^><]*subj-group-type="heading")[ >]).)*<subj-group [^><]*subj-group-type="heading"[^>]*>((?:(?!</?subj-group>).)+)</subj-group>', xml, re.I|re.S);
head1 = re.search(r'<front>(?:(?!</?(?:front|series-title [^><]*content-type="section-heading")[ >]).)*<series-title [^><]*content-type="section-heading"[^>]*>((?:(?!</?series-title>).)+)</series-title>', xml, re.I|re.S);
if head:
	API = re.sub(r'<Section-heading></Section-heading>',r'<Section-heading>'+_Removetag(head.group(1))+'</Section-heading>',API,0);
elif head1:
	API = re.sub(r'<Section-heading></Section-heading>',r'<Section-heading>'+_Removetag(head1.group(1))+'</Section-heading>',API,0);

# article type:
# artype = re.search(r'<front>(?:(?!</?(?:front|subj-group [^><]*subj-group-type="article-type")[ >]).)*<subj-group [^><]*subj-group-type="article-type"[^>]*>((?:(?!</?subj-group>).)+)</subj-group>', xml, re.I|re.S);
# artype1 = re.search(r'<front>(?:(?!</?(?:front|series-title [^><]*content-type="article-type")[ >]).)*<series-title [^><]*content-type="article-type"[^>]*>((?:(?!</?series-title>).)+)</series-title>', xml, re.I|re.S);

artype = re.search(r'<article [^><]*article-type="article"', icore_cnt, re.I|re.S);
# artype = re.search(r'<article [^><]*document-type="([^"]+)"', icore_cnt, re.I|re.S);
if artype:	
	API = re.sub(r'<Article-type></Article-type>',r'<Article-type>Research Article</Article-type>',API,0);
else:
	artype = re.search(r'<article [^><]*document-type="([^"]+)"', icore_cnt, re.I|re.S);
	if artype:
		API = re.sub(r'<Article-type></Article-type>',r'<Article-type>'+_Removetag(artype.group(1))+'</Article-type>',API,0);

# open-data:
badge1 = re.search(r'<sec [^><]*sec-type="open-scholarship open-data"', xml, re.I|re.S);
if badge1:
	API = re.sub(r'<Databadge></Databadge>',r'<Databadge>TRUE</Databadge>',API,0);

# open-materials:
badge2 = re.search(r'<sec [^><]*sec-type="open-scholarship open-materials"', xml, re.I|re.S);
if badge2:
	API = re.sub(r'<Open-Materials-Badge></Open-Materials-Badge>',r'<Open-Materials-Badge>TRUE</Open-Materials-Badge>',API,0);

# preregistered:
badge3 = re.search(r'<sec [^><]*sec-type="open-scholarship preregistered"', xml, re.I|re.S);
if badge3:
	API = re.sub(r'<Pre-Registered-Data-badge></Pre-Registered-Data-badge>',r'<Pre-Registered-Data-badge>TRUE</Pre-Registered-Data-badge>',API,0);

# FundingDetails: v1.2
fund = re.search(r'<funding-group(?: [^>]+)?>((?:(?!</funding-group>).)+)</funding-group>', xml, re.I|re.S);
if fund:
	fundBody = '';
	for ag in re.finditer(r'<award-group(?: [^>]+)?>(?:(?!</award-group>).)+</award-group>', fund.group(1), re.I|re.S):
		fb = '';
		FundRefDoi = re.search(r'<institution-id [^><]*institution-id-type="open-funder-registry"[^>]*>((?:(?!</institution-id>).)+)</institution-id>', ag.group(), re.I|re.S);
		GrantId = '';
		Description = re.search(r'<institution(?: [^>]+)?>((?:(?!</institution>).)+)</institution>', ag.group(), re.I|re.S);
		
		if FundRefDoi:
			fb += '<FundRefDoi>'+_Removetag(FundRefDoi.group(1))+'</FundRefDoi>';
		for ai in re.finditer(r'<award-id(?: [^>]+)?>((?:(?!</award-id>).)+)</award-id>', ag.group(), re.I|re.S):
				GrantId += _Removetag(ai.group(1))+', ';
		GrantId = re.sub(r', $','',GrantId,0);
		if len(GrantId):
			fb += '\n<GrantId>'+GrantId+'</GrantId>';		
		if Description:
			fb += '\n<Description>'+_Removetag(Description.group(1))+'</Description>';
	
		fb = '<FundingBody>\n'+fb+'\n</FundingBody>';
		fb = re.sub(r'<FundingBody>\s*</FundingBody>','',fb,re.I|re.S);
		if len(fb):
			fundBody += fb+'\n';

	if len(fundBody):
		fundBody = re.sub(r'\n+','\n',fundBody,0);
		fundBody = re.sub(r'\n$','',fundBody,0);
		API = re.sub(r'<FundingDetails>\s*</FundingDetails>',r'<FundingDetails>\n'+fundBody+'\n</FundingDetails>',API,0);
status="";
# AuthorDetails: v1.2

autList = re.search(r'<contrib-group(?: [^>]+)?>((?:(?!</contrib-group[ >]).)+)</contrib-group>', xml, re.I|re.S);
if autList:
	authorlist = '';
	flag="";
	for aut in re.finditer(r'<contrib(?: [^>]*)? contrib-type="author"[^>]*>((?:(?!</contrib[ >]).)+)</contrib>', autList.group(1), re.I|re.S):
	
		autInfo = '';ring_id="";orcid_id="";
		lastname = '';firstname="";
		
		autOrcid = re.search(r'<contrib-id [^><]*\bcontrib-id-type=["\']ORCID["\'][^>]*>((?:(?!</contrib-id[ >]).)+)</contrib-id>', aut.group(), re.I|re.S);
		if(autOrcid): orcid_id=autOrcid.group(1);
		
		autRingID = re.search(r'<contrib-id [^><]*\bcontrib-id-type=["\']ringgold["\'][^>]*>((?:(?!</contrib-id[ >]).)+)</contrib-id>', aut.group(), re.I|re.S);
		if(autRingID):
			ring_id=autRingID.group(1);
		
		autfirstname = re.search(r'<given-names(?: [^>]*)?>((?:(?!<\/?given-names[^>]*>).)+)<\/given-names>', aut.group(), re.I|re.S);
		if(autfirstname):
			firstname=autfirstname.group(1);
		
		autlastname = re.search(r'<surname(?: [^>]*)?>((?:(?!<\/?surname[^>]*>).)+)<\/surname>', aut.group(), re.I|re.S);
		if(autlastname):
			lastname=autlastname.group(1);
		city="";country="";	aff="";email="";aff_value="";total_aff="";author_email="";
		
		for affil in re.finditer(r'<xref(?: [^>]*)? ref-type="aff"[^>]*>', aut.group(1), re.I|re.S):
			affID = re.search(r' rid="([^"]+)"', affil.group(), re.I|re.S);
			if(affID):
			
				autaff = re.search(r'<aff(?: [^>]*)? id="'+affID.group(1)+'"[^>]*>((?:(?!<\/?aff[^>]*>).)+)<\/aff>', xml, re.I|re.S);
				
				if(autaff):
					aff=_Removetag(autaff.group(1));
					
					
					aff_value=re.sub(r'<label(?: [^>]*)?>((?:(?!<\/?label[^>]*>).)*)<\/label>','',aff,re.I|re.S);
					aff_value=re.sub(r'</?[^>]*>','',aff_value,re.I|re.S);
					
					
					autcity= re.search(r'<City(?: [^>]*)?>((?:(?!<\/?City[^>]*>).)+)<\/City>', aff, re.I|re.S);
					if(autcity): city=autcity.group(1)
					autcountry = re.search(r'<Country(?: [^>]*)?>((?:(?!<\/?Country[^>]*>).)+)<\/Country>', aff, re.I|re.S);	
					if(autcountry): country=autcountry.group(1)
					total_aff += '\n<aff>'+(aff_value)+'</aff>';
					total_aff += '\n<City>'+_Removetag(city)+'</City>';
					total_aff += '\n<Country>'+_Removetag(country)+'</Country>';
		
		corr="";	
		corresp_val="";
		
		
		for corresp in re.finditer(r'<xref(?: [^>]*)? ref-type="corresp"[^>]*>', aut.group(1), re.I|re.S):	
			correspID = re.search(r' rid="([^"]+)"', corresp.group(), re.I|re.S);
			corresp_val=correspID.group(1);
			if(corresp_val):				
				autcorresp = re.search(r'<corresp(?: [^>]*)? id="'+correspID.group(1)+'"[^>]*>((?:(?!<\/?corresp[^>]*>).)+)<\/corresp>', xml, re.I|re.S);
				if(autcorresp):
					corr=autcorresp.group(1);
					autemail= re.search(r'<email(?: [^>]*)?>((?:(?!<\/?email[^>]*>).)+)<\/email>', corr, re.I|re.S);
					if(autemail): email += '\n<Email>'+_Removetag(autemail.group(1))+'</Email>';
		
        
		autmail= re.search(r'<email(?: [^>]*)?>((?:(?!<\/?email[^>]*>).)+)<\/email>', aut.group(1), re.I|re.S);
		if(autmail): author_email += '\n<Email>'+_Removetag(autmail.group(1))+'</Email>';
		
		
		if(email):
			corresp_author="Y";
	
		else:
			corresp_author="N";
		
		if not(lastname):
			status+="fail1|"
		
		if(corresp_val):
			if(corr):
				if((email)):
					status+="success|"
					if(re.search(r'(<Email>@|<Email>Email)',email, re.I|re.S)):status+="fail4|"
					if not(re.search(r'@',email, re.I|re.S)):status+="fail4|"
				else:
					status+="fail2|"
				
			else:
				status+="fail3|"			
		
		autInfo += '\n<FirstName>'+_Removetag(firstname)+'</FirstName>';
		autInfo += '\n<LastName>'+_Removetag(lastname)+'</LastName>';
		if(email):
			autInfo += email
		else:
			
			autInfo += author_email;
		
		autInfo += total_aff;
		autInfo += '\n<Orcid>'+_Removetag(orcid_id)+'</Orcid>';
		autInfo += '\n<CorrespondingAuthor>'+corresp_author+'</CorrespondingAuthor>';
		autInfo += '\n<RingGoldId>'+_Removetag(ring_id)+'</RingGoldId>';
			
		autInfo = '<Author>\n'+autInfo+'\n</Author>';
		autInfo = re.sub(r'<Author>\s*</Author>','',autInfo,re.I|re.S);
		
		if len(autInfo):
			authorlist += autInfo+'\n';

	if len(authorlist):
		authorlist = re.sub(r'\n+','\n',authorlist,0);
		authorlist = re.sub(r'\n$','',authorlist,0);
		API = re.sub(r'<AuthorDetails>\s*</AuthorDetails>',r'<AuthorDetails>\n'+authorlist+'\n</AuthorDetails>',API,0);
authr_cnt=0;
for authr_cnt1 in re.finditer(r'<Author>', API, re.I|re.S):
    authr_cnt+=1;
correps_cnt=0;
for correps_cnt1 in re.finditer(r'<CorrespondingAuthor>N', API, re.I|re.S):
    correps_cnt+=1;        

if(authr_cnt == correps_cnt):
    status+="fail6|"
      
if(status):
	if(not(re.search(r'fail(1|2|3|4|5|6)', status, re.I|re.S))):
		API = re.sub(r'<EntryStatus>\s*</EntryStatus>',r'<EntryStatus>success</EntryStatus>',API,0);
	else:
		API = re.sub(r'<EntryStatus>\s*</EntryStatus>',r'<EntryStatus>fail</EntryStatus>',API,0);
else:
	API = re.sub(r'<EntryStatus>\s*</EntryStatus>',r'<EntryStatus>success</EntryStatus>',API,0);



warnings="";
# add warnings:

abstract_war = re.search(r'<abstract[ >]', xml, re.I|re.S);
if not abstract_war:
    warnings +="\n<warning type=\"AbstractMissing\">Abstract is missing</warning>";
kwd_grp_war = re.search(r'<kwd-group[ >]', xml, re.I|re.S);
if not kwd_grp_war:
    warnings +="\n<warning type=\"KeywordsMissing\">Keyword is missing</warning>";
shorttitle_war = re.search(r'<shorttitle[ >]', xml, re.I|re.S);    
if not shorttitle_war:
    warnings +="\n<warning type=\"ShortTitleNeeded\">ShortTitle is missing</warning>";
aff_war = re.search(r'<aff[ >]', xml, re.I|re.S);
if not aff_war:
    warnings +="\n<warning type=\"AuthorAffilMissing\">Affiliation is missing</warning>";
author_war = re.search(r'<contrib-group[ >]', xml, re.I|re.S);
if not author_war:
    warnings +="\n<warning type=\"AuthorNamesMissing\">Author Name is missing</warning>";    
ref_war = re.search(r'<ref[ >]', xml, re.I|re.S);
if not ref_war:
    warnings +="\n<warning type=\"NoReferences\">Reference is missing</warning>";  
fund_war = re.search(r'<funding[ >]', xml, re.I|re.S);
if not fund_war:
    warnings +="\n<warning type=\"FundingInformationPresent(WithData)\">Funding is missing</warning>";   

#
# API = re.sub(r'<([a-z0-9_-]+)(?: [^>]*)?>\s*</\1>',r'',API,0,re.I|re.S);
# API = re.sub(r'<([a-z0-9_-]+)(?: [^>]*)?>\s*</\1>',r'',API,0,re.I|re.S);
Error="";
# add Error:
if(status):
	if(re.search(r'fail1', status, re.I|re.S)):
		Error +="\n<Error>Lastname/Surname missing in xml</Error>"; 
	if(re.search(r'fail2', status, re.I|re.S)):
		Error +="\n<Error>CorrespondingAuthor Email ID missing in xml</Error>"; 
	if(re.search(r'fail3', status, re.I|re.S)):
		Error +="\n<Error>CorrespondingAuthor missing in xml</Error>"; 
	if(re.search(r'fail4', status, re.I|re.S)):
		Error +="\n<Error>Invalid Email present in CorrespondingAuthor</Error>";
	if(re.search(r'fail6', status, re.I|re.S)):
		Error +="\n<Error>CorrespondingAuthor missing in xml</Error>";
	artype_api = re.search(r'<Article-type(?: [^>]*)?>Research Article<\/Article-type>', API, re.I|re.S);
	if artype_api:
		if(not(re.search(r'<Article-history-date(?: [^>]*)?>((?:(?!<\/?Article-history-date[^>]*>).)+)<\/Article-history-date>', API, re.I|re.S))):
			warnings +="\n<warnings>Article-history-date missing in xml</warnings>";   
			##deepika##01-07-2022##req by Sivakumar  
API = re.sub(r'</AuthorDetails>',r'</AuthorDetails>'+Error,API,0,re.I|re.S);
API = re.sub(r'</AuthorDetails>',r'</AuthorDetails>'+warnings,API,0,re.I|re.S);
API = re.sub(r'<([a-z0-9_-]+)(?: [^>]*)?>\s*</\1>',r'',API,0,re.I|re.S);
API = re.sub(r'\n{2,}',r'\n',API,0,re.I|re.S);
API = re.sub(r'\n\s*',r'\n',API,0,re.I|re.S);
API = re.sub(r'(</?)((?:bold|italic|sub|sup|sc|underline|break)>)',r'',API,0,re.I|re.S);

_save_file(Output,API);

#------ Local tracking --------------
# _local_tracking(tool_id,Tra_input,_get_file_size(Tra_input),st_time, _get_timestamp());
#-----------------------------------
#------ Local tracking -------------
_local_tracking(tool_id,ToolVersion,Tra_input,_get_file_size(Tra_input),st_time, _get_timestamp());
#-----------------------------------

sys.exit ("\n\tAPI ini Created successfully!!!\n");