import webbrowser

def createhtml(cnt,path):
    html = """
    <!DOCTYPE html>
<html>
<head>
    <title>Trained Data...</title>
</head>
<body>
    """+cnt+"""

    <script>
        // JavaScript code to highlight corrected words and print both old and replaced words
        function highlightAndPrintWords() {
            const paragraphs = document.getElementsByTagName('p');

            for (const paragraph of paragraphs) {
                const incorrectSentence = paragraph.innerHTML.split('Incorrect sentence:')[1].split('<br>')[0].trim();
                const correctedSentence = paragraph.innerHTML.split('Corrected sentence:')[1].split('<br>')[0].trim();
                const incorrectWords = incorrectSentence.split(' ');
                const correctedWords = correctedSentence.split(' ');

                let newContent = '';

                for (let i = 0; i < incorrectWords.length; i++) {
                    const correctedWord = correctedWords[i];
                    const incorrectWord = incorrectWords[i];

                    if (correctedWord !== undefined && correctedWord !== incorrectWord) {
                        newContent += `<span style="background-color: yellow; font-weight: bold;">${correctedWord} (${incorrectWord})</span> `;
                    } else {
                        newContent += `${incorrectWord} `;
                    }
                }

                paragraph.innerHTML = newContent;
            }
        }

        // Call the function to highlight corrected words and print both old and replaced words when the page loads
        window.onload = highlightAndPrintWords;
    </script>
</body>
</html>


    """
    with open(path, "w") as file:
        file.write(html)
    webbrowser.open(path)
    return "Html created..."