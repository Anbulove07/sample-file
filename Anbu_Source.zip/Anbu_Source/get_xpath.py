from lxml import etree

# Parse the XML document
xml = etree.parse(r"D:\Giventool\Pradeep\Sample\JRIM-03-2022-0087.xml")

# Get all XPaths in the document
xpaths = []
for element in xml.iter():
    xpath = xml.getpath(element)
    if xpath not in xpaths:
        xpaths.append(xpath)

# Print the XPaths
for xpath in xpaths:
    print(xpath)
