import time
import docx
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
source_text=[]
def read_docx(file_path):
    doc = docx.Document(file_path)
    text = " ".join([paragraph.text for paragraph in doc.paragraphs])
    return text

def translate_text_with_deepl(source_text, source_lang, target_lang):
    # # Create options for the Chrome WebDriver
    options = Options()
    options.add_argument("--headless")  # Enable headless mode

    # Create a WebDriver instance (e.g., using Chrome)
    driver = webdriver.Chrome(options=options)
    time.sleep(5)
    # Navigate to the DeepL translation page
    driver.get("https://www.deepl.com/translator")

    # Wait for the target language dropdown to be visible
    target_lang_dropdown = WebDriverWait(driver, 60).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, '[data-testid="translator-target-lang-btn"]'))
    )

    # Click the target language dropdown to open the options
    target_lang_dropdown.click()

    # Wait for the cookie banner to appear and locate the close button
    cookie_banner_close = WebDriverWait(driver, 60).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, '[data-testid="cookie-banner-lax-close-button"]'))
    )


    # Click the close button on the cookie banner
    cookie_banner_close.click()

    # Wait for the target language dropdown to be visible
    target_lang_dropdown = WebDriverWait(driver, 60).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, '[data-testid="translator-target-lang-btn"]'))
    )

    # Click the target language dropdown to open the options
    target_lang_dropdown.click()

    # Add a delay to allow the dropdown menu to load
    time.sleep(2)

    # Locate the Spanish option and click it
    spanish_option = WebDriverWait(driver, 100).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, '[data-testid="translator-lang-option-es"]'))
    )
    spanish_option.click()
    # print("Selected Spanish")

    # Find the textarea for the source text
    source_text_area = WebDriverWait(driver, 60).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, '[data-testid="translator-source-input"]'))
    )

    # Simulate keyboard actions to select all text and press the delete key
    source_text_area.send_keys(Keys.CONTROL, 'a')
    source_text_area.send_keys(Keys.DELETE)
    # print("Cleared source text area")

    # Enter the new source text
    source_text_area.send_keys(source_text)
    # print("Entered source text")

    # Add a delay to allow time for translation
    time.sleep(2)

    # Wait for the translation to appear and get the translated text
    translation_text_area = WebDriverWait(driver, 20).until(
        EC.visibility_of_element_located(
            (By.CSS_SELECTOR, '[data-testid="translator-target-input"] [data-content="true"]'))
    )
    translated_text = translation_text_area.text

    # Close the WebDriver
    driver.quit()

    return translated_text

def split_paragraphs(text, char_limit=1500):
    paragraphs = text.split('\n\n')  # Assuming paragraphs are separated by two line breaks
    chunks = []
    current_chunk = ""

    for paragraph in paragraphs:
        if len(current_chunk) + len(paragraph) <= char_limit:
            current_chunk += paragraph + "\n"
        else:
            chunks.append(current_chunk.strip())
            current_chunk = paragraph + "\n"

    if current_chunk:
        chunks.append(current_chunk.strip())

    return chunks

def calculate_similarity(source_text,round_text): # no_of_characters is nothing but character limit of deepl
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform([source_text, round_text])
    similarity_score = cosine_similarity(tfidf_matrix[0], tfidf_matrix[1])[0][0]
    return similarity_score*100

input1='''PROFESOR: En este ejemplo, vamos a utilizar el comando de remuestreo de StatCrunch y el applet Bootstrap para construir un intervalo de confianza del 95%. El sitio web fueleconomy.gov permite a los conductores informar de las millas por galón de su vehículo. Los datos de la tabla muestran las millas por galón reportadas de automóviles Honda Accord Hybrid 2019 para 16 propietarios diferentes.   Trate la muestra como una muestra aleatoria simple de todos los automóviles Honda Accord Hybrid 2019. Construya un intervalo de confianza del 95% para la media de millas por galón de un Honda Accord Híbrido 2019 usando una muestra Bootstrap. Interprete el intervalo. Así que los datos son 42.3, 43.6, 48.2, 40, 39, 42.9, 44.8, 43, 40.7, 38.6, 39, 44.5, 35.5, 45.1, 35.4, y 42.2.   Así que primero tenemos que introducir estos datos en una hoja de cálculo de StatCrunch. Y puedes ver que la primera columna es MPG, las millas por galón para los 16 automóviles. Ahora seleccione Stat, Resample, Statistic. La columna es Millas por Galón. Y luego en Estadística, vas a escribir media de millas por galón. El método de muestreo es el Bootstrap. El tipo de remuestreo es univariado. Queremos 2.000 remuestreos.   Y luego asegúrese de que los percentiles 2,5 y 97,5 se incluyen porque tenemos un intervalo de confianza del 95%. Si quisieras un intervalo de confianza del 90%, necesitarías los percentiles 5 y 95. Si quisieras un intervalo de confianza del 99%, necesitarías los percentiles 0,5 y 99,5.   Al hacer este problema, vamos a utilizar una semilla fija de 9382 para que pueda confirmar nuestros resultados. Haga clic en Calcular. No

tice que el percentil 2,5 es 39,84, y el percentil 97,5 es 43,21. Por lo tanto, estamos 95% seguros de que la media de millas por galón de un Honda Accord Hybrid 2019 está entre 39.84 millas por galón y 43.21 millas por galón.   En lugar de utilizar el comando de remuestreo, también podemos utilizar el applet de remuestreo. Con los datos en la hoja de cálculo StatCrunch, seleccione Applets, Resampling, Bootstrap a Statistic. Vamos a seleccionar los datos de la columna Millas por Galón bajo Muestras. La estadística es la media. Y vamos a utilizar una semilla fija de 3892 para que pueda confirmar nuestros resultados.   Haga clic en Calcular. Lo que vamos a hacer es seleccionar 1.000 veces dos veces para obtener 2.000 muestras Bootstrap. El percentil 2,5 es 39,96. Y el percentil 97,5 es 43,25. Así que tenemos un 95% de confianza en que la media de millas por galón de un Honda Accord Hybrid 2019 está entre 39,96 millas por galón y 43,25 millas por galón.   Observe que el intervalo de confianza Bootstrap usando el applet difiere del comando remuestrear. Esto se debe a que tenemos diferentes muestras Bootstrap en cada ejemplo. Esto ilustra un punto importante. Diferentes muestras Bootstrap conducen a diferentes intervalos de confianza. Sin embargo, los resultados deberían ser parecidos siempre que obtenga al menos 2.000 muestras Bootstrap.
'''
output1='''PROFESOR: En este ejemplo, vamos a usar el comando de remuestreo de StatCrunch y el subprograma Bootstrap para construir un intervalo de confianza del 95 %. El sitio web fueleconomy.gov permite a los conductores informar de las millas por galón de su vehículo. Los datos de la tabla muestran las millas por galón informadas por 16 propietarios diferentes de  automóviles Honda Accord Hybrid 2019. 
Considere la muestra como una muestra aleatoria simple de todos los automóviles Honda Accord Hybrid 2019. Construya un intervalo de confianza del 95 % para el promedio de millas por galón de un Honda Accord Híbrido 2019 utilizando una muestra Bootstrap. Proceda a interpretar el intervalo. Así que los datos son 42,3, 43,6, 48,2, 40, 39, 42,9, 44,8, 43, 40,7, 38,6, 39, 44,5, 35,5, 45,1, 35,4 y 42,2. 
Entonces, primero tenemos que ingresar estos datos en una hoja de cálculo de StatCrunch. Puede ver que la primera columna es MPG, es decir las millas por galón para los 16 automóviles. Ahora seleccione Stat [Estad], Resample [Remuestreo], Statistic [Estadística]. La columna es Millas por galón. Luego, en Statistic [Estadística], escribirá el promedio de millas por galón. El método de muestreo es el Bootstrap. El tipo de remuestreo es univariado. Buscamos obtener 2.000 remuestreos. 
A continuación, asegúrese de que se incluyan los percentiles 2,5 y 97,5 porque tenemos un intervalo de confianza del 95 %. Si quisiera un intervalo de confianza del 90 %, necesitaría los percentiles 5 y 95. En cambio, si deseara un intervalo de confianza del 99 %,  los percentiles serían 0,5 y 99,5. 
Al resolver este problema, usaremos una semilla fija de 9382 para que pueda confirmar nuestros resultados. Haga clic en Compute [Calcular]. Observe que el percentil 2,5 es 39,84 y el percentil 97,5 es 43,21. Por lo tanto, estamos 95 % seguros de que el promedio de millas por galón de un Honda Accord Hybrid 2019 está entre 39,84 millas por galón y 43,21 millas por galón. 
En lugar de usar el comando de remuestreo, también podemos usar el subprograma de remuestreo. Con los datos en la hoja de cálculo de StatCrunch, seleccione Applets [Subprogramas], Resampling [Remuestreo], Bootstrap a Statistic [Bootstrap a Estadística]. Vamos a seleccionar los datos de la columna Millas por galón en Samples [Muestras]. La estadística es el promedio. Además, usaremos una semilla fija de 3892 para que pueda confirmar nuestros resultados. 
Haga clic en Compute [Calcular]. Lo que vamos a hacer es seleccionar 1.000 veces dos veces para obtener 2.000 muestras de Bootstrap. El percentil 2,5 es 39,96 mientras que el percentil 97,5 es 43,25. Por lo tanto, estamos un 95 % seguros de que el promedio de millas por galón de un Honda Accord Hybrid 2019 está entre 39,96 millas por galón y 43,25 millas por galón. 
Sírvase notar que el intervalo de confianza Bootstrap con el subprograma difiere del intervalo de confianza con el comando de remuestreo. Esto se debe a que tenemos diferentes muestras de Bootstrap en cada ejemplo. Esto ilustra un punto importante: diferentes muestras de Bootstrap conducen a diferentes intervalos de confianza. Sin embargo, los resultados deberían ser similares siempre que obtenga al menos 2.000 muestras de Bootstrap.
'''
# out=calculate_similarity(input1,output1)
# print(out)

def sou(input_file_path,no_of_characters):
    sou_text = read_docx(input_file_path)
    sou_batches = [sou_text[i:i + no_of_characters] for i in range(0, len(sou_text), no_of_characters)]
    sou_list = []
    for batch in sou_batches:
        sou_list.append(batch)
    source_text = "\n\n".join(sou_list)
    return source_text,sou_list

# no_of_characters = 1500
# source_text,sou_list=sou(r"D:\Giventool\Pradeep\New_Translation_Project\Input\Wordinput\swis3e_9_4_EX2_sc_en_small.docx",no_of_characters)

# sou_text = read_docx(input_file_path)
# sou_batches = [sou_text[i:i+no_of_characters] for i in range(0, len(sou_text), no_of_characters)]
# sou_list = []
# for batch in sou_batches:
#     sou_list.append(batch)
# source_text = "\n\n".join(sou_list)
# print("****************************************************Source****************************************************")
# print(source_text)
# print("****************************************************Source****************************************************")
# # print(sou_list)

# source_lang = "English"
# target_lang = "Spanish"
# trans_list=[]
# for i in sou_list:
#     trans_list.append(translate_text_with_deepl(i,source_lang,target_lang))
#
# print(trans_list)
#
# round_list=[]
# for i in trans_list:
#     round_list.append(translate_text_with_deepl(i,target_lang,source_lang))
# round_text = "\n\n".join(round_list)
#
# # print("****************************************************Round****************************************************")
# print(round_text)
# print("****************************************************Round****************************************************")
# print("\n\n\n")
# print("Similarity Score: ",calculate_similarity(source_text=source_text,round_text=round_text))
   