###################################################################
# 																  #
#  Project Name : OUP_Book_MARC_To_CSV.py	    					      #
#  Version      : 1.0.0.0                                         #
#  Developed    : ANBU .G |                                       #
#  Purpose		: Content Creation for XML to Excel               #
#  Syntax 		:  <EXE> <Folder_Path>  					              #
#                                                                 #
###################################################################
import xlrd

###################################################################
#
# Run  		  : OUP_Book_MARC_To_CSV.py <Folder_Path>
# Description : Create Excel file from input Xml Content
###################################################################

###################################################################
# Updation History
#=================================================================
#	14-04-2023 | v1.0.0.0 | ANBU .G	Initial Development
###################################################################

ToolVersion = "1.0.0.0";

import os
from os.path import basename, dirname
import sys
import re
from iModule.Basic import *
import xlsxwriter
import pandas as pd
import csv

# Tool path
ToolPath = dirname(sys.argv[0]);
ToolPath = re.sub(r'\/', r'\\', ToolPath, 0)

os.system("cls")

# Inline argument checking
if ((len(sys.argv) != 2) or not os.path.isdir(sys.argv[1])): sys.exit("\n\tSyntax: OUP_Book_MARC_To_CSV.py <Folder_Path>\n")

print("\n\n\tOUP_Book_MARC_To_CSV v" + str(ToolVersion) + "...\n")
print("\tCopyright @ Integra Software Services Ltd.\n")


# Global variable declaration
Input = sys.argv[1]
# filename = basename(Input)
# InPath = dirname(Input)
# print(Input)
var11=0
# arr_txt1 = [x for x in os.listdir(Input) if x.endswith(".xml, .xls, .xlsx, .xlsm")]

arr_txt1=_get_file_list(Input,1,1, ".xml$|.xls$|.xlsx$|.xlsm$")

# print(arr_txt1)
for i in range(len(arr_txt1)):
    if re.search('bookdetails.xml',arr_txt1[i],re.I|re.S):
        cnt = _open_file(arr_txt1[i])
        var11=1
        break
    if re.search('Handover Form',arr_txt1[i],re.I|re.S):
        handoverform=arr_txt1[i]
        var11=2
        break
for i in range(len(arr_txt1)):
    if re.search('Prelims.xml',arr_txt1[i],re.I|re.S):
        cnt1 = _open_file(arr_txt1[i])
        break
if var11==1:
    print("WMS")
    updatecsv=""
    err=""
    if re.search(r'<Digital-Online-ISBN(?: [^>]*)?>((?:(?!</Digital-Online-ISBN>).)*)</Digital-Online-ISBN>',cnt,re.I|re.S):
        digionline_ISBN = re.search(r'<Digital-Online-ISBN(?: [^>]*)?>((?:(?!</Digital-Online-ISBN>).)*)</Digital-Online-ISBN>',cnt,re.I|re.S)
        updatecsv= "eISBN," + digionline_ISBN.group(1) + ",\n"
    else:
        err="eISBN, Not found"
    if re.search(r'<Hardback-ISBN(?: [^>]*)?>((?:(?!</Hardback-ISBN>).)*)</Hardback-ISBN>',cnt,re.I|re.S):
        Hardback_ISBN = re.search(r'<Hardback-ISBN(?: [^>]*)?>((?:(?!</Hardback-ISBN>).)*)</Hardback-ISBN>',cnt,re.I|re.S)
        updatecsv= updatecsv + "Print ISBN," + Hardback_ISBN.group(1) + ",\n"
    else:
        err=err+"Print ISBN, Not found"
    if re.search(r'<book-author-name(?: [^>]*)?>((?:(?!</book-author-name>).)*)</book-author-name>',cnt,re.I|re.S):
        book_author_name = re.search(r'<book-author-name(?: [^>]*)?>((?:(?!</book-author-name>).)*)</book-author-name>',cnt,re.I|re.S)
        updatecsv= updatecsv + "Author," + book_author_name.group(1) + ",\n"
    else:
        err=err+"Author, Not found"
    if re.search(r'<Book-Name(?: [^>]*)?>((?:(?!</Book-Name>).)*)</Book-Name>',cnt,re.I|re.S):
        Book_Name = re.search(r'<Book-Name(?: [^>]*)?>((?:(?!</Book-Name>).)*)</Book-Name>',cnt,re.I|re.S)
        updatecsv= updatecsv + "Title," + Book_Name.group(1) + ",\n"
    else:
        err=err+"Title, Not found"
    if re.search(r'<Year-of-publication(?: [^>]*)?>((?:(?!</Year-of-publication>).)*)</Year-of-publication>',cnt,re.I|re.S):
        Year_of_publication = re.search(r'<Year-of-publication(?: [^>]*)?>((?:(?!</Year-of-publication>).)*)</Year-of-publication>',cnt,re.I|re.S)
        updatecsv= updatecsv + "Year of Publication," + Year_of_publication.group(1) + ",\n"
    else:
        err=err+"Year of Publication, Not found"
    if re.search(r'<DOI-URL(?: [^>]*)?>((?:(?!</DOI-URL>).)*)</DOI-URL>',cnt,re.I|re.S):
        Year_of_publication = re.search(r'<DOI-URL(?: [^>]*)?>((?:(?!</DOI-URL>).)*)</DOI-URL>',cnt,re.I|re.S)
        updatecsv= updatecsv + "DOI URL," + Year_of_publication.group(1) + ",\n"
    else:
        err=err+"DOI URL, Not found"

    if err=="":
        _save_file(Input+"\\"+Hardback_ISBN.group(1)+".csv",updatecsv)
        print("CSV file created successfully")

elif var11==2:
    print("Non WMS")
    updatecsv=''
    err=''
    df = pd.read_excel(handoverform, sheet_name=None)
    first_sheet_name = list(df.keys())[0]
    df[first_sheet_name].to_csv(dirname(handoverform) + "\\FirstSheet.csv")
    rows = []
    with open(dirname(handoverform) + "\\FirstSheet.csv", 'r', encoding='utf-8') as file:
        csvreader = csv.reader(file)
        header = next(csvreader)
        for row in csvreader:
            rows.append(row)
    os.remove(dirname(handoverform) + "\\FirstSheet.csv")

    for x in range(len(rows)):
        if rows[x][4] == "Digital-Online":
            Digital_Online = rows[x][5]
        if rows[x][4] == "Hardback":
            Hardback = rows[x][5]
        if rows[x][4] == "Exact wording of author name(s) on the title page:":
            Author_name = rows[x][5]
        if rows[x][4] == "Title: ":
            Title = rows[x][5]
        if rows[x][4] == "Estimated Online Release Date:":
            Year_of_publication = rows[x][5]

    if Digital_Online=="":
        err=err+"eISBN, Not found"
    if Hardback=="":
        err=err+"Print ISBN, Not found"
    if Author_name=="":
        err=err+"Author, Not found"
    if Title=="":
        err=err+"Title, Not found"
    if Year_of_publication=="":
        err=err+"Year of Publication, Not found"

    if re.search(r'<line(?: [^>]*)?>(DOI:(?:(?!</line>).)*)</line>', cnt1, re.I | re.S):
        Year_of_publication = re.search(r'<line(?: [^>]*)?>(DOI:(?:(?!</line>).)*)</line>', cnt1, re.I | re.S)
        updatecsv = updatecsv + "DOI URL," + Year_of_publication.group(1) + ",\n"
    else:
        err = err + "DOI URL, Not found"

    if err=="":
        updatecsv= "eISBN," + Digital_Online + ",\n"
        updatecsv= updatecsv + "Print ISBN," + Hardback + ",\n"
        updatecsv= updatecsv + "Author," + Author_name + ",\n"
        updatecsv= updatecsv + "Title," + Title + ",\n"
        updatecsv= updatecsv + "Year of Publication," + Year_of_publication.group(1) + ",\n"
        _save_file(Input+"\\"+Hardback+".csv",updatecsv)
        print("CSV file created successfully")


    #
    # # YOU MUST PUT sheet_name=None TO READ ALL CSV FILES IN YOUR XLSM FILE
    # print(handoverform)
    # df = pd.read_excel(handoverform, sheet_name=None, engine='openpyxl')
    #
    # # prints all sheets
    # print(df)

