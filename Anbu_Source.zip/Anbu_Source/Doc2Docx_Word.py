import os
import win32com.client

def convert_doc_to_docx(doc_file_path, docx_file_path):
    # Create a new instance of Word
    word = win32com.client.Dispatch("Word.Application")

    # Open the DOC file
    doc = word.Documents.Open(doc_file_path)

    # Save as DOCX
    doc.SaveAs(docx_file_path, 12)  # 12 is the value for DOCX format

    # Close the documents and Word application
    doc.Close()
    word.Quit()

# Example usage
doc_file_path = r"D:\Giventool\karthik\IOPP\IOPP\input new update\Incoming IOPP\TRAN_117671\Source\acf3da\Source files for the revised manuscript with no tracked changes.doc"
docx_file_path = r"D:\Giventool\karthik\IOPP\IOPP\input new update\Incoming IOPP\TRAN_117671\Source\acf3da\Source files for the revised manuscript with no tracked changes.docx"
convert_doc_to_docx(doc_file_path, docx_file_path)
