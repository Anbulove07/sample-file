import os
import re
import shutil
import time
import zipfile
import imgkit
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
def full_page_screenshot(url, output_image, width, height):
    # Configure Chrome options
    chrome_options = Options()
    chrome_options.add_argument('--headless')  # Run Chrome in headless mode

    # Set path to chromedriver executable
    # Initialize Chrome driver
    driver = webdriver.Chrome( options=chrome_options)


    url=re.sub(r'\\','/',url,0)

    # Navigate to the URL
    driver.get(f'file:///{url}')
    print(f'file:///{url}')
    time.sleep(5)
    # Get page height
    page_height = driver.execute_script('return document.body.scrollHeight')

    # Set window size to match the entire page height
    # driver.set_window_size(driver.execute_script('return window.innerWidth'), page_height)
    driver.set_window_size(width, page_height)

    # Capture screenshot of the entire page
    driver.save_screenshot(output_image)

    # Close the driver
    driver.quit()

def extract_zip_file(zip_file_path):
    # Get the directory path of the zip file
    zip_dir = os.path.dirname(zip_file_path)

    # Create an output folder path
    output_folder = os.path.join(zip_dir, 'output')

    # Create the output folder if it doesn't exist
    os.makedirs(output_folder, exist_ok=True)

    # Open the zip file
    with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
        # Extract all files to the output folder
        zip_ref.extractall(output_folder)

    print(f'Zip file extracted to: {output_folder}')


# # Example usage
# zip_file_path = r"D:\Giventool\Thangaprakasam\New folder\Digibooks_Content_Extraction\9780134478333.zip"
# extract_zip_file(zip_file_path)

def _createtable(param,linkcnt,path,tabcount):

    path1=os.path.dirname(path)+'\\'+r'output\OPS\xhtml/'
    htmlcnt=f'<html><head>{linkcnt}</head><body>{param}</body></html>'
    with open(path1+f'table{tabcount}.html','w',encoding='utf-8') as f:
        f.write(htmlcnt)
    # html_to_image(path1+'table.html',path1+'table.png')
    # tabcount = tabcount + 1
    # url = path1+f'table{tabcount}.html'
    # # url = re.sub(r'\\', '//', url1)
    # # url = re.sub(r' ', '%20', url)
    # output_image = re.sub(r'\.html$', r'.png', url)

    width = 1280  # Desired screen width
    height = 800  # Desired screen height
    print(path1+f'table{tabcount}.html')
    retn="\n\n[pathin]"+(path1+f'table{tabcount}.png')+"[pathout]\n\n"
    full_page_screenshot(path1+f'table{tabcount}.html', path1+f'table{tabcount}.png', width, height)
    return retn
    # print(path1)
    # print(r"D:\Giventool\Thangaprakasam\Newfolder\Digibooks_Content_Extraction\output\OPS\xhtml\table1.html")

    # print(tabcount)

    # exit()
    # print(linkcnt)
    # print(param)
    # print('------------------------------------').
# width = 1280  # Desired screen width
# height = 800
# full_page_screenshot(r"D:\Giventool\Thangaprakasam\New folder\Digibooks_Content_Extraction\output\OPS\xhtml\table1.html", r"D:\Giventool\Thangaprakasam\New folder\Digibooks_Content_Extraction\output\OPS\xhtml\table1.png", width, height)