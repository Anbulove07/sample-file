import time
from iModule.Basic import _open_file

from docx import Document
from flask import flash
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from flask import render_template, request, redirect, flash, send_file, send_from_directory, abort, url_for, \
    session
def translate_text_with_deepl(source_text, target_lang):
    # Create a WebDriver instance (e.g., using Chrome)

    chrome_options = webdriver.ChromeOptions()
    # chrome_options.add_argument("--headless")  # Run in headless mode
    driver = webdriver.Chrome(options=chrome_options)
    # Navigate to the DeepL translation page
    driver.get("https://www.deepl.com/translator")

    cookie_banner_close_button = WebDriverWait(driver, 20).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, 'span.dl_cookieBanner--cta-buttonClose'))
    )
    cookie_banner_close_button.click()

    # Wait for the target language dropdown to be visible
    target_lang_dropdown = WebDriverWait(driver, 20).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, '[data-testid="translator-target-lang-btn"]'))
    )

    # Click the target language dropdown to open the options
    # Scroll the target language dropdown into view
    driver.execute_script("arguments[0].scrollIntoView(true);", target_lang_dropdown)

    # target_lang_dropdown.click()
    driver.execute_script("arguments[0].click();", target_lang_dropdown)

    # Add a delay to allow the dropdown menu to load
    time.sleep(2)
    if target_lang == 'spanish':
        # Locate the Spanish option and click it
        spanish_option = WebDriverWait(driver, 20).until(
            EC.visibility_of_element_located((By.CSS_SELECTOR, '[data-testid="translator-lang-option-es"]'))
        )
    elif target_lang == 'English':
        # Locate the Spanish option and click it
        spanish_option = WebDriverWait(driver, 20).until(
            EC.visibility_of_element_located((By.CSS_SELECTOR, '[data-testid="translator-lang-option-en-US"]'))
        )
    spanish_option.click()
    # print("Selected Spanish")

    # Find the textarea for the source text
    source_text_area = WebDriverWait(driver, 20).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, '[data-testid="translator-source-input"]'))
    )

    # Simulate keyboard actions to select all text and press the delete key
    source_text_area.send_keys(Keys.CONTROL, 'a')
    source_text_area.send_keys(Keys.DELETE)
    # print("Cleared source text area")

    # Enter the new source text
    source_text_area.send_keys(source_text)
    # print("Entered source text")

    # Add a delay to allow time for translation
    time.sleep(2)

    # Wait for the translation to appear and get the translated text
    translation_text_area = WebDriverWait(driver, 20).until(
        EC.visibility_of_element_located(
            (By.CSS_SELECTOR, '[data-testid="translator-target-input"] [data-content="true"]'))
    )
    translated_text = translation_text_area.text

    # Close the WebDriver
    driver.quit()

    return translated_text


def read_word_file(file_path, target_lang):
    doc = Document(file_path)
    full_text = []
    for para in doc.paragraphs:
        translated_text = translate_text_with_deepl(para.text, target_lang)
        # flash("File Translating...using DeepL")
        # return render_template("index.html")
        full_text.append(translated_text)
    # flash("File Translated Successfully")
    # return render_template("index.html")
    return '\n'.join(full_text)

# Example usage
source_text =_open_file(r"D:\Giventool\Pradeep\Translate\21-06-2023\Video Transcripts for Testing\Text Transcripts - English\swis3e_9_4_EX2_sc_en.txt")
cnt=source_text.split("\n\n")
print(len(cnt))
# # exit()
source_lang = "English"
target_lang = "Spanish"
txt=''
# read_word_file(r"D:\Giventool\Pradeep\New_Translation_Project\Input\Subodh\swis3e_9_4_EX2_sc_es_Spanish.docx")
for i in cnt:
    translated_text = translate_text_with_deepl(i, target_lang)
    txt=txt+translated_text+"\n\n"
print("Translated Text:", txt)
