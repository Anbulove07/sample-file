# import PySimpleGUI as sg
# import subprocess
# import os
#
# def run_exe_in_background(exe_path, folder_path):
#     # Run the .exe file in the background using CMD
#     cmd = f'cmd /c start /B {exe_path} {folder_path}'
#     subprocess.Popen(cmd, shell=True)
#
# def main():
#     layout = [
#         [sg.Text("Select a folder:")],
#         [sg.InputText(key='-FOLDER-'), sg.FolderBrowse(target='-FOLDER-')],
#         [sg.Button("Run .exe in Background")],
#         [sg.Output(size=(60, 10))],
#     ]
#
#     window = sg.Window("EpubCreation", layout)
#
#     while True:
#         event, values = window.read()
#
#         if event == sg.WIN_CLOSED:
#             break
#         elif event == "Run .exe in Background":
#             folder_path = values['-FOLDER-']
#             exe_path = r'D:\temp\Narayanan\input\EpubCreation.exe'  # Replace this with the actual path to your .exe file
#
#             if os.path.exists(exe_path) and os.path.isdir(folder_path):
#                 print(f"Running {exe_path} in the background with folder path: {folder_path}")
#                 run_exe_in_background(exe_path, folder_path)
#                 print("Execution started.")
#             else:
#                 print("Error: Invalid path to .exe or folder.")
#
#     window.close()
#
# if __name__ == "__main__":
#     main()
import sys

import PySimpleGUI as sg
import subprocess
import os


def run_exe_and_capture_output(exe_path, folder_path):
    cmd = [exe_path, folder_path]
    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

    # Capture and display the output in the GUI
    while True:
        output = process.stdout.readline()
        if output == '' and process.poll() is not None:
            break
        if output:
            print(output.strip())


def main():
    layout = [
        [sg.Text("Select a folder:")],
        [sg.InputText(key='-FOLDER-'), sg.FolderBrowse(target='-FOLDER-')],
        [sg.Button("Submit")],
        [sg.Output(size=(60, 10))],
    ]

    window = sg.Window("Run .exe and Capture Output", layout)

    while True:
        event, values = window.read()

        if event == sg.WIN_CLOSED:
            break
        elif event == "Submit":
            folder_path = values['-FOLDER-']
            exepath=os.path.dirname(sys.argv[0])+r'\EpubCreation.exe'
            exe_path = exepath  # Replace this with the actual path to your .exe file

            if os.path.exists(exe_path) and os.path.isdir(folder_path):
                print(f"Running {exe_path} with folder path: {folder_path}")
                run_exe_and_capture_output(exe_path, folder_path)
                print("Execution completed.")
            else:
                print("Error: Invalid path to .exe or folder.")

    window.close()


if __name__ == "__main__":
    main()
