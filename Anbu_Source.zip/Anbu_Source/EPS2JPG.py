#------------------------------------------------------------------
#  Tool Name    : Image_into_Excel.py
#  Developer    : Anbarasan P | CTAE XML
#  Description  : Eps image to JPG image converting
#  Client/DU    : Vendor
#  Syntax		: <EXE> <Image Folder>
#------------------------------------------------------------------

#------------ Rivision History  -----------------------------------
#  19-10-2022 | v1.0.0.0 | Anbarasan  | Req Kannika
#------------------------------------------------------------------

version='1.0.0.0'

import os
from os.path import basename,dirname
import sys
import subprocess
import re
import shutil
from iModule.Basic import*
from iModule.WebServices import *
import pandas as pd
import PIL
from PIL import Image
import io
from psd_tools import PSDImage
from PIL import EpsImagePlugin

Toolpath = dirname(os.sys.argv[0]);
Toolpath = re.sub(r'\/',r'\\',Toolpath,0)

os.system("cls");

if (len(os.sys.argv) != 2 or not os.path.isdir(os.sys.argv[1])): sys.exit("\n\tSyntax: EPS2JPG.exe <Image Folder>\n")


inputDir = os.sys.argv[1]

print ("\n\n\tEPS to JPG v"+version+" is Running...\n\n");

#------------ Tracking --------------------------------------------
Tra_input = sys.argv[1]
tool_id = 496; ##vendor.py Tool
is_local = _daily_onetime_supplier_validity_registry(tool_id, Tra_input, version, 1)
if not is_local:
	sys.exit(0)
run_size = 0
st_time = _get_timestamp()
#------------------------------------------------------------------

#EPS to jpg conversion
EpsImagePlugin.gs_windows_binary =  r'C:\Program Files\gs\gs9.52\bin\gswin64c'
EPS = _get_file_list(inputDir,1,1,r'\.eps')

for img in EPS:
    im = Image.open(img)
    imgpath = img.replace('.eps', '.jpg')

    mywidth = 1250
    # print(Out_Image)
    # imgs = Image.open(img)
    wpercent = (mywidth / float(im.size[0]))
    # print(wpercent)
    hsize = int((float(im.size[1]) * float(wpercent)))
    im.load(scale=10)
    im = im.resize((mywidth, hsize), Image.Resampling.LANCZOS)

    try:
        # im.load(scale=3)
        im.save(imgpath)
        im.close()
    except:
        print("Not updated")
        # im.close()

    os.unlink(img)

#Tif to jpg conversion
Tif = _get_file_list(inputDir,1,1,r'\.tif')
for img in Tif:
    im = Image.open(img)

    Out_Image = re.sub(r'\.tif', '', img, re.I | re.S)

    try:
        # im.load(scale=3)
        im.save(Out_Image+'.jpg')
        im.close()
    except:
        print("Not updated")
        # im.close()
    os.unlink(img)

png = _get_file_list(inputDir,1,1,r'\.png')
for img in png:
    im = Image.open(img)
    Out_Image = re.sub(r'\.png', '', img, re.I | re.S)
    try:
        im.save(Out_Image+'.jpg')
        im.close()
    except:
        print("Not updated")

    os.unlink(img)

# Tif1 = _get_file_list(inputDir,1,1,r'\.tif')
# for img in Tif1:
#     im = Image.open(img)
#     Out_Image = re.sub(r'\.tif', '', img, re.I | re.S)
#     try:
#         # im.load(scale=3)
#         im.save(Out_Image+'.jpg')
#         im.close()
#     except:
#         print("Not updated")
#
#     os.unlink(img)



#------ Local tracking -------------
_local_tracking(tool_id,version,Tra_input,_get_file_size(Tra_input),st_time,_get_timestamp());
#-----------------------------------

print("\n\tEPS image converted to JPG image successfully!!!\n");
sys.exit(0)

