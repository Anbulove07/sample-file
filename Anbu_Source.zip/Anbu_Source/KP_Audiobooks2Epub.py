
# ---------------------------------------------------------------------
#  Tool Name	: KP_Audiobooks2Epub.py
#  Developer	: Anbu G
#  Description  : To Convert the EPUB file
#  Client/DU	: KoganPages / Journal Others
#  Syntax		: <EXE> <EPUB_File>
# -----------------------------------------------------------------------



# ------------ Rivision History  -------------------------------------------
#  22-07-2021 | v1.0.0.0 | Anbu G | Initial Development
# --------------------------------------------------------------------------


ToolVersion = "1.0.0.0";


from iModule.ToolTracking import _get_timestamp, _local_tracking, _get_file_size
import zipfile
import os
import glob
import itertools #for id sequence
from datetime import date
import sys
from num2words import num2words
import re
from iPython.Basic import _open_utf8, _element_leveling
import xml.etree.ElementTree as ET

from iModule.Basic import _open_utf8, _save_utf8
from lxml.html.soupparser import fromstring
# Command line argument validation here:
try :
    Epub_filename = sys.argv[1]
except :
    # src = r'D:\Anbu\XML\pdftest.pdf'
    print("Please Enter .Epub file location")
    exit()

print("\n\n\tEPUB_Converstion v" + ToolVersion + " is Running...");
print("\tCopyright @ Integra Software Services Ltd.\n");

# ------------ Tracking --------------------------------------------
Tra_input = sys.argv[1];
tool_id = 467;  # Epub_Validation
run_size = 0;
st_time = _get_timestamp();
# ------------------------------------------------------------------



# Epub_filename=r"D:\Anbu\Epub_Validation\New_folder\9781789663334_EPUB.epub"
DirZipFile=Epub_filename.replace(".epub",".zip")
mypath12=Epub_filename.replace(".epub","")
filenameoutput=os.path.basename(DirZipFile)
filenameoutput1=filenameoutput.replace(".zip","")

OutputDir=os.path.dirname(Epub_filename)+"\\"+filenameoutput1
todays_date = date.today()
yearcrnt=todays_date.year
# Remove already exist EPUB files and folders

if os.path.exists(mypath12):
    import os, re, os.path, shutil

    for root, dirs, files in os.walk(mypath12):
        for file in files:
            os.remove(os.path.join(root, file))

    folder_path = mypath12
    for file_object in os.listdir(folder_path):
        file_object_path = os.path.join(folder_path, file_object)
        if os.path.isfile(file_object_path) or os.path.islink(file_object_path):
            os.unlink(file_object_path)
        else:
            shutil.rmtree(file_object_path)


# Extract Epub file in output folder
with zipfile.ZipFile(Epub_filename,"r") as zip_ref:
    zip_ref.extractall(OutputDir)

# arr = os.listdir(OutputDir+"\content")
# Get list of files(specific .xhtml) in content folder
arr_txt = [x for x in os.listdir(OutputDir+"\content") if x.endswith(".xhtml")]
# files_path = [os.path.abspath(x) for x in os.listdir(OutputDir+"\content") if x.endswith(".xhtml")]
outpath=OutputDir+"\content"

# full_path=os.path.join(outpath,arr_txt[4])

length1=len(arr_txt)


# Remove :	Content to remove like file dir, section
for x in range(length1):
    # name=arr_txt[x].split("_")
    # endname=len(name)-1


    # heroRegex = re.compile(r"halftitle|endorsements|seriespage|dedication|copyright|toc|notes|loi|lot|loa|lov|about-the-author|acknowledgements|chronology|contributors|abbreviations|frontmatter|chapter-endnotes|chapter-references|endnotes|references|appendix|glossary|answers|endmatter|index", flags=re.IGNORECASE)
    # mo1 = heroRegex.search(arr_txt[x])
    full_path1 = os.path.join(outpath, arr_txt[x])
    data = _open_utf8(full_path1)
    heroRegex = re.compile(r'<section(?: [^>]*)? class="(halftitle|endorsements|seriespage|dedication|copyright|toc|notes|loi|lot|loa|lov|about-the-author|acknowledgements|chronology|contributors|abbreviations|frontmatter|chapter-endnotes|chapter-references)"[^>]*?>((?:(?!</section>).)*)</section>', flags=re.IGNORECASE)
    mo1 = heroRegex.search(data)

    try:
        mo1.group()
        full_path = os.path.join(outpath, arr_txt[x])
        os.remove(full_path)
    except:
        pass
        full_path1 = os.path.join(outpath, arr_txt[x])
        data = _open_utf8(full_path1)
        data=re.sub(r'<section(?: [^>]*)? class="references"[^>]*?>((?:(?!</section>).)*)</section>',r"",data,0,re.I|re.S)
        data=re.sub(r'<section(?: [^>]*)? class="endnotes"[^>]*?>((?:(?!</section>).)*)</section>',r"",data,0,re.I|re.S)
        data=re.sub(r'<section(?: [^>]*)? class="appendix"[^>]*?>((?:(?!</section>).)*)</section>',r"",data,0,re.I|re.S)
        data=re.sub(r'<section(?: [^>]*)? class="glossary"[^>]*?>((?:(?!</section>).)*)</section>',r"",data,0,re.I|re.S)
        data=re.sub(r'<section(?: [^>]*)? class="answers"[^>]*?>((?:(?!</section>).)*)</section>',r"",data,0,re.I|re.S)
        data=re.sub(r'<section(?: [^>]*)? class="endmatter"[^>]*?>((?:(?!</section>).)*)</section>',r"",data,0,re.I|re.S)
        data=re.sub(r'<section(?: [^>]*)? class="index"[^>]*?>((?:(?!</section>).)*)</section>',r"",data,0,re.I|re.S)
        data=re.sub(r'<img[^>]*>',r"",data,0,re.I|re.S)



    # full_path1 = os.path.join(outpath, arr_txt[x])
    # data = _open_utf8(full_path1)


        _save_utf8(full_path1, data)
    # _save_utf8(full_path, data)
        #
        # # ADD Blockquote | Epigraph-Quote-Equation-
        # data=re.sub(r'(<blockquote><p (?: [^>]class="block-quote")*((?:(?!</blockquote>).)*)</blockquote>)',r'<p class="text-fo">Quote.</p>\n \g<1> ',data,0,re.I|re.S)
        # data=re.sub(r'(<blockquote><p (?: [^>]class="epigraph")*((?:(?!</blockquote>).)*)</blockquote>)',r'<p class="text-fo">Epigraph.</p>\n \g<1> ',data,0,re.I|re.S)
        # data=re.sub(r'(<blockquote><p (?: [^>]class="block-equation")*((?:(?!</blockquote>).)*)</blockquote>)',r'<p class="text-fo">Equation.</p>\n \g<1> ',data,0,re.I|re.S)
        #
        #
        # # Add Strat of box and end of box in <aside> tag
        # data=re.sub(r'(<aside(?: [^>]*)? class="(?:case-study|tint|objectives|box|example|tip|exercise|lessons|checklist|review|key-points|questions)"[^>]*?>((?:(?!</aside>).)*)</aside>)',r'<p class="text-fo">Start of box.</p>\n \g<1> \n<p class="text-fo">End of box.</p>',data,0,re.I|re.S)
        #
        #

# Get .xhtml files in content folder
arr_txt1 = [x for x in os.listdir(OutputDir + "\content") if x.endswith(".xhtml")]

length1=len(arr_txt1)

# Remove Section while the halftitle, endorsement, serispage etc., mactching inside section class
for x in range(length1):
    full_path1 = os.path.join(outpath, arr_txt1[x])
    data = _open_utf8(full_path1)
    heroRegex11 = re.compile(r'<section(?: [^>]*)? class="(halftitle|endorsements|seriespage|dedication|contents|copyright|toc|notes|loi|lot|loa|lov|about-the-author|acknowledgements|chronology|contributors|abbreviations|frontmatter|chapter-endnotes|chapter-references|endnotes|references|reference|appendix|glossary|answers|endmatter|index)"[^>]*?>((?:(?!</section>).)*)</section>', re.I | re.S)
    mo111 = heroRegex11.search(data)
    try:
        mo111.group()
        full_path = os.path.join(outpath, arr_txt1[x])
        os.remove(full_path)
    except:
        pass
    # print(x+1)





    # if(mo1.group()=="Endorsements"):
    #
    #     full_path = os.path.join(outpath, arr_txt[x])
    #     os.remove(full_path)

# tree = ET.parse(Epub_filename)
# root = tree.getroot()

# Fig Remove
# Remove <a> and <figure> tag here
arr_txt11 = [x for x in os.listdir(OutputDir+"\content") if x.endswith(".xhtml")]
for x in arr_txt11:
    # path= r"D:\Anbu\Epub_Validation\New_folder\Temp\content\new7.xhtml"
    path= OutputDir + "\content" + "\\" + x

    full_path = OutputDir + "\content" + "\\" + x

    data = _open_utf8(path)
    # print(data)
    data = re.sub(r'(<a(?: [^>]*)?>\s*)(<span(?: [^>]*)?>(?:(?!</span>).)*</span>)', r'\2\1', data, 0, re.I | re.S)
    data = re.sub(r'(<figure(?: [^>]*)?>(?:(?!<span ).)*)(<span(?: [^>]*)? id="page"[^>]*?>)', r'\2\1', data, 0, re.I | re.S)

    # data = re.sub(r'<aside(?: [^>]*)?>\s*</aside>', r'fgjhfgjhgfdjhgfdjhgf', data, ,re.I | re.S)

    # data = re.sub(r'(<a [^>]*>(?:(?!<span[^>]*).)*)((?:(?!</span>).)*</span>)', r'\2\1', data, 0, re.I | re.S)
    # data = re.sub(r'(<sup[^>]*>(?:(?!</sup>).)*(?:(?!</sup>).)*)', r'', data, 0, re.I | re.S)

    # # ADD Blockquote | Epigraph-Quote-Equation-
    # data = re.sub(r'(<blockquote><p (?: [^>]class="block-quote")*((?:(?!</blockquote>).)*)</blockquote>)', r'<p class="text-fo">Quote.</p>\n \g<1> ', data, 0, re.I | re.S)
    # data = re.sub(r'(<blockquote><p (?: [^>]class="epigraph")*((?:(?!</blockquote>).)*)</blockquote>)', r'<p class="text-fo">Epigraph.</p>\n \g<1> ', data, 0, re.I | re.S)
    # data = re.sub(r'(<blockquote><p (?: [^>]class="block-equation")*((?:(?!</blockquote>).)*)</blockquote>)', r'<p class="text-fo">Equation.</p>\n \g<1> ', data, 0, re.I | re.S)

    # Add Strat of box and end of box in <aside> tag
    # data = re.sub(r'(<aside(?: [^>]*)? class="(?:case-study|tint|objectives|box|example|tip|exercise|lessons|checklist|review|key-points|questions)"[^>]*?>((?:(?!</aside>).)*)</aside>)', r'<p class="text-fo">Start of box.</p>\n \g<1> \n<p class="text-fo">End of box.</p>', data, 0, re.I | re.S)

    # from lxml import etree

    # Change (the below table) to (Table X.X in the accompanying PDF)perform Table,Figure,Fig. ,Figs, figures
    count=0
    list=[]
    list1=[]
    vale = ""
    for findFigtag in re.finditer(r'(the (below ((?:table|figures|fig\.|figs|figure))))((?:(?!<figure(?: [^>]*)?>).)(?:(?!</figure>).)*<span(?: [^>]*)? epub:type="ordinal"[^>]*?>((?:[^>]*))</span>)',data, re.I | re.S):
        # print(findFigtag.group())
        try:
            listdata = (findFigtag.group())
            list = (findFigtag.group(1))
            figname = findFigtag.group(3)
            figname1 = figname.title()
            figvalue = findFigtag.group(5)
            if figvalue != "" or figname != "":
                substr = figname.title() + " " + figvalue + " in the accompanying PDF"
                listdata1 = listdata.replace(list, substr)
                data = data.replace(listdata, listdata1)

        except:
            pass

    for findFigtag in re.finditer(r'(the (((?:table|figures|fig\.|figs|figure)) below))((?:(?!<figure(?: [^>]*)?>).)(?:(?!</figure>).)*<span(?: [^>]*)? epub:type="ordinal"[^>]*?>((?:[^>]*))</span>)',data, re.I | re.S):
        # print(findFigtag.group())
        try:
            listdata = (findFigtag.group())
            list = (findFigtag.group(1))
            figname = findFigtag.group(3)
            figvalue = findFigtag.group(5)
            if figvalue != "" or figname != "":
                substr = figname.title() + " " + figvalue + " in the accompanying PDF"
                listdata1 = listdata.replace(list, substr)
                data = data.replace(listdata, listdata1)

        except:
            pass

    for findFigtag in re.finditer(r'(<figure(?: [^>]*)?>(?:(?!the above figure).)*)the above figure', data,re.I | re.S):
        # print(findFigtag.group())
        try:
            listdata = (findFigtag.group())
            for findFigtag2 in re.finditer(
                    r'(<figure(?: [^>]*)>(?:(?!</figure>).)*<span(?: [^>]*)? epub:type="ordinal"(?: [^>]*)?>((?:[^>]*))</span>)',
                    listdata, re.I | re.S):
                vale = findFigtag2.group()
                # print(findFigtag2.group())

        except:
            pass
    # print(listdata)
    if vale != "":
        for findFigtag in re.finditer(r'(<figure(?: [^>]*)?>(?:(?!the above figure).)*)the above figure', data,re.I | re.S):
            # print(findFigtag.group())
            try:
                listdata = (findFigtag.group())
                finalvalueabove = re.search(r'(<figure(?: [^>]*)>(?:(?!</figure>).)*(<span(?: [^>]*)? epub:type="ordinal"(?: [^>]*)?>((?:[^>]*))</span>))',vale, re.I | re.S)
                updatevalueabove = finalvalueabove.group(3)
                replacetextabove = listdata.replace("the above figure","Figure " + updatevalueabove + " in the accompanying PDF")
                data = data.replace(listdata, replacetextabove)

            except:
                pass

    for findFigtag in re.finditer(r'(<figure(?: [^>]*)?>(?:(?!the figure above).)*)the figure above', data,re.I | re.S):
        # print(findFigtag.group())
        try:
            listdata = (findFigtag.group())
            for findFigtag2 in re.finditer(r'(<figure(?: [^>]*)>(?:(?!</figure>).)*<span(?: [^>]*)? epub:type="ordinal"(?: [^>]*)?>((?:[^>]*))</span>)',listdata, re.I | re.S):
                vale = findFigtag2.group()
                # print(findFigtag2.group())

        except:
            pass
    # print(listdata)
    if vale != "":
        for findFigtag in re.finditer(r'(<figure(?: [^>]*)?>(?:(?!the figure above).)*)the figure above', data,re.I | re.S):
            # print(findFigtag.group())
            try:
                listdata = (findFigtag.group())
                finalvalueabove = re.search(r'(<figure(?: [^>]*)>(?:(?!</figure>).)*(<span(?: [^>]*)? epub:type="ordinal"(?: [^>]*)?>((?:[^>]*))</span>))',vale, re.I | re.S)
                updatevalueabove = finalvalueabove.group(3)
                replacetextabove = listdata.replace("the figure above","Figure " + updatevalueabove + " in the accompanying PDF")
                data = data.replace(listdata, replacetextabove)

            except:
                pass


    # table part


    for findFigtag in re.finditer(r'(<figure(?: [^>]*)?>(?:(?!the above table).)*)the above table', data,re.I | re.S):
        # print(findFigtag.group())
        try:
            listdata = (findFigtag.group())
            for findFigtag2 in re.finditer(r'(<figure(?: [^>]*)>(?:(?!</figure>).)*<span(?: [^>]*)? epub:type="ordinal"(?: [^>]*)?>((?:[^>]*))</span>)',listdata, re.I | re.S):
                vale = findFigtag2.group()
                # print(findFigtag2.group())

        except:
            pass
    # print(listdata)
    if vale != "":
        for findFigtag in re.finditer(r'(<figure(?: [^>]*)?>(?:(?!the above table).)*)the above table', data,re.I | re.S):
            # print(findFigtag.group())
            try:
                listdata = (findFigtag.group())
                finalvalueabove = re.search(r'(<figure(?: [^>]*)>(?:(?!</figure>).)*(<span(?: [^>]*)? epub:type="ordinal"(?: [^>]*)?>((?:[^>]*))</span>))',vale, re.I | re.S)
                updatevalueabove = finalvalueabove.group(3)
                replacetextabove = listdata.replace("the above table","Table " + updatevalueabove + " in the accompanying PDF")
                data = data.replace(listdata, replacetextabove)

            except:
                pass

    for findFigtag in re.finditer(r'(<figure(?: [^>]*)?>(?:(?!the table above).)*)the table above', data,re.I | re.S):
        # print(findFigtag.group())
        try:
            listdata = (findFigtag.group())
            for findFigtag2 in re.finditer(r'(<figure(?: [^>]*)>(?:(?!</figure>).)*<span(?: [^>]*)? epub:type="ordinal"(?: [^>]*)?>((?:[^>]*))</span>)',listdata, re.I | re.S):
                vale = findFigtag2.group()
                # print(findFigtag2.group())

        except:
            pass
    # print(listdata)
    if vale != "":
        for findFigtag in re.finditer(r'(<figure(?: [^>]*)?>(?:(?!the table above).)*)the table above', data,re.I | re.S):
            # print(findFigtag.group())
            try:
                listdata = (findFigtag.group())
                finalvalueabove = re.search(r'(<figure(?: [^>]*)>(?:(?!</figure>).)*(<span(?: [^>]*)? epub:type="ordinal"(?: [^>]*)?>((?:[^>]*))</span>))',vale, re.I | re.S)
                updatevalueabove = finalvalueabove.group(3)
                replacetextabove = listdata.replace("the table above","Table " + updatevalueabove + " in the accompanying PDF")
                data = data.replace(listdata, replacetextabove)

            except:
                pass

    # print(data)
    # exit()

    # Remove <ul> tag to <ol>
    data = re.sub('<ul', r'<ol', data, 0, re.I | re.S)
    data = re.sub('</ul', r'</ol', data, 0, re.I | re.S)



    # Remove all figure tag
    data = re.sub(r'<figure(?: [^>]*)? ((?:(?!</figure>).)*)</figure>', r"", data, 0, re.I | re.S)
    data = re.sub(r'<aside(?: [^>]*)?>\s*</aside>', r'', data, 0,re.I | re.S)
    data = re.sub(r'(<aside(?: [^>]*)? class="(?:case-study|tint|objectives|box|example|tip|exercise|lessons|checklist|review|key-points|questions)"[^>]*?>((?:(?!</aside>).)*)</aside>)',r'<p class="text-fo">Start of box.</p>\n \g<1> \n<p class="text-fo">End of box.</p>', data, 0, re.I | re.S)

    # Remove table
    data = re.sub(r'<table(?: [^>]*)? ((?:(?!</table>).)*)</table>', r"", data, 0, re.I | re.S)

    # Change (Figure X.X)  to (see Figure X.X in the accompanying PDF)
    data = re.sub(r"\(Figure (?:(\d+\.\d+|\d+))\)",r"(see Figure \g<1> in the accompanying PDF)", data,0,re.I|re.S)
    data = re.sub(r"Figure (?:(\d+\.\d+|\d+))",r"Figure \g<1> in the accompanying PDF", data,0,re.I|re.S)
    data = re.sub(r"Figures ((?:(\d+\.\d+|\d+)) and (?:(\d+\.\d+|\d+)))",r"Figures \g<1> in the accompanying PDF", data,0,re.I|re.S)
    data = re.sub(r"Figure ((?:(\d+\.\d+|\d+)) and (?:(\d+\.\d+|\d+)))",r"Figure \g<1> in the accompanying PDF", data,0,re.I|re.S)

    # Change (table X.X)  to (see table X.X in the accompanying PDF)
    data = re.sub(r"\(Table (?:(\d+\.\d+|\d+))\)",r"(see Table \g<1> in the accompanying PDF)", data,0,re.I|re.S)
    data = re.sub(r"Table (?:(\d+\.\d+|\d+))",r"Table \g<1> in the accompanying PDF", data,0,re.I|re.S)
    data = re.sub(r"Tables ((?:(\d+\.\d+|\d+)) and (?:(\d+\.\d+|\d+)))",r"Tables \g<1> in the accompanying PDF", data,0,re.I|re.S)
    data = re.sub(r"Table ((?:(\d+\.\d+|\d+)) and (?:(\d+\.\d+|\d+)))",r"Table \g<1> in the accompanying PDF", data,0,re.I|re.S)

    # ADD Blockquote | Epigraph-Quote-Equation-
    data = re.sub(r'(<blockquote>(?:(?!</blockquote>).)*<p(?: [^>]*)? class="block-quote"[^>]*?>((?:(?!</blockquote>).)*)</blockquote>)',r'<p class="text-fo">Quote.</p>\n \g<1> ', data, 0, re.I | re.S)
    data = re.sub(r'(<blockquote>(?:(?!</blockquote>).)*<p(?: [^>]*)? class="epigraph"[^>]*?>(?:(?!</blockquote>).)*</blockquote>)',r'<p class="text-fo">Epigraph.</p>\n \g<1> ', data, 0, re.I | re.S)
    data = re.sub(r'(<blockquote>(?:(?!</blockquote>).)*<p(?: [^>]*)? class="block-equation"[^>]*?>(?:(?!</blockquote>).)*</blockquote>)',r'<p class="text-fo">Equation.</p>\n \g<1> ', data, 0, re.I | re.S)
    # print(data)

    # data = re.sub('(\(Figure (.*)\))', r'see Figure X.X in the accompanying PDF', data, 0, re.I | re.S)
    # regex = re.finditer(r"\(Figure (?:(\d+\.\d+|\d+))\)", re.IGNORECASE)
    # for line in data:
    #     val=regex.group(1)
    #     data = regex.sub("see Figure "+val+" in the accompanying PDF", data)
        # do something with the updated line
    # Remove <class="list-bullet"> to <class="numbered-bullet">


        # findtxt="(Figure "+val+")"
        # val2="see Figure " + val + " in the accompanying PDF"
        # data = data.replace(findtxt, val2)

    # Change (class="list-bullet") to (class="list-number")
    data = re.sub('class=\"list-bullet\"', 'class=\"list-number\"', data, 0, re.I | re.S)


    # Remove double entry accompanying PDF
    data = re.sub('in the accompanying PDF in the accompanying PDF', 'in the accompanying PDF', data, 0, re.I | re.S)



    # data = re.sub('</ul>', r'<ol', data, 0, re.I | re.S)

    # for findFigtag in re.finditer(r'<ul(?: [^>]*)?>(?:(?!</ul>).)*</ul>',data,re.I|re.S):
    #     # print(findFigtag.group())
    #     list1=(findFigtag.group())
    #     data = re.sub('<ul(?: [^>]*)?>', r'\1', data, 0, re.I | re.S)
    #     # substr1=_element_leveling(list1, "ul",1)
    #     print(substr1)
    #     data = data.replace(list1, substr1)


    # print(len(findFigtag))
    # print(len(list1))
    # print(data)
    # tree = fromstring(list[0])
    # print(tree.xpath("//span[@class='ordinal']/text()"))
    # print(tree.xpath("//a/text()"))

    with open(path, "w", encoding="utf-8") as f1:
        f1.write(data)
        f1.close()

    # Change Header Title Numbers to Words
    # path= r"D:\Anbu\Epub_Validation\AudioOptimser\Sample\3 BOOKS TO TEST\CAREER FEAR_01_ARIAN_9781789664621\EBOOKS\CAREER FEAR_01_ARIAN_9781789664638\02 EPUB\9781789664638_EPUB\content\06_chapter01.xhtml"
    data = _open_utf8(path)

    heroRegex = re.search(r"<section(?: [^>]*)? epub:type=\"([^\"]+)\"(?: [^>]*)?>\s*(?:<header>)?\s*<p(?: [^>]*)>((?:(?!</p>).)*)</p>",data, flags=re.IGNORECASE)
    # mo1 = heroRegex.search(data)
    try:
        outputval1=(heroRegex.group(1))
        outdata2=(heroRegex.group(2))

        # print(outdata1)
        # print(outdata2)
        if re.search(r'<span(?: [^>]*)?[^>]*?>((?:(?!</span>).)*)</span>', outdata2,re.I|re.S):
            heroRegex1=re.search(r'<span(?: [^>]*)? class="ordinal"[^>]*?>((?:(?!</span>).)*)</span>', outdata2,re.I|re.S)
            outputval2=(heroRegex1.group(1))
        valtwo = 0
        checknumber=["One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight","Nine", "Ten", "Eleven", "Twelve", "thirteen", "Fourteen", "Fifteen",  "Sixteen", "Seventeen",  "Eighteen","Nineteen", "Twenty"]
        for xx in checknumber:
            if xx == outputval2:
                valtwo=1
                # rplcetxt = ">" + "Chapter " + outputval2.title() + "<"
                # searchtxt = ">" + outputval2 + "<"
                # data = data.replace(searchtxt, rplcetxt)
                #
                # with open(path, "w", encoding="utf-8") as f1:
                #     f1.write(data)
                #     f1.close()
                # print(outputval2)
                # nothingtouch=outputval2.title()
                # print(nothingtouch)
                # with open(path, "w", encoding="utf-8") as f1:
                #     f1.write(data)
                #     f1.close()
                # # print("ok")



        # exit()
        # <section(?: [^>]*)?>\s*(<header>)?\s*<p(?: [^>]*)?>(?:(?!</p>).)*</p>



        # Most common usage.
        # print(num2words(26))

        # # Other variants, according to the type of article.
        # print(num2words(36, to = 'ordinal'))
        # print(num2words(36, to = 'ordinal_num'))
        # print(num2words(36, to = 'year'))
        # print(num2words(36, to = 'currency'))
        #
        # # Language Support.
        # print(num2words(36, lang ='es'))

        if valtwo!=1:
            conv_map={"I": "One", "II": "Two", "III": "Three", "IV": "Four", "V": "Five", "VI": "Six", "VII": "Seven", "VIII": "Eight", "IX": "Nine", "X": "Ten","XI": "Eleven", "XII": "Twelve", "XIII": "thirteen", "XIV": "Fourteen", "XV": "Fifteen", "XVI": "Sixteen", "XVII": "Seventeen", "XVIII": "Eighteen", "XIX": "Nineteen", "XX": "Twenty"}

            def replace_roman_numerals(inputStr, map_=conv_map):
                w = inputStr.split()
                outstr2=""
                outstr1=""
                count=0
                if len(w)<=2:
                    for x in range(len(w)):
                        w[x]=map_.get(w[x], w[x])

                        if w[x].isnumeric():
                            # w[-1].isnumeric()
                            valueint=w[x].lstrip('0')
                            outstr2=(num2words(valueint))
                            # print("True")
                            # return (outstr2)

                        else:
                            if count<=1:
                                outstr2=(w[x])
                                count=count+1
                            # elif count==1:
                            #     outstr2=(w[x])
                            # return (w[-1])
                    outstr=outstr2
                else:

                    valueint = w[0].lstrip('0')

                    outst0 = (num2words(valueint))
                    outstr =outst0

                    # return outstr
                return outstr


            s = outputval2
            s = replace_roman_numerals(s)
            outtextfinal=s.title()
            matchtext=outputval2.split(" ")

            # if len(matchtext)==2:
            if matchtext[0].title()=="Chapter" or matchtext[0].title()=="Part":
                rplcetxt=">"+matchtext[0].title()+" "+s.title()+"<"
                searchtxt=">"+outputval2+"<"
                data=data.replace(searchtxt,rplcetxt)
            else:
                datafid=re.search(r'<span(?: [^>]*)? epub:type="label"[^>]*?>((?:(?!</span>).)*)</span>',data, flags=re.IGNORECASE)
                try:
                    datafid1=datafid.group(1)
                    if datafid1=="Part":
                        rplcetxt = ">" + s.title() + "<"
                        searchtxt = ">" + outputval2 + "<"
                        data = data.replace(searchtxt, rplcetxt)
                except:

                    rplcetxt = ">"+"Chapter "+ s.title() + "<"
                    searchtxt = ">" +outputval2+ "<"
                    data = data.replace(searchtxt, rplcetxt)

            with open(path, "w", encoding="utf-8") as f1:
                f1.write(data)
                f1.close()

    except:
        pass

        # Need to add try catch in decimal valu for initial 0 or only 0 happens in (s)


    # Remove all anchor tag <a> and Except http://
    # for x in arr_txt:
        # print(x)
    if (x.endswith(".xhtml")):
        # print(x)
        full_path = OutputDir + "\content" + "\\" + x

        data = _open_utf8(OutputDir + "\content" + "\\" + x)
        # print(data)
        data = re.sub('\n\s+', r'\n', data, 0, re.I | re.S)
        data = re.sub('\s+\n', r'\n', data, 0, re.I | re.S)
        data = re.sub('<sup(?: [^>]*)?>((?:(?!</sup>).)*)</sup>', r'', data, 0, re.I | re.S)

        if re.search(r"<a(?: [^>]*)?>((?:(?!</a>).)*)</a>", data, re.I | re.S):
            valu1 = re.search(r"<a(?: [^>]*)?>((?:(?!</a>).)*)</a>", data, re.I | re.S)
            if (re.search(r'<a(?: [^>]*)? href="http[^"]*"[^>]*?>((?:(?!</a>).)*)</a>', valu1.group(), re.I | re.S)):
                continue
            else:
                # update = valu1.group()
                # data = data.replace(update, "")
                data = re.sub(r'<a(?: [^>]*)?>((?:(?!</a>).)*)</a>', r'\1', data, 0, re.I | re.S)
                data = re.sub(r'<a(?: [^>]*)?><sup>\d+</sup>*((?:(?!</a>).)*)</a>', r'', data, 0, re.I | re.S)
                data = re.sub(r'<sup><a(?: [^>]*)?>\d+</a>*((?:(?!</sup>).)*)</sup>', r'', data, 0, re.I | re.S)
                # _save_utf8(OutputDir + "\content" + "\\" + x, data)
                with open(full_path, "w", encoding="utf-8") as f1:
                    f1.write(data)
                    f1.close()


# Content.opf file operation here
pathforopf=OutputDir+"\\"+"content.opf"

f1fileread=_open_utf8(pathforopf)
titlename=re.search(r'<dc:title [^>]*>(.*)</dc:title>',f1fileread,re.I|re.S)
authorname=re.search(r'<dc:creator [^>]*>(.*)</dc:creator>',f1fileread,re.I|re.S)
dateyear=re.search(r'<dc:date[^>]*>(.*)</dc:date>',f1fileread,re.I|re.S)
f1fileread=re.sub(r'<reference type="cover"[^>]*>',r'',f1fileread,0,re.I|re.S)
f1fileread=re.sub(r'<meta name="cover"[^>]*>',r'',f1fileread,0,re.I|re.S)
f1fileread=re.sub(r'\n\n+',r'\n',f1fileread,0,re.I|re.S)


# Front Page creation here
path1=outpath+'\\'+"00_frontpage.xhtml"

datafinal='''<?xml version="1.0"?>
<html xmlns:epub="http://www.idpf.org/2007/ops" xmlns="http://www.w3.org/1999/xhtml" lang="en-GB" xml:lang="en-GB">
<head>
<title>'''+titlename.group(1)+'''</title>
<meta charset="UTF-8"/>
<link href="../koganpage.css" rel="stylesheet" type="text/css"/>
</head>
<body>
<section id="fm_sec_001" class="frontmatter" epub:type="frontmatter">'''+'<p class="text-fo">'+"Kogan Page presents "+titlename.group(1)+" by "+authorname.group(1)+".</p>\n<p class=\"text-fo\">Digitally narrated using the voice of [KP will update this].</p>\n<p class=\"text-fo\">The publisher has provided the figures and tables for this book in an accompanying PDF. You can refer to this as you listen.</p>\n</section>\n</body>\n</html>"


# Back Page creation here
path12=outpath+'\\'+str(length1)+"_backpage.xhtml"

datafinal1='''<?xml version="1.0"?>
<html xmlns:epub="http://www.idpf.org/2007/ops" xmlns="http://www.w3.org/1999/xhtml" lang="en-GB" xml:lang="en-GB">
<head>
<title>'''+titlename.group(1)+'''</title>
<meta charset="UTF-8"/>
<link href="../koganpage.css" rel="stylesheet" type="text/css"/>
</head>
<body>
<section id="bm_sec_001" class="endmatter" epub:type="endmatter">'''+'<p class="text-fo">'+"This recording of "+titlename.group(1)+" by "+authorname.group(1)+" was presented by Kogan Page.</p>\n<p class=\"text-fo\">Sound recording copyright "+str(yearcrnt)+" and produced by Google "+str(yearcrnt)+"</p>\n</section>\n</body>\n</html>"
with open(path1, "w", encoding="utf-8") as f1:
    f1.write(datafinal)
    f1.close()
with open(path12, "w", encoding="utf-8") as f1:
    f1.write(datafinal1)
    f1.close()
# for f1fileread in re.finditer(r'<manifest>(?:(?!</manifest>).)*</manifest>',f1fileread, re.I | re.S):
#     print(f1fileread.group(1))

# Conten.opf convertion here
idmatch=[]
manifestdata = re.search(r'<manifest>(?:(?!</manifest>).)*</manifest>', f1fileread, re.I | re.S)

# manifestdata = re.search(r'<item id=([^>]*) href=([^>]*) media-type=([^>]*)>', f1fileread, re.I | re.S)
for manifestdata in re.finditer(r'<item id=([^>]*) href=([^>]*) media-type=([^>]*)>',f1fileread, re.I | re.S):

    # print(manifestdata.group(2))
    # print(manifestdata)
    patternmatch = re.compile(r'halftitle|endorsements|seriespage|dedication|copyright|toc|Contents|notes|loi|lot|loa|lov|about-the-author|acknowledgements|chronology|contributors|abbreviations|frontmatter|chapter-endnotes|chapter-references',flags=re.IGNORECASE)
    mo12 = patternmatch.search(manifestdata.group(2))
    try:
        mo12.group()
        idmatch.append(manifestdata.group(1))
        # f1fileread = re.sub(manifestdata.group(), r"", f1fileread, 0, re.I | re.S)
        f1fileread=f1fileread.replace(manifestdata.group(),"")

    except:
        pass


manifestdata = re.search(r'<manifest>(?:(?!</manifest>).)*</manifest>', f1fileread, re.I | re.S)
count=0
# manifestdata = re.search(r'<item id=([^>]*) href=([^>]*) media-type=([^>]*)>', f1fileread, re.I | re.S)
for manifestdata in re.finditer(r'<item id=([^>]*) href="content([^>]*) media-type=([^>]*)>',f1fileread, re.I | re.S):

    # print(manifestdata.group(2))
    # print(manifestdata)
    if count==0:

        try:

            val22=manifestdata.group()
            finvalue='<item id="frontpage" href="content/00_frontpage.xhtml" media-type="application/xhtml+xml"/>\n'+val22
            # idmatch1.append(manifestdata.group(1))
            # f1fileread = re.sub(manifestdata.group(), r"", f1fileread, 0, re.I | re.S)
            f1fileread=f1fileread.replace(manifestdata.group(),finvalue)
            f1fileread=f1fileread.replace("</manifest>",'<item id="backpage" href="content/'+str(length1)+'_backpage.xhtml" media-type="application/xhtml+xml"/>\n</manifest>')

        except:
            pass

        count = count+1

manifestdata = re.search(r'(<spine[^>]*>)', f1fileread, re.I | re.S)
zenone=manifestdata.group()
f1fileread=f1fileread.replace(zenone,zenone+'\n<itemref idref="frontpage"/>')

manifestdata111 = re.search(r'(</spine>)', f1fileread, re.I | re.S)
zenone1=manifestdata111.group()
f1fileread=f1fileread.replace(zenone1,'<itemref idref="backpage"/>\n'+zenone1)

idmatch1=[]
manifestdata = re.search(r'<manifest>(?:(?!</manifest>).)*</manifest>', f1fileread, re.I | re.S)


# manifestdata = re.search(r'<item id=([^>]*) href=([^>]*) media-type=([^>]*)>', f1fileread, re.I | re.S)
for manifestdata in re.finditer(r'<item id=([^>]*) href="cover([^>]*) media-type=([^>]*)>',f1fileread, re.I | re.S):

    # print(manifestdata.group(2))
    # print(manifestdata)


    try:
        manifestdata.group()
        idmatch1.append(manifestdata.group(1))
        # f1fileread = re.sub(manifestdata.group(), r"", f1fileread, 0, re.I | re.S)
        f1fileread=f1fileread.replace(manifestdata.group(),"")

    except:
        pass

for x in range(len(idmatch1)):
    for spinedata1 in re.finditer(r'<itemref idref=([^>]*)>',f1fileread, re.I | re.S):
        patternmatch1 = re.compile(idmatch1[x],flags=re.IGNORECASE)
        mo1231 = patternmatch1.search(spinedata1.group(1))

        try:
            mo1231.group()
            f1fileread = f1fileread.replace(spinedata1.group(), "")
        except:
            pass




for manifestdata in re.finditer(r'<item[^>]* media-type=([^>]*)>',f1fileread, re.I | re.S):

    # print(manifestdata.group(2))
    # print(manifestdata)
    patternmatch1 = re.compile(r'image',flags=re.IGNORECASE)
    mo12 = patternmatch1.search(manifestdata.group(1))
    try:
        mo12.group()
        # idmatch.append(manifestdata.group(1))
        # f1fileread = re.sub(manifestdata.group(), r"", f1fileread, 0, re.I | re.S)
        f1fileread=f1fileread.replace(manifestdata.group(),"")

    except:
        pass


spinedata = re.search(r'<spine [^>]*>(?:(?!</spine>).)*</spine>', f1fileread, re.I | re.S)
# print(idmatch)

for x in range(len(idmatch)):
    for spinedata in re.finditer(r'<itemref idref=([^>]*)>',f1fileread, re.I | re.S):
        patternmatch1 = re.compile(idmatch[x],flags=re.IGNORECASE)
        mo123 = patternmatch.search(spinedata.group(1))

        try:
            mo123.group()
            f1fileread = f1fileread.replace(spinedata.group(), "")
        except:
            pass

guidedata = re.search(r'<guide>(?:(?!</guide>).)*</guide>', f1fileread, re.I | re.S)

# manifestdata = re.search(r'<item id=([^>]*) href=([^>]*) media-type=([^>]*)>', f1fileread, re.I | re.S)
for guidedata in re.finditer(r'<reference[^>]* href=([^>]*)>',f1fileread, re.I | re.S):

    # print(manifestdata.group(2))
    # print(manifestdata)
    patternmatch = re.compile(r'halftitle|endorsements|seriespage|dedication|copyright|toc|Contents|notes|loi|lot|loa|lov|about-the-author|acknowledgements|chronology|contributors|abbreviations|frontmatter|chapter-endnotes|chapter-references|endnotes|references|appendix|glossary|answers|endmatter|index',flags=re.IGNORECASE)
    mo12 = patternmatch.search(guidedata.group(1))
    try:
        mo12.group()
        # idmatch.append(manifestdata.group(1))
        # f1fileread = re.sub(manifestdata.group(), r"", f1fileread, 0, re.I | re.S)
        f1fileread=f1fileread.replace(guidedata.group(),"")

    except:
        pass


# Remove cover folder

try:
    removefilespath=OutputDir+"\\"+"cover"
    arr122 = os.listdir(removefilespath)
    for x in range(len(arr122)):
        full_path1 = os.path.join(removefilespath, arr122[x])
        os.remove(full_path1)

    os.rmdir(OutputDir+"\\"+"cover")
except:
    pass

# Remove Images folder

try:
    removefilespath=OutputDir+"\\"+"\content\images"
    arr122 = os.listdir(removefilespath)
    for x in range(len(arr122)):
        full_path1 = os.path.join(removefilespath, arr122[x])
        os.remove(full_path1)

    os.rmdir(removefilespath)
except:
    pass
# Remove all double enter
f1fileread=f1fileread.replace("\n\n","\n")
f1fileread=f1fileread.replace("\n\n\n","\n")
f1fileread=f1fileread.replace("\n\n\n\n","\n")
f1fileread=f1fileread.replace("\n\n\n\n\n","\n")
f1fileread=f1fileread.replace("\t","\n")
f1fileread=f1fileread.replace("\n\n","\n")

with open(pathforopf, "w", encoding="utf-8") as f1:
    f1.write(f1fileread)
    f1.close()

# Nav.xhtml file convertion
pathtonav=OutputDir+"\\"+"nav.xhtml"

f1fileread1=_open_utf8(pathtonav)
# navxhtml = re.search(r'<li [^>]*>(?:(?!</li>).)*</li>', f1fileread1, re.I | re.S)

# manifestdata = re.search(r'<item id=([^>]*) href=([^>]*) media-type=([^>]*)>', f1fileread, re.I | re.S)
for navxhtml in re.finditer(r'<li [^>]*>(?:(?!</li>).)*</li>',f1fileread1, re.I | re.S):

    # print(manifestdata.group(2))
    # print(manifestdata)
    patternmatch1 = re.compile(r'halftitle|endorsements|contents|seriespage|dedication|cover|copyright|notes|loi|lot|loa|lov|about-the-author|acknowledgements|chronology|contributors|abbreviations|frontmatter|chapter-endnotes|chapter-references|endnotes|references|appendix|glossary|answers|endmatter|index',flags=re.IGNORECASE)
    mo12 = patternmatch1.search(navxhtml.group())
    try:
        mo12.group()
        # idmatch.append(manifestdata.group(1))
        # f1fileread = re.sub(manifestdata.group(), r"", f1fileread, 0, re.I | re.S)
        f1fileread1=f1fileread1.replace(navxhtml.group(),"")

    except:
        pass

f1fileread1=f1fileread1.replace("\n\n","\n")
f1fileread1=f1fileread1.replace("\n\n\n","\n")
f1fileread1=f1fileread1.replace("\n\n\n\n","\n")
f1fileread1=f1fileread1.replace("\n\n\n\n\n","\n")
f1fileread1=f1fileread1.replace("\t","\n")
f1fileread1=f1fileread1.replace("\n\n","\n")

# f1fileread1=re.sub(r'(<section(?: [^>]*)?(epub:type="loi")*>(?:(?!</section>).)*</section>)',r'',re.I|re.S)
f1fileread1 = re.sub(r'(<section[^>]* epub:type="loi"[^>]*>(?:(?!</section>).)*</section>)', r'', f1fileread1, 0, re.I | re.S)
f1fileread1 = re.sub(r'(<section[^>]* id="page-list"[^>]*>(?:(?!</section>).)*</section>)', r'', f1fileread1, 0, re.I | re.S)

with open(pathtonav, "w", encoding="utf-8") as f1:
    f1.write(f1fileread1)
    f1.close()

# Nav.ncx file convertion

pathtonavncx = OutputDir+"\\"+"nav.ncx"

f1fileread2=_open_utf8(pathtonavncx)
# navxhtml = re.search(r'<li [^>]*>(?:(?!</li>).)*</li>', f1fileread1, re.I | re.S)

# manifestdata = re.search(r'<item id=([^>]*) href=([^>]*) media-type=([^>]*)>', f1fileread, re.I | re.S)
for navncx in re.finditer(r'<ncx:navPoint [^>]*>(?:(?!</ncx:navPoint>).)*</ncx:navPoint>',f1fileread2, re.I | re.S):

    # print(manifestdata.group(2))
    # print(manifestdata)
    patternmatch2 = re.compile(r'halftitle|endorsements|seriespage|contents|dedication|cover|notes|copyright|loi|lot|loa|lov|about-the-author|acknowledgements|chronology|contributors|abbreviations|frontmatter|chapter-endnotes|chapter-references|endnotes|references|appendix|glossary|answers|endmatter|index',flags=re.IGNORECASE)
    mo12 = patternmatch2.search(navncx.group())
    try:
        mo12.group()
        # idmatch.append(manifestdata.group(1))
        # f1fileread = re.sub(manifestdata.group(), r"", f1fileread, 0, re.I | re.S)
        f1fileread2=f1fileread2.replace(navncx.group(),"")

    except:
        pass

f1fileread2=f1fileread2.replace("\n\n","\n")
f1fileread2=f1fileread2.replace("\n\n\n","\n")
f1fileread2=f1fileread2.replace("\n\n\n\n","\n")
f1fileread2=f1fileread2.replace("\n\n\n\n\n","\n")
f1fileread2=f1fileread2.replace("\t","\n")
f1fileread2=f1fileread2.replace("\n\n","\n")



# for nff,m in enumerate(re.finditer(r'<ncx:navPoint(?: [^>]*)? playOrder="([^"]*)"[^>]*?>',f1fileread2,re.I|re.S),start=1):
nff = itertools.count(1)
f1fileread2=re.sub(r'(<ncx:navPoint(?: [^>]*)? playOrder=")[^>"]*(">)', lambda m: m.group(1)+str(next(nff))+m.group(2),f1fileread2,0,re.I|re.S)
    # print(f1fileread2)

# pageno=0
# for navncx1 in re.finditer(r'<ncx:navPoint(?: [^>]*)? playOrder="([^"]*)"[^>]*?>',f1fileread2, re.I | re.S):
#     print(navncx1.group(1))
#     f1fileread2=re.sub()
#     pageno=pageno+1

with open(pathtonavncx, "w", encoding="utf-8") as f1:
    f1.write(f1fileread2)
    f1.close()


# ------ Local tracking ------------------
_local_tracking(tool_id, ToolVersion, Tra_input, _get_file_size(Tra_input), st_time, _get_timestamp());
# -----------------------------------------

print("\nProcess completed...!!!");




# Ok