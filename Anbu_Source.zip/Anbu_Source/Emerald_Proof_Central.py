# ---------------------------------------------------------------------
#  Tool Name	: Emerald_Proof_Central.py
#  Developer	: Premkumar P
#  Description  : To validate the XML file
#  Client/DU	: Emerald / Journal Others
#  Syntax		: <EXE> <Folder_Path>
# -----------------------------------------------------------------------

# ------------ Rivision History  -------------------------------------------
#  15-04-2022 | v1.0.0.0 | Premkumar P | Initial Development
#  17-08-2022 | v1.0.1.0 | Premkumar P | Single line xml
# --------------------------------------------------------------------------
ToolVersion = "1.0.1.0"

import os
from os.path import basename, dirname
import shutil
import ctypes
import sys
import re
import subprocess
from iModule.Basic import _open_file, _open_utf8, _save_file, _element_leveling, _save_utf8, _make_path
from iModule.ErrorLog import *
from iModule.ToolTracking import *
import xml.etree.ElementTree as ET
from datetime import datetime
import itertools
import hashlib
from PIL import Image

apppath = dirname(sys.argv[0]);
apppath = re.sub(r'\/', r'\\', apppath, 0)

dtimes = datetime.now().strftime('%Y-%m-%d T%H:%M:%S.000')

os.system("cls");
print(f"\n\n\tEmerald_Proof_Central v{ToolVersion} is Running...")
print("\tCopyright @ Integra Software Services Ltd.\n");

# ---------Inline argument checking & File path checking------------#
if (len(sys.argv) != 2 or not os.path.isdir(sys.argv[1])): sys.exit("\n\tSyntax: Emerald_Proof_Central.exe <Folder_Path>\n")

# ------------ Tracking --------------------------------------------
Tra_input = sys.argv[1];
tool_id = 462;  # Emerald_Proof_Central
run_size = 0;
st_time = _get_timestamp();
# ------------------------------------------------------------------

# Global variable declaration
InputDir = sys.argv[1]
FoderBaseName = basename(InputDir)

errfile = dirname(InputDir)+f'\\{FoderBaseName}_err.htm'
if os.path.isfile(errfile): os.remove(errfile)

Readybook = ET.Element("ready-signal")
Readymetadata = ET.SubElement(Readybook, "metadata")
ET.SubElement(Readymetadata, "supplier").text = "INTEGRA"
PackageInfo = ET.SubElement(Readybook, "package-info")

xmlbook = ET.Element("package-details")
ET.SubElement(xmlbook, "timestamp").text = str(dtimes)
metadata = ET.SubElement(xmlbook, "metadata")
ET.SubElement(metadata, "supplier").text = "INTEGRA"
ET.SubElement(metadata, "package-id").text = FoderBaseName
Art_info = ET.SubElement(metadata, "article-info")

# Difference Subroutine:
def Difference(First, Second):
	return (list(set(First) - set(Second)))

#Cleanup tag
def _cleanup(txt):
	txt = re.sub(r'<\?A3B2 (?:(?!\?>).)*\?>','',txt,0,re.I|re.S)
	txt = re.sub(r'<\!--(?:(?!-->).)*-->','',txt,0,re.I|re.S)
	return txt
	
def _Graphic(txt1,txt2,txt3):
	src = f"{InputDir}\\images\\{txt1}"
	ext = txt1.split('.')[-1]
	tmp = f"{FoderBaseName}{str(txt2).zfill(3)}.{ext}"
	dst = f"{txt3}\\{FoderBaseName}{str(txt2).zfill(3)}.{ext}"
	shutil.copy(src,dst)
	return tmp
	
def _validation():
	ErrStr = ""
	AllFiles = os.listdir(InputDir)
	if f'{FoderBaseName}.xml' not in AllFiles:
		ErrStr +=f"[1:1]: Error: [EMD-1001]: '{FoderBaseName}.xml' file is missing in input path.\n"
	if f'{FoderBaseName}.pdf' not in AllFiles:
		ErrStr +=f"[1:1]: Error: [EMD-1002]: '{FoderBaseName}.pdf' file is missing in input path.\n"
	if f'images' not in AllFiles:
		ErrStr +="f[1:1]: Error: [EMD-1003]: 'images' folder is missing in input path.\n"
	if(len(AllFiles) != 3):
		ErrStr +=f"[1:1]: Error: [EMD-1004]: Input directory only allowed folders ('images','{FoderBaseName}.xml' and '{FoderBaseName}.pdf') files. Please check extra files/folders.\n"
	if(ErrStr):
		return ErrStr
	Xml_Cnt = _open_utf8(InputDir+f'\\{FoderBaseName}.xml')
	Images = os.listdir(InputDir+'\\images')
	#image validation
	ImageList = list(map(lambda m: f'{InputDir}\\images\\{m}',Images))
	for imagecheck in ImageList:
		imageSize  = os.path.getsize(imagecheck)
		try:
			img = Image.open(imagecheck)
			img.verify()
		except(IOError, SyntaxError) as e:
			ErrStr +=f"[1:1]: Error: [EMD-1005]: Invalid image file in path '{imagecheck}'.\n"
		if not(imageSize):
			ErrStr +=f"[1:1]: Error: [EMD-1006]: Invalid image file size in path '{imagecheck}'.\n"
	
	Graphic = re.findall(r'<(?:(?:inline-)?graphic)(?: [^>]*)? xlink:href="([^"]+)"(?: [^>]*)?/>',Xml_Cnt,re.I|re.S)
	ExtraFoderGraphic = Difference(Images,Graphic)
	if ExtraFoderGraphic: 
		ErrStr +="[1:1]: Error: [EMD-1007]: Extra files present in 'image' folder '"+', '.join(map(str,ExtraFoderGraphic))+"' but not present in xml file.\n"
	ExtraFileGraphic = Difference(Graphic,Images)
	if ExtraFileGraphic: 
		ErrStr +="[1:1]: Error: [EMD-1008]: Extra images present in xml '"+', '.join(map(str,ExtraFileGraphic))+"' but not present in image folder.\n"
	Frontcnt = re.search(r'<front(?: [^>]*)?>(?:(?!</front>).)*</front>',Xml_Cnt,re.I|re.S)
	if Frontcnt:
		Frontcnt = Frontcnt.group()
		#JID
		JID = re.search(r'<abbrev-journal-title(?: [^>]*)? abbrev-type="publisher"(?: [^>]*)?>((?:(?!</abbrev-journal-title>).)*)</abbrev-journal-title>',Frontcnt,re.I|re.S)
		if(JID):
			ET.SubElement(Art_info, "journal-id").text = JID.group(1)
			#for ready
			ET.SubElement(PackageInfo, "journal-id").text = JID.group(1)
			#ArtID
			ArtID = re.sub(r'^'+str(JID.group(1)+r'-'),'',FoderBaseName,0,re.I)
			ET.SubElement(Art_info, "article-id").text = ArtID
			#for ready
			ET.SubElement(PackageInfo, "article-id").text = ArtID
			ET.SubElement(PackageInfo, "package-id").text = FoderBaseName
			ET.SubElement(PackageInfo, "package-name").text = f"{FoderBaseName}.zip"
		else:
			ErrStr +="[1:1]: Error: [EMD-1009]: Journal id tag is missing in xml. Please check and update.\n"
		#ArtType
		ArtType = re.search(r'<article(?: [^>]*)? article-type="([^"]+)"(?: [^>]*)?>',Xml_Cnt,re.I|re.S)
		if(ArtType):
			ET.SubElement(Art_info, "article-type").text = ArtType.group(1)
		else:
			ErrStr +="[1:1]: Error: [EMD-1010]: Article id tag is missing in xml. Please check and update.\n"
		#ArtTitle
		ArtTitle = re.search(r'<article-title(?: [^>]*)?>((?:(?!</article-title>).)*)</article-title>',Frontcnt,re.I|re.S)
		if(ArtTitle):
			ArtTitle = _cleanup(ArtTitle.group(1))
			ET.SubElement(Art_info, "article-title").text = ArtTitle
		else:
			ErrStr +="[1:1]: Error: [EMD-1011]: Article title tag is missing in xml. Please check and update.\n"
		if ErrStr:
			return ErrStr
		#Author list
		AuthorList = []
		for strname in re.finditer(r'<string-name(?: [^>]*)?>\s*<given-names>((?:(?!</given-names>).)*)</given-names>\s*<surname>((?:(?!</surname>).)*)</surname>\s*</string-name>',Frontcnt,re.I|re.S):
			GiveName = _cleanup(strname.group(1))
			SurName = _cleanup(strname.group(2))
			AuthorList.append(f'{GiveName} {SurName}')
		#Author
		if(re.search(r'<corresp(?: [^>]*)?>((?:(?!</corresp>).)*)</corresp>',Frontcnt,re.I|re.S)):
			Corrs = ET.SubElement(Art_info, "corresponding-authors")
			for cordata in re.finditer(r'<corresp(?: [^>]*)?>((?:(?!</corresp>).)*)</corresp>',Frontcnt,re.I|re.S):
				TmpData = _cleanup(cordata.group(1))
				Contrib = ET.SubElement(Corrs, "contrib")
				for aut in AuthorList:
					if re.search(r'^'+str(aut),TmpData,re.I|re.S):	
						ET.SubElement(Contrib, "name").text = aut
						Email = re.search(r'<ext-link(?: [^>]*)?>((?:(?!</ext-link>).)*)</ext-link>',TmpData,re.I|re.S)
						if Email:
							ET.SubElement(Contrib, "email").text = Email.group(1)
		
		ZipPath = InputDir+f'\\{FoderBaseName}\\{FoderBaseName}\\{ArtID}'
		ZipImagePath = ZipPath+'\\images'
		_make_path(ZipPath)
		_make_path(ZipImagePath)
		shutil.copy(InputDir+f'\\{FoderBaseName}.pdf',ZipPath+f'\\{FoderBaseName}_proof.pdf')
		
		Grapcount = itertools.count(1)
		Xml_Cnt = re.sub(r'(<(?:(?:inline-)?graphic)(?: [^>]*)? xlink:href=")([^"]+)("(?: [^>]*)?/>)',lambda m: f"{m.group(1)}{_Graphic(m.group(2),next(Grapcount),ZipImagePath)}{m.group(3)}",Xml_Cnt,0,re.I|re.S)
		Xml_Cnt = re.sub(r'\n','',Xml_Cnt,0,re.I|re.M)
		_save_utf8(ZipPath+f'\\{FoderBaseName}_proof.xml',Xml_Cnt)
		
		File_info = ET.SubElement(metadata, "file-info")
		File1 = ET.SubElement(File_info, "file",category="main",type="XML")		
		ET.SubElement(File1, "path").text = f"{ArtID}/{FoderBaseName}_proof.xml"
		File2 = ET.SubElement(File_info, "file",category="main",type="PDF")		
		ET.SubElement(File2, "path").text = f"{ArtID}/{FoderBaseName}_proof.pdf"
		for grap in re.finditer(r'<(?:(?:inline-)?graphic)(?: [^>]*)? xlink:href="([^"]+)"(?: [^>]*)?/>',Xml_Cnt,re.I|re.S):
			File3 = ET.SubElement(File_info, "file",category="assets",type="IMAGE")		
			ET.SubElement(File3, "path").text = f"{ArtID}/graphic/{grap.group(1)}"
		
		xmldata = ET.ElementTree(xmlbook)
		ET.indent(xmldata, level=0)
		xmldata.write(InputDir+f'\\{FoderBaseName}\\{FoderBaseName}\\package.xml', encoding="utf-8", xml_declaration=True)
		shutil.make_archive(InputDir.rsplit('\\', 1)[0]+f'\\{FoderBaseName}', "zip", InputDir+f'\\{FoderBaseName}')
		shutil.rmtree(InputDir+f'\\{FoderBaseName}\\{FoderBaseName}')
		
		with open(dirname(InputDir)+f'\\{FoderBaseName}.zip', "rb") as f:
			data = f.read()
			readable_hash = hashlib.md5(data).hexdigest()
			ET.SubElement(PackageInfo, "md5").text = readable_hash
		#ready xml
		Readydata = ET.ElementTree(Readybook)
		ET.indent(Readydata, level=0)
		Readydata.write(dirname(InputDir)+f'\\{FoderBaseName}.ready.xml', encoding="utf-8", xml_declaration=True)
	
	return ErrStr


# ------ Local tracking ------------------
_local_tracking(tool_id, ToolVersion, Tra_input, _get_file_size(Tra_input), st_time, _get_timestamp());
# -----------------------------------------

ErrCnt = _validation()
if ErrCnt:
	CreateErrorLog(InputDir, f"Emerald_Proof_Central v{ToolVersion}", ErrCnt, 0)
	sys.exit("\n\t\t Please clear error...!!!\n")	

sys.exit("\n\t\t Process completed...!!!\n")
