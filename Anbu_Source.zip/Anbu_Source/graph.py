from flask import Flask, render_template, jsonify

app = Flask(__name__)

@app.route('/')
def index():
    graph_data = {
        'labels': ['Positive', 'Neutral', 'Negative', 'Critical'],
        'data': [15, 8, 5, 21],
        'colors': ['#00FF00', '#FFFF00', '#FFA07A', '#FF0000']
    }
    return render_template('graph.html', graph_data=graph_data)
if __name__ == '__main__':
    app.run(debug=True)
