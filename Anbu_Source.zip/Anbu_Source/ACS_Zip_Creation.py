###################################################################
# 																  #
#  Project Name : ACS_Zip_Creation.py  	    					  #
#  Version      : 1.0.0.0                                         #
#  Developed    : ANBU .G |                                       #
#  Purpose		:  Zip creation for ACS             			  #
#  Syntax 		:  <EXE> <Folder Path>                     		  #
#                                                                 #
###################################################################
import os
import re
import shutil
import sys
from iModule.Basic import _make_path
from os.path import dirname, basename

import zipdir as zipdir

###################################################################
#
# Run  		  : <Exe>
# Note		  : -
# Description : Create Zip file for ACS
###################################################################


###################################################################
# Updation History
#=================================================================
#	18-04-2023 | v1.0.0.0 | ANBU .G	Initial Development
###################################################################

ToolVersion = "1.0.15.0"
# Tool path
ToolPath = dirname(sys.argv[0]);
ToolPath = re.sub(r'\/', r'\\', ToolPath, 0)

os.system("cls")

# Inline argument checking
if (len(sys.argv) != 2 or not os.path.isdir(sys.argv[1])): sys.exit(
    "\n\tSyntax: ACS_Zip_Creation.exe <Folder Path>\n")

print("\n\n\tACS_Zip_Creation v" + str(ToolVersion) + "...\n")

# Input
Input = sys.argv[1]
# print("Input Folder : ", Input)
files= os.listdir(Input)
# print("Files in Input Folder : ", files)
str1=""
for x in files:
    extn= x.split(".")[-1]
    str1=str1+"<graphicFile name=\""+str(x)+"\" extension=\""+str(extn)+"\"/>\n"

updatexml= Input + r"\acs_transaction.xml"


def getdatetime():
    import datetime
    now = datetime.datetime.now()
    return now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "-04:00"

datetimenow= getdatetime()

stringxmlcnt='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<acsTransResponse transCode="150" transDesc="graphics_response" version="1.0" timestamp="'''+str(datetimenow)+'''" requestId="12345" responseCode="100">
<manuscriptInfo>
<mscNo>'''+str(os.path.basename(Input))+'''</mscNo>
</manuscriptInfo>
<attributeList>
<notesFromVendor></notesFromVendor>
</attributeList>
<fileList>
<graphicFiles>
'''+str1+'''
</graphicFiles>
</fileList>
</acsTransResponse>'''

with open(updatexml, "w") as f:
    f.write(stringxmlcnt)

datetimestring=str(datetimenow).replace(":","").replace("-","").replace(".","").replace("T","_")

zipfilename= str(datetimenow).replace(":","").replace("-","").split(".")[0].replace("T","_")

filenameinput=str(os.path.dirname(Input))


zipf = (dirname(Input) +"\\"+zipfilename)


# shutil.make_archive(zipf, 'zip', Input)
# # shutil.rmtree(dirname(Input))
_make_path(dirname(Input)+"\\tmp\\"+str(os.path.basename(Input)))




source_folder =Input

# Destination folder path
destination_folder = dirname(Input)+"\\tmp\\"+str(os.path.basename(Input))


shutil.copytree(Input, destination_folder,dirs_exist_ok=True)

shutil.make_archive(dirname(Input)+f"\\{basename(Input)}_{zipfilename}", 'zip', dirname(Input)+"\\tmp")

shutil.rmtree(dirname(Input)+"\\tmp")

print("Successfully created the Zip file")