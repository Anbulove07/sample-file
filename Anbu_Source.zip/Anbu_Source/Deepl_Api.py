import deepl

def deeplapi(text,  target_lang):
    auth_key = "c1897ee5-0f1d-d670-04d1-852374f5a6e3"  # Replace with your key
    translator = deepl.Translator(auth_key)
    result = translator.translate_text(text, target_lang=target_lang)
    return result.text

# print(deeplapi("test"))  # "Bonjour, le monde !"