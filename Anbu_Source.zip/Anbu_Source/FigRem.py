# mypath = "D:\Anbu\Epub_Validation\9781789663334_EPUB"

import re
#
#
# import re
# from iPython.Basic import _open_utf8, _element_leveling
#
# path= r"D:\Anbu\Epub_Validation\New_folder\Temp\content\new7.xhtml"
# data = _open_utf8(path)
# # print(data)
# string = "<figure>akj;ldkj kjajldjkf dskja;ljdsf ljkdkjasjdfa lsjdflasjdf ;laksjdf;lkaj </figure> alkj;dsljkfasdjfaslkdf a;lksjdfa;lksjdf;aklsjdfaslkdjf<figure>akj;ldkj kjajldjkf dskja;ljdsf ljkdkjasjdfa lsjdflasjdf ;laksjdf;lkaj </figure> alkj;dsljkfasdjfaslkdf a;lksjdfa;lksjdf;aklsjdfaslkdjf the above figure"
# poo = "the above figure"
# foo = re.match('.*(?=' +(poo) + ')', string).group(0)
#
# # poo = "the above figure"
# # foo = re.match('.*(?=/' + re.escape(poo) + ')', string)
#
# # poo = "the above figure"
# # foo = re.match('(?<=<figure).*(?=/' + re.escape(poo) + ')', data)
#
#
# print(foo)
# exit()
#
#
#
# import os
# if os.path.exists(mypath):
#
#
#     import os, re, os.path, shutil
#
#     for root, dirs, files in os.walk(mypath):
#         for file in files:
#             os.remove(os.path.join(root, file))
#
#     folder_path = 'D:\Anbu\Epub_Validation\9781789663334_EPUB'
#     for file_object in os.listdir(folder_path):
#         file_object_path = os.path.join(folder_path, file_object)
#         if os.path.isfile(file_object_path) or os.path.islink(file_object_path):
#             os.unlink(file_object_path)
#         else:
#             shutil.rmtree(file_object_path)
#
#
# exit()
#
#
#
# #!/usr/bin/python
# import commands
#
# filename = "any filename"
# string_to_search = "What you want to search"
#
# extract  = (commands.getstatusoutput("grep -C 10 '%s' %s"%(string_to_search,filename)))[1]
#
# print(extract)
#
# exit()
#
#
#
#



import re
from iPython.Basic import _open_utf8, _element_leveling

path= r"D:\Anbu\Epub_Validation\New_folder\Temp\content\new7.xhtml"
data = _open_utf8(path)
# print(data)

from lxml.html.soupparser import fromstring
from lxml import etree


count=0
list=[]
list1=[]
# for findFigtag in re.finditer(r'(?:shown|see|the) below (?:table|figures|fig.|figs|tables|figure)(?:(?!<figure(?: [^>]*)?>).)*<figure(?: [^>]*)?>(?:(?!</figure>).)*</figure>',data,re.I|re.S):
# for findFigtag in re.finditer(r'(the (below ((?:table|figures|fig\.|figs|figure))))((?:(?!<figure(?: [^>]*)?>).)(?:(?!</figure>).)*<span(?: [^>]*)? epub:type="ordinal"[^>]*?>((?:[^>]*))</span>)',data,re.I|re.S):
#     # print(findFigtag.group())
#     try:
#         listdata = (findFigtag.group())
#         list=(findFigtag.group(1))
#         figname=findFigtag.group(3)
#         figname1=figname.title()
#         figvalue=findFigtag.group(5)
#         if figvalue!="" or figname!="":
#             substr = figname.title() + " " + figvalue + " in the accompanying PDF"
#             listdata1=listdata.replace(list,substr)
#             data=data.replace(listdata,listdata1)
#
#     except:
#         pass
#
# for findFigtag in re.finditer(r'(the (((?:table|figures|fig\.|figs|figure)) below))((?:(?!<figure(?: [^>]*)?>).)(?:(?!</figure>).)*<span(?: [^>]*)? epub:type="ordinal"[^>]*?>((?:[^>]*))</span>)',data, re.I | re.S):
#     # print(findFigtag.group())
#     try:
#         listdata = (findFigtag.group())
#         list = (findFigtag.group(1))
#         figname = findFigtag.group(3)
#         figvalue = findFigtag.group(5)
#         if figvalue != "" or figname != "":
#             substr = figname.title() + " " + figvalue + " in the accompanying PDF"
#             listdata1 = listdata.replace(list, substr)
#             data = data.replace(listdata, listdata1)
#
#     except:
#         pass
for findFigtag in re.finditer(r'(<figure(?: [^>]*)?>(?:(?!the above figure).)*)the above figure',data, re.I | re.S):
    # print(findFigtag.group())
    try:
        listdata = (findFigtag.group())
        for findFigtag2 in re.finditer(r'(<figure(?: [^>]*)>(?:(?!</figure>).)*<span(?: [^>]*)? epub:type="ordinal"(?: [^>]*)?>((?:[^>]*))</span>)',listdata,re.I|re.S):
            vale=findFigtag2.group()
            # print(findFigtag2.group())

    except:
        pass
# print(listdata)
if vale!="":
    for findFigtag in re.finditer(r'(<figure(?: [^>]*)?>(?:(?!the above figure).)*)the above figure', data, re.I | re.S):
        # print(findFigtag.group())
        try:
            listdata = (findFigtag.group())
            finalvalueabove = re.search(r'(<figure(?: [^>]*)>(?:(?!</figure>).)*(<span(?: [^>]*)? epub:type="ordinal"(?: [^>]*)?>((?:[^>]*))</span>))',vale, re.I | re.S)
            updatevalueabove=finalvalueabove.group(3)
            replacetextabove=listdata.replace("the above figure","Figure "+updatevalueabove+" in the accompanying PDF")
            data=data.replace(listdata,replacetextabove)

        except:
            pass

for findFigtag in re.finditer(r'(<figure(?: [^>]*)?>(?:(?!the figure above).)*)the figure above',data, re.I | re.S):
    # print(findFigtag.group())
    try:
        listdata = (findFigtag.group())
        for findFigtag2 in re.finditer(r'(<figure(?: [^>]*)>(?:(?!</figure>).)*<span(?: [^>]*)? epub:type="ordinal"(?: [^>]*)?>((?:[^>]*))</span>)',listdata,re.I|re.S):
            vale=findFigtag2.group()
            # print(findFigtag2.group())

    except:
        pass
# print(listdata)
if vale!="":
    for findFigtag in re.finditer(r'(<figure(?: [^>]*)?>(?:(?!the figure above).)*)the figure above', data, re.I | re.S):
        # print(findFigtag.group())
        try:
            listdata = (findFigtag.group())
            finalvalueabove = re.search(r'(<figure(?: [^>]*)>(?:(?!</figure>).)*(<span(?: [^>]*)? epub:type="ordinal"(?: [^>]*)?>((?:[^>]*))</span>))',vale, re.I | re.S)
            updatevalueabove=finalvalueabove.group(3)
            replacetextabove=listdata.replace("the figure above","Figure "+updatevalueabove+" in the accompanying PDF")
            data=data.replace(listdata,replacetextabove)

        except:
            pass


# print(vale)
# exit()
    # # print(list)
    # # exit()
    # # for x in range(len(list)):
    # valtabelow=re.search((r'(?:shown|see|the) below'),list, re.I|re.S)
    # matchvalu=(valtabelow.group())
    # matchvalu0=matchvalu.replace(" below","")
    # valtabelow1 = re.search(r'below (table|figures|fig.|figs|tables|figure)', list, re.I | re.S)
    # matchvalu1 =(valtabelow1.group())
    # matchvalu11 = matchvalu1.replace("below ", "")
    # tree = fromstring(list)
    # tabno=(tree.xpath("//span[@class='ordinal']/text()")[0])
    # tabname=(tree.xpath("//a/text()")[0])
    # substr=matchvalu0+" "+matchvalu11+" "+tabno+" in the accompanying PDF"
    # data=data.replace(list,substr)
#
# for findFigtag in re.finditer(r'(?:shown|see|the) above (?:table|figures|fig.|figs|tables|figure)(?:(?!<figure(?: [^>]*)?>).)*<figure(?: [^>]*)?>(?:(?!</figure>).)*</figure>',data,re.I|re.S):
#     # print(findFigtag.group())
#     list=(findFigtag.group())
#     # print(list)
#     # exit()
#     # for x in range(len(list)):
#     valtabelow=re.search((r'(?:shown|see|the) above'),list, re.I|re.S)
#     matchvalu=(valtabelow.group())
#     matchvalu0=matchvalu.replace(" above","")
#     valtabelow1 = re.search(r'above (table|figures|fig.|figs|tables|figure)', list, re.I | re.S)
#     matchvalu1 =(valtabelow1.group())
#     matchvalu11 = matchvalu1.replace("above ", "")
#     tree = fromstring(list)
#     tabno=(tree.xpath("//span[@class='ordinal']/text()")[0])
#     tabname=(tree.xpath("//a/text()")[0])
#     substr=matchvalu0+" "+matchvalu11+" "+tabno+" in the accompanying PDF"
#     data=data.replace(list,substr)
#
#
# # print(data)
# # exit()
# # Remove <ul> tag to <ol>
# data = re.sub('<ul', r'<ol', data, 0, re.I | re.S)
# data = re.sub('</ul', r'</ol', data, 0, re.I | re.S)
#
#
# # Change (Figure X.X)  to (see Figure X.X in the accompanying PDF)
# data = re.sub(r"\(Figure (?:(\d+\.\d+|\d+))\)",r"see Figure \g<1> in the accompanying PDF", data,0,re.I|re.S)
#
# # data = re.sub('(\(Figure (.*)\))', r'see Figure X.X in the accompanying PDF', data, 0, re.I | re.S)
# # regex = re.finditer(r"\(Figure (?:(\d+\.\d+|\d+))\)", re.IGNORECASE)
# # for line in data:
# #     val=regex.group(1)
# #     data = regex.sub("see Figure "+val+" in the accompanying PDF", data)
#     # do something with the updated line
# # Remove <class="list-bullet"> to <class="numbered-bullet">
#
#
#     # findtxt="(Figure "+val+")"
#     # val2="see Figure " + val + " in the accompanying PDF"
#     # data = data.replace(findtxt, val2)
#
# data = re.sub('class=\"list-bullet\"', 'class=\"list-number\"', data, 0, re.I | re.S)
#
#
#
# # data = re.sub('</ul>', r'<ol', data, 0, re.I | re.S)
#
# # for findFigtag in re.finditer(r'<ul(?: [^>]*)?>(?:(?!</ul>).)*</ul>',data,re.I|re.S):
# #     # print(findFigtag.group())
# #     list1=(findFigtag.group())
# #     data = re.sub('<ul(?: [^>]*)?>', r'\1', data, 0, re.I | re.S)
# #     # substr1=_element_leveling(list1, "ul",1)
# #     print(substr1)
# #     data = data.replace(list1, substr1)
#
#
# # print(len(findFigtag))
# # print(len(list1))
# # print(data)
# # tree = fromstring(list[0])
# # print(tree.xpath("//span[@class='ordinal']/text()"))
# # print(tree.xpath("//a/text()"))

with open(path, "w", encoding="utf-8") as f1:
    f1.write(data)
    f1.close()





# Need to add
#  see below - ok
# see above - ok
# see table below -pending
# see above table - ok
# see above figure - ok
# (Figure X.X) - (see Figure X.X in the accompanying PDF) - ok
# Need to add <class="list-bullet"> -  ok
