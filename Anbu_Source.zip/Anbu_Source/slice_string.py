a = " I am Ayyanarbosan From Madurai!.. "


print(a[2:20])

print(a[:20])

print(a[3:])
