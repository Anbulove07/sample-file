# ---------------------------------------------------------------------
# Tool Name	: IOPP.py
#  Developer	: Anbu G
#  Description  : To validate input ZIP file
#  Client/DU	: IOPP
#  Syntax		: <EXE> <ZIP_File>
# -----------------------------------------------------------------------



# -------------------------Revision History------------------------------

# 03-08-2023 | V1.0.0.0 | Anbu G | Req by Pradeep

# -----------------------------------------------------------------------


from os.path import dirname
import sys
import docx as d
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx2pdf import convert
from docx.shared import Inches
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from PIL import Image
from io import BytesIO
import docx
from os.path import basename
import glob
# import cv2
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
import shutil
import zipfile
import re,os
from docx import Document
import requests
import win32com.client

from MetaScript.Find_mainDoc import folder_testing

os.system("cls")
ToolVersion = "1.0.0.0";
ToolPath = dirname(sys.argv[0]);
ToolPath = re.sub(r'\/', r'\\', ToolPath, 0)
# Inline argument checking
if (len(sys.argv) != 2 or not os.path.isfile(sys.argv[1])): sys.exit(
    "\n\tSyntax: IOPP.exe <Zip file path>\n")

print("\n\n\tIOPP v" + ToolVersion + " is Running...");
print("\tCopyright @ Integra Software Services Ltd.\n");

zip_file_path = (sys.argv[1])
unzip_file_path1 = (zip_file_path).split('.')[0]

# if os.path.isdir(unzip_file_path1):
# shutil.rmtree(unzip_file_path1)
# print("Folder deleted",unzip_file_path1)
# exit()

unzip_file_path2=re.sub(r'^[0-9A-Z]+','',(os.path.basename(unzip_file_path1)),0,)
unzip_file_path = os.path.dirname(unzip_file_path1) + "\\" + unzip_file_path2

# print(zip_file_path)
Errlog_path = os.path.dirname(unzip_file_path)+ "\\_Errlog.txt"
Err=[]
key=['ADD','ANL','ART','BEN','BKR','BRI','CAI','CMT','CNF','COM','COP','COR','COS','CRP','CTY','DAP','DIS','EDT','END','ERT','EXC','FIA','FIR','FRT','FTC','GSC','IED','INP','INR','INV','IRP','ISM','IST','KEY','LET','LTE','MEM','MET','MJR','MTR','NAI','NAR','NAV','NOT','OBT','OPN','OTH','OUT','PAN','PAP','PRF','PRM','PSP','RAP','RDM','REP','RET','REV','RPL','RVP','SCM','SPE','SPR','SRM','SRP','STP','SYM','TEC','TIA','TNR','TOP','TUT','VPT','SCM','SPE','SPR','SRP','SRV','STA','STF','STP','STR','SYM','TEC','TIA','TNR','TOP','TUT','VPT']


def convert_doc_to_docx(doc_file_path, docx_file_path):
    # Create a new instance of Word
    word = win32com.client.Dispatch("Word.Application")

    # Open the DOC file
    doc = word.Documents.Open(doc_file_path)

    # Save as DOCX
    doc.SaveAs(docx_file_path, 12)  # 12 is the value for DOCX format

    # Close the documents and Word application
    doc.Close()
    word.Quit()
def api_for_iCompare(pdf1, pdf2,log_path):
    # Define the API endpoint URL

    # Define the API endpoint URL
    url = "http://172.16.200.157/api/comparison/compare"

    # Define the JSON data to be sent in the POST request
    data = {
        "file1": {
            "url": pdf1,
        },
        "file2": {
            "url": pdf2,
        },
        "name": "My Comparison",
        "result": "pdf"
    }

    # Define your Basic Auth credentials
    username = "iCompare"
    password = "iCompare"

    # Send the POST request with JSON data and Basic Authentication headers
    response = requests.post(url, json=data, auth=(username, password))

    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        # Parse the JSON response
    #     response_data = response.json()
    #
    #     # Print the response
    #     print("Response: Error found in the document")
    #     # print(json.dumps(response_data, indent=4))
    # else:
    #     print(f"Error: {response.status_code} - {response.text}")

        response_data = response.content  # Get the response content (PDF bytes)

        # Save the response PDF to a file
        with open(log_path, 'wb') as output_file:
            output_file.write(response_data)
            return "False"
    else:
        print(f"Error: {response.status_code} - {response.text}")

    return "True"

    # Load your JSON data
    # data = response_data
    # if len(data['differences']) == 0:
    #     return "True"
    #
    # wb = openpyxl.Workbook()
    # ws = wb.active
    #
    # # Write header row
    # header = ["Document", "CompareDocument", "PageNumber", "ModificationType", "MediaType", "Message"]
    # ws.append(header)
    # # Write data rows
    # for diff in data['differences']:
    #     row = [data['document'], data['compareDocument'], diff['pageNumber'], diff['modificationType'],
    #            diff['mediaType'], diff['message']]
    #     ws.append(row)
    #
    # # Save the workbook to a file
    # # wb.save("comparison_report.xlsx")
    # wb.save(log_path)
    # return "False"


def upload_files_and_print_response(file1_path, file2_path, upload_url):
    try:
        with open(file1_path, 'rb') as file1, open(file2_path, 'rb') as file2:
            files = {
                'file1': ('file1.pdf', file1),
                'file2': ('file2.pdf', file2)
            }

            response = requests.post(upload_url, files=files)
            if response.status_code == 200:
                response_data = response.json()
                # print("Response:")
                # print(response_data)
                return response_data
            else:
                print(f"Error uploading files: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"Error: {e}")



def count_of_fig(file_name):
    count_of_fig = []
    archive = zipfile.ZipFile(file_name, "r")
    for file in archive.filelist:
        if file.filename.startswith('word/media/'):
            count_of_fig.append(archive.extract(file))
    if os.path.isdir('word'):
        shutil.rmtree('word')
    return len(count_of_fig)

#Count number of tables
def count_of_tables(file_name):
    document = Document(file_name)
    return len(document.tables)

#Count of footnotes
def count_of_footnotes(file_name):
    archive = zipfile.ZipFile(file_name, "r")
    count_of_footnote = []
    for i in archive.namelist():
        if i == 'word/footnotes.xml':
            ms_data = archive.read("word/footnotes.xml")
            archive.close()
            app_xml = ms_data.decode("utf-8")

            regex = r"(<w:footnote\sw:id=\"\d+\">)"
            count_of_footnote = re.findall(regex, app_xml, re.MULTILINE)
        else:
            pass
    return len(count_of_footnote)

def equation_count(file_name):
    archive = zipfile.ZipFile(file_name, "r")
    for i in archive.namelist():
        if i == "word/document.xml":
            ms_data = archive.read("word/document.xml")
            archive.close()
            app_xml = ms_data.decode("utf-8")
            regex_start = r"(<m:oMath|<o:OLEObject Type=\"Embed\" ProgID=\"Equation)"
            matches_start = re.findall(regex_start, app_xml, re.MULTILINE|re.IGNORECASE)

            if len(matches_start):
                return len(matches_start)
            else:
                return 0

def find_duplicate_tables(doc):
    """Finds all duplicate tables in a Word document.
    Args:
      doc: The Word document to search.
    Returns:
      A list of all duplicate tables.
    """
    tables = doc.tables
    table_ids = {}
    for table in tables:
        table_text = ""
        for row in table.rows:
            for cell in row.cells:
                table_text += cell.text

        if table_text not in table_ids:
            table_ids[table_text] = []
        table_ids[table_text].append(table)

    duplicate_tables = []
    for table_text, tables in table_ids.items():
        if len(tables) > 1:
            duplicate_tables.append(tables)
    return duplicate_tables

def find_duplicate_fig(doc,path):
    """Finds all duplicate figures in a Word document."""
    images = []
    for rel in doc.part.rels.values():
        if "image" in rel.reltype:
            image_data = rel.target_part.blob
            images.append(image_data)
    #make directory for image extraction
    if not os.path.exists(f'{path}\\image_extraction'):
        os.makedirs(f'{path}\\image_extraction')
    for i, image_data in enumerate(images):
        with open(f"{path}\\image_extraction\\fig_{i}.jpg", "wb") as f:
            f.write(image_data)
    # Load the pre-trained VGG16 model
    # model = VGG16(weights='imagenet', include_top=False)

    #Feature extraction using VGG16 model
    def extract_features(image):
            pass
        # image = cv2.resize(image, (224, 224))
        # image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        # # image = preprocess_input(image)
        # image = np.expand_dims(image, axis=0)
        # features = model.predict(image)
        # features = features.flatten()
        # return features

    #Calculate image similarities
    def calculate_similarities(feature_vectors):
        similarities = cosine_similarity(feature_vectors)
        return similarities

    #Define similarity threshold
    similarity_threshold = 0.8
    image_files = glob.glob(path+r"\image_extraction\*.jpg")
    feature_vectors = []
    # for image_file in image_files:
    #     image = cv2.imread(image_file)
    #     # Preprocess image if required
    #     feature_vector = extract_features(image)
    #     feature_vectors.append(feature_vector)

    feature_vectors = np.array(feature_vectors)
    similarities = calculate_similarities(feature_vectors)

    duplicate_groups = []
    num_images = len(similarities)
    for i in range(num_images):
        duplicates = [basename(image_files[j]) for j in range(i + 1, num_images) if similarities[i, j] >= similarity_threshold]
        if duplicates:
            duplicates.append(basename(image_files[i]))
            duplicate_groups.append(duplicates)

    return duplicate_groups

def separate_list_by_figtab(input_list, regex_pattern):
    """
    Separate list by regex pattern
    :param input_list:
    :param regex_pattern:
    :return:
    """
    list1 = []
    list2 = []

    for item in input_list:
        if re.match(regex_pattern, item):
            list1.append(item)
        else:
            list2.append(item)

    return list1, list2

def Query(file_name):
    doc = docx.Document(file_name)
    Xrefcitation = []
    citation = []
    cnt = ''
    Err = ''
    #reference list
    for para in doc.paragraphs:
        qwerty = re.sub(r'^(?:Figura |Figure |fig\. ?|fig |illustration |Tables? |Tab\. ?|Tab |Tableau )[a-z]?[0-9]+[a-z]?(?:(?:.?[0-9]+[a-z]?)+)?', r'',para.text, 0, re.I | re.S)
        qwerty = re.sub(r'\[\[/?figure \d+\]\]', r'', qwerty, 0, re.I | re.S)
        Xrefcitation.extend(re.findall(r'\b(?:Figura |Figure |fig\. ?|fig |illustration |Tables? |Tab\. ?|tab |Tableau )[a-z]?[0-9]+[a-z]?(?:(?:.?[0-9]+[a-z]?)+)?',qwerty,re.I|re.M))
        cnt += para.text+'\n'

    dict_Xrefcitation = dict(map(lambda x: (re.sub(r'([a-z]-\d+)?[a-z]$', '', re.sub(r'^(?:Figura|Figure|fig\.|fig|illustration) ?',r'Figure ',
                    re.sub(r'^(?:Tables?|Tab\.|Tab|Tableau) ?',r'Table ',x,0,re.I),0,re.I),0,re.I), x), Xrefcitation))
    Xrefcitation = list(dict_Xrefcitation.keys())
    # print(Xrefcitation)
    for m in re.finditer(r'^(?:Figura |Figure |fig\. ?|fig |illustration |Tables? |Tab\. ?|tab |Tableau )[a-z]?[0-9]+[a-z]?(?:(?:.?[0-9]+[a-z]?)+)?', cnt,re.I | re.M):
        tmp = m.group()
        tmp = re.sub(r'^(?:Figura|Figure|fig\.?|illustration) ?', r'Figure ',re.sub(r'^(?:Tables?|Tab\.?|Tableau) ?', r'Table ', tmp, 0, re.I), 0, re.I)
        citation.append(tmp)

    citation = list(set(citation))
    if citation:
        (Table_citation, Figure_citation) = separate_list_by_figtab(citation, r'^Table')
        Figure_count = count_of_fig(file_name)
        Table_count = count_of_tables(file_name)
        if len(Figure_citation) > Figure_count:
            Err += f'figure missing, please check and update.\n'
        if len(Table_citation) > Table_count:
            Err += f'table missing, please check and update.\n'

    DiffCitation = list(set(Xrefcitation) - set(citation))
    try:
        DiffCitation = [dict_Xrefcitation[x] for x in DiffCitation]
    except:
        pass
    #get reference missing list
    if DiffCitation:
        Err += '"' + ", ".join(map(str, DiffCitation)) + '" caption is missing.\n'
    #Duplicate table finding
    duplicate_tables = find_duplicate_tables(doc)
    if duplicate_tables:
        Err += f'Duplicate Table received, please check to proceed.\n'
    #Duplicate figure finding
    # try:
    #     duplicate_figure = find_duplicate_fig(doc,dirname(file_name))
    #     if duplicate_figure:
    #         Err += f'Duplicate Figure received, please check to proceed.\n'
    # except:
    #     pass
    # print(Err)
    # filename = dirname(dirname(file_name)) + f"\\Query.txt"
    # if Err:
    #     file = open(filename, "w+", encoding='utf-8')
    #     file.write(Err)
    #     file.close
    #     return False
    if Err:
        return Err

    return True

def get_reference_content(doc, reference_heading):
    reference_found = False
    reference_content = []

    for paragraph in doc.paragraphs:
        if reference_found:
            reference_content.append(paragraph.text)
        if paragraph.text.strip() == reference_heading:
            reference_found = True

    return reference_content


def reference_count(document_path, reference_heading):
    # document_path = r"D:\Giventool\karthik\IOPP\IOPP\Input\TRAN_114304\Source\2DMacec58\2DMacec58.docx"  # Replace with the actual path
    # reference_heading = "References"  # Replace with the actual reference heading

    doc = docx.Document(document_path)
    reference_content = get_reference_content(doc, reference_heading)

    if reference_content:
        reference_lines = "\n".join(reference_content).split("\n")
        line_count = len(reference_lines)

        # print("Reference content:")
        # for line in reference_lines:
        #     print(line)

        # print("\nTotal lines in reference content:", line_count)
        if line_count>150:
            return "\nTotal lines in reference content:"+str(line_count)
        else:
            return ""
    else:
        # print("Reference heading not found in the document.")
        return "Reference heading not found in the document."


def resize_image(image_blob, max_width=576, max_height=576):
    img = Image.open(BytesIO(image_blob))
    img.thumbnail((max_width, max_height))
    img_buffer = BytesIO()
    img.save(img_buffer, format="PNG")
    return img_buffer.getvalue()

def save_images_with_alt_text(images,captions, output_path):
    new_doc = Document()
    center_alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    if captions[0]!="False":
        for i, image in enumerate(images):
            alt_text = f"Image {i + 1}"
            image_blob = image.blob
            resized_image_blob = resize_image(image_blob)
            img_width, img_height = Image.open(BytesIO(resized_image_blob)).size
            new_doc.add_paragraph().add_run().add_picture(BytesIO(resized_image_blob), width=Inches(img_width / 96),
                                                          height=Inches(img_height / 96))
            new_doc.paragraphs[-1].alignment = center_alignment
            new_doc.add_paragraph(captions[i]).alignment = center_alignment
        # for i, caption in enumerate(captions):
        #     new_doc.add_paragraph(caption)
        # Add the count of images to the output filename
        count_images = len(images)
        output_path_with_count = output_path.replace('.docx', f'_Figure 1-{count_images}.docx')

        new_doc.save(output_path_with_count)

def extract_images(docx_path):
    doc = Document(docx_path)
    images = []

    # doc = docx.Document(docx_path)
    captions = []

    for paragraph in doc.paragraphs:
        # if paragraph.style.name.startswith('Normal'):
        #     captions.append(paragraph.text)
        if paragraph.text.startswith("Fig.") or paragraph.text.startswith("Figure"):
            captions.append(paragraph.text)

    for rel in doc.part.rels:
        part = doc.part.rels[rel].target_part
        if "image/" in part.content_type:
            images.append(part)


    if len(images) != len(captions):
        print("Number of images and captions do not match.")
        cap=[]
        Err.append("Number of images and captions do not match.")
        cap.append("False")
        return images, cap
    else:
        return images,captions


def word_to_pdf_with_docx2pdf(input_docx_path, output_pdf_path):
    # Ensure absolute file paths are used
    input_docx_path = os.path.abspath(input_docx_path)
    output_pdf_path = os.path.abspath(output_pdf_path)

    try:
        # Convert Word document to PDF using docx2pdf
        convert(input_docx_path, output_pdf_path)
        print(f"Conversion successful. PDF saved to {output_pdf_path}")
    except Exception as e:
        print(f"Error: {e}")


def extract_zip_file(zip_file_path,unzip_file_path):
    # Get the directory path of the zip file
    zip_dir =unzip_file_path
    # Create an output folder path
    output_folder = os.path.join(zip_dir)
    # Create the output folder if it doesn't exist
    os.makedirs(output_folder, exist_ok=True)
    shutil.unpack_archive(zip_file_path, output_folder, 'zip')
    print(f'Zip file extracted to: {output_folder}')

def _get_list_of_files(dir_name):
    listOfFile = os.listdir(dir_name)
    # print(listOfFile)
    return listOfFile

def _line_remove_docx(filepath):
    subDoc = d.Document(filepath)
    # remove line number from the master document
    for section1 in subDoc.sections:
        sectPr1 = section1._sectPr
        # Remove any existing line number properties
        lnNumType = OxmlElement('w:lnNumType')
        # Set the value to None
        lnNumType.set(qn('w:countBy'), '0')
        lnNumType.set(qn('w:restart'), '0')
        # Add the element to the section properties

        sectPr1.append(lnNumType)

    print("line number removed from the document")
    subDoc.save(filepath)

def _xml_part(file_list):
    xml_count = 0
    for file in file_list:
       # if xml_count==0:
        if re.search(r'\.xml$', file, re.I):
            xml_count=xml_count+1
            xml_file=file
            xml_file_path=os.path.join(unzip_file_path,xml_file)
            # print(xml_file_path)
            with open(xml_file_path, 'r', encoding='utf-8') as f:
                cnt=f.read()
                # print(cnt)

            if re.search(r'<files(?: [^>]*)?>(?:(?!</files>).)*</files>',cnt,re.I|re.S):
                files=re.search(r'<files(?: [^>]*)?>(?:(?!</files>).)*</files>',cnt,re.I|re.S).group(0)
                # print(files)
                docxcount=0
                for file in re.finditer(r'<file>((?:(?!</file>).)*)</file>', files, re.I | re.S):
                    xml_contains_file = file.group(1)
                    if re.search(r'.(docx|doc)$', xml_contains_file, re.I):
                        temp=re.search(r'.(docx|doc)$', xml_contains_file, re.I)
                        docxcount=docxcount+1
                        docordocx=temp.group(1)
                        # print(docxcount)
                # if docxcount==1:
                for file in re.finditer(r'<file>((?:(?!</file>).)*)</file>',files,re.I|re.S):
                    # print(file.group(1))
                    xml_contains_file=file.group(1)
                    count=0
                    for filename in file_list:
                        if not filename.lower().endswith('.xml'):
                            if xml_contains_file==filename:
                                # print(xml_contains_file,filename)
                                count=1
                                # filenamelist.append(filename)
                                # print(filenamelist)
                    if count==0:
                        # print("file not present in folder: "+xml_contains_file)
                        Err.append("file not present in folder: "+xml_contains_file)
                        # filenamelist.append(xml_contains_file)
                        # print(filenamelist)
                    if re.search(r'.docx|doc$',xml_contains_file,re.I):
                        docxfilename = (os.path.basename(xml_contains_file))
                        input_path1=os.path.join(unzip_file_path,docxfilename)
                        inputpathchange = input_path1.replace('.doc', '.docx')
                        if docordocx.lower() == 'doc':
                            convert_doc_to_docx(input_path1, inputpathchange)
                            os.remove(input_path1)
                input_path=folder_testing(unzip_file_path)

                docxfilename=(input_path)
                # input_path=os.path.join(unzip_file_path,docxfilename)

                basenamefile=re.sub(r'^[0-9A-Z]+','',(os.path.basename(unzip_file_path)),0,)
                output_path=os.path.join(unzip_file_path,basenamefile+'.docx')


                output_path_pdf=os.path.join(unzip_file_path,basenamefile+'.pdf')
                output_path1=os.path.join(os.path.dirname(unzip_file_path),basenamefile+'.docx')
                try:
                    if docordocx.lower() == 'doc':
                        os.rename(inputpathchange, output_path)
                    else:
                        os.rename(input_path, output_path)
                except:
                    if docordocx.lower() == 'doc':
                        os.remove(output_path)
                        os.rename(inputpathchange, output_path)
                    else:
                        os.remove(output_path)
                        os.rename(input_path, output_path)
                try:
                    images,captions = extract_images(output_path)

                    save_images_with_alt_text(images,captions, output_path1)
                except:
                    pass
                reference1=(reference_count(output_path, "References"))
                if len(reference1)>1:
                    Err.append(reference_count(output_path, "References"))
                _line_remove_docx(output_path)
                word_to_pdf_with_docx2pdf(output_path, output_path_pdf)
                query_finding=Query(output_path)
                try:
                    if len(query_finding)>1:
                        Err.append(query_finding)
                except:
                    pass
                # pdfname=re.sub(r'.(docx|doc)$',r'.pdf',re.escape(docxfilename),0,re.I)
                pdfname = docxfilename.replace('.docx', '.pdf')
                pdfname = pdfname.replace('.doc', '.pdf')
                pdfname = re.sub(r'\\', r'\\\\', pdfname, 0, re.I)
                if not re.search(pdfname,files,re.I):
                    Err.append("pdf file not present in xml")
                else:
                    upload_url = "http://is-srv072:88/IOPP/index.php"
                    file1_path = unzip_file_path+"\\"+pdfname
                    file2_path = output_path_pdf
                    log_path= os.path.join(os.path.dirname(unzip_file_path), "log_report_iCompare.pdf")
                    if os.path.isfile(file1_path) and os.path.isfile(file2_path):
                        pdf1, pdf2 = upload_files_and_print_response(file1_path, file2_path, upload_url)

                        api_response=api_for_iCompare(pdf1, pdf2, log_path)

                        if api_response=="True":
                            print("There is no difference between the files")
                            Err.append("iCompare - There is no difference between the files")
                        else:
                            print("There is difference between the files")
                            Err.append("iCompare - There is difference between the files, Please check the log report")
                # else:
                #     print("More than one docx file present in xml")
                #     Err.append("More than one docx file present in xml")


            if re.search(r'<subj-group(?: [^>]*)?>(?:(?!</subj-group>).)*</subj-group>',cnt,re.I|re.S):
                subgrp=re.search(r'<subj-group(?: [^>]*)?>(?:(?!</subj-group>).)*</subj-group>',cnt,re.I|re.S).group(0)
                if re.search(r'<subject(?: [^>]*)?>(?:(?!</subject>).)*</subject>',subgrp,re.I|re.S):
                    keywordcheck=re.search(r'<subject(?: [^>]*)?>((?:(?!</subject>).)*)</subject>',subgrp,re.I|re.S).group(1)
                    # print(keywordcheck)
                    key_check=0
                    for k in key:
                        if keywordcheck==k:
                            # print(keywordcheck)
                            key_check=1
                            break
                    if keywordcheck=='OTH':
                        Err.append("Wrong subject present in xml")
                    if key_check==0:
                        Err.append("Subject not present in xml")


    if xml_count>1:
        Err.append("More than one xml file present in folder")



extract_zip_file(zip_file_path,unzip_file_path)
file_list=_get_list_of_files(unzip_file_path)
_xml_part(file_list)
# print(Err)
if len(Err)!=0:
    print("\n\n\tPlease Find the Log_Report.txt file in the folder")
    with open(os.path.join((os.path.dirname(unzip_file_path)),'Log_Report.txt'), 'w') as f:
        for item in Err:
            f.write("%s\n" % item)
else:
    print("\n\n\tProcess completed...")

