# ------------------------------------------------------------------
#  Tool Name    : iCoRe_EmeraldJATS.py
#  Developer    : Premkumar P | CTAE XML
#  Description  : To convert iCore to Jats
#  Client/DU    : Emerald / Journal Others
#  Syntax		: <EXE> <XML_File_Path>
# ------------------------------------------------------------------

# ------------ Rivision History  -----------------------------------
#  05-10-2021 | v1.0.0.0 | Premkumar P	| Initial Development
#  19-10-2021 | v1.0.1.0 | Premkumar P	| Updates
#  29-10-2021 | v1.0.2.0 | Premkumar P	| Updates
#  16-11-2021 | v1.0.3.0 | Premkumar P	| Updates
#  24-11-2021 | v1.0.4.0 | Premkumar P	| Updates
#  25-11-2021 | v1.0.5.0 | Premkumar P	| Updates
#  21-12-2021 | v1.0.6.0 | Premkumar P	| Updates
#  27-12-2021 | v1.0.7.0 | Premkumar P	| Updates
#  20-01-2022 | v1.0.8.0 | Premkumar P	| MathML update
#  01-03-2022 | v1.0.9.0 | Premkumar P	| Customer updates
#  19-05-2022 | v1.0.10.0 | Premkumar P	| Customer updates
#  01-06-2022 | v1.0.11.0 | Premkumar P	| Customer updates
#  07-06-2022 | v1.0.12.0 | Shobana		| insert publication-type="book-chapter" for <chapter-title> present | req by stella
#  14-06-2022 | v1.0.13.0 | Shobana		| retain ref tag | req by stella
#  05-08-2022 | v1.0.14.0 | Sudhakar V	| [iProTrack- TaskID:1923]| req by stella
# -------------------------------------------------------------------------------------------------------------

# --------------- Variables for Source information -----------------
#	Jid					 - Journal code of file
#	Artid				 - Article id of file
#	DOI					 - Article doi of file
#	filename			 - Basename of file
#	InPath				 - Input file directory
#	ToolPath			 - Tool directory
#	MetaCnt				 - Journal code based content of meta.xml
#	vol					 - volume value of content
#	isu					 - issue value of content
#	fpage				 - first page value of content
#	cYear				 - current year
#	cMonth				 - current month
# -----------------------------------------------------------------------------------------

# -------------------- Functions ----------------------------------------------------------
#	FrontConversion	 			- front part conversion
#	hex2chr			 			- hexadecimal to special character
#	RemoveQuery		 			- remove query comment
#	RemoveA3B2			 		- remove 3B2 comment
#	RemoveFullFormate 			- check full formate
#	Duplicate			 		- insert duplicate value for ignore the text
#	RemoveTag			 		- Remove specific elements
#	RemoveCnt			 		- Remove content of specific element
#	sectionID			 		- Section id reorder
#	Figure				 		- Figure conversion
#	Table				 		- Table conversion
# -----------------------------------------------------------------------------------------

ToolVersion = "1.0.14.0"

# Module Declaration
import os
from os.path import basename, dirname
import shutil
import ctypes
import sys
import re
import itertools  # for id sequence
from iModule.Basic import _open_file, _open_utf8, _save_utf8, _element_leveling
from datetime import datetime  # get current date
from iModule.ToolTracking import *
from iso3166 import countries
from collections import Counter

# Tool path
ToolPath = dirname(sys.argv[0]);
ToolPath = re.sub(r'\/', r'\\', ToolPath, 0)

os.system("cls")

# Inline argument checking
if (len(sys.argv) != 2 or not os.path.isfile(sys.argv[1]) or not sys.argv[1].endswith('.xml')): sys.exit(
    "\n\tSyntax: iCoRe_EmeraldJATS.exe <XML>\n")

print("\n\n\tiCoRe_EmeraldJATS v" + str(ToolVersion) + "...\n")

# Global variable declaration
Input = sys.argv[1]
filename = basename(Input)
InPath = dirname(Input)

ASCIIEncoding = str(ToolPath) + r'\\ASCIIEncoding.ini'
MetaFile = re.sub(r'(_icore)?.xml$', ' Metadata.xml', Input, re.I)

FileName = re.sub(r'(_icore)?.xml$', '', filename, re.I)

Jid = '';
JnlTitle = '';
Artid = '';
ArtType = '';
DOI = '';
lang = '';
vol = '';
isu = '';
fpage = '';

FigIdCount = itertools.count(1);
TabIdCount = itertools.count(1);
DispIdCount = itertools.count(1);
InlineIdCount = itertools.count(1);
ImageIdCount = itertools.count(1);

# ------------ Tracking --------------------------------------------
Tra_input = sys.argv[1];
tool_id = 422;
run_size = 0;
st_time = _get_timestamp();
# ------------------------------------------------------------------

# read input
# file = open(Input,"r+") or Mbox(r'Error', r'Unable to open"'+Input+r'"');
# content = file.read();
# file.close;
content = _open_utf8(Input);

# supporting file
if not os.path.isfile(MetaFile):
    sys.exit(r'Meta file is missing in input path.')
if not os.path.isfile(ASCIIEncoding):
    sys.exit(r'ASCIIEncoding.ini is missing in tool path.')
# old file check
if not (re.search(r'<metainfo(?: [^>]*)?>(?:(?!</metainfo>).)*</metainfo>', content, re.I | re.S)):
    sys.exit('Old Meta Information found, Please update Meta Information.\n');
# named_entity_mapping txt file check and read:
if not os.path.isfile(f'{ToolPath}\\named_entity_mapping.txt'):
    sys.exit('\'named_entity_mapping.txt\' file is missing in tool path.\n')
Entity = {}
namedEntity = _open_file(f'{ToolPath}\\named_entity_mapping.txt');
for m in re.finditer(r'<!ENTITY ([^ ]+)[^"&]+"(&#x)0(1?[0-9|A-Z|a-f]{4,5});[^\n]+>', namedEntity, re.I | re.S):
    Entity[m.group(1)] = m.group(2) + m.group(3);

# current date
today = datetime.today();
cMonth = datetime.today().strftime("%m");
cYear = datetime.today().strftime("%Y");
cDay = datetime.today().strftime("%d")

# month
Month = '(?:January|February|March|April|May|June|July|August|September|October|November|December|Septembre|Octobre|Novembre|Decembre|Jan\.?|Feb\.?|Mar\.?|Apr\.?|Jun\.?|Jul\.?|Aug\.?|Sept?\.?|Oct\.?|Nov\.?|Dec\.?)';

Abbr2Num = {'January': '01', 'Jan': '01', 'February': '02', 'Feb': '02', 'March': '03', 'Mar': '03', 'April': '04',
            'Apr': '04', 'May': '05', 'June': '06', 'Jun': '06', 'July': '07', 'Jul': '07', 'August': '08', 'Aug': '08',
            'September': '09', 'Sep': '09', 'Sept': '09', 'October': '10', 'Oct': '10', 'November': '11', 'Nov': '11',
            'December': '12', 'Dec': '12'};


def _url_entity_Conversion(txtcnt):
    ASCIIEncodingCnt = _open_utf8(ASCIIEncoding);
    r = re.findall(r'((?:(?!\==>).)*)==>((?:(?!\n).)*)\n', ASCIIEncodingCnt, re.I | re.S | re.M)
    ASCII_dict = {a: b for a, b in r}
    for id in ASCII_dict.keys():
        txtcnt = re.sub(id, ASCII_dict[id], txtcnt)
    return txtcnt


def hex2chr(hex):
    return chr(int(hex, 16));


def RemoveA3B2(txt):
    txt = re.sub(r'<\?A3B2[^>]*\?>', '', txt, 0, re.I);
    return txt;


def RemoveQuery(txt):
    txt = re.sub(r'<!--(?:(?!-->).)*-->', '', txt, 0, re.I)
    txt = re.sub(r'<xref [^><]*\bref-type="query"[^><]*/>', '', txt, 0, re.I)
    txt = re.sub(r'<xref [^><]*\bref-type="query"[^><]*>(?:(?!</?xref[ >]).)+</xref>', '', txt, 0, re.I)
    return txt


def RemoveFullFormate(txt):
    # txt = RemoveQuery(txt);
    txt = re.sub(r'<!--(?:(?!-->).)*-->', '', txt, 0, re.I | re.S)
    txt = RemoveA3B2(txt)
    txt = re.sub(r'</(italic|i|bold|b|sup|sub|sc|underline|u)>(\s*)<\1(?: [^>]+)?>', '\g<2>', txt, 0, re.I | re.S)
    while (
    re.search(r'^<(italic|i|bold|b|sup|sub|sc|underline|u)(?: [^>]+)?>((?:(?!</?\1[ >]).)*)</\1>$', txt, re.I | re.S)):
        txt = re.sub(r'^<(italic|i|bold|b|sup|sub|sc|underline|u)(?: [^>]+)?>((?:(?!</?\1[ >]).)*)</\1>$', '\g<2>', txt,
                     0, re.I | re.S)
    return txt


def RemoveTag(txt, element):
    formating = '|'.join(element.split(','));
    txt = re.sub(r'<\/?(' + str(formating) + r')(?: [^>]+)?>', r'', txt, 0, re.I);

    return txt;


def RemoveCnt(txt, element):
    txt = re.sub(r'<' + str(element) + r'(?: [^>]+)?>(?:(?!</?' + str(element) + r'>).)*</' + str(element) + r'>', r'',
                 txt, 0, re.I | re.S);

    return txt;


def list(txt, val):
    if (re.match(r'^0$', val)):
        txt = re.sub(r'(</?)(p(?: [^>]+)?>)', '\g<1>&del;\g<2>', txt, 0, re.I);
    elif (re.match(r'^1$', val)):
        txt = _element_leveling(txt, 'list-item');
        txt = re.sub(
            r'(<list-item1(?: [^>]+)?>(?:(?!</?(?:list\d+|list-item\d+|label)[ >]).)*<)(label>(?:(?!</?label>).)*</)(label>)',
            r'\g<1>&del;\g<2>&del;\g<3>', txt, 0, re.I | re.S);
        txt = re.sub(r'<(list\d+)( [^><]*\blist-type="simple"[^>]*>(?:(?!</?\1[ >]).)*)</\1>', r'<list\g<2></list>',
                     txt, 0, re.I | re.S);
    else:
        txt = re.sub(r'<label>(?:(?!</?label>).)*</label>', r'', txt, 0, re.I | re.S)

    return txt


def boxed(txt, no):
    bx = re.search(r'<boxed-text(?: [^>]+)? id="((U?BT)0*(\d+[a-z]?))"', txt, re.I);
    txt = re.sub(r'(<boxed-text(?: [^>]+)?) id="[^"]*"', r'\g<1>', txt, 0, re.I);
    if (bx):
        if (bx.group(2) == 'UBT'):
            newId = 'unbox' + bx.group(3)
        else:
            newId = 'box' + bx.group(3)

        xref[bx.group(1)] = newId;
        txt = re.sub(r'(<boxed-text(?: [^>]+)?)>', r'\g<1> id="' + str(newId) + '">', txt, 0, re.I)
        Labelcheck = re.search(r'<boxed-text(?: [^>]*)?>\s*<label(?: [^>]*)?>', txt, re.I | re.S)
        Title = re.search(
            r'<boxed-text(?: [^>]*)?>\s*<label(?: [^>]*)?>(?:(?!</label>).)*</label>\s*<title(?: [^>]*)?>(?:(?!</title>).)*</title>',
            txt, re.I | re.S)
        if (Title):
            txt = re.sub(
                r'(<boxed-text(?: [^>]*)?>\s*<label(?: [^>]*)?>(?:(?!</label>).)*</label>\s*)(<title(?: [^>]*)?>((?:(?!</title>).)*)</title>)',
                r'\g<1><caption>\g<2></caption>', txt, 0, re.I | re.S)
        if (Labelcheck):
            txt = re.sub(r'(<boxed-text(?: [^>]+)?)>', r'\g<1> position="float">', txt, 0, re.I)
        else:
            txt = re.sub(r'(<boxed-text(?: [^>]+)?)>', r'\g<1> position="anchor">', txt, 0, re.I)

    txt = re.sub(r'(<title>)\s*<p>((?:(?!</?title>).)*)</p>\s*(</title>)', r'\g<1>\g<2>\g<3>', txt, 0, re.I | re.S)
    txt = re.sub(r'(</?)sec((?: [^>]+)?>)', r'\g<1>&del;sec\g<2>', txt, 0, re.I | re.S)
    txt = re.sub(r'(</?)fn((?: [^>]+)?>)', r'\g<1>&del;fn\g<2>', txt, 0, re.I | re.S)

    return txt


def sectionID(txt, lvl):
    no = 1;

    secTit = {'introduction': 'intro', 'materials and methods': 'materials|methods', 'methods': 'materials|methods',
              'materials': 'materials|methods', 'discussion': 'discussion', 'results': 'results'};

    st = re.search(r'<sec\d+(?: [^>]+)?>\s*<title>((?:(?!</?title>).)+)</title>', txt, re.I | re.S);
    if (st):
        if RemoveTag(RemoveQuery(st.group(1)), '[a-z0-9:-]+').lower() in secTit.keys():
            secType = secTit[RemoveTag(RemoveQuery(st.group(1)), '[a-z0-9:-]+').lower()];
            txt = re.sub(r'<sec\d+', r'\g<0> newsec-type="' + str(secType) + r'"', txt);

    newId = 's' + str(lvl);
    si = re.search(r'<sec\d+ [^><]*id="([^"]+)"', txt, re.I);
    if (si):
        xref[si.group(1)] = newId;
    txt = re.sub(r'<(sec\d+)((?: [^>]+)?>(?:(?!</?\1>).)*</\1>)', r'<&del;\g<1> newid="' + str(newId) + r'"\g<2>', txt,
                 0, re.I | re.S);

    if (re.search(r'<(sec\d+)(?: [^>]+)?>(?:(?!</?\1>).)*</\1>', txt, re.S | re.I)):
        secId1 = str(lvl) + '-s' + str(no);
        txt = sectionID(txt, secId1);
        no += 1;

    return (txt);


def sectionID8(txt, id, lvl1):
    newId = id + '.' + str(lvl1)
    si = re.search(r'<sec8 [^><]*id="([^"]+)"', txt, re.I);
    if (si):
        xref[si.group(1)] = newId;

    txt = re.sub(r'<(sec8)((?: [^>]+)?>(?:(?!</?\1>).)*</\1>)', r'<&del;\g<1> newid="' + str(newId) + r'"\g<2>', txt, 0,
                 re.I | re.S);
    return (txt);


def sectionID7(txt, id, lvl1):
    newId = id + '.' + str(lvl1)
    si = re.search(r'<sec7 [^><]*id="([^"]+)"', txt, re.I);
    if (si):
        xref[si.group(1)] = newId;

    txt = re.sub(r'<(sec7)((?: [^>]+)?>(?:(?!</?\1>).)*</\1>)', r'<&del;\g<1> newid="' + str(newId) + r'"\g<2>', txt, 0,
                 re.I | re.S);
    secId8 = itertools.count(1);
    txt = re.sub(r'<sec8(?: [^>]+)?>(?:(?!</?sec8>).)*</sec8>', lambda m: sectionID8(m.group(), newId, next(secId8)),
                 txt, 0, re.I | re.S);

    return (txt);


def sectionID6(txt, id, lvl1):
    newId = id + '.' + str(lvl1)
    si = re.search(r'<sec6 [^><]*id="([^"]+)"', txt, re.I);
    if (si):
        xref[si.group(1)] = newId;
    txt = re.sub(r'<(sec6)((?: [^>]+)?>(?:(?!</?\1>).)*</\1>)', r'<&del;\g<1> newid="' + str(newId) + r'"\g<2>', txt, 0,
                 re.I | re.S);
    secId7 = itertools.count(1);
    txt = re.sub(r'<sec7(?: [^>]+)?>(?:(?!</?sec7>).)*</sec7>', lambda m: sectionID7(m.group(), newId, next(secId7)),
                 txt, 0, re.I | re.S);

    return (txt);


def sectionID5(txt, id, lvl1):
    newId = id + '.' + str(lvl1)
    si = re.search(r'<sec5 [^><]*id="([^"]+)"', txt, re.I);
    if (si):
        xref[si.group(1)] = newId;
    txt = re.sub(r'<(sec5)((?: [^>]+)?>(?:(?!</?\1>).)*</\1>)', r'<&del;\g<1> newid="' + str(newId) + r'"\g<2>', txt, 0,
                 re.I | re.S);
    secId6 = itertools.count(1);
    txt = re.sub(r'<sec6(?: [^>]+)?>(?:(?!</?sec6>).)*</sec6>', lambda m: sectionID6(m.group(), newId, next(secId6)),
                 txt, 0, re.I | re.S);

    return (txt);


def sectionID4(txt, id, lvl1):
    newId = id + '.' + str(lvl1)
    si = re.search(r'<sec4 [^><]*id="([^"]+)"', txt, re.I);
    if (si):
        xref[si.group(1)] = newId;
    txt = re.sub(r'<(sec4)((?: [^>]+)?>(?:(?!</?\1>).)*</\1>)', r'<&del;\g<1> newid="' + str(newId) + r'"\g<2>', txt, 0,
                 re.I | re.S);

    secId5 = itertools.count(1);
    txt = re.sub(r'<sec5(?: [^>]+)?>(?:(?!</?sec5>).)*</sec5>', lambda m: sectionID5(m.group(), newId, next(secId5)),
                 txt, 0, re.I | re.S);

    return (txt);


def sectionID3(txt, id, lvl1):
    newId = id + '.' + str(lvl1)
    si = re.search(r'<sec3 [^><]*id="([^"]+)"', txt, re.I);
    if (si):
        xref[si.group(1)] = newId;
    txt = re.sub(r'<(sec3)((?: [^>]+)?>(?:(?!</?\1>).)*</\1>)', r'<&del;\g<1> newid="' + str(newId) + r'"\g<2>', txt, 0,
                 re.I | re.S);

    secId4 = itertools.count(1);
    txt = re.sub(r'<sec4(?: [^>]+)?>(?:(?!</?sec4>).)*</sec4>', lambda m: sectionID4(m.group(), newId, next(secId4)),
                 txt, 0, re.I | re.S);

    return (txt);


def sectionID2(txt, id, lvl1):
    newId = id + '.' + str(lvl1)
    si = re.search(r'<sec2 [^><]*id="([^"]+)"', txt, re.I);
    if (si):
        xref[si.group(1)] = newId;
    txt = re.sub(r'<(sec2)((?: [^>]+)?>(?:(?!</?\1>).)*</\1>)', r'<&del;\g<1> newid="' + str(newId) + r'"\g<2>', txt, 0,
                 re.I | re.S);

    secId3 = itertools.count(1);
    txt = re.sub(r'<sec3(?: [^>]+)?>(?:(?!</?sec3>).)*</sec3>', lambda m: sectionID3(m.group(), newId, next(secId3)),
                 txt, 0, re.I | re.S);

    return (txt)


def sectionID1(txt, lvl):
    newId = 'sec' + str(lvl).zfill(3)
    si = re.search(r'<sec1 [^><]*id="([^"]+)"', txt, re.I);
    if (si):
        xref[si.group(1)] = newId
    txt = re.sub(r'<(sec1)((?: [^>]+)?>(?:(?!</?\1>).)*</\1>)', r'<&del;\g<1> newid="' + str(newId) + r'"\g<2>', txt, 0,re.I | re.S);

    secId2 = itertools.count(1);
    txt = re.sub(r'<sec2(?: [^>]+)?>(?:(?!</?sec2>).)*</sec2>', lambda m: sectionID2(m.group(), newId, next(secId2)),txt, 0, re.I | re.S);

    return (txt);


def Figure(txt):
    fg = re.search(r'<fig [^><]*id="((U?F)0*(\d+[a-z]?))"', txt, re.I);
    if (fg):
        newId = fg.group(2).upper() + '_' + str(FileName) + fg.group(3).zfill(3)
        xref[fg.group(1)] = newId;
        txt = re.sub(r'(<fig [^><]*id=")U?F0*\d+[a-z]?"', r'\g<1>' + str(newId) + '"', txt, 0, re.I);
    # v1.0.0.9
    # pos = re.search(r'<fig [^><]*position="[^"]*"',txt,re.I);
    # if(pos):
    # txt = re.sub(r'(<fig [^><]*position=")[^"]*"','\g<1>float"',txt,0,re.I);
    # else:
    # txt = re.sub(r'(<fig(?: [^>]+)?)>','\g<1> position="float">',txt,0,re.I);
    # --
    txt = re.sub(r'(<graphic(?: [^>]+)?)/>\s*(<object-id>(?:(?!</?object-id>).)*</object-id>)',
                 r'\g<1>>\g<2></graphic>', txt, 0, re.I | re.S)
    txt = re.sub(r'(<fig [^><]*id="[^"]*")', '\g<1> orientation="portrait"', txt, 0, re.I);
    txt = re.sub(r'(<fig [^><]*fig-type=")[^"]*"', '\g<1>diagram"', txt, 0, re.I);
    txt = re.sub(r'(<graphic(?: [^>]*)? )xlink:type="simple"((?: [^>]*)?/>)', '\g<1>\g<2>', txt, 0, re.I | re.S)
    txt = re.sub(r'(<graphic(?: [^>]*)?)/>', '\g<1> xlink:type="simple"/>', txt, 0, re.I | re.S)

    # graphic id count for fig
    txt = re.sub(r'<graphic [^><]*xlink:href="[^"]*"[^>]*>',
                 lambda m: Graphic(m.group(), 'fig', next(FigIdCount), 'eps'), txt, 0, re.I | re.S)

    alt = re.search(r'<alt-text(?: [^>]+)?>(?:(?!</?alt-text>).)*</alt-text>', txt, re.I | re.S);
    if (alt and re.search(r'<graphic(?: [^>]+)?', txt, re.I)):
        alt_txt = '';
        for m in re.finditer(r'<alt-text(?: [^>]+)?>(?:(?!</?alt-text>).)*</alt-text>', txt, re.I | re.S):
            txt = re.sub(m.group(), r'', txt);
            alt_txt += m.group();
        txt = re.sub(r'<graphic(?: [^>]+)?', alt_txt + '\n' + r'\g<0>', txt, 0, re.I);

    txt = re.sub(r'<p(?: [^>]+)?>\s*(<attrib(?: [^>]+)?>(?:(?!</?attrib>).)*</attrib>)\s*</p>', r'\g<1>', txt, 0,
                 re.I | re.S);

    return (txt);


def trow(txt, element):
    if (re.match(r'^th$', element, re.I)):
        txt = RemoveTag(txt, 'bold');

    txt = re.sub(r'<\/p>\s*<p(?: [^>]+)?>', r'<break/>', txt, 0, re.S);
    txt = re.sub(r'<\/?p(?: [^>]+)?>', r'', txt, 0, re.S);
    txt = re.sub(r'(<(t[hd])(?: [^>]+)?)>\s*<\/\2>', r'\g<1>/>', txt, 0, re.S);

    return (txt);


tfnID = {};


def tabfn(txt, tabid, tno):
    fn = re.search(r'^<fn [^><]*id="([^"]+)"', txt, re.I);
    newId = str(tabid) + '-fn' + str(tno)
    if (fn):
        tfnID[fn.group(1)] = newId;
        txt = re.sub(r'(<fn(?: [^>]*)?) id="[^"]+"', r'\g<1> id="' + str(newId) + '"', txt, re.I);
    else:
        txt = re.sub(r'(<fn(?: [^>]+)?) id="[^"]*"', r'\g<1>', txt, 0, re.I);
        txt = re.sub(r'<fn((?: [^>]+)?>)', r'<fn id="' + str(newId) + '"\g<1>', txt, 0, re.I);

    return txt


def tableFoot(txt, tabid):
    # txt = RemoveTag(txt,'fn-group');
    tfnNo = itertools.count(1);
    txt = re.sub(r'<fn(?: [^>]+)?>(?:(?!</fn>).)*</fn>', lambda m: tabfn(m.group(), tabid, next(tfnNo)), txt, 0,
                 re.I | re.S);

    return txt


# v1.0.0.9
def appendix(txt, ano):
    appp = re.search(r'^<app [^><]*id="([^"]+)"', txt, re.I);
    newId = 'app' + str(ano)
    if (appp):
        xref[appp.group(1)] = newId;
        txt = re.sub(r'(<app(?: [^>]*)?) id="[^"]+"', r'\g<1> id="' + str(newId) + '"', txt, re.I);
    else:
        txt = re.sub(r'(<app(?: [^>]+)?) id="[^"]*"', r'\g<1>', txt, 0, re.I);
        txt = re.sub(r'<app((?: [^>]+)?>)', r'<app id="' + str(newId) + '"\g<1>', txt, 0, re.I);

    return (txt);


# --
def _tableAlign(txt1, txt2, txt3):
    Num = re.search(r'^(?:&#x(?:[a-f0-9]{4});)?(?:[+|-|_|$|@])?\d+', txt2, re.I | re.S)
    col = re.search(r' (?:colspan|rowspan)="([^"]+)"', txt1, re.I | re.S)

    if col:
        if (col.group(1) > '1'):
            txt1 = re.sub(r'(<t[hd](?: [^>]*)?)>', r'\g<1> align="center">', txt1, 0, re.I | re.S)
        else:
            if Num:
                txt1 = re.sub(r'(<t[d](?: [^>]*)?)>', r'\g<1> align="char" char=".">', txt1, 0, re.I | re.S)
                txt1 = re.sub(r'(<t[h](?: [^>]*)?)>', r'\g<1> align="center">', txt1, 0, re.I | re.S)
            else:
                txt1 = re.sub(r'(<t[hd](?: [^>]*)?)>', r'\g<1> align="left">', txt1, 0, re.I | re.S)
    else:
        if Num:
            txt1 = re.sub(r'(<t[d](?: [^>]*)?)>', r'\g<1> align="char" char=".">', txt1, 0, re.I | re.S)
            txt1 = re.sub(r'(<t[h](?: [^>]*)?)>', r'\g<1> align="center">', txt1, 0, re.I | re.S)
        else:
            txt1 = re.sub(r'(<t[hd](?: [^>]*)?)>', r'\g<1> align="left">', txt1, 0, re.I | re.S)

    return f"{txt1}{txt2}{txt3}"


def Table(txt, tfn):
    tb = re.search(r'<table-wrap [^><]*id="((U?T)0*(\d+[a-z]?))"', txt, re.I)
    if (tb):
        if (tb.group(2) == 'T'):
            newId = 'tbl' + tb.group(3).lower()
        else:
            newId = 'utbl' + tb.group(3).lower()
        tfn = tb.group(2)
        xref[tb.group(1)] = newId

        txt = re.sub(r'(<table-wrap [^><]*id=")U?T0*\d+[a-z]?"', '\g<1>' + str(newId) + '"', txt, 0, re.I)
        txt = re.sub(r'(<table-wrap-foot(?: [^>]+)?>)((?:(?!</table-wrap-foot>).)*)(</table-wrap-foot>)',
                     lambda m: str(m.group(1)) + str(r'<fn-group content-type="footnotes">') + tableFoot(m.group(2),
                                                                                                         newId) + str(
                         '</fn-group>') + str(m.group(3)), txt, 0, re.I | re.S);

    txt = re.sub(r'(<table-wrap [^><]*id="[^"]*")', '\g<1> orientation="portrait"', txt, 0, re.I);
    txt = re.sub(r'</label>\s*<caption>', r'</label><caption>', txt, 0, re.S | re.I);
    txt = re.sub(r'<table(?: [^>]+)?>', r'<alternatives>\n<graphic xlink:href=""/>\n<table frame="hsides">', txt, 0,
                 re.I);
    txt = re.sub(r'</table>', r'</table>\n</alternatives>', txt, 0, re.I);
    txt = re.sub(r'(<tr(?: [^>]+)?) valign="[^"]*"', r'\g<1>', txt, 0, re.I);

    # v1.0.0.9
    txt = re.sub(r'(<(td|th)(?: [^>]+)?) valign="[^"]*"', r'\g<1>', txt, 0, re.I);
    txt = re.sub(r'(<(td|th)(?: [^>]+)?) align="[^"]*"', r'\g<1>', txt, 0, re.I)
    # --

    txt = re.sub(r'(<t[hd](?: [^>]+)?) width="[^"]*"', r'\g<1>', txt, 0, re.I);
    # txt = re.sub(r' align="justify"',r' align="left"',txt,0,re.I);

    txt = _element_leveling(txt, 'list')
    txt = re.sub(r'<(list\d+)(?: [^>]+)?>(?:(?!</?\1>).)+</\1>', lambda m: list(m.group(), '0'), txt, 0, re.I | re.S);
    txt = re.sub(r'<(t[hd])(?: [^>]+)?>(?:(?!</\1>).)*</\1>', lambda m: trow(m.group(), m.group(1)), txt, 0,
                 re.I | re.S);

    # txt = re.sub(r'(<(td|th)(?: [^>]+)?)(>((?:(?!</\2>).)*)</\2>)', lambda m: m.group(1)+_tableAlign(m.group(3),m.group(4)),txt,0,re.I)
    txt = re.sub(r'(<(td|th)(?: [^>]+)?>)((?:(?!</\2>).)*)(</\2>)',
                 lambda m: _tableAlign(m.group(1), m.group(3), m.group(4)), txt, 0, re.I)

    txt = re.sub(r'&del;', r'', txt, 0, re.I);
    txt = re.sub(r'(</?list)\d+', r'\g<1>', txt, 0, re.I)
    # graphic id count for table
    txt = re.sub(r'<graphic [^><]*xlink:href="[^"]*"[^>]*>',
                 lambda m: Graphic(m.group(), 'tbl', next(TabIdCount), 'eps'), txt, 0, re.I | re.S)

    txt = re.sub(r'(<colgroup(?: [^>]*)?) cols="[^"]+"((?: [^>]*)?>)', r'\g<1>\g<2>', txt, 0, re.I | re.S)
    txt = re.sub(r'(<col(?: [^>]*)?) colnum="[^"]+"((?: [^>]*)?>)', r'\g<1>\g<2>', txt, 0, re.I | re.S)

    return txt


def DispFormula(txt, tfn):
    tb = re.search(r'<disp-formula [^><]*id="((U?M)0*(\d+[a-z]?))"', txt, re.I)
    if (tb):
        if (tb.group(2) == 'M'):
            newId = 'eqn' + tb.group(3).lower()
        else:
            newId = ('ueqn' + tb.group(3)).lower()
        tfn = tb.group(2)
        xref[tb.group(1)] = newId

        txt = re.sub(r'(<disp-formula [^><]*id=")U?M0*\d+[a-z]?"', '\g<1>' + str(newId) + '"', txt, 0, re.I)

    return (txt)


def PersonGrp1(pre, txt, post):
    txt = re.sub(r'</?person-group(?: [^>]+)?>', r'', txt, 0, re.I | re.S);
    # while (re.search(r'(</[a-z0-9:-]+>)[ \.:;]+(<[a-z0-9:-]+(?: [^>]+)?>)', txt, re.I)):
        # txt = re.sub(r'(</[a-z0-9:-]+>)([ \.,:;\)\(]+)(<[a-z0-9:-]+(?: [^>]+)?>)',r'\g<1><?x-open>\g<2><?x-close?>\g<3>',txt,0,re.I);
        # txt = re.sub(r'(</[a-z0-9:-]+>)([ \.,:;\)\(]+)(<[a-z0-9:-]+(?: [^>]+)?>)', r'\g<1>\g<3>', txt, 0, re.I);
    return (pre + txt + post);


def PersonGrp(txt):
    txt = re.sub(
        r'(<person-group(?: [^>]+)? person-group-type="author"[^><]*>)((?:(?!</?(?:year|chapter-title|article-title|source)[ >]).)*)(</person-group>)',
        lambda m: PersonGrp1(m.group(1), m.group(2), m.group(3)), txt, 0, re.I | re.S);
    txt = re.sub(
        r'(<person-group(?: [^>]+)? person-group-type="editor"[^><]*>)((?:(?!</?(?:year|chapter-title|article-title|source)[ >]).)*)(</person-group>)',
        lambda m: PersonGrp1(m.group(1), m.group(2), m.group(3)), txt, 0, re.I | re.S);

    return (txt);


def PageRange(txt):
    if (re.search(r'^\s*<(bold|italic)>(?:(?!</?\1>).)+</\1>\s*$', txt, re.I | re.S)):
        frmt = re.search(r'^\s*<(bold|italic)>(?:(?!</?\1>).)+</\1>\s*$', txt, re.I | re.S);
        txt = RemoveTag(txt, 'bold,italic');
        frtag = frmt.group(1);
        txt = re.sub(r'^\s*([0-9a-z]+)[\.\?, ]*(\&\#x\d{4};|\-)\s*([0-9a-z]+)[\.\?,; ]*$',
                     r'<fpage><' + str(frtag) + r'>\g<1><' + str(frtag) + r'></fpage>\g<2><lpage><' + str(
                         frtag) + r'>\g<3><' + str(frtag) + r'></lpage>', txt, 0, re.I | re.S);
        txt = re.sub(r'^\s*(\d+)\s*$', r'<fpage><' + str(frtag) + r'>\g<1><' + str(frtag) + r'></fpage>', txt, 0,
                     re.I | re.S);
        txt = re.sub(r'^\s*([a-z]+\d+|\d+[a-z]+)\s*$',
                     r'<elocation-id><' + str(frtag) + r'>\g<1><' + str(frtag) + r'></elocation-id>', txt, 0,
                     re.I | re.S);
    else:
        txt = RemoveTag(txt, 'bold,italic');
        txt = re.sub(r'^\s*([0-9a-z]+)[\.\?, ]*(\&\#x\d{4};|\-)\s*([0-9a-z]+)[\.\?,; ]*$',
                     r'<fpage>\g<1></fpage>\g<2><lpage>\g<3></lpage>', txt, 0, re.I | re.S);
        txt = re.sub(r'^\s*(\d+)\s*$', r'<fpage>\g<1></fpage>', txt, 0, re.I | re.S);
        txt = re.sub(r'^\s*([a-z]+\d+|\d+[a-z]+)\s*$', r'<elocation-id>\g<1></elocation-id>', txt, 0, re.I | re.S);

    return (txt);


def _DoiLink(txt):
    txt = re.sub(r'&#x002F;', r'/', txt, 0, re.I | re.S);
    txt = re.sub(r'&#x2010;', r'-', txt, 0, re.I | re.S);
    if (re.search(r'<doi(?: [^>]*)?>(?:(?!</doi>).)*</doi>', txt, re.I | re.S)):
        txt = re.sub(r'<doi(?: [^>]*)?>((?:(?!</doi>).)*)</doi>', '<pub-id pub-id-type="doi">\g<1></pub-id>', txt, 0,
                     re.I | re.S)
    else:
        txt = RemoveA3B2(txt)
        uridata = re.search(r'<xref(?: [^>]*)? ref-type="query"(?: [^>]*)?/?>', txt, re.I)
        if uridata:
            uriLinkdata = re.sub(r'<xref(?: [^>]*)? ref-type="query"(?: [^>]*)?/?>', '', txt, 0, re.I)
            uriQuerydata = uridata.group()
        else:
            uriLinkdata = txt
            uriQuerydata = ""

        txt = re.sub(r'<xref(?: [^>]*)? ref-type="query"(?: [^>]*)?/?>', '', txt, 0, re.I)
        txt = re.sub(r'<uri(?: [^>]*)?>((?:(?!</uri>).)*)</uri>',
                     lambda m: '<ext-link ext-link-type="uri" xlink:href="' + str(
                         _url_entity_Conversion(m.group(1))) + '">' + str(m.group(1)) + '</ext-link>' + str(
                         uriQuerydata), txt, 0, re.I | re.S)

    txt = re.sub(r'https?://doi.org/https?://doi.org/', r'https://doi.org/', txt, 0)

    return txt


def Reference(txt, no):

    rf = re.search(r'<ref [^><]*id="([^"]*)"', txt, re.I);
    if (rf):
        newId = 'ref' + str(no).zfill(3)
        xref[rf.group(1)] = newId;
        txt = re.sub(r'(<ref [^><]*id=")[^"]*"', r'\g<1>' + str(newId) + '"', txt, re.I);

    # txt = re.sub(r'(</?)mixed-citation((?: [^>]+)?>)',r'\g<1>citation\g<2>',txt,0,re.I);
    # txt = re.sub(r'(<mixed-citation [^><]*)publication-type(="[^"]*")',r'\g<1>citation-type\g<2>',txt,0,re.I);
    txt = re.sub(r'(<mixed-citation [^><]*publication-type=")conf-proc(")', r'\g<1>confproc\g<2>', txt, 0, re.I);

    txt = re.sub(r'(<mixed-citation [^><]*publication-type=")paper(")', r'\g<1>working-paper\g<2>', txt, 0, re.I);

    txt = re.sub(r'(<ref(?: [^>]+)?>)((?:(?!</?(?:ref|label)>).)*)(<label>(?:(?!</?label>).)*</label>)\s*',
                 r'\g<1>\g<3>\g<2>', txt, 0, re.I | re.S);
    txt = re.sub(r'<author type="([^"]+)">', r'<person-group person-group-type="\g<1>"><string-name>', txt, 0, re.I);
    txt = re.sub(r'<author>', r'<person-group person-group-type="author"><string-name>', txt, 0, re.I);
    txt = re.sub(r'</author>', r'</string-name></person-group>', txt, 0, re.I);
    txt = re.sub(r'<collab(?: [^>]+)?>(?:(?!</collab>).)*</collab>',
                 r'<person-group person-group-type="author">\g<0></person-group>', txt, 0, re.I | re.S);
    txt = re.sub(r'<editor(?: [^>]+)?>(?:(?!</editor>).)*</editor>',
                 r'<person-group person-group-type="editor">\g<0></person-group>', txt, 0, re.I | re.S);
    # txt = re.sub(r'<string-name(?: [^>]+)?>(?:(?!</string-name>).)*</string-name>',r'<person-group person-group-type="author">\g<0></person-group>',txt,0,re.I|re.S);
    txt = re.sub(r'(</?)editor', r'\g<1>string-name', txt, 0, re.I);
    txt = re.sub(
        r'<person-group [^><]*person-group-type="author"[^><]*>(?:(?!<person-group [^><]*person-group-type="editor"[^><]*>).)+$',
        lambda m: PersonGrp(m.group()), txt, 0, re.I | re.S);

    txt = re.sub(
        r'<person-group [^><]*person-group-type="editor"[^><]*>(?:(?!<person-group [^><]*person-group-type="author"[^><]*>).)+$',
        lambda m: PersonGrp(m.group()), txt, 0, re.I | re.S);

    # txt = re.sub(r'(<person-group(?: [^>]+)?>(?:(?!</?person-group[ >]).)*</person-group>)(,\s*<etal>et\s*al\.?</etal>)',r'\g<1><etal/>',txt,0,re.I|re.S);
    txt = re.sub(r'<etal>et\s*al\.?</etal>', r'<etal/>.', txt, 0, re.I | re.S);

    # v1.0.0.9
    # txt = re.sub(r'([ \.,:;\)\(]+)<etal/>',r'<?x-open?>\g<1><?x-close?><etal/>',txt,0,re.I|re.S);
    # txt = re.sub(r'<etal/>([ \.,:;\)\(]+)',r'<etal/><?x-open?>\g<1><?x-close?>',txt,0,re.I|re.S);
    # --

    txt = re.sub(r'(<source(?: [^>]+)?>)((?:(?!</?source>).)+)(</source>)',
                 lambda m: m.group(1) + RemoveFullFormate(m.group(2)) + m.group(3), txt, 0, re.I | re.S);

    txt = re.sub(r'<page-range(?: [^>]+)?>((?:(?!</?page-range[ >]).)+)</page-range>', lambda m: PageRange(m.group(1)),
                 txt, 0, re.I | re.S);

    txt = re.sub(r'(?:\bdoi[ :]*)?\s*<(uri|doi)(?: [^>]*)?>(?:(?!</\1>).)*</\1>', lambda m: _DoiLink(m.group()), txt, 0,
                 re.I | re.S);

    txt = re.sub(r'[ \.]+</label>', r'</label>', txt, 0);

    # v1.0.0.3
    # txt = re.sub(r'[\( ]+(<([a-z0-9:-]+)(?: [^>]+)?>(?:(?!</?\2[ >]).)*</\2>)[ \)]+',r'\g<1>',txt,0,re.I|re.S);
    # if(re.search(r'<citation [^><]*\bcitation-type="(?:journal|book)"',txt,re.I)):
    # while(re.search(r'(</[a-z0-9:-]+>)([ \.,:;\)\(\.\s*[\]]+)(</?[a-z0-9:-]+(?: [^>]+)?>)',txt,re.I)):
    # v1.0.0.9
    # txt = re.sub(r'(</[a-z0-9:-]+>)([ \.,:;\)\(\.\s*[\]]+)(</?[a-z0-9:-]+(?: [^>]+)?>)',r'\g<1><?x-open?>\g<2><?x-close?>\g<3>',txt,0,re.I);
    # ---
    # v1.0.0.7
    # txt = re.sub(r'[\. ]*<etal/>[\. ]*',r'<etal/>',txt,0,re.I);
    # ---
    txt = re.sub(r'<x(?: [^>]+)?>((?:(?!</?x>).)*)</x>', r'<comment>\g<1></comment>', txt, 0, re.I | re.S)

    # shobana#07-06-2022##
    for m in re.finditer(
            r'<ref(?: [^>]*)?>(?:(?!</ref>).)*<mixed-citation(?: [^>]*)? publication-type="[^"]*"[^>]*?>((?:(?!</mixed-citation>).)*)</mixed-citation>((?:(?!</ref>).)*)</ref>',
            txt, re.I | re.S):
        if (
        re.search(r'<chapter-title(?: [^>]*)?>(?:(?!</chapter-title>).)*</chapter-title>', m.group(1), re.I | re.S)):
            txt = re.sub(r'(<mixed-citation(?: [^>]*)? publication-type=")[^"]*("[^>]*?>)', r'\g<1>book-chapter\g<2>',
                         m.group(), 0, re.I | re.S)
    # shobana#07-06-2022#14-06-2022#

    return txt


def QueryReverse(txt):
    queryTag = ""
    for m in re.finditer(r'<xref(?: [^>]*)? ref-type="query"(?: [^>]*)?/>', txt, re.I | re.S):
        queryTag += m.group()
    return queryTag


query_cnt = ""


def PreCleanup(cnt):
    # special character to hexa-decimal:
    def _hexa(tmp):
        test = hex(ord(tmp)).split('x')[-1]
        test = '&#x' + test.zfill(4).upper() + ';'
        return test

    # Convert <!--AU to <!--AQ
    cnt = re.sub(r'(<query-text(?: [^>]*)?>(?:<p>)?)(AQ:\s*)', r'\g<1>', cnt, 0, re.I | re.S)
    cnt = re.sub(r'[^\x00-\x7F]', lambda m: _hexa(m.group()), cnt)
    cnt = re.sub(r'&#x002F;', r'/', cnt, 0)
    cnt = re.sub(r'<metainfo(?: [^>]*)?>(?:(?!</metainfo>).)*</metainfo>\s*', r'', cnt, 0, re.I | re.S);
    cnt = re.sub(
        r'(<(?:abstract)(?: [^>]+)?>\s*)(<title>(?:(?!</?title>).)*</title>)\s*((?:<p(?: [^>]*)?>)|(?:<sec(?: [^>]*)?>\s*(?:<(?:label|title)>(?:(?!</(?:label|title)>).)*</(?:label|title)>)?\s*<p(?: [^>]*)?>))',
        lambda m: f"{m.group(1)}\n{m.group(3)}{QueryReverse(m.group(2))}", cnt, 0, re.I | re.S)
    cnt = re.sub(r'<(label|title|subtitle|etal|volume|year|article-title)>((?:(?!</?\1>).)*?)</\1>',
                 lambda m: r'<' + str(m.group(1)) + '>' + RemoveFullFormate(m.group(2)) + r'</' + str(m.group(1)) + '>',
                 cnt, 0, re.I | re.S)

    cnt = _element_leveling(cnt, 'list');
    # v1.0.0.8: ignore label with simple list only
    while (re.search(r'<(list\d+)(?: [^>]*)? list-type="simple"[^>]*>(?:(?!</?\1[ >]).)*</\1>', cnt, re.I | re.S)):
        cnt = re.sub(r'<(list\d+)(?: [^>]*)? list-type="simple"[^>]*>(?:(?!</?\1[ >]).)*</\1>',
                     lambda m: list(m.group(), '1'), cnt, 0, re.I | re.S);
    # ---
    cnt = re.sub(r'<(list\d+)(?: [^>]*)?>(?:(?!</?\1[ >]).)*</\1>', lambda m: list(m.group(), '2'), cnt, 0,
                 re.I | re.S);

    cnt = re.sub(r'(</?list(?:-item)?)\d+', r'\g<1>', cnt, 0, re.I);
    cnt = re.sub(r'&del;', r'', cnt, 0, re.I);
    cnt = re.sub(r'<comment>\s*(<xref(?: [^>]+)? rid="aq\d+"[^>]*\/>(?:\s*<xref(?: [^>]+)? rid="aq\d+"[^>]*\/>)*)</comment>',r'\g<1>', cnt, 0, re.I | re.S)
    cnt = re.sub(r'(<tr(?: [^>]+)?>)\s*(<(?:td|th)(?: [^>]+)?>)', '\g<1>\n\g<2>', cnt, 0, re.I | re.S);
    cnt = re.sub(r'&#x005F;', r'_', cnt, 0);
    cnt = re.sub(r'&#x0040;', r'@', cnt, 0);
    cnt = re.sub(r'^[ ]+(<p(?: [^>]+)?>)', r'\g<1>', cnt, 0);
    # v1.0.0.10
    cnt = re.sub(r'(<fig position="anchor">)\s*((?:(?!</?fig>).)*)\s*(</fig>)',
                 r'\g<1>\g<2>\n<graphic xlink:href=" "/>\g<3>', cnt, 0);
    # ---
    cnt = _element_leveling(cnt, 'p');

    # v1.0.0.2
    while (re.search(r'<(p\d+)(?: [^>]+)?>\s*<(p\d+)(?: [^>]+)?>(?:(?!</\2>).)*</\2>\s*</\1>', cnt, re.S | re.I)):
        cnt = re.sub(r'(<(p\d+)(?: [^>]+)?>\s*)<(p\d+)(?: [^>]+)?>((?:(?!</\3>).)*)</\3>(\s*</\2>)', r'\g<1>\g<4>\g<5>',
                     cnt, 0, re.I | re.S);
    cnt = re.sub(r'(</?p)\d+', r'\g<1>', cnt, 0, re.I)
    # ---

    cnt = re.sub(r'<front>', r'<front id="meta-hdr">', cnt, 0, re.I | re.S)
    cnt = re.sub(r'</?MATHML>', r'', cnt, 0, re.I | re.S)
    # cnt = re.sub(r'<MATHML(?: [^>]*)?>(?:(?!</MATHML>).)*</MATHML>',r'',cnt,0,re.I|re.S)
    cnt = re.sub(r'(</?)m(:[a-z]+(?: [^>]*)?>)', r'\g<1>mml\g<2>', cnt, 0, re.I | re.S)

    # if query_cnt:
    #	for query in query_cnt:
    #		cnt = re.sub(query,"",cnt,0,re.I|re.S)

    return cnt


def articleTitle(txt):
    txt = re.sub('\n+(<abbrev(?: [^>]+)?>)', r'\g<1>', txt, 0, re.S);
    txt = re.sub('\n+(</abbrev>)', r'\g<1>', txt, 0, re.S);

    return txt


def contribAut(txt):
    orcid = '';
    deg = '';
    suffix = '';
    prefix = '';
    o = re.search(r'<orcid(?: [^>]+)?>((?:(?!</?orcid>).)+)</orcid>', txt, re.I | re.S);
    d = re.search(r'<degrees(?: [^>]+)?>(?:(?!</?degrees>).)+</degrees>', txt, re.I | re.S);
    s = re.search(r'<suffix(?: [^>]+)?>(?:(?!</?suffix>).)+</suffix>', txt, re.I | re.S);
    p = re.search(r'<prefix(?: [^>]+)?>(?:(?!</?prefix>).)+</prefix>', txt, re.I | re.S);

    if (o):
        orcid = r'<contrib-id contrib-id-type="orcid">http://orcid.org/' + str(o.group(1)) + '</contrib-id>';
    if (d):
        deg = d.group();
    if (s):
        suffix = s.group();
    if (p):
        prefix = p.group();

    txt = re.sub(r'<(orcid|degrees|suffix|prefix)(?: [^>]+)?>(?:(?!</?\1>).)*</\1>', r'', txt, 0, re.I | re.S)
    txt = re.sub(r'(<given-names(?: [^>]+)?>.*?</given-names>)(\s*)(<surname>.*?</surname>)',
                 r'<name name-style="western">\g<3>\g<2>\g<1>' + str(prefix) + str(
                     suffix) + r'</name>\n<string-name name-style="western">\g<1> \g<3></string-name>', txt, 0,
                 re.I | re.S)
    txt = re.sub(r'</?author(?: [^>]+)?>', r'', txt, 0, re.I | re.S)
    txt = re.sub(r'</string-name>', r'\g<0>' + str(deg), txt, 0, re.I | re.S)
    # txt = str(orcid)+'\n<name-alternatives>\n'+str(txt)+'\n</name-alternatives>'+str(deg)
    txt = str(orcid) + str(txt)
    return txt


def contrib(txt, MetaContribEmail):
    txt = RemoveCnt(txt, 'x');
    txt = RemoveTag(txt, 'sup')
    contype = re.search(r'<contrib(?: [^>]*)? contrib-type="([^"]+)"(?: [^>]*)?>', txt, re.I | re.S)
    if contype:
        txt = re.sub(r'(<collab(?: [^>]*)?)>', r'\g<1> collab-type="' + str(contype.group(1)) + '">', txt, 0,
                     re.I | re.S)

    txt = re.sub(r' corresp="no"', r'', txt, 0, re.I)
    txt = re.sub(r'<author(?: [^>]+)?>(?:(?!</?author>).)*</author>', lambda m: contribAut(m.group()), txt, 0,
                 re.I | re.S)
    txt = re.sub('(<xref(?: [^>]*)?)>(?:(?!</xref>).)*</xref>', r'\g<1>/>', txt, 0, re.I | re.S)
    txt = re.sub(r'<name(?: [^>]*)?>', r'<name-alternatives>\n\g<0>', txt, 0, re.I | re.S)
    txt = re.sub(r'</string-name>', r'\g<0>\n</name-alternatives>', txt, 0, re.I | re.S)
    email = re.search(r'<email(?: [^>]+)?>(?:(?!</?email>).)*</email>', txt, re.I | re.S)
    if (email):
        email = email.group()
        txt = re.sub(r'<email(?: [^>]+)?>(?:(?!</?email>).)*</email>', '', txt, 0, re.I | re.S)
        txt = re.sub(r'</name-alternatives>', r'\g<0>' + str(email), txt, 1, re.I | re.S)
    else:
        GivenSurName = re.search(
            r'<surname(?: [^>]*)?>((?:(?!</surname>).)*)</surname>\s*<given-names(?: [^>]*)?>((?:(?!</given-names>).)*)</given-names>',
            txt, re.I | re.S)
        if GivenSurName:
            try:
                MetaEmail = MetaContribEmail[
                    str(GivenSurName.group(1).lower().strip()) + str(GivenSurName.group(2).lower().strip())]
                txt = re.sub(r'</name-alternatives>', r'\g<0>' + str(MetaEmail), txt, 1, re.I | re.S)
            except:
                pass
    collab = '';
    clb = re.search(r'<collab(?: [^>]+)?>\s*(?:<on-behalf-of>)?((?:(?!</?collab>).)*)(</on-behalf-of>\s*)</collab>',
                    txt, re.I | re.S);
    if (clb):
        collab = r'<on-behalf-of>' + clb.group(1) + r'</on-behalf-of>';

    return (txt + '\n' + str(collab));


def affiliation(txt, no):
    # txt = re.sub(r'<(?!/?bold|/?italic|/?underline|/?sup|/?label|/?xref|/?aff)[^><]*>',r'',txt,0,re.I);
    txt = re.sub(r'(</?)institution>', r'\g<1>institution-wrap>', txt, 0, re.I)
    txt = re.sub(r'(</?)institution-name>', r'\g<1>institution>', txt, 0, re.I)
    txt = re.sub(r'<institution-wrap>', r'', txt, 0, re.I)
    txt = re.sub(r'\s*<postal-code(?: [^>]*)?>(?:(?!</postal-code>).)*</postal-code>', r'', txt, 0, re.I)
    txt = re.sub(r'(<institution>)', r'<institution-wrap>\g<1>', txt, 0, re.I);
    txt = re.sub(r'</?(?:department|city|state)>', r'', txt, 0, re.I)
    txt = re.sub(r'<label(?: [^>]*)?>(?:(?!</label>).)*</label>', r'', txt, 0, re.I)

    try:
        txt = re.sub(r'<country(?: [^>]*)?>((?:(?!</country>).)*)</country>',
                     lambda m: r'<country country="' + countries.get(m.group(1)).alpha2 + '">' + m.group(
                         1) + r'</country>', txt, 0, re.I)
    except:
        txt = re.sub(r'<country(?: [^>]*)?>((?:(?!</country>).)*)</country>',
                     lambda m: r'<country country="' + m.group(1) + '">' + m.group(1) + r'</country>', txt, 0, re.I)
    af = re.search(r'^<aff [^><]*id="([^"]+)"', txt, re.I)
    newId = 'aff' + str(no)
    if (af):
        xref[af.group(1)] = newId
        txt = re.sub(r'(<aff(?: [^>]*)?) id="[^"]+"', r'\g<1> id="' + str(newId) + '"', txt, re.I)
    else:
        txt = re.sub(r'(<aff(?: [^>]+)?) id="[^"]*"', r'\g<1>', txt, 0, re.I)
        txt = re.sub(r'<aff((?: [^>]+)?>)', r'<aff id="' + str(newId) + '"\g<1>', txt, 0, re.I)

    return txt


def authorFN(txt, no):
    fi = re.search(r'<fn [^><]*id="([^"]+)"', txt, re.I);

    ci = re.search(r'<corresp(?: [^>]+)? id="([^"]+)"', txt, re.I)


    if (fi):
        newId = 'au-note' + str(no)
        xref[fi.group(1)] = newId
        txt = re.sub(r'(<fn(?: [^>]+)?) id="[^"]*"', r'\g<1> id="' + str(newId) + '"', txt, 0, re.I)
    elif (ci):
        newId = 'cor' + str(no)
        xref[ci.group(1)] = newId
        txt = re.sub(r'(<corresp(?: [^>]+)?) id="[^"]*"', r'\g<1> id="' + str(newId) + '"', txt, 0, re.I)

    txt = re.sub(r'(<corresp(?: [^>]*)?>\s*(?:[^ >]*)?>?)Corresponding author', r'\g<1>', txt, 0, re.I|re.S)
    txt = re.sub(r'</?x>', r'', txt, 0, re.I)
    txt = re.sub(r'<bold>.*</bold>', r'', txt, 0, re.I)

    return txt


def authorNote(txt):
    for m in re.finditer(r'(<email)(>((?:(?!</?email>).)*)</email>)', txt, re.I | re.S):
        if (m):
            txt = re.sub(r'<email>(?:(?!</?email>).)*</email>',
                         str(m.group(1)) + r' xlink:href="' + RemoveA3B2(str(m.group(3))) + '"' + str(m.group(2)), txt,
                         1, re.I | re.S);

    fno = itertools.count(1);
    txt = re.sub(r'<(fn)(?: [^>]+)?>(?:(?!</?\1[ >]).)+</\1>', lambda m: authorFN(m.group(), next(fno)), txt, 0,
                 re.I | re.S);
    cno = itertools.count(1);
    txt = re.sub(r'<(corresp)(?: [^>]+)?>(?:(?!</?\1[ >]).)+</\1>', lambda m: authorFN(m.group(), next(cno)), txt, 0,
                 re.I | re.S);

    return (txt)


def HistDateSplit(txt):
    ds = re.search(r'([0-9]{1,2}) (' + Month + ') ([0-9]{2,4})', txt, re.I);
    ds1 = re.search(r'(' + Month + ') ([0-9]{1,2}) ([0-9]{2,4})', txt, re.I);
    if (ds):
        dt = '{0}'.format(ds.group(1).zfill(2));
        mn = Abbr2Num[ds.group(2)[0].upper() + ds.group(2)[1:].lower()];
        yr = ds.group(3);
        txt = r'<day>' + str(dt) + r'</day><month>' + str(mn) + r'</month><year>' + str(yr) + r'</year>';
    elif (ds1):
        dt = '{0}'.format(ds1.group(2).zfill(2));
        mn = Abbr2Num[ds1.group(1)[0].upper() + ds1.group(1)[1:].lower()];
        yr = ds1.group(3);
        txt = r'<day>' + str(dt) + r'</day><month>' + str(mn) + r'</month><year>' + str(yr) + r'</year>';

    return (txt)


def ISODateSplit(txt):
    ds = re.search(r'([0-9]{1,2}) (' + Month + ') ([0-9]{2,4})', txt, re.I);
    ds1 = re.search(r'(' + Month + ') ([0-9]{1,2}) ([0-9]{2,4})', txt, re.I);
    if (ds):
        dt = '{0}'.format(ds.group(1).zfill(2));
        mn = Abbr2Num[ds.group(2)[0].upper() + ds.group(2)[1:].lower()];
        yr = ds.group(3);
        txt = str(yr) + r'-' + str(mn) + r'-' + str(dt)
    elif (ds1):
        dt = '{0}'.format(ds1.group(2).zfill(2));
        mn = Abbr2Num[ds1.group(1)[0].upper() + ds1.group(1)[1:].lower()];
        yr = ds1.group(3);
        txt = str(yr) + r'-' + str(mn) + r'-' + str(dt)

    return (txt);


# def History(txt):

# query = '';
# for m in re.finditer(r'<xref [^><]*rid="aq\d+"[^>]*/>', txt, re.I|re.S):
# txt = re.sub(m.group(),r'',txt);
# query += m.group();

# MetaDate = ""
# for m in re.finditer(r'<date(?: [^>]*)? date-type="(received|accepted|revised)"(?: [^>]*)?>((?:(?!</date>).)*)</date>',MetaCnt,re.I|re.S):
# tmp = m.group()
# HYear = re.search(r'<year>((?:(?!</year>).)*)</year>',tmp,re.I)
# if HYear: HYear = HYear.group(1)
# else: HYear = ""
# HMonth = re.search(r'<month>((?:(?!</month>).)*)</month>',tmp,re.I)
# if HMonth: HMonth = HMonth.group(1)
# else: HMonth = ""
# HDay = re.search(r'<day>((?:(?!</day>).)*)</day>',tmp,re.I)
# if HDay: HDay = HDay.group(1)
# else: HDay = ""
# tmp = re.sub(r'(<date(?: [^>]*)?)>',r'\g<1> iso-8601-date="'+str(HYear)+'-'+str(HMonth)+'-'+str(HDay)+'">',tmp,0,re.I|re.S)
# MetaDate += tmp+'\n'
# if MetaDate:
# txt = re.sub(r'<history(?: [^>]*)?>(?:(?!</history>).)*</history>',r'<history>\n'+MetaDate+'\n</history>',txt,0,re.I|re.S)
# return txt
# else:
# txt = RemoveTag(txt,'[a-z0-9:-]+');
# if(re.search(r'(?:Received|Submitted / Geli&#x015F; Tarihi:|Submitted) ([0-9]{1,2} '+str(Month)+' [0-9]{2,4})',txt,re.I)):
# txt = re.sub(r'^(?:Received|Submitted / Geli&#x015F; Tarihi:|Submitted) ([0-9]{1,2} '+str(Month)+' [0-9]{2,4})',lambda m : r'<date date-type="received" iso-8601-date="'+ISODateSplit(m.group(1))+'">'+HistDateSplit(m.group(1))+r'</date>',txt,0,re.I);
# elif(re.search(r'(?:Received|Submitted / Geli&#x015F; Tarihi:|Submitted) ('+str(Month)+' [0-9]{1,2} [0-9]{2,4})',txt,re.I)):
# txt = re.sub(r'^(?:Received|Submitted / Geli&#x015F; Tarihi:|Submitted) ('+str(Month)+' [0-9]{1,2} [0-9]{2,4})',lambda m : r'<date date-type="received" iso-8601-date="'+ISODateSplit(m.group(1))+'">'+HistDateSplit(m.group(1))+r'</date>',txt,0,re.I);

# if(re.search(r'(?:Revised|Received in revised form) ([0-9]{1,2} '+str(Month)+' [0-9]{2,4})',txt,re.I)):
# txt = re.sub(r'(?:Revised|Received in revised form) ([0-9]{1,2} '+str(Month)+' [0-9]{2,4})',lambda m : r'<date date-type="revised" iso-8601-date="'+ISODateSplit(m.group(1))+'">'+HistDateSplit(m.group(1))+r'</date>',txt,0,re.I);
# elif(re.search(r'(?:Revised|Received in revised form) ('+str(Month)+' [0-9]{1,2} [0-9]{2,4})',txt,re.I)):
# txt = re.sub(r'(?:Revised|Received in revised form) ('+str(Month)+' [0-9]{1,2} [0-9]{2,4})',lambda m : r'<date date-type="revised" iso-8601-date="'+ISODateSplit(m.group(1))+'">'+HistDateSplit(m.group(1))+r'</date>',txt,0,re.I);
# if(re.search(r'Last revision received ([0-9]{1,2} '+str(Month)+' [0-9]{2,4})',txt,re.I|re.S)):
# txt = re.sub(r'Last revision received ([0-9]{1,2} '+str(Month)+' [0-9]{2,4})',lambda m : r'<date date-type="revised" iso-8601-date="'+ISODateSplit(m.group(1))+'">'+HistDateSplit(m.group(1))+r'</date>',txt,0,re.I);
# elif(re.search(r'Last revision received ('+str(Month)+' [0-9]{1,2} [0-9]{2,4})',txt,re.I|re.S)):
# txt = re.sub(r'Last revision received ('+str(Month)+' [0-9]{1,2} [0-9]{2,4})',lambda m : r'<date date-type="revised" iso-8601-date="'+ISODateSplit(m.group(1))+'">'+HistDateSplit(m.group(1))+r'</date>',txt,0,re.I);

# if(re.search(r'(?:Accepted / Kabul Tarihi:|Accepted) ([0-9]{1,2} '+str(Month)+' [0-9]{2,4})',txt,re.I|re.S)):
# txt = re.sub(r'(?:Accepted / Kabul Tarihi:|Accepted) ([0-9]{1,2} '+str(Month)+' [0-9]{2,4})',lambda m : r'<date date-type="accepted" iso-8601-date="'+ISODateSplit(m.group(1))+'">'+HistDateSplit(m.group(1))+r'</date>',txt,0,re.I);

# elif(re.search(r'(?:Accepted / Kabul Tarihi:|Accepted) ('+str(Month)+' [0-9]{1,2} [0-9]{2,4})',txt,re.I|re.S)):
# txt = re.sub(r'(?:Accepted / Kabul Tarihi:|Accepted) ('+str(Month)+' [0-9]{1,2} [0-9]{2,4})',lambda m : r'<date date-type="accepted" iso-8601-date="'+ISODateSplit(m.group(1))+'">'+HistDateSplit(m.group(1))+r'</date>',txt,0,re.I);

# if(re.search(r'Published ?(?:with(?: online)?|online)? ([0-9]{1,2} '+str(Month)+' [0-9]{2,4})',txt,re.I)):
# txt = re.sub(r'Published ?(?:with(?: online)?|online)? ([0-9]{1,2} '+str(Month)+' [0-9]{2,4})',lambda m : r'<date date-type="online" iso-8601-date="'+ISODateSplit(m.group(1))+'">'+HistDateSplit(m.group(1))+r'</date>',txt,0,re.I);
# elif(re.search(r'Published ?(?:with(?: online)?|online)? ('+str(Month)+' [0-9]{1,2} [0-9]{2,4})',txt,re.I)):
# txt = re.sub(r'Published ?(?:with(?: online)?|online)? ([0-9]{1,2} '+str(Month)+' [0-9]{2,4})',lambda m : r'<date date-type="online" iso-8601-date="'+ISODateSplit(m.group(1))+'">'+HistDateSplit(m.group(1))+r'</date>',txt,0,re.I);

# txt = '<history>\n'+str(txt)+'\n'+str(query)+'\n</history>';

# return txt

def Abstract(txt):
    # txt = re.sub(r'<abstract(?: [^>]*)?',r'\g<0> xml:lang="en"',txt,0,re.I|re.S)
    txt = re.sub(r'<p>\s*((?:<sec(?: [^>]+)?>(?:(?!</sec>).)*</sec>\s*)+)</p>', r'\g<1>', txt, 0, re.I | re.S)
    txt = re.sub(r'<p>\s*((?:&#\w\d*; ))', '<p>', txt, 0, re.I | re.S)
    txt = re.sub(r'(<sec(?: [^>]+)?) sec-type="[^"]*"', r'\g<1>', txt, 0, re.I)
    txt = re.sub(r'(<sec(?: [^>]*)?>\s*<title)(?: [^>]*)?>', r'\g<1> content-type="abstract-subheading">', txt, 0,
                 re.I | re.S)
    return txt


def KwdGroup(txt):
    txt = re.sub(r'<x(?: [^>]*)?>', r'<x xml:space="preserve">', txt, 0, re.I | re.S)
    KTit = re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>', txt, re.I | re.S)
    if KTit:
        if (KTit.group(1) == 'Keywords'):
            KTit = 'author-generated'
        else:
            KTit = re.sub(r' Classification', r'', KTit.group(1).lower(), 0, re.I)

        txt = re.sub(r'<kwd-group(?: [^>]*)?>',
                     r'<kwd-group kwd-group-type="' + str(KTit) + '" xml:lang="' + str(lang) + '">', txt, 0,
                     re.I | re.S)
    txt = re.sub(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>', '', txt, 0, re.I | re.S)

    return txt


def disp_quotegroup(txt):
    # txt = re.sub(r'(<disp-quote(?: [^>]*)?>)(<p>)?','\g<1>',txt,0,re.I|re.S)
    txt = re.sub(r'<p>(<attrib(?: [^>]*)?>)', '\g<1>', txt, 0, re.I | re.S)
    txt = re.sub(r'(</attrib(?: [^>]*)?>)\.', '.\g<1>', txt, 0, re.I | re.S)
    txt = re.sub(r'(</attrib>)(?:(?!</disp-quote>).)*</disp-quote>', lambda m: RemoveTag(m.group(), 'p'), txt, 0,
                 re.I | re.S)
    txt = re.sub(r'(?:</p>\s*)?(<attrib(?: [^>]*)?>)', '</p>\g<1>', txt, 0, re.I | re.S)

    return txt


def _titlegroup(txt):
    txt = re.sub(r'<supertitle(?: [^>]*)?>(?:(?!</supertitle>).)*</supertitle>', r'', txt, 0, re.I | re.S)
    # Alt = re.findall(r'<alt-title(?: [^>]*)?>',txt,re.I|re.S)
    # if(len(Alt) == 1):
    txt = re.sub(r'(<alt-title(?: [^>]*)? alt-title-type=")[^"]+("(?: [^>]*)?>)', r'\g<1>running-head\g<2>', txt, 0,
                 re.I | re.S)
    return txt


def _MathAtrib(tag, txt):
    if (tag == 'inline-formula'):
        txt = re.sub(r'<mml:math(?: [^>]*)?>', r'<mml:math display="inline">', txt, 0, re.I | re.S)
        txt = re.sub(r'<graphic((?: [^>]*)?/>)', r'<inline-graphic\g<1>', txt, 0, re.I | re.S)
        # inline-graphic id count for inline
        txt = re.sub(r'<inline-graphic [^><]*xlink:href="[^"]*"[^>]*>',
                     lambda m: Graphic(m.group(), 'inl', next(InlineIdCount), 'eps'), txt, 0, re.I | re.S)

    # ---
    if (tag == 'disp-formula'):
        txt = re.sub(r'<mml:math(?: [^>]*)?>',r'<mml:math display="block">',txt,0,re.I|re.S)
        # txt = re.sub(r'<graphic((?: [^>]*)?/>)',r'<graphic xmlns:xlink="http://www.w3.org/1999/xlink"\g<1>',txt,0,re.I|re.S)
        txt = re.sub(r'<inline-graphic((?: [^>]*)?/>)', r'<graphic\g<1>', txt, 0, re.I | re.S)
        # inline-graphic id count for inline
        txt = re.sub(r'<graphic [^><]*xlink:href="[^"]*"[^>]*>', lambda m: Graphic(m.group(), 'eqn', next(DispIdCount), 'eps'), txt, 0, re.I | re.S)
        if re.search(r'<mml:mo>(?:\(|\)|\{|\}|\[|\])</mml:mo>',  txt, re.I | re.S):
            txt = re.sub(r'(<mml:mo)(>(?:\(|\)|\{|\}|\[|\])</mml:mo>)', r'\g<1> stretchy="false"\g<2>', txt, 0, re.I | re.S)


    # ---
    txt = re.sub(r'<TEX(?: [^>]*)?>(?:(?!</TEX>).)*</TEX>', r'', txt, 0, re.I | re.S)
    # txt = re.sub(r'<TEX(?: [^>]*)?>',r'<tex-math><![CDATA[',txt,0,re.I|re.S)
    # txt = re.sub(r'</TEX>',r']]></tex-math>',txt,0,re.I|re.S)
    txt = re.sub(r'>\s*<', r'><', txt, 0, re.I | re.S)

    return txt


def _Author_corress(txt, MetaCoress):
    if (re.search(r'<corresp(?: [^>]*)?>(?:(?!</corresp>).)*</corresp>', txt, re.I | re.S)):
        txt = re.sub(r'<corresp(?: [^>]*)?>(?:(?!</corresp>).)*</corresp>', '', txt, 0, re.I | re.S)
        txt = re.sub(r'</author-notes>', str(MetaCoress) + r'\g<0>', txt, 0, re.I | re.S)
    return txt


def History(txt):
    query = ''
    for m in re.finditer(r'<xref [^><]*rid="aq\d+"[^>]*/>', txt, re.I | re.S):
        txt = re.sub(m.group(), r'', txt)
        query += m.group()

    txt = '<history>\n' + str(query) + '\n</history>'

    return txt


def FrontConversion(cnt):
    cnt = re.sub(
        r'<journal-id(?: [^>]*)?>(?:(?!</journal-id>).)*</journal-id>(?:\s*<journal-id(?: [^>]*)?>(?:(?!</journal-id>).)*</journal-id>)*',
        r'<journal-id journal-id-type="publisher-id">' + str(Jid) + '</journal-id>', cnt, 0, re.I | re.S)
    # Meta DOI
    MetaDOI = re.search(r'<journal-id(?: [^>]*)? journal-id-type="doi"(?: [^>]*)?>(?:(?!</journal-id>).)*</journal-id>',
                        MetaCnt, re.I | re.S)

    if MetaDOI:
        cnt = re.sub(r'<journal-title-group(?: [^>]*)?>', MetaDOI.group() + r'\n\g<0>', cnt, re.I | re.S)

    # Meta_funding changes
    Meta_funding = re.search(r'<funding-group(?: [^>]*)?>(?:(?!</funding-group>).)*</funding-group>', MetaCnt,
                             re.I | re.S)
    if Meta_funding:
        cnt = re.sub(r'</kwd-group>(\n)', r'\g<0>' + Meta_funding.group() + r'\n', cnt, re.I | re.S)

    # MetaJournal group
    MetaJgroup = re.search(r'<journal-title-group(?: [^>]*)?>(?:(?!</journal-title-group>).)*</journal-title-group>',
                           MetaCnt, re.I | re.S)

    if MetaJgroup:
        cnt = re.sub(r'<journal-title-group(?: [^>]*)?>(?:(?!</journal-title-group>).)*</journal-title-group>',
                     MetaJgroup.group(), cnt, 0, re.I | re.S)

    # Meta issn
    cnt = re.sub(r'<issn(?: [^>]*)? pub-type="[^"]+"(?: [^>]*)?>(?:(?!</issn>).)*</issn>', '', cnt, 0, re.I | re.S)
    issn = ''
    for m in re.finditer(r'<issn(?: [^>]*)?>(?:(?!</issn>).)*</issn>', MetaCnt, re.I):
        issn += m.group() + '\n'
    cnt = re.sub(r'</journal-title-group>', '</journal-title-group>\n' + issn, cnt, 0, re.I | re.S)
    # Meta Publisher
    Publisher = re.search(r'<publisher(?: [^>]*)?>(?:(?!</publisher>).)*</publisher>', MetaCnt, re.I | re.S)
    if Publisher:
        cnt = re.sub(r'<publisher(?: [^>]*)?>(?:(?!</publisher>).)*</publisher>', Publisher.group(), cnt, 0,
                     re.I | re.S)

    # Alt title xref place change
    query_cnt = re.findall(r'<xref(?: [^>]*)? ref-type=\"query\"(?: [^>]*)?/>', cnt)
    query_cnt1 = ""
    if query_cnt:
        for x in range(len(query_cnt)):
            query_cnt1 = query_cnt1 + query_cnt[x]
            cnt = cnt.replace(query_cnt[x], "")
    cnt1 = query_cnt1 + "</article-title>"
    cnt = cnt.replace('</article-title>', cnt1)

    # Remove repeated alt text tags
    cnt = re.sub(
        r'(<alt-title(?: [^>]*)?>(?:(?!</alt-title>).)*</alt-title>)\s*<alt-title(?: [^>]*)?>(?:(?!</alt-title>).)*</alt-title>',
        '\g<1>', cnt, 0, re.I | re.S)

    # Article id attrib place
    MetaArtattrib = re.search(r'<article-title(?: [^>]*)?>', MetaCnt, re.I | re.S)
    if MetaArtattrib:
        cnt = re.sub(r'<article-title(?: [^>]*)?>', MetaArtattrib.group(), cnt, 0, re.I | re.S)

    cnt = re.sub(r'<article-meta(?: [^>]*)?>', r'<article-meta id="art-meta">', cnt, 0, re.I | re.S)
    cnt = re.sub(r'<article-id(?: [^>]*)? pub-id-type="publisher-id"(?: [^>]*)?>(?:(?!</article-id>).)*</article-id>',
                 r'', cnt, 0, re.I | re.S)
    # Meta article categories
    ArticleIDMeta = re.search(r'<article-meta(?: [^>]*)?>((?:(?!<article-categories>).)*)<article-categories>', MetaCnt,
                              re.I | re.S)
    ArticleMeta = re.search(r'<article-categories(?: [^>]*)?>((?:(?!</article-categories>).)*)</article-categories>',
                            MetaCnt, re.I | re.S)
    if ArticleMeta:
        ArtCat = ArticleMeta.group()
        if (re.search("&[a-z]+;", ArtCat, re.I)):
            for key in Entity:
                ArtCat = re.sub(r'&' + str(key) + r';', Entity[key] + ';', ArtCat)

        cnt = re.sub(r'<article-meta(?: [^>]*)?>', r'\g<0>' + ArticleIDMeta.group(1) + ArtCat, cnt, 0, re.I | re.S)

    cnt = re.sub(r'(<article-id(?: [^>]*)? pub-id-type="filename"(?: [^>]*)?>)(?:(?!</article-id>).)*(</article-id>)',
                 r'\g<1>' + str(FileName) + '\g<2>', cnt, 0, re.I | re.S)

    cnt = re.sub(r'<title-group(?: [^>]*)?>(?:(?!</title-group>).)*</title-group>', lambda m: _titlegroup(m.group()),
                 cnt, 0, re.I | re.S)
    # Volume
    cnt = re.sub(r'(<(volume|issue)(?: [^>]*)?>)(?:(?!</\2>).)*(</\2>)', r'', cnt, 0, re.I | re.S)
    # Meta volume
    MetaVolIssue = re.search(
        r'<volume(?: [^>]*)?>(?:(?!</volume>).)*</volume>\s*<issue(?: [^>]*)?>(?:(?!</issue>).)*</issue>', MetaCnt,
        re.I | re.S)
    if MetaVolIssue:
        MetaVolIssue = MetaVolIssue.group()
    else:
        MetaVolIssue = ''
    cnt = re.sub(r'((?:<fpage(?: [^>]*)?>)|(?:<fpage/>))', str(MetaVolIssue) + r'\n\g<0>', cnt, 0, re.I | re.S)

    # MetaContriEmail
    MetaContribEmail = {}
    for m in re.finditer(
            r'<contrib(?: [^>]*)?>(?:(?!(?:</contrib>|<surname(?: [^>]*)?>)).)*<surname(?: [^>]*)?>((?:(?!</surname>).)*)</surname>\s*<given-names(?: [^>]*)?>((?:(?!</given-names>).)*)</given-names>(?:(?!</contrib>).)*</contrib>',
            MetaCnt, re.I | re.S):
        ContEmail = re.search(r'<email(?: [^>]*)?>(?:(?!</email>).)*</email>', m.group(), re.I | re.S)
        if ContEmail:
            MetaContribEmail[str(m.group(1).lower().strip()) + str(m.group(2).lower().strip())] = ContEmail.group()
    cnt = re.sub(r'<contrib(?: [^>]+)?>(?:(?!</?contrib[ >]).)+</contrib>',
                 lambda m: contrib(m.group(), MetaContribEmail), cnt, 0, re.I | re.S)

    CopyRightAuthor = []
    for m in re.finditer(r'<contrib(?: [^>]*)?>(?:(?!</contrib>).)*</contrib>', cnt, re.I | re.S):
        Names = re.search(r'<name(?: [^>]*)?>(?:(?!</name>).)*</name>', m.group(), re.I | re.S)
        if Names:
            Surname = re.search(r'<surname(?: [^>]*)?>((?:(?!</surname>).)*)</surname>', Names.group(), re.I | re.S)
            if Surname:
                Surname = Surname.group(1)
            else:
                Surname = ''
            GivenName = re.search(r'<given-names(?: [^>]*)?>((?:(?!</given-names>).)*)</given-names>', Names.group(),
                                  re.I | re.S)
            if GivenName:
                GivenName = GivenName.group(1)
            else:
                GivenName = ''
            CopyRightAuthor.append(Surname + ' ' + GivenName)
    # Copyright
    Copyright = re.search(
        r'<custom-meta(?: [^>]*)?>\s*<meta-name>copyright-code</meta-name>\s*<meta-value>((?:(?!</meta-value>).)*)</meta-value>\s*</custom-meta>',
        MetaCnt, re.I | re.S)
    if Copyright:
        MetaPermission = re.search(r'<permissions(?: [^>]*)?>(?:(?!</permissions>).)*</permissions>', MetaCnt,
                                   re.I | re.S)
        if MetaPermission:
            CopyYear = re.search(r'<copyright-year>((?:(?!</copyright-year>).)*)</copyright-year>',
                                 MetaPermission.group(), re.I | re.S)
            if CopyYear:
                CopyYear = CopyYear.group(1)
            else:
                CopyYear = ''
            license = re.search(r'<license(?: [^>]*)?>(?:(?!</license>).)*</license>', MetaPermission.group(),
                                re.I | re.S)
            if license:
                license = license.group()
            else:
                license = ''
            if (Copyright.group(1).upper() == 'Z'):
                cnt = re.sub(r'<permissions/>', r'<permissions>\n<copyright-statement>&#x00A9; ' + " and ".join(
                    [", ".join(CopyRightAuthor[:-1]), CopyRightAuthor[-1]] if len(
                        CopyRightAuthor) > 2 else CopyRightAuthor) + '</copyright-statement>\n<copyright-year>' + str(
                    CopyYear) + '</copyright-year>\n<copyright-holder>' + " and ".join(
                    [", ".join(CopyRightAuthor[:-1]), CopyRightAuthor[-1]] if len(
                        CopyRightAuthor) > 2 else CopyRightAuthor) + r'</copyright-holder>\n' + str(
                    license) + r'\n</permissions>', cnt, 0, re.I | re.S)
            else:
                cnt = re.sub(r'<permissions/>', MetaPermission.group(), cnt, 0, re.I | re.S)

        cnt = re.sub(r'<copyright-statement>(?:(?!</copyright-statement>).)*</copyright-statement>',
                     lambda m: re.sub(r'&amp;#169;', r'&#x00A9;', m.group(), 0, re.I | re.S), cnt, 0, re.I | re.S)
        cnt = re.sub(r'</permissions>', r'\g<0>\n<self-uri content-type="pdf" xlink:href="' + str(FileName) + '.pdf"/>',
                     cnt, re.I | re.S)

    for m in re.finditer(r'<fn [^><]*\bid="([^"]+)"[^>]*>((?:(?!</?fn[ >]).)+)</fn>', cnt, re.I | re.S):
        if (re.search(r'authors contributed equally to this work', RemoveTag(m.group(2), '[a-z0-9:-]+'), re.I)):
            cnt = re.sub(r'(<contrib(?: [^>]+)?)(>(?:(?!</?contrib[ >]).)*<xref [^><]*\brid="' + str(m.group(1)) + '")',
                         r'\g<1> equal-contrib="yes"\g<2>', cnt, 0, re.I | re.S);

    while (re.search(r'<contrib [^><]*\bequal-contrib="yes"(?: [^>]+)? equal-contrib="yes"', cnt, re.I)):
        cnt = re.sub(r'(<contrib [^><]*\bequal-contrib="yes"(?: [^>]+)?) equal-contrib="yes"', r'\g<1>', cnt, 0, re.I);

    # affiliation
    afno = itertools.count(1);
    cnt = re.sub(r'<aff(?: [^>]+)?>(?:(?!</?aff[ >]).)+</aff>', lambda m: affiliation(m.group(), next(afno)), cnt, 0,
                 re.I | re.S);

    # author-notes
    cnt = re.sub(r'<author-notes(?: [^>]+)?>(?:(?!</?author-notes[ >]).)+</author-notes>',
                 lambda m: authorNote(m.group()), cnt, 0, re.I | re.S);

    # MetaCorres
    MetaCoress = ''

    MetaCorr = re.search(r'<author-notes(?: [^>]*)?>(?:(?!</author-notes>).)*</author-notes>', cnt, re.I | re.S)

    if MetaCorr:
        for m in re.finditer(r'<corresp(?: [^>]*)?>(?:(?!</corresp>).)*</corresp>', MetaCorr.group(), re.I | re.S):
            MetaCoress += m.group() + '\n'

    cnt = re.sub(r'<author-notes(?: [^>]*)?>(?:(?!</author-notes>).)*</author-notes>',
                 lambda m: _Author_corress(m.group(), MetaCoress), cnt, 0, re.I | re.S)

    MetaCorr1 = re.search(r'<corresp(?: [^>]*)>(?:(?!<ext-link(?: [^>]*)>).)*(<ext-link [^>]*>(?:(?!</ext-link>).)*</ext-link>)(?:(?!</corresp>).)*</corresp>', MetaCnt, re.I | re.S)

    if MetaCorr1:
        cnt = re.sub(r'(<corresp(?: [^>]*)>(?:(?!<email [^>]*>).)*)((?:(?!</email>).)*</email>)((?:(?!</corresp>).)*</corresp>)', r'\g<1>'+MetaCorr1.group(1)+'\g<3>', cnt, 0, re.I | re.S)

    MetaPubDate = ""
    for PubDate in re.finditer(r'(<pub-date(?: [^>]*)?)/>', MetaCnt, re.I | re.S):
        PubVar = re.sub(r' date-type="[pe]pub"', r' date-type="pub"', PubDate.group(1), 0, re.I)
        PubVar = re.sub(r'<pub-date ',
                        r'<pub-date iso-8601-date="' + str(cYear) + '-' + str(cMonth) + '-' + str(cDay) + '" ', PubVar,
                        0, re.I)
        PubVar = f"{PubVar}><day>{cDay}</day><month>{cMonth}</month><year>{cYear}</year></pub-date>"
        MetaPubDate += PubVar + '\n'

    if (MetaPubDate):
        cnt = re.sub(r'<pub-date(?: [^>]*)? pub-type="[^"]+">(?:(?!</pub-date>).)*</pub-date>', '', cnt, 0, re.I | re.S)
        cnt = re.sub(r'</author-notes>', '\g<0>\n' + MetaPubDate, cnt, 0, re.I | re.S)

    cnt = re.sub(r'<fpage/>', '<fpage>0</fpage>', cnt, re.I | re.S)
    cnt = re.sub(r'<lpage/>', '<lpage>0</lpage>', cnt, re.I | re.S)

    # histroy
    cnt = re.sub(r'<history(?: [^>]+)?>(?:(?!</history>).)+</history>', lambda m: History(m.group()), cnt, 0,
                 re.I | re.S)
    MetaDate = ""
    for m in re.finditer(
            r'<date(?: [^>]*)? date-type="(received|accepted|revised)"(?: [^>]*)?>((?:(?!</date>).)*)</date>', MetaCnt,
            re.I | re.S):
        tmp = m.group()
        HYear = re.search(r'<year>((?:(?!</year>).)*)</year>', tmp, re.I)
        if HYear:
            HYear = HYear.group(1)
        else:
            HYear = ""
        HMonth = re.search(r'<month>((?:(?!</month>).)*)</month>', tmp, re.I)
        if HMonth:
            HMonth = HMonth.group(1)
        else:
            HMonth = ""
        HDay = re.search(r'<day>((?:(?!</day>).)*)</day>', tmp, re.I)
        if HDay:
            HDay = HDay.group(1)
        else:
            HDay = ""
        tmp = re.sub(r'(<date(?: [^>]*)?)>',
                     r'\g<1> iso-8601-date="' + str(HYear) + '-' + str(HMonth) + '-' + str(HDay) + '">', tmp, 0,
                     re.I | re.S)
        MetaDate += str(tmp) + '\n'
    if MetaDate:
        cnt = re.sub(r'<history(?: [^>]*)?>((?:(?!</history>).)*)</history>',
                     r'<history>\n' + str(MetaDate) + '\g<1></history>', cnt, 0, re.I | re.S)
        cnt = re.sub(r'<history/>', r'<history>\n' + str(MetaDate) + '\n</history>', cnt, 0, re.I | re.S)
    # exit(cnt)
    his = re.search(r'<history(?: [^>]+)?>(?:(?!</history>).)+</history>', cnt, re.I | re.S);
    if (his):
        if (re.search(r'<permissions\/?>', cnt, re.I)):
            cnt = re.sub(his.group(), r'', cnt, 0, re.I | re.S);
            cnt = re.sub(r'<permissions\/?>', his.group() + '\n' + r'\g<0>', cnt, 0, re.I | re.S);
    cnt = re.sub(r'<history(?: [^>]+)?>\s*</history>', r'', cnt, 0, re.I | re.S);
    cnt = re.sub(r'<history ?\/>', r'', cnt, 0, re.I | re.S);
    cnt = re.sub(r'&del;', r'', cnt, 0, re.I);

    # abstract
    cnt = re.sub(r'<abstract(?: [^>]+)?>(?:(?!</abstract>).)+</abstract>', lambda m: Abstract(m.group()), cnt, 0,
                 re.I | re.S);
    abs = re.search(r'(?:<abstract(?: [^>]+)?>(?:(?!</abstract>).)*</abstract>\s*)+', cnt, re.I | re.S);
    if (abs):
        tAbs = '';
        for m in re.finditer(r'<trans-abstract(?: [^>]+)?>(?:(?!</trans-abstract>).)*</trans-abstract>', cnt,
                             re.I | re.S):
            tAbs += m.group() + '\n'
        cnt = re.sub(r'<trans-abstract(?: [^>]+)?>(?:(?!</trans-abstract>).)*</trans-abstract>', r'', cnt, 0,
                     re.I | re.S)
        if len(tAbs):
            cnt = re.sub(r'(?:<abstract(?: [^>]+)?>(?:(?!</abstract>).)*</abstract>\s*)+', r'\g<0>' + str(tAbs), cnt, 0,
                         re.I | re.S);
    cnt = re.sub(r':\s*</title>', r'</title>', cnt, 0, re.I | re.S)

    # kwd-group
    cnt = re.sub(r'<kwd-group(?: [^>]+)?>(?:(?!</kwd-group>).)+</kwd-group>', lambda m: KwdGroup(m.group()), cnt, 0,
                 re.I | re.S);

    # Remove {odel}{cdel} content
    for m in re.finditer(r'<abstract(?: [^>]*)?>(?:(?!</abstract>).)*(\{\{\?odel\?\}\}(?:(?!\{\{\?cdel\?\}\}).)*\{\{\?cdel\?\}\})(?:(?!</abstract>).)*</abstract>', cnt, re.I | re.S):
        var=m.group()
        var1=var.replace('{{?odel?}}','{{?xdel?}}')
        var1=var1.replace('{{?cdel?}}','{{?ydel?}}')
        var1=var1.replace('{{?oins?}}','{{?xins?}}')
        var1=var1.replace('{{?cins?}}','{{?yins?}}')
        cnt=cnt.replace(var,var1)


    # Remove {odel}{cdel} content
    for m in re.finditer(r'<kwd-group(?: [^>]*)?>(?:(?!</kwd-group>).)*(\{\{\?odel\?\}\}(?:(?!\{\{\?cdel\?\}\}).)*\{\{\?cdel\?\}\})(?:(?!</kwd-group>).)*</kwd-group>',cnt, re.I | re.S):
        var = m.group()
        var1 = var.replace('{{?odel?}}', '{{?xdel?}}')
        var1 = var1.replace('{{?cdel?}}', '{{?ydel?}}')
        var1 = var1.replace('{{?oins?}}', '{{?xins?}}')
        var1 = var1.replace('{{?cins?}}', '{{?yins?}}')
        cnt = cnt.replace(var, var1)

    # Remove {odel}{cdel} content
    cnt = re.sub(r'\{\{\?odel\?\}\}(?:(?!\{\{\?cdel\?\}\}).)*\{\{\?cdel\?\}\}', r'', cnt, 0, re.I | re.S)
    # Remove {oins}{cins} tag
    cnt = re.sub(r'\{\{\?oins\?\}\}((?:(?!\{\{\?cins\?\}\}).)*)\{\{\?cins\?\}\}', r'\g<1>', cnt, 0, re.I | re.S)

    # Remove {odel}{cdel} content
    for m in re.finditer(r'<abstract(?: [^>]*)?>(?:(?!</abstract>).)*(\{\{\?xdel\?\}\}(?:(?!\{\{\?ydel\?\}\}).)*\{\{\?ydel\?\}\})(?:(?!</abstract>).)*</abstract>',cnt, re.I | re.S):
        var = m.group()
        var1 = var.replace('{{?xdel?}}', '{{?odel?}}')
        var1 = var1.replace('{{?ydel?}}', '{{?cdel?}}')
        var1 = var1.replace('{{?xins?}}', '{{?oins?}}')
        var1 = var1.replace('{{?yins?}}', '{{?cins?}}')
        cnt = cnt.replace(var, var1)

    # Remove {odel}{cdel} content
    for m in re.finditer(r'<kwd-group(?: [^>]*)?>(?:(?!</kwd-group>).)*(\{\{\?xdel\?\}\}(?:(?!\{\{\?ydel\?\}\}).)*\{\{\?ydel\?\}\})(?:(?!</kwd-group>).)*</kwd-group>',cnt, re.I | re.S):
        var = m.group()
        var1 = var.replace('{{?xdel?}}', '{{?odel?}}')
        var1 = var1.replace('{{?ydel?}}', '{{?cdel?}}')
        var1 = var1.replace('{{?xins?}}', '{{?oins?}}')
        var1 = var1.replace('{{?yins?}}', '{{?cins?}}')
        cnt = cnt.replace(var, var1)


    # MetaCount
    MetaCount = re.search(r'<counts(?: [^>]*)?>(?:(?!</counts>).)*</counts>', MetaCnt, re.I | re.S)
    if MetaCount:
        MetaCount = re.sub(r'<fig-count(?: [^>]*)?/?>', r'<fig-count count="' + str(len(figcount)) + '"/>',
                           MetaCount.group(), 0, re.I | re.S)
        MetaCount = re.sub(r'<table-count(?: [^>]*)?/?>', r'<table-count count="' + str(len(tablecount)) + '"/>',
                           MetaCount, 0, re.I | re.S)
        MetaCount = re.sub(r'<equation-count(?: [^>]*)?/?>', r'<equation-count count="' + str(len(dispcount)) + '"/>',
                           MetaCount, 0, re.I | re.S)
        MetaCount = re.sub(r'<ref-count(?: [^>]*)?/?>', r'<ref-count count="' + str(len(refcount)) + '"/>', MetaCount,
                           0, re.I | re.S)
        MetaCount = re.sub(r'<count(?: [^>]*)?/>', r'', MetaCount, 0, re.I | re.S)
        cnt = re.sub(r'</article-meta>', r'\n' + str(MetaCount) + r'\n</article-meta>', cnt, re.I | re.S)

    CustomMeta = ""
    for m in re.finditer(
            r'<custom-meta(?: [^>]*)?>\s*<meta-name>(?:peer-reviewed|academic-content|EContentType|rightslink)</meta-name>\s*<meta-value>((?:(?!</meta-value>).)*)</meta-value>\s*</custom-meta>',
            MetaCnt, re.I | re.S):
        CustomMeta += m.group()
    if (CustomMeta):
        cnt = re.sub(r'</article-meta>', '<custom-meta-group>\n' + str(CustomMeta) + r'\n</custom-meta-group>\n\g<0>',
                     cnt, 0, re.I | re.S)

    # funding
    fund = re.search(
        r'<fund(?: [^>]+)?>(?:(?!</?(?:fund|funding-source)[ >]).)*<funding-source(?: [^>]+)?>(?:(?!</?funding-source>).)*</funding-source>(?:(?!</?fund>).)*</fund>',
        content, re.I | re.S);

    if (fund):
        fundGrp = '';
        fundGrp += '<funding-group>\n';
        for f in re.finditer(r'<funding-source(?: [^>]+)?>((?:(?!</funding-source>).)+)</funding-source>', fund.group(),
                             re.I | re.S):
            fundGrp += '<award-group><funding-source>\n' + r'<named-content content-type="funder-name">' + str(
                f.group(1)) + '</named-content>\n</funding-source>\n</award-group>\n';
        fundGrp += '</funding-group>\n';
        fundGrp = re.sub(r'<funding-group>\s*</funding-group>', r'', fundGrp, 0, re.I | re.S);

        for c in re.finditer(r'<conference(?: [^>]+)?>(?:(?!</conference>).)*</conference>', cnt, re.I | re.S):
            fundGrp += c.group() + '\n';
            cnt = re.sub(c.group(), r'', cnt, 0, re.I | re.S);
        if len(fundGrp):
            cnt = re.sub(r'</article-meta>', str(fundGrp) + r'\g<0>', cnt, 0, re.I);

    return cnt


def PreFormat(txt):
    txt = RemoveTag(txt, 'p')
    return (txt)


def BodyConversion(cnt):
    cnt = re.sub(
        r'(?:<chem-struct-wrap>\s*)?(<chem-struct(?: [^>]*)?>(?:(?!</chem-struct>).)*</chem-struct>)(?:\s*</chem-struct-wrap>)?',
        r'<chem-struct-wrap>\g<1></chem-struct-wrap>', cnt, 0, re.I | re.S);
    cnt = re.sub(r'<preformat(?: [^>]*)?>(?:(?!</preformat>).)+</preformat>', lambda m: PreFormat(m.group()), cnt, 0,
                 re.I | re.S);
    cnt = re.sub(r'<disp-quote(?: [^>]+)?>(?:(?!</disp-quote>).)+</disp-quote>', lambda m: disp_quotegroup(m.group()),
                 cnt, 0, re.I | re.S)

    return cnt


def secReOrder(txt):
    txt = re.sub(r'<(sec\d+)((?: [^>]+)?>(?:(?!</?\1>).)*)</\1>', r'<sec\g<2></sec>', txt, 0, re.I | re.S);

    if (re.search(r'<(sec\d+)(?: [^>]+)?>(?:(?!</?\1>).)*</\1>', txt, re.S | re.I)):
        txt = re.sub(r'(<(sec\d+)(?: [^>]+)?>(?:(?!</?\2>).)*</\2>)((?:(?!</sec>).)*</sec>)', r'\g<3>' + '\n' + '\g<1>',
                     txt, 0, re.I | re.S);
        txt = secReOrder(txt);

    txt = re.sub('\n+', '\n', txt, 0);

    return txt


fnxref = {}


def _backfnid(txt, no):
    fi = re.search(r'<fn [^><]*id="([^"]+)"', txt, re.I)
    if fi:
        newId = 'fn' + str(no).zfill(3)
        fnxref[fi.group(1)] = newId
        txt = re.sub(r'(<fn(?: [^>]+)?) id="[^"]*"', r'\g<1> id="' + str(newId) + '"', txt, 0, re.I)
    return txt


def backFn(txt):
    # txt = re.sub(r'(<fn(?: [^>]+)?>)(\s*<p>\s*)(<label>(?:(?!</?label[ >]).)*</label>)',r'\g<1>\g<3>\g<2>',txt,0,re.I|re.S)
    txt = re.sub(r'(<fn-group(?: [^>]*)? )fn-type="en"((?: [^>]*)?>)', r'\g<1>id="fn-grp"\g<2>', txt, 0, re.I | re.S)
    fnid = itertools.count(1)
    txt = re.sub(r'<fn(?: [^>]+)?>', lambda m: _backfnid(m.group(), next(fnid)), txt, 0, re.I | re.S)
    return txt


def DateCit(txt):
    txt = RemoveTag(txt, 'day,month,year');
    txt = re.sub(r'(</?)date-in-citation((?: [^>]+)?>)', r'\g<1>comment\g<2>', txt, 0, re.I | re.S);
    return txt


def ref_list(txt):
    # Remove {odel}{cdel} content
    txt = re.sub(r'\{\{\?odel\?\}\}(?:(?!\{\{\?cdel\?\}\}).)*\{\{\?cdel\?\}\}', r'', txt, 0, re.I | re.S)
    # Remove {oins}{cins} tag
    txt = re.sub(r'\{\{\?oins\?\}\}((?:(?!\{\{\?cins\?\}\}).)*)\{\{\?cins\?\}\}', r'\g<1>', txt, 0, re.I | re.S)
    return txt


def BackConversion(cnt):
    cnt = re.sub(r'<app-group(?: [^>]+)?>(?:(?!</?app-group>).)+</app-group>', lambda m: boxed(m.group(), ''), cnt, 0,
                 re.I | re.S);
    cnt = _element_leveling(cnt, 'sec');
    cnt = re.sub(r'<(sec[1-9])(?: [^>]+)?>(?:(?!</\1>).)*</\1>', lambda m: secReOrder(m.group()), cnt, 0, re.I | re.S)

    # cnt = re.sub(r'<fn-group(?: [^>]+)?>(?:(?!</fn-group>).)*</fn-group>',lambda m : boxed(m.group(),''),cnt,0,re.I|re.S);
    cnt = re.sub(r'<fn-group(?: [^>]+)?>(?:(?!</fn-group>).)*</fn-group>', lambda m: backFn(m.group()), cnt, 0,
                 re.I | re.S);

    # cnt = re.sub('</fn-group>\s*<fn-group(?: [^>]+)?>',r'',cnt,0);

    # cnt = re.sub(r'(<fn-group(?: [^>]+)?) fn(-type="[^>]*>)',r'\g<1> content\g<2>',cnt,0,re.I|re.S);

    cnt = re.sub(r'<date-in-citation(?: [^>]+)?>(?:(?!</date-in-citation>).)*</date-in-citation>',
                 lambda m: DateCit(m.group()), cnt, 0, re.I | re.S);

    cnt = re.sub(r'&del;', r'', cnt, 0);
    # Remove format inside <conf-name>
    cnt = re.sub(r'(<conf-name(?: [^>]*)?>)\s*<italic>((?:(?!</italic>).)*)</italic>(\)?\s*</conf-name>)',r'\g<1>\g<2>\g<3>', cnt, 0, re.I | re.S)
    cnt = re.sub(r'</mixed-citation>.</ref>', r'.</mixed-citation>.</ref>', cnt, 0, re.I | re.S)


    #cnt = re.sub(r'(<ref-list(?: [^>]*)?>(?:(?!</ref-list>).)*)\{\{\?oins\?\}\}((?:(?!\{\{\?cins\?\}\}).)*)\{\{\?cins\?\}\}((?:(?!</ref-list>).)*</ref-list>)', r'\g<1>\g<2>\g<3>', cnt, 0, re.I | re.S)

    # Remove {oins}{cins} tag
    #cnt = re.sub(r'(<ref-list(?: [^>]*)?>(?:(?!</ref-list>).)*)\{\{\?odel\?\}\}(?:(?!\{\{\?cdel\?\}\}).)*\{\{\?cdel\?\}\}((?:(?!</ref-list>).)*</ref-list>)', r'\g<1>\g<2>', cnt, 0, re.I | re.S)

    # for m in re.finditer(r'<ref-list(?: [^>]*)?>(?:(?!</ref-list>).)*(\{\{\?odel\?\}\}(?:(?!\{\{\?cdel\?\}\}).)*\{\{\?cdel\?\}\})(?:(?!</ref-list>).)*</ref-list>', cnt, re.I | re.S):

    # Remove {odel}{cdel} content
    cnt = re.sub(r'<ref-list(?: [^>]*)?>(?:(?!</ref-list>).)*(\{\{\?odel\?\}\}(?:(?!\{\{\?cdel\?\}\}).)*\{\{\?cdel\?\}\})(?:(?!</ref-list>).)*</ref-list>',lambda m: ref_list(m.group()),cnt, 0, re.I|re.S)


    return cnt


def Graphic(txt, type, no, ext):
    # no = '{0}'.format(str(no).zfill(2));
    # txt = re.sub(r'(<graphic(?: [^>]+)? xlink:href=")[^"]*("[^>]*>)',r'\g<1>'+str(Jid)+'-'+str(vol)+'-'+str(isu)+'-'+str(fpage)+'-g'+str(no)+r'.eps\g<2>',txt,0,re.I);
    txt = re.sub(r'<((?:inline-)?graphic(?: [^>]+)? xlink:href=")[^"]*("[^>]*>)', r'<&del;\g<1>' + str(FileName) + '-' + str(type) + str(no).zfill(3) + r'.' + str(ext) + r'\g<2>', txt,0, re.I)
    return txt

def iGraphic(txt, type, no, ext):
    # no = '{0}'.format(str(no).zfill(2));
    # txt = re.sub(r'(<graphic(?: [^>]+)? xlink:href=")[^"]*("[^>]*>)',r'\g<1>'+str(Jid)+'-'+str(vol)+'-'+str(isu)+'-'+str(fpage)+'-g'+str(no)+r'.eps\g<2>',txt,0,re.I);
    txt = re.sub(r'<((?:inline-)?graphic(?: [^>]+)? xlink:href=")[^"]*("[^>]*>)', r'<&del;\g<1>' + str(FileName) + '_' + str(type) + str(no).zfill(3) + r'.' + str(ext) + r'\g<2>', txt,0, re.I)
    return txt


def _bio(txt, no):
    id = re.search(r'<bio(?: [^>]*)? id="([^"]+)"(?: [^>]*)?>', txt, re.I)
    if id:
        xref[id.group(1)] = 'bio' + str(no)
    txt = re.sub(r'(<bio(?: [^>]*)? id=")[^"]+("(?: [^>]*)?>)', '\g<1>bio' + str(no) + '\g<2>', txt, 0, re.I | re.S)
    return txt


def idReOreder(cnt):
    cnt = re.sub(r'<glossary(?: [^>]+)?>', lambda m: r'<glossary id="gloss">', cnt, 0, re.I | re.S)

    bio = itertools.count(1)
    cnt = re.sub(r'<bio(?: [^>]+)?>', lambda m: _bio(m.group(), next(bio)), cnt, 0, re.I | re.S)

    abstr = itertools.count(1)
    cnt = re.sub(r'<abstract((?: [^>]+)?>)',
                 lambda m: r'<abstract id="abstr' + str(next(abstr)) + '" xml:lang="en"' + str(m.group(1)), cnt, 0,
                 re.I | re.S)

    arrays = itertools.count(1)
    cnt = re.sub(r'<array(?: [^>]+)?>', lambda m: r'<array id="array' + str(next(arrays)) + '">', cnt, 0, re.I | re.S)

    deflist = itertools.count(1)
    cnt = re.sub(r'<def-list(?: [^>]+)?>', lambda m: r'<def-list id="def-list' + str(next(deflist)) + '">', cnt, 0,
                 re.I | re.S)

    refsgrp = itertools.count(1)
    cnt = re.sub(r'<ref-list(?: [^>]+)?>', lambda m: r'<ref-list id="refs' + str(next(refsgrp)) + '">', cnt, 0,
                 re.I | re.S)

    chemgrp = itertools.count(1)
    cnt = re.sub(r'<chem-struct-wrap(?: [^>]+)?>',
                 lambda m: r'<chem-struct-wrap id="chem-grp' + str(next(chemgrp)) + '">', cnt, 0, re.I | re.S)

    chem = itertools.count(1)
    cnt = re.sub(r'<chem-struct(?: [^>]+)?>', lambda m: r'<chem-struct id="chem' + str(next(chem)) + '">', cnt, 0,
                 re.I | re.S)

    Preformat = itertools.count(1)
    cnt = re.sub(r'<preformat( [^>]+)?>', lambda m: r'<preformat id="preform' + str(
        next(Preformat)) + '" orientation="portrait" position="anchor">', cnt, 0, re.I | re.S)

    Listno = itertools.count(1)
    cnt = re.sub(r'<list( [^>]+)?>', lambda m: r'<list id="list' + str(next(Listno)) + '"' + str(m.group(1)) + '>', cnt,
                 0, re.I | re.S)

    statement = itertools.count(1)
    cnt = re.sub(r'(<statement(?: [^>]+)?)>', lambda m: str(m.group(1)) + ' id="stmt' + str(next(statement)) + '">',
                 cnt, 0, re.I | re.S)

    cnt = re.sub(r'<inline-formula(?: [^>]+)?>', lambda m: re.sub(r' id="[^"]+"', r'', m.group(), 0, re.I), cnt, 0,
                 re.I | re.S)

    boxId = itertools.count(1);
    cnt = re.sub(r'<boxed-text(?: [^>]+)?>(?:(?!</?boxed-text[ >]).)+</boxed-text>',
                 lambda m: boxed(m.group(), next(boxId)), cnt, 0, re.I | re.S);

    # section
    cnt = re.sub(r'<front(?: [^>]*)?>(?:(?!</front>).)*</front>',
                 lambda m: re.sub(r'<sec(?: [^>]*)?>', '<&del;sec>', m.group(), 0, re.I | re.S), cnt, 0, re.I | re.S)

    secId = itertools.count(1);
    cnt = _element_leveling(cnt, 'sec');

    # cnt = re.sub(r'<sec([1-9])(?: [^>]+)?>(?:(?!</?sec\1>).)*</sec\1>',lambda m : sectionID(m.group(),next(secId))),cnt,0,re.I|re.S);
    cnt = re.sub(r'<sec1(?: [^>]+)?>(?:(?!</?sec1>).)*</sec1>', lambda m: sectionID1(m.group(), next(secId)), cnt, 0,
                 re.I | re.S);
    cnt = re.sub(r'&del;', r'', cnt, 0);
    cnt = re.sub(r'(</?sec)\d+', r'\g<1>', cnt, 0, re.I | re.S);
    cnt = re.sub(r'(<sec(?: [^>]+)?) id="[^"]*"', r'\g<1>', cnt, 0, re.I | re.S);
    cnt = re.sub(r'(<sec(?: [^>]+)?) new(id="[^"]*")', r'\g<1> \g<2>', cnt, 0, re.I | re.S);
    cnt = re.sub(r'(<sec(?: [^>]+)?) sec-type="[^"]*"', r'\g<1>', cnt, 0, re.I | re.S);
    cnt = re.sub(r'(<sec(?: [^>]+)?) new(sec-type="[^"]*")', r'\g<1> \g<2>', cnt, 0, re.I | re.S);

    # figure
    cnt = re.sub(r'<fig(?: [^>]+)?>(?:(?!</fig>).)*</fig>', lambda n: Figure(n.group()), cnt, 0, re.I | re.S)

    # DispFormula
    Disp = itertools.count(1)
    cnt = re.sub(r'<disp-formula(?: [^>]+)?>', lambda m: DispFormula(m.group(), next(Disp)), cnt, 0, re.I | re.S)

    # table
    tno = itertools.count(1);
    cnt = re.sub(r'<table-wrap(?: [^>]+)?>(?:(?!</table-wrap>).)*</table-wrap>', lambda m: Table(m.group(), next(tno)),
                 cnt, 0, re.I | re.S);

    for id in tfnID:
        replace = tfnID[id];
        cnt = re.sub(r'( r?id="[^"]*\b)' + str(id) + r'(\b[^"]*")', r'\g<1>' + str(replace) + '\g<2>', cnt, 0,
                     re.I | re.S);

    # appendix
    appNo = itertools.count(1);
    cnt = re.sub(r'<app(?: [^>]+)?>(?:(?!</app>).)*</app>', lambda m: appendix(m.group(), next(appNo)), cnt, 0,
                 re.I | re.S);

    # reference
    refId = itertools.count(1);
    cnt = re.sub(r'<ref(?: [^>]+)?>(?:(?!</ref>).)*</ref>', lambda m: Reference(m.group(), next(refId)), cnt, 0,
                 re.I | re.S);

    cnt = re.sub(r'&del;', r'', cnt, 0);

    return cnt


def xrefClean(txt):
    if (re.search(r'</?sup>', txt, re.I)):
        txt = RemoveTag(txt, 'sup');
        txt = r'<sup>' + str(txt) + r'</sup>'
    return (txt);


def CmtClean(txt):
    txt = RemoveTag(txt, 'comment[2-9]+');

    return (txt);


def ArrayTab(txt):
    txt = RemoveTag(txt, 'table')
    txt = re.sub(r'(<td(?: [^>]+)?>\s*)<p>((?:(?!</?td>).)*)</p>(\s*</td>)', r'\g<1>\g<2>\g<3>', txt, 0, re.I | re.S)
    txt = re.sub(r'(<(td|th)(?: [^>]+)?) align="[^"]*"', r'\g<1>', txt, 0, re.I)
    txt = re.sub(r'(<(td|th)(?: [^>]+)?) valign="[^"]*"', r'\g<1>', txt, 0, re.I)
    txt = re.sub(r'(<(td|th)(?: [^>]+)?)(>((?:(?!</\2>).)*)</\2>)',
                 lambda m: m.group(1) + _tableAlign(m.group(3), m.group(4)), txt, 0, re.I)
    txt = re.sub(r'(<td(?: [^>]+)?) width="[^"]*"', r'\g<1>', txt, 0, re.I);
    return txt


def SpeechSpeaker(txt):
    txt = re.sub(r'<speaker>(?:(?!</?speaker>).)*</speaker>(?:(?!</?(?:speaker)>).)*', r'<speech>\g<0></speech>\n', txt,
                 0, re.I | re.S);
    if not (re.search(r'<speech>', txt, re.I)):
        txt = '<speech>' + str(txt) + '</speech>';

    txt = re.sub(r'\s+</speech>', r'</speech>', txt, 0, re.I);

    return (txt)


def _ack(txt):
    txt = re.sub(r'<ack(?: [^>]*)?>', '<ack id="ack">', txt, 0, re.I | re.S)
    txt = re.sub(r'<title(?: [^>]*)?>(?:(?!</title>).)*</title>', '', txt, 0, re.I | re.S)
    return txt


def SupplementaryCleanup(txt):
    fname = FileName
    fname = re.sub(r'(?:\_icore|_epub\d*)?$', r'', fname, 0);
    if os.path.isdir(InPath + '\\Support'):
        links = next(os.walk(InPath + '\\Support'))[2];

        txt = _element_leveling(txt, 'p');

        nonSuppl = '';
        for link in links:
            no = '';
            name = '';
            lk = re.search(r'^' + fname + r'_S(\d+)\.(.*)$', link, re.I);

            if (lk): no = lk.group(1); name = lk.group(2);

            mimType = 'application';
            mimSubType = name;

            if (re.search(r'^(aac|wav|wma)$', name, re.I)):
                mimType = 'audio';
            elif (r'^(avi|flv|mp4)$', name, re.I):
                mimType = 'video';
            elif (r'^wmv$', name, re.I):
                mimType = 'x-ms-wmv';
            elif (r'^mov$', name, re.I):
                mimType = 'quicktime';
            elif (r'^(?:mpg|mp3)$', name, re.I):
                mimType = 'mpeg';

            txt = re.sub(r'<(boxed-text|table-wrap|list|fig)(?: [^>]+)?>(?:(?!</?\1>).)+</\1>',
                         lambda m: list(m.group(), '0'), txt, 0, re.I | re.S);

            uri = re.search(r'<uri [^><]*link="Support(?:&#x002F;|/)' + str(link) + '"[^>]*>((?:(?!</?uri>).)*)</uri>',
                            txt, re.I | re.S);

            if (uri):
                if len(no):
                    txt = re.sub(r'<uri [^><]*link="Support(?:&#x002F;|/)' + str(
                        link) + r'"[^>]*>((?:(?!</?uri>).)*)</uri>((?:(?!</p1>).)*</p1>)',
                                 '<xref ref-type="supplementary-material" rid="SP' + str(
                                     no) + '">\g<1></xref>\g<2>\n<supplementary-material id="SP' + str(
                                     no) + '" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:title="local_file" xlink:href="' + str(
                                     link) + '" mimetype="' + str(
                                     mimType) + '">\n<label>Supplementary data</label><caption><p>Supplementary PDF file supplied by authors.</p></caption>\n</supplementary-material>',
                                 txt, 1, re.I | re.S);
                    txt = re.sub(
                        r'<uri [^><]*link="Support(?:&#x002F;|/)' + str(link) + r'"[^>]*>((?:(?!</?uri>).)*)</uri>',
                        '<xref ref-type="supplementary-material" rid="SP' + str(no) + '">\g<1></xref>', txt, 1,
                        re.I | re.S);
            else:
                nonSuppl += r'<supplementary-material id="SP' + str(
                    no) + '" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:title="local_file" xlink:href="' + str(
                    link) + '" mimetype="' + str(
                    mimType) + '">\n<label>Supplementary data</label><caption><p>Supplementary PDF file supplied by authors.</p></caption>\n</supplementary-material>';
        if len(nonSuppl):
            txt = re.sub(r'<body>(?:(?!</p1>).)*</p1>', '\g<0>\n' + str(nonSuppl), txt, 1, re.I | re.S);
        txt = re.sub(r'&del;', r'', txt, 0);
        txt = re.sub(r'(</?p)\d+', r'\g<1>', txt, 0);

    return (txt);


def uriLink(txt, uri):
    if not (re.search(r'<uri [^><]*\bcontent-type="orcid"', txt, re.I)):
        txt = re.sub(r'&#x002F;', r'/', txt, 0, re.I | re.S);
        uri = re.sub(r'&#x002F;', r'/', uri, 0, re.I | re.S);

        if (re.search(r'^<[a-z0-9:-]+ [^><]*\b(?:link|xlink:href)="[^"]+"', txt, re.I)):
            txt = re.sub(r'^<([a-z0-9:-]+)( [^><]*)(?:link|xlink:href)(="[^"]+"[^>]*>(?:(?!</\1>).)*</)\1>',
                         r'<ext-link ext-link-type="uri"\g<2>xlink:href\g<3>ext-link>', txt, 0, re.I | re.S);
        else:
            uri = RemoveA3B2(uri);
            uri = RemoveTag(uri, '[a-z0-9:-]+');
            if (re.search(r'^https?://', uri, re.I)):

                if (re.search(r'^https?://www.', uri, re.I)):
                    txt = re.sub(r'^<([a-z0-9:-]+)(?: [^>]+)?>((?:(?!</\1>).)*)</\1>',
                                 r'<ext-link ext-link-type="uri" xlink:href="' + str(uri) + r'">\g<2></ext-link>', txt,
                                 0, re.I | re.S);
                else:
                    uri = re.sub(r'^https?://', r'https://www.', uri, 0);
                    txt = re.sub(r'^<([a-z0-9:-]+)(?: [^>]+)?>((?:(?!</\1>).)*)</\1>',
                                 r'<ext-link ext-link-type="uri" xlink:href="' + str(uri) + r'">\g<2></ext-link>', txt,
                                 0, re.I | re.S);
            elif (re.search(r'^www.', uri, re.I)):
                uri = re.sub(r'^www.', r'https://www.', uri, 0);
                txt = re.sub(r'^<([a-z0-9:-]+)(?: [^>]+)?>((?:(?!</\1>).)*)</\1>',
                             r'<ext-link ext-link-type="uri" xlink:href="' + str(uri) + r'">\g<2></ext-link>', txt, 0,
                             re.I | re.S);
            else:
                txt = re.sub(r'^<([a-z0-9:-]+)(?: [^>]+)?>((?:(?!</\1>).)*)</\1>',
                             r'<ext-link ext-link-type="uri" xlink:href="https://www.' + str(
                                 uri) + r'">\g<2></ext-link>', txt, 0, re.I | re.S);

    return txt


def _title_caps(txt):
    if (txt == txt.upper()):
        txt = txt.capitalize()
    return txt


def _AltTitle(txt):
    Tmp = re.search(
        r'<alt-title(?: [^>]*)? alt-title-type="left-running-head"(?: [^>]*)?>((?:(?!</alt-title>).)*)</alt-title>\s*<alt-title(?: [^>]*)? alt-title-type="right-running-head"(?: [^>]*)?>((?:(?!</alt-title>).)*)</alt-title>',
        txt, re.I | re.S)
    if Tmp:
        if (Tmp.group(1) == Tmp.group(2)):
            Tmp = r'<alt-title alt-title-type="running-head">' + str(Tmp.group(1)) + '</alt-title>'
            return Tmp
        else:
            return txt
    else:
        return txt

def _ReplaceQuery(txt):
    print(txt)
    return txt

def _statement(txt):
    txt = re.sub(r'</?p(?: [^>]*)?>', r'', txt, 0, re.I | re.S)
    txt = f'<p>{txt}</p>'
    txt = re.sub(r'<p><label>', r'<label>', txt, 0, re.I)
    txt = re.sub(r'</label>', r'</label><p>', txt, 0, re.I)
    return txt

def _Xref(txt):
    txt = re.sub(r'\)</xref>', r'</xref>)', txt, 0, re.I)
    return txt

def _removetagspace(txt):
    txt = re.sub(r'<p>\s+', r'<p>', txt, 0, re.I)
    return txt

def _removeunwantedspace(txt):
    txt = re.sub(r'> ', r'>', txt, 0, re.I)
    return txt

def _removeunwantedtag(txt):
    txt = re.sub(r'</p></p>', r'</p>', txt, 0, re.I)
    return txt

def _replacetag(txt):
    txt = re.sub(r'<label>((?: [^>]*)?)</label>', r'', txt, 0 , re.I)
    return txt

def PostCleanup(cnt):
    cnt = re.sub(r'<x>(\s*.,\s*)</x>', r'\g<1>', cnt, 0, re.I | re.S);
    cnt = re.sub(r'<xref [^><]*ref-type="(?:fig|table|bibr)"[^>]*>(?:(?!</?xref[ >]).)+</xref>',
                 lambda m: xrefClean(m.group()), cnt, 0, re.I | re.S);
    cnt = re.sub(r'</xref></sup><sup>', r'</xref>', cnt, 0, re.I | re.S);
    cnt = re.sub(r'</sup><sup><xref', r'<xref', cnt, 0, re.I | re.S);
    cnt = re.sub(r'(<xref(?: [^>]+)? ref-type=")EN("[^>]*>)', r'\g<1>fn\g<2>', cnt, 0, re.I | re.S);
    cnt = re.sub(r'(<xref(?: [^>]+)? ref-type=")bio("[^>]*>)', r'\g<1>contrib\g<2>', cnt, 0, re.I | re.S);
    # v1.0.0.10
    cnt = re.sub(r'(<xref(?: [^>]+)? )(rid="app)', r'\g<1>ref-type="app" \g<2>', cnt, 0, re.I | re.S);
    # --
    cnt = re.sub(r'(<title(?: [^>]*)?>)((?:(?!</title>).)*)(</title>)',
                 lambda m: m.group(1) + _title_caps(m.group(2)) + m.group(3), cnt, 0, re.I | re.S)

    query = {};
    for m in re.finditer(
            r'<query(?: [^>]*)? id="([^"]+)">(?:(?!</query>).)*<query-text>((?:(?!</query-text>).)*)</query-text>(?:(?!</query>).)*</query>',
            cnt, re.I | re.S):
        query[m.group(1)] = m.group();

    for qid in query:
        # Temp changes req by Stella (query tag changes)
        query[qid] = RemoveTag(query[qid], 'p,query-text')
        #query[qid] = RemoveTag(query[qid], 'p,query-text,query')

        #query[qid] = re.sub(r'(<query(?: [^>]*)?>)(?:AU|PE|LE):\s*',r'\g<1>',query[qid],0,re.I|re.S)
        if (re.search(r'<xref(?: [^>]*)? rid="' + str(qid) + '"[^>]*\/>', cnt, re.I)):
            cnt = re.sub(r'<query(?: [^>]*)? id="' + str(qid) + '">(?:(?!</query>).)*</query>', r'', cnt, 0, re.I | re.S)
            cnt = re.sub(r'<xref(?: [^>]*)? rid="' + str(qid) + '"[^>]*\/>',  r'<!--' + str(query[qid]) + r'-->', cnt, 0, re.I | re.S)
            # cnt = re.sub(r'<xref(?: [^>]*)? rid="' + str(qid) + '"[^>]*\/>', r'<!--' + str(query[qid]) + r'-->', cnt, 0,re.I | re.S)

    cnt = re.sub(r'<aqg>\s*(<title>Author Queries</title>)?\s*</aqg>', r'', cnt, 0, re.I | re.S)

    cnt = re.sub(r'</?eds(?: [^>]+)?>', r'', cnt, 0, re.I | re.S);

    cnt = _element_leveling(cnt, 'comment');
    cnt = re.sub(r'<(comment1)(?: [^>]+)?>(?:(?!</?\1>).)*</\1>', lambda m: CmtClean(m.group()), cnt, 0, re.I | re.S);
    cnt = re.sub(r'(</?)comment\d+', r'\g<1>comment', cnt, 0, re.I);
    cnt = re.sub(r'(</label>)\s+(<caption>)', r'\g<1>\g<2>', cnt, 0, re.I);

    cnt = re.sub(
        r'(<author-comment(?: [^>]+)?>)(?:\s*<p>)?((?:(?!</?author-comment>).)+)(?:\s*</p>)?(</author-comment>)',
        r'\g<1><p>\g<2></p>\g<3>', cnt, 0, re.I | re.S);
    cnt = re.sub(r'(<bio(?: [^>]+)?>)(?:\s*<p>)?((?:(?!</?bio>).)+)(?:\s*</p>)?(</bio>)', r'\g<1><p>\g<2></p>\g<3>',
                 cnt, 0, re.I | re.S);
    # cnt = re.sub(r'(<notes(?: [^>]+)?>)(?:\s*<p>)?((?:(?!</?notes>).)+)(?:\s*</p>)?(</notes>)',r'\g<1><p>\g<2></p>\g<3>',cnt,0,re.I|re.S);
    cnt = re.sub(r'(<annotation(?: [^>]+)?>)(?:\s*<p>)?((?:(?!</?annotation>).)+)(?:\s*</p>)?(</annotation>)',
                 r'\g<1><p>\g<2></p>\g<3>', cnt, 0, re.I | re.S)
    cnt = re.sub(
        r'(?:<p>)?(<private-char(?: [^>]+)?>)(?:<glyph-data>)?((?:(?!</?private-char>).)+)(?:</glyph-data>)?(</private-char>)(?:</p>)?',
        r'<p>\g<1><glyph-data>\g<2></glyph-data>\g<3></p>', cnt, 0, re.I | re.S)
    # cnt = re.sub(r'(</?)chem-struct-wrap((?: [^>]+)?>)',r'\g<1>chem-struct-wrapper\g<2>',cnt,0,re.I|re.S);

    cnt = re.sub(r'<array(?: [^>]+)?>(?:(?!</?array>).)*</array>', lambda m: ArrayTab(m.group()), cnt, 0, re.I | re.S)

    cnt = re.sub(r'<speech(?: [^>]+)?>((?:(?!</?speech>).)+)</speech>', lambda m: SpeechSpeaker(m.group(1)), cnt, 0, re.I | re.S)

    # v1.0.0.5
    cnt = SupplementaryCleanup(cnt)
    # ---
    #v1.0.0.6
    cnt = re.sub(r'<uri(?: [^>]*)?>((?:(?!</?uri[ >]).)+)</uri>', lambda m: uriLink(m.group(), m.group(1)), cnt, 0,
                 re.I | re.S)
    cnt = re.sub(r'<abstract(?: [^>]+)?>(?:(?!</abstract>).)+</abstract>', lambda m: Abstract(m.group()), cnt, 0,
                 re.I | re.S)
    # ---
    # v1.0.0.7
    cnt = re.sub(r'(<(t[hd])(?: [^>]+)?)>\s*</\2>', r'\g<1>/>', cnt, 0, re.I | re.S);
    # ---
    # contrib cleanup
    cnt = re.sub(r'<contrib(?: [^>]*)?>\s*</contrib>', '', cnt, 0, re.I | re.S)
    # ext-link .,movement
    cnt = re.sub(r'(\.|\,)(</ext-link>)', '\g<2>\g<1>', cnt, 0, re.I | re.S)
    # table set first align
    cnt = re.sub(r'(<tr>\s*<(?:td|th)(?: [^>]*)? align=")[^"]+("(?: [^>]*)?>)', r'\g<1>left\g<2>', cnt, 0, re.I | re.S)
    cnt = re.sub(r'(<tr>\s*<(?:td|th)(?: [^>]*)?) char="[^"]+"((?: [^>]*)?>)', r'\g<1>\g<2>', cnt, 0, re.I | re.S)
    # inline-formula
    cnt = re.sub(r'<(inline-formula|disp-formula)(?: [^>]*)?>(?:(?!</\1>).)*</\1>',
                 lambda m: _MathAtrib(m.group(1), m.group()), cnt, 0, re.I | re.S)
    # ack
    cnt = re.sub(r'<ack(?: [^>]+)?>(?:(?!</ack>).)*</ack>', lambda m: _ack(m.group()), cnt, 0, re.I | re.S)
    # back xref replace
    for id in fnxref:
        replace = fnxref[id]
        cnt = re.sub(r'( rid="[^"]*\b)' + str(id) + r'(\b[^"]*")', r'\g<1>' + str(replace) + '\g<2>', cnt, 0,
                     re.I | re.S)
    # v1.0.0.9
    cnt = re.sub(r'<p>(\s*)?</p>(\s*)?', r'', cnt, 0);
    # v1.0.0.10
    cnt = re.sub(r'<colgroup(?: [^>]*)?>(?:(?!</colgroup>).)*</colgroup>',
                 lambda m: re.sub(r'(<col(?: [^>]*)? align=")center("(?: [^>]*)?/?>)', r'\g<1>left\g<2>', m.group(), 0,
                                  re.I | re.S), cnt, 0, re.I | re.S)
    # --
    # inline-graphic
    cnt = re.sub(r'<inline-graphic [^><]*xlink:href="[^"]*"[^>]*>',
                 lambda m: iGraphic(m.group(), 'fx', next(ImageIdCount), 'eps'), cnt, 0, re.I | re.S)


    cnt = re.sub(r'<fn(?: [^>]*)?>\s*</fn>', r'', cnt, 0, re.I | re.S)

    cnt = re.sub(
        r'<alt-title(?: [^>]*)? alt-title-type="left-running-head"(?: [^>]*)?>((?:(?!</alt-title>).)*)</alt-title>\s*<alt-title(?: [^>]*)? alt-title-type="right-running-head"(?: [^>]*)?>((?:(?!</alt-title>).)*)</alt-title>',
        lambda m: _AltTitle(m.group()), cnt, 0, re.I | re.S)

    cnt = re.sub('<title/>', '', cnt, 0, re.S)

    # v1.0.10.0
    cnt = re.sub(r'(<fn-group(?: [^>]*)?) fn-type="en"((?: [^>]*)?>)', r'\g<1>\g<2>', cnt, 0, re.I | re.S)
    cnt = re.sub(r'(<statement(?: [^>]+)?>)((?:(?!</statement>).)*)(</statement>)',
                 lambda m: m.group(1) + _statement(m.group(2)) + m.group(3), cnt, 0, re.I | re.S)

    # v1.0.9.0
    cnt = re.sub(r'\{\{\?odel\?\}\}', r'<!--DEL-->', cnt, 0, re.I | re.S)
    cnt = re.sub(r'\{\{\?cdel\?\}\}', r'<!--/DEL-->', cnt, 0, re.I | re.S)
    cnt = re.sub(r'\{\{\?oins\?\}\}', r'<!--INS-->', cnt, 0, re.I | re.S)
    cnt = re.sub(r'\{\{\?cins\?\}\}', r'<!--/INS-->', cnt, 0, re.I | re.S)
    cnt = re.sub(r'<mixed-citation(?: [^>]*)?>(?:(?!</mixed-citation>).)*</mixed-citation>',
                 lambda m: re.sub(r'</?(?:day|month)>', r'', m.group(), 0, re.I | re.S), cnt, 0, re.I | re.S)
    Queryseq = itertools.count(1)
    cnt = re.sub(r'(<query(?: [^>]*)? id="[a-z]+)\d+("(?: [^>]*)?>)',
                 lambda m: f"{m.group(1)}{next(Queryseq)}{m.group(2)}", cnt, 0, re.I | re.S)
    cnt = re.sub(r'\(<xref(?: [^>]*)? ref-type="bibr"(?: [^>]*)?>(?:(?!</xref>).)*</xref>', lambda m: _Xref(m.group()),
                 cnt, 0, re.I | re.S)
    cnt = re.sub(r'(</label>)\s*(<title(?: [^>]*)?>)', r'\g<1> \g<2>', cnt, 0, re.I | re.S)
    cnt = re.sub(r'(</label>)\s*(<p(?: [^>]*)?>)', r'\g<1> \g<2>', cnt, 0, re.I | re.S)
    cnt = re.sub(r'&#x003F;', r'?', cnt, 0, re.I | re.S)
    cnt = re.sub(r'&#x0021;', r'!', cnt, 0, re.I | re.S)
    cnt = re.sub(r'&#x0026;', r'&amp;', cnt, 0, re.I | re.S)
    cnt = re.sub(r'<mml:math(?: [^>]*)?>', lambda m: re.sub(r'\'', r'"', m.group(), 0, re.I), cnt, 0, re.I | re.S)
    cnt = re.sub(r'(</label>\s*)((?:<\!--(DEL|INS)-->(?:(?!<\!--/\3-->).)*<\!--/\3-->)+)', r'\g<2>\g<1>', cnt, 0,
                 re.I | re.S)
    cnt = re.sub(r'</kwd-group>\s*, and', r'</kwd-group>', cnt, 0, re.I | re.S)
    cnt = re.sub(r'</funding-group>\s*, and', r'</funding-group>', cnt, 0, re.I | re.S)

    # ---

    cnt = re.sub('[\n\r][\n\r]+', '\n', cnt, 0, re.S)
    cnt = re.sub('\t+', '', cnt, 0, re.S)
    cnt = re.sub('^\s+<', '<', cnt, 0, re.M)
    cnt = re.sub('\n+', '\n', cnt, 0, re.S)
    cnt = re.sub(r'(</?)&del;', r'\g<1>', cnt, 0)

    cnt = re.sub(r'<mml:math(?: [^>]*)?>(?:(?!</mml:math>).)*</mml:math>',
                 lambda m: re.sub(r'\n', '', m.group(), 0, re.I | re.S), cnt, 0, re.I | re.S)
    cnt = re.sub(r'<sub>(\s*<(?:inline-)?graphic(?: [^>]*)/>\s*)</sub>', r'\g<1>', cnt, 0, re.I | re.S)

    # xref corresp cleanup
    cnt = re.sub(r'(<xref(?: [^>]+)? ref-type=\")corresp(\"[^>]*>)', '', cnt, re.I | re.S)
    # ext-link xlink removal
    # ext_link_xlink = re.search(r'<ext-link(?: [^>]+)? ext-link-type=\"email\" (xmlns.*xlink\"\s+).*</ext-link>', cnt)
    # if ext_link_xlink:
    #     cnt = re.sub(ext_link_xlink.group(1), r'', cnt, 0, re.I | re.S)
    # fn-group removal
    fn_group = re.findall(r'(<fn-group>)((?:(?!</fn-group>).)*)(</fn-group>)', cnt, re.I | re.S)
    #lst_fn_group = [item for t in fn_group for item in t if fn_group]
    #fn_group_txt = [res.replace('<fn-group>', '').replace('</fn-group>', '') for res in lst_fn_group if fn_group]
    if fn_group:
        cnt = re.sub(r'(<fn-group>)((?:(?!</fn-group>).)*)(</fn-group>)', r'\n\g<2>\n', cnt, 0, re.I | re.S)
        cnt = re.sub(r'\n\n','', cnt, re.I | re.S)

    cnt = re.sub(r'<statement [^><]*content-type[^><]*>((?:(?!</statement>).)+)</statement>', lambda m: _removetagspace(m.group()),cnt, 0, re.I | re.S)
    cnt = re.sub(r'<compound-subject-part [^><]*content-type[^><]*>((?:(?!</compound-subject>).)+)</compound-subject>',
                 lambda m: _removeunwantedspace(m.group()), cnt, 0, re.I | re.S)
    cnt = re.sub(r'<bio(?: [^>]*)? id=\"bio1\"(?: [^>]*)?>(?:(?!</bio>).)*</bio>', lambda m: _removeunwantedtag(m.group()), cnt, 0, re.I | re.S)

    cnt = re.sub(r'(<disp-formula(?: [^>]*)?>)((?:(?!</disp-formula>).)*)(<label>(?:(?!</label>).)*</label>)((?:(?!</disp-formula>).)*)(</disp-formula>)', r'\g<1>\g<3><alternatives>\g<2>\g<4></alternatives>\g<5>', cnt, 0, re.I | re.S)

    if re.search(r'<pub-date(?: [^>]+)? publication-format="print"[^>]*?>', cnt, re.I | re.S):
        cnt = re.sub(r'(<pub-date(?: [^>]+)? publication-format=")print("[^>]*?>)', r'\g<1>electronic\g<2>', cnt, 1, re.I | re.S)

    #bio author place change
    dic_cnt={} ;  auth_name=[]; c=0;
    for m in re.finditer(r'<string-name(?: [^>]*)? name-style="western">\s*<given-names>((?:(?!</given-names>).)*)</given-names>\s*<surname>((?:(?!</surname>).)*)</surname>\s*</string-name>',cnt,re.I|re.S):
        names = m.group(1)+' '+m.group(2)
        auth_name.append(names)
    for n in re.finditer(r'<bio(?: [^>]*)? id="bio\d+"[^>]*?>(?:(?!</bio>).)*</bio>',cnt,re.I|re.S):
        if(re.search(r''+auth_name[c]+r'',n.group(),re.I|re.S)):
            auth = re.search(r''+auth_name[c]+r'',n.group(),re.I|re.S)
            dic_cnt[auth.group()] = n.group()
            c=c+1
    for key, values in dic_cnt.items():
        key = key.split(' ')
        cnt = re.sub(r'(<contrib(?: [^>]*)? contrib-type="author"[^>]*?>(?:(?!<string-name ).)*<string-name(?: [^>]*)? name-style="western"[^>]*?><given-names>'+key[0]+r'</given-names>\s*<surname>'+key[1]+r'</surname>(?:(?!</contrib>).)*)(</contrib>)',r'\g<1>'+values+r'\g<2>',cnt,0,re.I|re.S)
        cnt = re.sub(r'<bio((?: [^>]*)?>(?:(?!</contrib>).)*</contrib>)', r'<&#delbio\g<1>', cnt, 0, re.I|re.S)
        cnt = re.sub(r'<bio(?: [^>]*)? id=\"bio\d+\"[^>]*?>(?:(?!</contrib-group>).)*',r'',cnt,0,re.I|re.S)
        cnt = re.sub(r'<&#delbio((?: [^>]*)?>(?:(?!</contrib>).)*</contrib>)', r'<bio\g<1>', cnt, 0, re.I | re.S)
    ########


    for m in re.finditer(r'<contrib(?: [^>]*)?>(?:(?!</contrib>).)*(<xref(?: [^>]*)? ref-type=\"contrib\"[^>]*?/?>)(?:(?!</contrib>).)*</contrib>', cnt,  re.I | re.S):
        cnt = re.sub(m.group(1), r'', cnt, 0, re.I | re.S)
    for m in re.finditer(r'<contrib(?: [^>]*)?>(?:(?!</contrib>).)*(<xref(?: [^>]*)? ref-type=\"corresp\"[^>]*?/?>)(?:(?!</contrib>).)*</contrib>', cnt,  re.I | re.S):
        cnt = re.sub(m.group(1), r'', cnt, 0, re.I | re.S)

    cnt = re.sub(r'(<ack(?: [^>]*)? id=\"ack\"[^>]*?>\s*<p>(?:(?!</p>).)*)</p>(\s*)<p>', r'\g<1>\g<2>', cnt, 0, re.I|re.S)
    # <!--INS--> and <!--DEL--> tag replacement
    cnt = re.sub(r'(<!--INS-->)\s*((<[a-z0-9]+>)+)((?:(?!</[a-z0-9]+>).)*)((</[a-z0-9]+>)+)(<!--/INS-->)', r'\g<2>\g<1>\g<4>\g<7>\g<5>', cnt, 0, re.I | re.S)
    cnt = re.sub(r'(<!--DEL-->)\s*((<[a-z0-9]+>)+)((?:(?!</[a-z0-9]+>).)*)((</[a-z0-9]+>)+)(<!--/DEL-->)', r'\g<2>\g<1>\g<4>\g<7>\g<5>', cnt, 0, re.I | re.S)
    # Temp changes req by Stella (query id 'aq' to 'q')
    cnt = re.sub(r'(<query(?: [^>]*)? id=\")(aq)(\d+\">(?:(?!</query).)*</query>)', r'\g<1>q\g<3>', cnt, 0, re.I | re.S)
    #cnt = re.sub(r'(<!--<query(?: [^>]*)?>)AU\:\s+', r'\g<1>', cnt, 0, re.I | re.S)

    # cnt = re.sub(r'(<pub-date(?: [^>]*)? publication-format=\")(?:print|electronic)(\"[^>]* date-type=\")pub(\") iso-8601-date=\"\"/>', r'\g<1>'+ 'electronic' + '\g<2>' + 'generated' + '\g<3>' + '><year/></pub-date>', cnt, 0, re.I | re.S)

    return cnt

# ---

def _colrowfun(txt):
    if not re.search(r' rowspan="[^"]+"', txt, re.I | re.S) and not re.search(r' colspan="[^"]+"', txt, re.I | re.S):
        txt = re.sub(r'(<t[hd])((?: [^>]*)?/?>)', r'\g<1> rowspan="1" colspan="1"\g<2>', txt, 0, re.I | re.S)
    elif (not re.search(r' rowspan="[^"]+"', txt, re.I | re.S)):
        txt = re.sub(r'(<t[hd])((?: [^>]*)?/?>)', r'\g<1> rowspan="1"\g<2>', txt, 0, re.I | re.S)
    elif (not re.search(r' colspan="[^"]+"', txt, re.I | re.S)):
        txt = re.sub(r'(<t[hd])((?: [^>]*)?/?>)', r'\g<1> colspan="1"\g<2>', txt, 0, re.I | re.S)
    return txt


# v1.0.0.9 for <colgroup> insert.
def TableColgroup(content):
    for m in re.finditer(r'(<table-wrap [^><]*id="([^"]+)"(?: [^>]+)?>(?:(?!</table-wrap>).)*</table-wrap>)', content,
                         re.I | re.S):
        table_cnt = m.group(1);
        table_id = m.group(2);
        tabth = re.search(r'<thead>\s*<tr(?: [^>]+)?>(?:(?!</tr>).)*</tr>', table_cnt, re.I | re.S);
        colgroup = re.search(r'<colgroup(?: [^>]+)?>(?:(?!</colgroup>).)+</colgroup>', table_cnt, re.I | re.S);

        if (tabth):
            for n in re.finditer(r'<thead>\s*(<tr(?: [^>]+)?>(?:(?!</tr>).)*</tr>)', table_cnt, re.I | re.S):
                table_cnt1 = n.group(1);
                add_col = '';
                for n1 in re.finditer(r'<th(?: [^>]*)?/?>', table_cnt1, re.I | re.S):
                    ColSpan = re.search(r' colspan="([^"]+)"', n1.group(), re.I | re.S)
                    if ColSpan:
                        try:
                            for tab1 in range(int(ColSpan.group(1))):
                                add_col += '<col width="1*" align="center" span="1"/>\n'
                        except:
                            pass
                    else:
                        add_col += '<col width="1*" align="center" span="1"/>\n'
                if (add_col):
                    content = re.sub(r'(<table-wrap [^><]*id="' + str(table_id) + '"(?: [^>]+)?>(?:(?!<thead>).)*)',
                                     r'\g<1>\n<colgroup>\n' + str(add_col) + '\n</colgroup>\n', content, 1, re.I | re.S)


        else:
            tabtd = re.search(r'<tbody>\s*<tr(?: [^>]+)?>(?:(?!</tr>).)*</tr>', table_cnt, re.I | re.S);
            if (tabtd):
                for n in re.finditer(r'<tbody>\s*(<tr(?: [^>]+)?>(?:(?!</tr>).)*</tr>)', table_cnt, re.I | re.S):
                    table_cnt1 = n.group(1);
                    add_col = '';
                    for n1 in re.finditer(r'<td(?: [^>]*)?/?>', table_cnt1, re.I | re.S):
                        ColSpan = re.search(r' colspan="([^"]+)"', n1.group(), re.I | re.S)
                        if ColSpan:
                            try:
                                for tab2 in range(int(ColSpan.group(1))):
                                    add_col += '<col width="1*" align="center" span="1"/>\n'
                            except:
                                pass
                        else:
                            add_col += '<col width="1*" align="center" span="1"/>\n'
                    if (add_col):
                        content = re.sub(r'(<table-wrap [^><]*id="' + str(table_id) + '"(?: [^>]+)?>(?:(?!<tbody>).)*)',
                                         r'\g<1>\n<colgroup>\n' + str(add_col) + '\n</colgroup>\n', content, 1,
                                         re.I | re.S)


    content = re.sub(r'<t[hd](?: [^>]*)?>', lambda m: _colrowfun(m.group()), content, 0, re.I | re.S)
    content = re.sub(r'(<colgroup(?: [^>]*)?) cols="[^"]+"((?: [^>]*)?>)', r'\g<1>\g<2>', content, 0, re.I | re.S)
    content = re.sub(r'(<col(?: [^>]*)?) colnum="[^"]+"((?: [^>]*)?>)', r'\g<1>\g<2>', content, 0, re.I | re.S)

    return content


# ----

# Doctype
content = re.sub(r'<!DOCTYPE[^>]*>',
                 r'<!DOCTYPE article PUBLIC "-//NLM//DTD JATS (Z39.96) Journal Archiving and Interchange DTD with MathML3 v1.1d1 20130915//EN" "JATS-archivearticle1-mathml3.dtd">',
                 content, re.I);

# ---Meta data---
MetaCnt = _open_utf8(MetaFile)
# art type
artType = re.search(r'<article(?: [^>]*)? article-type="([^"]+)"(?: [^>]*)?>', MetaCnt, re.I | re.S)
if (artType):
    artType = artType.group(1)
else:
    artType = ''
# language
lang = re.search(r'<article(?: [^>]*)? xml:lang="([^"]+)"(?: [^>]*)?>', MetaCnt, re.I | re.S)
if (lang):
    lang = lang.group(1)
else:
    lang = ''
# Journal ID
Jid = re.search(r'<journal-id [^><]*journal-id-type="publisher"[^><]*>((?:(?!</journal-id>).)+)</journal-id>', MetaCnt,
                re.I | re.S)
if (Jid):
    Jid = Jid.group(1)
else:
    Jid = ''
# Journal ID
JnlTitle = re.search(r'<journal-title(?: [^>]*)?>((?:(?!</journal-title>).)*)</journal-title>', MetaCnt, re.I | re.S)
if (JnlTitle):
    JnlTitle = JnlTitle.group(1)
else:
    JnlTitle = ''
# FigCount
figcount = re.findall(r'<fig(?: [^>]*)?>', content, re.I | re.S)
tablecount = re.findall(r'<table-wrap(?: [^>]*)?>', content, re.I | re.S)
dispcount = re.findall(r'<disp-formula(?: [^>]*)?>', content, re.I | re.S)
refcount = re.findall(r'<ref(?: [^>]*)?>', content, re.I | re.S)

# --end---#


content = re.sub(r'<article(?: [^>]*)?>',
                 r'<article xmlns:mml="http://www.w3.org/1998/Math/MathML" xmlns:xlink="http://www.w3.org/1999/xlink" dtd-version="1.1d1" xml:lang="' + str(
                     lang) + r'" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" article-type="' + str(
                     artType) + r'">', content, re.I);

xref = {};

# Main Process
content = PreCleanup(content)
content = re.sub(r'<front(?: [^>]+)?>(?:(?!</front>).)+</front>', lambda m: FrontConversion(m.group()), content, 0,
                 re.I | re.S)
content = re.sub(r'<body(?: [^>]+)?>(?:(?!</body>).)+</body>', lambda m: BodyConversion(m.group()), content, 0,
                 re.I | re.S)
content = re.sub(r'<back(?: [^>]+)?>(?:(?!</back>).)+</back>', lambda m: BackConversion(m.group()), content, 0,
                 re.I | re.S)


# v1.0.0.10
def ParaRemove(txt):
    txt = re.sub(r'(</?)(p(?: [^>]+)?>)', r'\g<1>&del;\g<2>', txt, 0, re.I);
    return txt


# figure & table movement
# content = _element_leveling(content,'p');
# Floation = '';
# for m in re.finditer(r'<(fig|table-wrap)(?: [^>]+)? id="([FT]\d+)"[^>]*>(?:(?!</?\1[ >]).)*</\1>',content,re.I|re.S):
# content = re.sub(r'<'+m.group(1)+'(?: [^>]+)? id="'+m.group(2)+'"[^>]*>(?:(?!</?'+m.group(1)+'[ >]).)*</'+m.group(1)+'>',r'',content,0,re.I|re.S)
# Floation  += m.group()+'\n'

TableFloation = '';
for m in re.finditer(r'(<table-wrap(?: [^>]*)? position="float"(?: [^>]*)?>)(?:(?!</table-wrap>).)*</table-wrap>',
                     content, re.I | re.S):
    tid = re.search(r' id="(T\d+)"', m.group(1), re.I)
    if (tid):
        content = re.sub(
            r'<table-wrap(?: [^>]+)? id="' + tid.group(1) + '"[^>]*>(?:(?!</?table-wrap[ >]).)*</table-wrap>', r'',
            content, 0, re.I | re.S)
        TableFloation += m.group() + '\n'

FigFloation = '';
for m in re.finditer(r'(<fig(?: [^>]*)? position="float"(?: [^>]*)?>)(?:(?!</fig>).)*</fig>', content, re.I | re.S):
    figid = re.search(r' id="(F\d+)"', m.group(1), re.I)
    if (figid):
        content = re.sub(r'<fig(?: [^>]+)? id="' + figid.group(1) + '"[^>]*>(?:(?!</?fig[ >]).)*</fig>', r'', content,
                         0, re.I | re.S)
        FigFloation += m.group() + '\n'

BoxMovement = ''
for m in re.finditer(r'<boxed-text(?: [^>]*)? id="(BT\d+)"(?: [^>]*)?>(?:(?!</boxed-text>).)*</boxed-text>', content,
                     re.I | re.S):
    content = re.sub(r'<boxed-text(?: [^>]+)? id="' + m.group(1) + '"[^>]*>(?:(?!</boxed-text>).)*</boxed-text>', r'',
                     content, 0, re.I | re.S)
    BoxMovement += m.group() + '\n'

content = content.replace(r'</back>',
                          "</back>\n<floats-group>\n" + str(BoxMovement) + "\n" + str(TableFloation) + "\n" + str(
                              FigFloation) + "\n</floats-group>", 1)

content = idReOreder(content)

content = TableColgroup(content)

content = PostCleanup(content)

# ---

# Id change
for id in xref:
    replace = xref[id]
    content = re.sub(r'( r?id="[^"]*\b)' + str(id) + r'(\b[^"]*")', r'\g<1>' + str(replace) + '\g<2>', content, 0,
                     re.I | re.S)



# content = re.sub(r'(<pub-date(?: [^>]*)? publication-format=\")(?:print|electronic)(\"[^>]* date-type=\")pub(\") iso-8601-date=\"\"/>', r'\g<1>'+ 'electronic' + '\g<2>' + 'generated' + '\g<3>' + '><year/></pub-date>', content, 0, re.I | re.S)
# ---

# save file
_save_utf8(InPath + '\\' + FileName + r'.xml', content)
# out = open(Input,"w+") or Mbox(r'Error', r'Unable to create"'+Input+r'"');
# out.write(content);
# out.close;

# ------ Local tracking -------------
_local_tracking(tool_id, ToolVersion, Tra_input, _get_file_size(Tra_input), st_time, _get_timestamp());
# -----------------------------------

sys.exit('\n\tProcess Completed!!!\n')