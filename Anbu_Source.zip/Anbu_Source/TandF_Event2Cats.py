###################################################################
# 																  #
#  Project Name : TandF_Event2Cats.pl	    					  #
#  Version      : 1.0.0.0                                         #
#  Developed    : ANBU .G |                                       #
#  Purpose		:  Conversion for TandF             			  #
#  Syntax 		:  <EXE> <XML> <CATS_folder> 					  #
#                                                                 #
###################################################################

###################################################################
#
# Run  		  : TandF_Event2Cats.pl <XML> <CATS_folder>
# Note		  : Supporting file (TandF_Event2Cats.ini)
# Description : Convert cats.xml based on Event.xml using TandF_Event2Cats.ini
###################################################################

###################################################################
# Updation History
#=================================================================
#	21-09-2022 | v1.0.0.0 | ANBU .G	Initial Development
###################################################################

import os.path
import re
import sys
import xml.etree.ElementTree as ET
import calendar
from iModule.ToolTracking import _get_timestamp, _local_tracking, _get_file_size

ToolVersion = "1.0.0.0";
# print("\n\n\tCleanUp Tool v" + ToolVersion + " is Running...");
# print("\tCopyright @ Integra Software Services Ltd.\n");


try :
    _eventfile = sys.argv[1]
    _xmldirname = sys.argv[2]

except :
    # src = r'D:\Anbu\XML\pdftest.pdf'
    print("Please Enter Correct input \n\tSyntax    :   <EXE> <XML> <CATS_folder> ")
    sys.exit()

# ------------ Tracking --------------------------------------------
Tra_input = sys.argv[0];
tool_id = 464;  # TandF_Event2Cats
run_size = 1;
st_time = _get_timestamp();
# ------------------------------------------------------------------


dirtname=(_xmldirname)


_err=[]
if getattr(sys,'frozen',False):
    application_path=os.path.dirname(sys.executable)
_catsfilecnt=_xmldirname+"\\Cats.xml"

# _iniFile=r'D:\Giventool\Siva\Old\TandF_Event2Cats.ini'


_iniFile=str(application_path)+'\TandF_Event2Cats.ini'
try:
    with open(_iniFile, "r", encoding="utf-8") as f1:
        inicnt=f1.read()
        f1.close()
except:
    _err.append("ini is missing in toolpath\n")

try:
    with open(_eventfile, "r", encoding="utf-8") as f1:
        eventcnt=f1.read()
        f1.close()
except:
    _err.append("Event.xml not found\n")

try:
    with open(_catsfilecnt, "r", encoding="utf-8") as f1:
        xmlupdcnt=f1.read()
        f1.close()
except:
    _err.append("Cats.xml not found in given folder\n")

if len(_err)!=0:
    # print("\nFAILED ::\nFailed to convert, ")
    # # with open(dirtname+r'\event2catserror.log', "w", encoding="utf-8") as f1:
    # for err in _err:
    #     print(str(err)+"\n")
    #     # f1.close()
    with open(dirtname+r'\event2catserror.log', "w", encoding="utf-8") as f1:
        f1.write("<result>\n<status>False</status>\n")
        for err in _err:
            f1.write("<Msg>"+str(err) + "</Msg>\n")
        f1.write("</result>")
        f1.close()
        print("FAILED :: \n Failed to convert, Please check error log.")
    sys.exit()
# print(inicnt)
xmlfind=''
xmlupdcnt1=re.search(r'(<cats(?: [^>]*)?>)',xmlupdcnt,re.I|re.S)
try:
    xmlupdcnt1.group()
    xmlfind=xmlupdcnt1.group(1)
    xmlupdcnt=xmlupdcnt.replace(xmlfind,'<cats>')
    with open(_catsfilecnt, "w", encoding="utf-8") as f1:
        f1.write(xmlupdcnt)
        f1.close()
except:
    pass

try:
    eventTree = ET.parse(_eventfile)

except:
    _err.append("Tag Mismatched in Eventfile")
    # print("Tag Mismatched in Eventfile")
    pass

try:
    catsTree = ET.parse(_catsfilecnt)
except:
    _err.append("Tag Mismatched in Catsfile")
    # print("Tag Mismatched in Catsfile")
    # sys.exit()

if len(_err)!=0:

    # with open(dirtname+r'\event2catserror.log', "w", encoding="utf-8") as f1:
    #     f1.write("File Parsing Error ::\n\n")
    # print("\nFAILED ::\nFailed to convert, ")
    # print("File Parsing Error ::\n ")
    # for err in _err:
    #     print(str(err) + "\n")
    #     # f1.close()
    #
    # # print("\nProcess completed...!!!")
    with open(dirtname+r'\event2catserror.log', "w", encoding="utf-8") as f1:
        f1.write("<result>\n<status>False</status>\n")
        for err in _err:
            f1.write("<Msg>"+str(err) + "</Msg>\n")
        f1.write("</result>")
        f1.close()
        print("FAILED :: \n Failed to convert, Please check error log.")
    sys.exit()

rootEvent = eventTree.getroot()
rootCats = catsTree.getroot()
# for child in root:
#     print(child)
# qq=root.findall("./Event")
# print(qq)
#
rootEvent.findall(".")
rootCats.findall(".")
# b2tf = rootCats.find('manuscripts/manuscript[@manuscriptid]')
# b2tf.attrib['manuscriptid']="99999"
# # print(b2tf.text)
# catsTree.write(_catsfilecnt)

# for weight_node_loc in rootCats.iter('transmittal'):
#     # catsTree.getroot().remove(weight_node_loc)
#     catsTree.getroot().getchildren().remove(weight_node_loc)
# catsTree.write(_catsfilecnt)
# exit()



changetxt=re.search(r'<change_text(?: [^>]*)?>((?:(?!</change_text>).)*)</change_text>',inicnt,re.I|re.S)
if changetxt:
    changetxt1=changetxt.group(1)
    changetxt1lines=changetxt1.split('\n')
    # print(changetxt1lines)
else:
    changetxt1lines=''

changetxtDirect=re.search(r'<directValue(?: [^>]*)?>((?:(?!</directValue>).)*)</directValue>',inicnt,re.I|re.S)
if changetxtDirect:
    changetxtDirect1=changetxtDirect.group(1)
    changetxtDirectlines=changetxtDirect1.split('\n')
    # print(changetxt1lines)
else:
    changetxtDirectlines=''
changetxtAttrib=re.search(r'<txt2attri(?: [^>]*)?>((?:(?!</txt2attri>).)*)</txt2attri>',inicnt,re.I|re.S)
if changetxtAttrib:
    changetxtAttrib1=changetxtAttrib.group(1)
    changetxtAttriblines=changetxtAttrib1.split('\n')
    # print(changetxt1lines)
else:
    changetxtAttriblines=''
# print(changetxtDirectlines)
# print(changetxtAttriblines)
# exit()


for x in changetxtAttriblines:
    if x!=''and x!='\t':
        # print(x)
        x=re.sub(r'\s*','',x,0,re.I|re.S)
        # x=re.sub(r'\n+','',x,0,re.I|re.S)
        leftcnt=x.split("==")[0]
        rghtcnt=x.split("==")[1]
        rghtcnt12=rghtcnt.split(".")
        attriname=re.search(r'attrib\[\'([a-z]+)\'\]',rghtcnt12[1],re.I|re.S)
        try:
            if attriname:
                attriname11=attriname.group(1)
                # print(leftcnt,rghtcnt)
                bbb1tf = rootEvent.find(leftcnt)

                try:
                    bbb2tf = rootCats.findall(rghtcnt12[0])
                    if(len(bbb2tf)!=0):
                        for xmm in bbb2tf:
                            xmm.attrib[attriname11]=bbb1tf.text
                    else:
                        removetagcats = ''
                        _err.append("'"+leftcnt+"' tag present in event but missing in cats.xml.")



                except:
                    pass
                    removetagcats=''
                    # _err.append(rghtcnt)
        except:
            pass
            # _err.append(rghtcnt)





dict={}
iom=1
for x in changetxt1lines:
    if x!=''and x!='\t':
        # print(x)
        x=re.sub(r'\s*','',x,0,re.I|re.S)
        # x=re.sub(r'\n+','',x,0,re.I|re.S)
        leftcnt=x.split("==")[0]
        rghtcnt=x.split("==")[1]
        # print(leftcnt,rghtcnt)
        b1tf = rootEvent.find(leftcnt)
        try:
            v=b1tf.text

            try:
                b2tf = rootCats.findall(rghtcnt)
                if len(b2tf)!=0:
                    # for tagcont1 in b2tf:
                    for tagcont in b2tf:
                        # print(tagcont.text)
                        # key=tagcont.text
                        # value=b1tf.text
                        tagcont.text=b1tf.text

                        # print(key,"-",value)
                else:
                    _err.append("'"+leftcnt+"' tag present in event but missing in cats.xml.")

            except:
                pass
                # _err.append(rghtcnt)
        except:
            pass


# eventTree.write(_eventfile)


for x in changetxtDirectlines:
    if x!=''and x!='\t':
        # print(x)
        x=re.sub(r'\s*','',x,0,re.I|re.S)
        # x=re.sub(r'\n+','',x,0,re.I|re.S)
        leftcnt=x.split("==")[0]
        rghtcnt=x.split("==")[1]
        rghtcnt1=rghtcnt.split("/")
        rghtcnt11=rghtcnt1[len(rghtcnt1)-1]
        bb1tf = rootEvent.find(leftcnt)
        try:
            v=bb1tf.text
            # if bb1tf:

            try:
                bb2tf = rootCats.find(rghtcnt)
                if len(bb2tf)!=0:
                    bb2tf.tag=rghtcnt11+"tagtoremove"+str(iom)
                    removetagcats=rghtcnt11+"tagtoremove"+str(iom)
                    tag1=bb2tf.tag
                    # dict[bb1tf.text]=removetagcats
                    dict[removetagcats]=bb1tf.text
                    # print(tag1)
                    iom=iom+1
                else:
                    removetagcats = ''
                    _err.append("'"+leftcnt+"' tag present in event but missing in cats.xml.")

            except:
                pass
                removetagcats=''
                # _err.append(rghtcnt)
            # else:
            #     _err.append(leftcnt)
        except:
            pass


# --------------------------------------------------------
MannualPath1='RqDate==transmittal/todate'
MannualPath12='TransmittalType==transmittal/transmittaltype'
# abbmonth=calendar.month_abbr[month_idx]

MannualPathleft1=MannualPath1.split("==")[0]
MannualPathright1=MannualPath1.split("==")[1]
try:
    mm1tf = rootEvent.find(MannualPathleft1)
    date11=mm1tf.text #2022-07-11T22:01:12Z
    datesplit=date11.split("T")[0]
    datesplit1=datesplit.split("-")
    abbmonth = calendar.month_abbr[int(datesplit1[1])]
    finaldate=str(datesplit1[2])+" "+str(abbmonth)+" "+str(datesplit1[0])
except:
    pass

try:
    mm2tf = rootCats.findall(MannualPathright1)
    for dateupdte in mm2tf:
        dateupdte.text=finaldate
except:
    pass


MannualPathleft12=MannualPath12.split("==")[0]
MannualPathright12=MannualPath12.split("==")[1]
tocheckarr1={"TME": "entry","Tagging": "tagging","Typesetting": "initial","Final": "final","Correction": "corrections"}
try:
    mm12tf = rootEvent.find(MannualPathleft12)
    date112=mm12tf.text #['TME','Tagging','Typesetting','Final','Correction']



except:
    pass

try:
    mm22tf = rootCats.findall(MannualPathright12)
    for dateupdte in mm22tf:
        dateupdte.text=tocheckarr1[date112]
except:
    pass


MannualPath3='EarlyxmlFileDueDate==transmittal/earlyxmlFile/requested'
MannualPath32='transmittal/earlyxmlFile'
MannualPathleft3=MannualPath3.split("==")[0]
MannualPathright3=MannualPath3.split("==")[1]

try:
    mm3tf = rootEvent.find(MannualPathleft3)
    try:
        mm31tf = rootCats.find(MannualPathright3)
        mm32tf = rootCats.find(MannualPath32)
        if mm3tf.text:
            mm31tf.text = 'true'
            mm32tf.attrib['includeEarlyPdf'] = 'true'
    except:
        pass
except:
    pass

MannualPath4='TaggedWordFileDueDate==transmittal/taggedWordFile/requested'

MannualPathleft4=MannualPath4.split("==")[0]
MannualPathright4=MannualPath4.split("==")[1]
try:
    mm41tf = rootEvent.find(MannualPathleft4)
    try:
        mm4tf = rootCats.find(MannualPathright4)
        if mm41tf.text:
            mm4tf.text = 'true'
    except:
        pass
except:
    pass



MannualPath5='InitialTypesetFileDueDate==transmittal/initialTypesetFile/requested'

MannualPathleft5=MannualPath5.split("==")[0]
MannualPathright5=MannualPath5.split("==")[1]
try:
    mm51tf = rootEvent.find(MannualPathleft5)
    try:
        mm5tf = rootCats.find(MannualPathright5)
        if mm51tf.text:
            mm5tf.text = 'true'
    except:
        pass
except:
    pass

MannualPath6='PreviewFileDueDate==transmittal/previewFile/requested'

MannualPathleft6=MannualPath6.split("==")[0]
MannualPathright6=MannualPath6.split("==")[1]
try:
    mm61tf = rootEvent.find(MannualPathleft6)
    try:
        mm6tf = rootCats.find(MannualPathright6)
        if mm61tf.text:
            mm6tf.text = 'true'
    except:
        pass
except:
    pass

MannualPath7='PrintFinalFileDueDate==transmittal/printFinalFile/requested'

MannualPathleft7=MannualPath7.split("==")[0]
MannualPathright7=MannualPath7.split("==")[1]
try:
    mm71tf = rootEvent.find(MannualPathleft7)
    try:
        mm7tf = rootCats.find(MannualPathright7)
        if mm71tf.text:
            mm7tf.text = 'true'
    except:
        pass
except:
    pass


MannualPath8='OnlineFinalDueDate==transmittal/onlineFinalFile/requested'

MannualPathleft8=MannualPath8.split("==")[0]
MannualPathright8=MannualPath8.split("==")[1]
try:
    mm81tf = rootEvent.find(MannualPathleft8)
    try:
        mm8tf = rootCats.find(MannualPathright8)
        if mm81tf.text:
            mm8tf.text = 'true'
    except:
        pass
except:
    pass

# -----------------------------------------------------



catsTree.write(_catsfilecnt)

with open(_catsfilecnt, "r", encoding="utf-8") as f1:
    xmlupdcnt=f1.read()
    f1.close()

for tag, value in dict.items():
    # print(value,tag)
    val3=dict[tag]
    xmlupdcnt=re.sub(r'(<'+tag+'(?: [^>]*)?>)(?:(?!</'+tag+'>).)*(</'+tag+'>)',r'\g<1>'+val3+'\g<2>',xmlupdcnt,0,re.I|re.S)

def _hexa(tmp):
    test = chr(int(tmp))
    return test               

# print(xmlupdcnt)
xmlupdcnt=xmlupdcnt.replace("<cats>","<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"+xmlfind)
xmlupdcnt=re.sub(r'tagtoremove\d+',r'',xmlupdcnt,0,re.I|re.S)
xmlupdcnt=re.sub(r'<(\w+) ?/>',r'<\g<1>></\g<1>>',xmlupdcnt,0,re.I|re.S)

xmlupdcnt = re.sub(r'&#([0-9]{3,4});', lambda m: _hexa(m.group(1)), xmlupdcnt, 0, re.I|re.S)
with open(_catsfilecnt, "w", encoding="utf-8") as f1:
    f1.write(xmlupdcnt)
    f1.close()


if len(_err)!=0:
    with open(dirtname+r'\event2catserror.log', "w", encoding="utf-8") as f1:
        f1.write("<result>\n<status>False</status>\n")
        for err in _err:
            f1.write("<Msg>"+str(err) + "</Msg>\n")
        f1.write("</result>")
        f1.close()
        print("FAILED :: \n Failed to convert, Please check error log.")
else:
    with open(dirtname+r'\event2catserror.log', "w", encoding="utf-8") as f1:
        # f1.write("SUCCESS :: \nSuccessfully Completed...!")
        f1.write("<result>\n<status>True</status>\n<Msg></Msg>\n</result>")
        f1.close()

    print("\nProcess completed...!!!")
    sys.exit()
# print(_err)
# ------ Local tracking ------------------
_local_tracking(tool_id, ToolVersion, Tra_input, _get_file_size(Tra_input), st_time, _get_timestamp());
# -----------------------------------------
