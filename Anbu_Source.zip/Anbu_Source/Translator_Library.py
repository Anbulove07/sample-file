from translate import Translator

def translate_text(text, source_lang, target_lang):
    translator = Translator(from_lang=source_lang, to_lang=target_lang)
    translation = translator.translate(text)
    return translation

# Example usage
english_text = "Hello, how are you?"
spanish_translation = translate_text(english_text, 'en', 'ko')
print(spanish_translation)
