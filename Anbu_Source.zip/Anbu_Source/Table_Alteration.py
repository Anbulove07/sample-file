# --------------------------------------------------------------------------
#  Tool Name	: Table_Alteration.py
#  Developer	: Sudhakar V
#  Description  : To modify the table as per the requirement
#  Client/DU	: Pearson
#  Syntax		: <EXE> <.XML_File>
# --------------------------------------------------------------------------

# ------------ Revision History---------------------------------------------
# 26-07-2023 | v1.0.0.0 | Sudhakar V | Initial Development
# --------------------------------------------------------------------------
import sys
import os
import re
from iModule.Basic import _open_utf8


ToolVersion = "1.0.0.0"

if len(sys.argv) != 2 or not os.path.isfile(sys.argv[1]):
    sys.exit("\n\tSyntax: Table_Alteration.exe <XML File>\n")
print(f"\n\n\tTable Alteration v{ToolVersion} is Running...")
print("\tCopyright @ Integra Software Services Ltd.\n")

# Get the XML file path
xml_file_cnt = _open_utf8(sys.argv[1])
for table in re.finditer(r'<table(?: [^>]*)?>((?:(?!</table>).)*)</table>', xml_file_cnt, re.I | re.S):
    tr = re.search(r'<tr(?: [^>]*)?>((?:(?!</tr>).)*)</tr>', table.group(1), re.I | re.S)
    if tr:
        temp=0
        for x in re.finditer(r'<(td|th)(?: [^>]*)?>', tr.group(1), re.I | re.S):
            # print(x.group())
            if re.search(r'colspan=\"(\d+)\"',x.group(),re.I|re.S):
                # print("colspan")
                temp+=int(re.search(r'colspan=\"(\d+)\"',x.group(),re.I|re.S).group(1))
            else:
                temp+=1
        var=''
        for x in range(temp):
            var=var+'<colspec colname="col'+str(x+1)+'"/>'

        tbody=re.sub(r'<tbody(?: [^>]*)?>',f'<tbody cols="{temp}">{var}',table.group(1), re.I|re.S)

        xml_file_cnt = xml_file_cnt.replace(table.group(1),tbody)

xml_file_cnt = re.sub(r'<br/>', r' ', xml_file_cnt, 0, re.I | re.S)
xml_file_cnt = re.sub(r'<td/>', r'<td></td>', xml_file_cnt, 0, re.I | re.S)
xml_file_cnt = re.sub(r'<tr/>', r'<tr></tr>', xml_file_cnt, 0, re.I | re.S)
xml_file_cnt = re.sub(r'<caption></caption>', r'', xml_file_cnt, 0, re.I | re.S)
xml_file_cnt = re.sub(r'<caption/>', r'', xml_file_cnt, 0, re.I | re.S)
xml_file_cnt = re.sub(r'&amp;#x00A0;', r'&#x00A0;', xml_file_cnt, 0, re.I | re.S)
with open((sys.argv[1]).replace(".xml","_output.xml"),'w',encoding='utf-8') as f:
    f.write(xml_file_cnt)
    f.close()
sys.exit("\n\tTable Alteration Completed Successfully...")


