# import extract_msg
# import glob
# import PySimpleGUI as sg
# import sys
# import nltk
# nltk.download('stopwords')
# from nltk.corpus import stopwords
# from nltk.tokenize import word_tokenize
# from nltk.stem import PorterStemmer
# from nltk.stem import WordNetLemmatizer
# import re
import json
import matplotlib.pyplot as plt
from transformers import pipeline

import sys
# import nltk
# # nltk.download('stopwords')
# from nltk.corpus import stopwords
# from nltk.tokenize import word_tokenize, sent_tokenize
# from nltk.stem import PorterStemmer
# from nltk.stem import WordNetLemmatizer
import re
from os.path import basename

model_path = r"SA_model_path"
sentiment_task = pipeline("sentiment-analysis", model=model_path, tokenizer=model_path, device='cpu')





def sentiment_analysis(json_filename):
    file_path = json_filename #'path/to/your/json/file.json'
    with open(file_path, 'r', encoding='utf-8') as json_file:
        data = json.load(json_file)
    # print("data", data)
    # Replace 'key_name' with the actual key you want to extract text from
    data_dict = data
    key_name = 'body'
    # id_key = "id"
    n_of_emails = len(data_dict)
    print(n_of_emails)
    sent_dict = {"positive":[], "neutral":[], "negative":[], "critical":[] }
    for i in data_dict:
        # Check if the key exists in the JSON data
        if key_name in i:
            extracted_text_body = i[key_name]
            id_key = i['id']
            try:
                sentiment_task(extracted_text_body)
                # print("Extracted Text:", extracted_text_body, )
                if sentiment_task(extracted_text_body)[0]['label']=="positive":
                    # my_dict["key1"].extend(values_to_add)
                    sent_dict["positive"].append({"id":id_key, "body":extracted_text_body, "score":sentiment_task(extracted_text_body)[0]['score']})
                elif sentiment_task(extracted_text_body)[0]['label']=="neutral":
                    sent_dict["neutral"].append({"id":id_key, "body":extracted_text_body, "score":sentiment_task(extracted_text_body)[0]['score']})
                elif sentiment_task(extracted_text_body)[0]['label']=="negative" and sentiment_task(extracted_text_body)[0]['score']<=0.8:
                    sent_dict["negative"].append({"id":id_key, "body":extracted_text_body, "score":sentiment_task(extracted_text_body)[0]['score']})
                elif sentiment_task(extracted_text_body)[0]['label']=="negative" and sentiment_task(extracted_text_body)[0]['score'] > 0.8:
                    sent_dict["critical"].append({"id":id_key, "body":extracted_text_body, "score":sentiment_task(extracted_text_body)[0]['score']})
            except RuntimeError as e:
                print(f"error: Email ignored due to longer size, \nRuntimeError: {e}")
        else:
            print(f"Key '{key_name}' not found in the JSON data.")
        print("sent_dict \n", sent_dict)

    # update_list.update({f'{file}':{f'{labels}':f'{dict}'}}) 

    pos_c = len(sent_dict["positive"])
    neu_c = len(sent_dict["neutral"])
    neg_c = len(sent_dict["negative"])
    crit_c = len(sent_dict["critical"])

    labels = ["Positive", "Neutral", "Negative", "Critical"]
    counts = [pos_c, neu_c, neg_c, crit_c]
    # print("counts", counts)
    # print(sent_dict["positive"][0])
    # Plot the bar chart
    # Add text labels on top of the bars

    pos_ids = [dict['id'] for dict in sent_dict["positive"]]

    # print("pos_ids", pos_ids)
    # Write the data to the JSON file
    with open(f'./templates/assest/{basename(json_filename)[:-5]}.json', "w", encoding='utf-8') as json_file:
        json.dump(sent_dict, json_file, indent=4)

    # with open(f'./templates/assest/{basename(json_filename)[:-5]}.json', "r") as json_file:
    #     data_list = json.load(json_file)
    #
    # # Create an HTML table
    # html_table = "<table border='1'><tr><th>ID</th><th>Date</th><th>From</th><th>Body</th></tr>"
    #
    # # Iterate through data and populate the table rows
    # for data in data_list:
    #     html_table += f"<tr><td>{str(data['id'])}</td><td>{str(data['date'])}</td><td>{str(data['From'])}</td><td>{str(data['body'])}</td></tr>"
    #
    # html_table += "</table>"
    #
    # # Write the HTML content to a file
    # html_filename = "./templates/assest/table.html"
    # with open(html_filename, "w") as html_file:
    #     html_file.write(html_table)
    #
    # print(f"Data has been written to ")

    # neu_ids = len(sent_dict["neutral"])
    # neg_ids = len(sent_dict["negative"])
    # crit_ids = len(sent_dict["critical"])
    # for x in counts:
    #     plt.text(x, str(x), ha='center', va='bottom')
    # Create a bar plot
    # plt.bar(labels, counts, color =['green', 'orange', 'blue', 'red'])
    # fig, ax = plt.subplots()
    # bars = ax.bar(labels, counts, color =['green', 'orange', 'tomato', '#cc0000'])
    # for bar in bars:
    #     yval = bar.get_height()
    #     plt.text(bar.get_x() + bar.get_width()/2, yval + 0.2, round(yval, 2), ha='center', va='top')
    #     # plt.text(bar.get_x() + bar.get_width()/2, yval + 1.2, pos_ids, ha='center', va='top')
    #
    # plt.title('Sentiment Labels')
    # plt.xlabel('Sentiment')
    # plt.ylabel('Count')
    # # Display the plot
    # plt.tight_layout(pad=0.5)
    # plt.savefig(f'./templates/assest/{basename(json_filename)[:-5]}.png')
    # plt.show()

    print("Negative emails are :\n", sent_dict["negative"])
    print("Critical emails are : \n", sent_dict["critical"])
    print("Sentiment Analysis Completed")
    return "success" ,labels, counts,[text['id'] for text in sent_dict["negative"]],[text['id'] for text in sent_dict["critical"]] #, sent_dict["critical"]['id']

# json_filename = r'RBJE.json'
# sentiment_analysis(json_filename)



