# ------------------------------------------------------------------
#  Tool Name    : OUP_OxchapML_ATLAS_Package.py
#  Developer    : Premkumar P | CTAE XML
#  Description  : create zip file based on input
#  Client/DU    : OUP / Journal Others
#  Syntax		: <EXE> <FolderPath>
# ------------------------------------------------------------------

# ------------ Rivision History  -----------------------------------
#  26-04-2022 | v1.0.0.0 | Premkumar P | Initial Development
#  04-08-2022 | v1.0.0.1 | Anbu G | MARC Folder Validation and MARC File ISBN Number Validation,
#                                     Cover Image Size, Cover Image Corrupted or Not Validation,
#                                     XLSM File read and get ISBN number.
# ------------------------------------------------------------------

ToolVersion = "1.0.0.0";

import os
from os.path import basename, dirname
import shutil
import sys
import re
from PIL import Image
from iModule.Basic import *
from iModule.ErrorLog import *
from iModule.ToolTracking import *
import csv
import pandas as pd


Toolpath = dirname(sys.argv[0]);
Toolpath = re.sub(r'\/', r'\\', Toolpath, 0)

os.system("cls")
if (len(sys.argv) != 2): sys.exit(
    "\n\tSyntax: OUP_OxchapML_ATLAS_Package.exe <FolderPath>/<ZIP>\n")
if re.search(r'\.zip',sys.argv[1],re.I|re.S):
    ValidationTool = Toolpath+"\\"+"OUP_ATLAS_Package.exe";
    validate = ValidationTool +" "+ sys.argv[1]
    os.system(validate)
    sys.exit()

# Inline argument checking & File path checking
if (len(sys.argv) != 2 or not os.path.isdir(sys.argv[1])): sys.exit(
    "\n\tSyntax: OUP_OxchapML_ATLAS_Package.exe <FolderPath>\n")

print("\n\n\tOUP_OxchapML_OSO_Package v" + str(ToolVersion) + " is Running...\n\n")

# ------------ Tracking --------------------------------------------
Tra_input = sys.argv[1];
tool_id = 463;  # OUP_OxchapML_ATLAS_Package Tool
run_size = 0;
st_time = _get_timestamp();
# ------------------------------------------------------------------

# Global variable declaration
InputDir = sys.argv[1]
path = InputDir
osoISBN = ""
ErrStr1 = ""
arr_txt1 = [x for x in os.listdir(path) if x.endswith(".xlsm")]
if len(arr_txt1)==1:
    # print("OK")
    # YOU MUST PUT sheet_name=None TO READ ALL CSV FILES IN YOUR XLSM FILE
    df = pd.read_excel(path+"\\"+arr_txt1[0], sheet_name=None)
    first_sheet_name = list(df.keys())[0]
    df[first_sheet_name].to_csv(path+"\\FirstSheet.csv")
    rows = []
    with open(path+"\\FirstSheet.csv", 'r',encoding='utf-8') as file:
        csvreader = csv.reader(file)
        header = next(csvreader)
        for row in csvreader:
            rows.append(row)
    # print(len(header))
    # print(header[50])

    # print(len(rows))
    # print(rows[4][4])

    for x in range(len(rows)):
        if rows[x][4]=="Digital-Online":
            ISBNvalue=rows[x][5]
            # print(ISBNvalue)
else:
    ErrStr1 += "[1:1]: Error: [OUP-1000]: 'HO EXCEL' file is missing in input path.\n"
    if ErrStr1:
        CreateErrorLog(InputDir, "OUP OxchapML ATLAS Package Ver " + str(ToolVersion), ErrStr1, 0)
        print("\n\tPlease clear the validation error!!!\n")
        sys.exit(0)

os.remove(path+"\\FirstSheet.csv")
errfile = InputDir + r'_err.htm'
if os.path.isfile(errfile): os.remove(errfile)


# Difference Subroutine:
def Difference(First, Second):
    return (list(set(First) - set(Second)))


def _FileCheck():
    global osoISBN
    ErrStr = ""
    AllFiles = os.listdir(InputDir)
    if 'cover' not in AllFiles:
        ErrStr += "[1:1]: Error: [OUP-1000]: 'cover' folder is missing in input path.\n"

    CoverFiles = os.listdir(InputDir + f'\\cover')
    if (len(CoverFiles) != 0):
        size = os.path.getsize(InputDir + f'\\cover\\'+CoverFiles[0])

        try:
            img = Image.open(InputDir + f'\\cover\\'+CoverFiles[0])  # open the image file
            img.verify()  # verify that it is, in fact an image
        except (IOError, SyntaxError) as e:
            # print('Bad file:', filename)  # print out the names of corrupt files
            ErrStr += f"[1:1]: Error: [OUP-1001]:Cover Image is Corrupted\n"
        # os.listdir(InputDir + f'\\MARC')
        megabytes = size / 1024
        megabytes1 = 61440 / 1024
        # print(size)
        format_float = "{:.2f}".format(megabytes)
        if megabytes > megabytes1:
            # print("File size is ", str(megabytes) + "KB", " Less than 60KB only allowed")
            ErrStr += f"[1:1]: Error: [OUP-1001]:Cover Image File size is {str(format_float)} KB, Less than 60KB only allowed\n"

    if 'print pdf' not in AllFiles:
        ErrStr += "[1:1]: Error: [OUP-1001]: 'print pdf' folder is missing in input path.\n"
    # if 'MARC' not in AllFiles:
    #     ErrStr += "[1:1]: Error: [OUP-1002]: 'MARC' folder is missing in input path.\n"


    ZipFileList = list(filter(re.compile(r'oso-[\d]{13}.zip').match, AllFiles))
    if not (ZipFileList):
        ErrStr += "[1:1]: Error: [OUP-1003]: 'oso' zip file is missing in input path.\n"
    else:
        osoISBN = ZipFileList[0]
    return ErrStr




def _ATLAS_PackageCreation():
    ErrStr = ""
    MarcFiles = os.listdir(InputDir + f'\\MARC')
    if (len(MarcFiles) != 0):

        # ISBN = re.sub(r'oso-([\d]{13}).zip', r'\g<1>', osoISBN, 0, re.I | re.S)
        if not (os.path.isfile(InputDir + f'\\cover\\{ISBN}.jpg')):
            ErrStr += f"[1:1]: Error: [OUP-1004]: '{ISBN}.jpg' file is missing in cover folder.\n"
        PDFISBN = re.sub(r'.zip$', r'', osoISBN, 0, re.I | re.S)
        if not (os.path.isfile(InputDir + f'\\print pdf\\{PDFISBN}.pdf')):
            ErrStr += f"[1:1]: Error: [OUP-1005]: '{PDFISBN}.pdf' file is missing in 'print pdf' folder.\n"
        if (os.path.isfile(InputDir + f'\\MARC\\{ISBN}.marc')):
            ErrStr += f"[1:1]: Error: [OUP-1006]: '{ISBN}.marc' file is not allowed in 'MARC' folder.\n"
        if not (os.path.isfile(InputDir + f'\\MARC\\{ISBNvalue}.marc')):
            ErrStr += f"[1:1]: Error: [OUP-1006]: '{MarcFiles[0]}'Please use the Correct Digital ISBN number as per HO form\n"

        CoverFiles = os.listdir(InputDir + f'\\cover')
        if (len(CoverFiles) > 1):
            ErrStr += "[1:1]: Error: [OUP-1007]: Extra files present in 'cover' folder.\n"
        PDFFiles = os.listdir(InputDir + f'\\print pdf')
        if (len(PDFFiles) > 1):
            ErrStr += "[1:1]: Error: [OUP-1008]: Extra files present in 'print pdf' folder.\n"
        MARCFiles = os.listdir(InputDir + f'\\MARC')
        if not (re.search(r'.marc$', MARCFiles[0], re.I)):
            ErrStr += "[1:1]: Error: [OUP-1009]: '.marc' file is missing in 'MARC' folder.\n"
        if (len(MARCFiles) > 1):
            ErrStr += "[1:1]: Error: [OUP-1010]: Extra files present in 'MARC' folder.\n"
        # unzip
        _extract_zip(InputDir + f'\\{osoISBN}')

        xmlfile = _get_file_list(InputDir + f'\\{PDFISBN}', 1, 0, r'.xml$')
        if not (os.path.isfile(xmlfile[0])):
            ErrStr += f"[1:1]: Error: [OUP-1011]: xml file is missing in zip file.\n"
        else:
            xmlcnt = _open_utf8(xmlfile[0])
            FileImage = re.findall(r'<graphic(?: [^>]*)? sysId="([^"]+)"(?: [^>]*)?/>', xmlcnt, re.I | re.S)
            FolderImage = os.listdir(InputDir + f'\\{PDFISBN}\\figures\\inline')
            FileValid = Difference(FileImage, FolderImage)
            if (FileValid):
                ErrStr += "[1:1]: Error: [OUP-1012]: '" + ', '.join(
                    map(str, FileValid)) + "' image files missing in image folder.\n"
            FolderValid = Difference(FolderImage, FileImage)
            if (FolderValid):
                ErrStr += "[1:1]: Error: [OUP-1013]: Extra images '" + ', '.join(
                    map(str, FolderValid)) + "' present in xml file.\n"
    else:
        ErrStr += "[1:1]: Error: [OUP-1014]: MARC Folder is Empty.\n"
    if ErrStr:
        CreateErrorLog(InputDir, "OUP OxchapML ATLAS Package Ver " + str(ToolVersion), ErrStr, 0)
        print("\n\tPlease clear the validation error!!!\n")
        sys.exit(0)

    _make_path(InputDir + f'\\10.1093_oso_{ISBN}.001.0001')

    shutil.copytree(InputDir + f'\\{PDFISBN}\\figures\\inline', InputDir + f'\\10.1093_oso_{ISBN}.001.0001\\assets')
    shutil.copytree(InputDir + f'\\{PDFISBN}\\pdf', InputDir + f'\\10.1093_oso_{ISBN}.001.0001\\chunked pdf')
    shutil.copytree(InputDir + f'\\cover', InputDir + f'\\10.1093_oso_{ISBN}.001.0001\\cover')
    shutil.copytree(InputDir + f'\\print pdf', InputDir + f'\\10.1093_oso_{ISBN}.001.0001\\print pdf')
    shutil.copytree(InputDir + f'\\MARC', InputDir + f'\\10.1093_oso_{ISBN}.001.0001\\MARC')
    shutil.copy(xmlfile[0], InputDir + f'\\10.1093_oso_{ISBN}.001.0001')

    shutil.make_archive(InputDir + f'\\10.1093_oso_{ISBN}.001.0001', "zip", InputDir + f'\\10.1093_oso_{ISBN}.001.0001')
    shutil.rmtree(InputDir + f'\\10.1093_oso_{ISBN}.001.0001')

    return ""


ErrCnt = _FileCheck()
ISBN = re.sub(r'oso-([\d]{13}).zip', r'\g<1>', osoISBN, 0, re.I | re.S)

zipped_file= InputDir + f'\\10.1093_oso_{ISBN}.001.0001' + '.zip'
zipped_file1= InputDir + f'\\oso-{ISBN}'

try:

    os.remove(zipped_file)
except:
    pass


# zipped_file = r'D:\test.zip'



if ErrCnt:
    CreateErrorLog(InputDir, "OUP OxchapML ATLAS Package Ver " + str(ToolVersion), ErrCnt, 0)
    print("\n\tPlease clear the validation error!!!\n")
    try:
        shutil.rmtree(zipped_file1)
    except:
        pass
    sys.exit(0)
else:
    _ATLAS_PackageCreation()
    try:
        shutil.rmtree(zipped_file1)
    except:
        pass


# ------ Local tracking -------------
_local_tracking(tool_id, ToolVersion, Tra_input, _get_file_size(Tra_input), st_time, _get_timestamp())
# -----------------------------------
print("\n\tPackage Created successfully!!!\n");
sys.exit(0)