from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from selenium.webdriver.chrome.options import Options as ChromeOptions

def search_shutterstock_by_image(image_path):
    abs_image_path = os.path.abspath(image_path)

    options = ChromeOptions()
    # options.add_argument('--disable-gpu')
    # options.add_argument('--headless')

    driver = webdriver.Chrome(options=options)
    driver.get('https://www.shutterstock.com')
    time.sleep(5)

    image_search_button = WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.XPATH, '//button[@aria-label="Search by image"]'))
    )
    driver.execute_script("arguments[0].click();", image_search_button)
    time.sleep(5)

    image_upload_input = WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.XPATH, '//input[@type="file"]'))
    )

    image_upload_input.send_keys(abs_image_path)
    time.sleep(20)

    print(driver.title)

    driver.quit()

search_shutterstock_by_image('image0.jpg')
