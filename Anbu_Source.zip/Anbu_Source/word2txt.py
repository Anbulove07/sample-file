from docx import Document

# Read the Word document
def read_word_file(file_path):
    doc = Document(file_path)
    full_text = []
    for para in doc.paragraphs:
        full_text.append(para.text)
    return '\n'.join(full_text)

# Write to a text file
def write_to_txt_file(text, file_path):
    with open(file_path, 'w') as txt_file:
        txt_file.write(text)

# Convert Word to text
word_text = read_word_file(r"D:\Giventool\Pradeep\New_Translation_Project\Input\Subodh\swis3e_9_4_EX2_sc_es_Spanish.docx")
write_to_txt_file(word_text, r"D:\Giventool\Pradeep\New_Translation_Project\Input\Subodh\swis3e_9_4_EX2_sc_es_Spanish.txt")
