# ------------------------------------------------------------------
#  Tool Name    : TFO_doi.py
#  Developer    : Anbu G | CTAE XML
#  Description  : Validate Folder structure name and update ini number
#  Client/DU    : Dove / Others
#  Syntax		: <EXE> <FolderPath>
# ------------------------------------------------------------------

# ------------ Rivision History  -----------------------------------
#  21-10-2022 | v1.0.0.0 | Anbu G | Initial Development

# ------------------------------------------------------------------
import base64

ToolVersion = "1.0.0.0";
import os
from os.path import basename, dirname
import sys
import re
from iPython.Basic import *
from iPython.ToolTracking import *
import pyodbc

print("\n\n\tTFO_doi Tool v" + ToolVersion + " is Running...");
print("\tCopyright @ Integra Software Services Ltd.\n");

Toolpath = dirname(sys.argv[0]);
Toolpath = re.sub(r'\/', r'\\', Toolpath, 0)


#------------ Tracking --------------------------------------------
Tra_input = sys.argv[1];
tool_id = 498; #TFO_doi Tool
run_size = 0;
st_time = _get_timestamp();
#------------------------------------------------------------------

# cc1=(os.getcwd())+"\\TFO-doi.ini"
# cc1=Toolpath+"\\TFO-doi.ini"
cc3=Toolpath+"\\updirname.txt"
# inicnt = _open_utf8(cc1)
os.system("cls")
if (len(sys.argv) != 2): sys.exit("\n\tSyntax: TFO_doi.exe <FolderPath>\n")

checkdirname=os.path.basename(sys.argv[1])
dirpath=sys.argv[1]
# print(checkdirname)
if not re.search(r'^\w+_\w+_[\d+]{8}_\w+$',checkdirname,re.I|re.S):
        # print("ok")
    # if re.search(r'\d+',inicnt,re.I|re.S):
    #     qq=re.search(r'\d+',inicnt,re.I|re.S)
    #     # print(qq.group())
        doinumber= ''
        try:
            cnxn = pyodbc.connect('DRIVER={SQL Server};SERVER=SQlServer01;DATABASE=iPubSuite;UID=' + base64.b64decode(
            'QXBwaVB1YlN1aXRl').decode() + ';PWD=' + base64.b64decode('c1EzRXhZN0Ek').decode() + '')

            cursor = cnxn.cursor()

            res = cursor.execute("select TOP(1) id,Rangenumber from vendorpackage where status = 1")
            row = res.fetchone()
            doinumber = row.Rangenumber
            cursor.execute("DELETE from vendorpackage where id = ?",(row.id))
            cnxn.commit()
        except:
            print("DB connection error!!!")
            sys.exit(0)
        # print(doinumber)
        # exit()
        graphicsfolderpath=dirpath+'\\graphic'
        arr_txt1 = [x for x in os.listdir(dirpath)]
        if os.path.isdir(graphicsfolderpath):
            arr_txt2 = [x for x in os.listdir(graphicsfolderpath)]
        else:
            arr_txt2=[]
        # print(arr_txt1)
        for checkfoldername in arr_txt1:
            if not re.search(r'^\w+_\w+_([\d+]{8})_\w+',checkfoldername,re.I|re.S):
                if re.search(r'^\w+_\w+_\d+_\w+\.xml', checkfoldername, re.I | re.S):
                    oldfilename=re.search(r'^\w+_\w+_(\d+)_\w+\.xml', checkfoldername, re.I | re.S)
                    updirname=re.sub(r'(^\w+_\w+_)\d+(_\w+\.xml)',r'\g<1>'+str(doinumber)+r'\g<2>',checkfoldername,0,re.I|re.S)

                    # print(updirname)
                    try:
                        os.rename(dirpath+'\\'+oldfilename.group(),dirpath+'\\'+updirname)
                    except:
                        pass
                    xmlcnt = _open_utf8(dirpath + '\\' + updirname)
                    xmlcnt = re.sub(r'\.S' + oldfilename.group(1), r'SsSsDdDd', xmlcnt, 0, re.I | re.S)
                    xmlcnt = re.sub(oldfilename.group(1), str(doinumber), xmlcnt, 0, re.I | re.S)
                    xmlcnt = re.sub(r'SsSsDdDd', r'.S' + oldfilename.group(1), xmlcnt, 0, re.I | re.S)
                    # print(xmlcnt)
                    _save_file(dirpath + '\\' + updirname, xmlcnt)


                if re.search(r'^\w+_\w+_\d+_\w+\.pdf', checkfoldername, re.I | re.S):
                    oldfilename=re.search(r'^\w+_\w+_(\d+)_\w+\.pdf', checkfoldername, re.I | re.S)
                    updirname=re.sub(r'(^\w+_\w+_)\d+(_\w+\.pdf)',r'\g<1>'+str(doinumber)+r'\g<2>',checkfoldername,0,re.I|re.S)

                    # print(updirname)
                    try:
                        os.rename(dirpath+'\\'+oldfilename.group(),dirpath+'\\'+updirname)
                    except:
                        pass





        if len(arr_txt2)!=0:
            # print(arr_txt2)
            for updgraphicname in arr_txt2:
                if re.search(r'^\w+_\w+_\d+_\w+', updgraphicname, re.I | re.S):
                    # oldfilename = re.search(r'^\w+_\w+_\d+_\w+', updgraphicname, re.I | re.S)
                    updirname = re.sub(r'(^\w+_\w+_)\d+(_\w+\.\w+)', r'\g<1>' + str(doinumber) + r'\g<2>', updgraphicname,0, re.I | re.S)

                    # print(updirname)

                    newpath = (graphicsfolderpath+'\\'+updgraphicname).replace(updgraphicname, updirname)
                    try:
                        os.rename(graphicsfolderpath+'\\'+updgraphicname, newpath)
                    except:
                        pass

        if re.search(r'^\w+_\w+_\d+_\w+', checkdirname, re.I | re.S):
            oldfilename = re.search(r'^\w+_\w+_\d+_\w+', checkdirname, re.I | re.S)
            updirname = re.sub(r'(^\w+_\w+_)\d+(_\w+)', r'\g<1>' + str(doinumber) + r'\g<2>', oldfilename.group(), 0,re.I | re.S)

            # print(updirname)

            newpath=dirpath.replace(checkdirname,updirname)
            try:
                os.rename(dirpath, newpath)
            except:
                pass
            dirpath1 = newpath
            _save_file(cc3, dirpath1)


    # inicnt=re.sub(doinumber+r'\n','',inicnt,0,re.I|re.S)
    # print(inicnt)

    # _save_file(cc1,inicnt)



# ------ Local tracking ------------------
_local_tracking(tool_id, ToolVersion, Tra_input, _get_file_size(Tra_input), st_time, _get_timestamp());
# -----------------------------------------



# print(inicnt)


