import json
import os.path
import re
import shutil
import sys
import time
from selenium.webdriver.common.by import By
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
# Replace 'path_to_chrome_webdriver' with the actual path to your Chrome webdriver executable
from selenium.webdriver.support.ui import WebDriverWait

# from sentiment_analysis_msg_5__225_edited_1815_ import sentiment_analysis

# Replace 'your_username' and 'your_password' with the actual username and password you want to enter

if not os.path.isfile('DUE_LIST.txt'):
    sys.exit('DUE_LIST File not found in EXE Folder...')

with open('DUE_LIST.txt', 'r') as file:
    # Read the content of the file
    list_content = file.read()

def _list_content_process(list_content):

    # for due in list_content:
        outfilename = list_content + ".json"

        # if os.path.isfile(outfilename):
        #     with open(outfilename, 'r') as file:
        #         # Read the content of the file
        #         json_content = json.load(file)
        # else:
        #     with open(outfilename, 'w') as outfile:
        #         pass
        # id_list_db = []
        # for id in range(len(json_content)):
        #     # print(json_content[id]['id'])
        #     id_list_db.append(json_content[id]['id'])
        # exit()

        # chrome_options = webdriver.ChromeOptions(executable_path="D:\\assets\\chromedriver.exe")
        # chrome_options.add_argument("--headless")  # Run in headless mode


        # chrome_options = webdriver.ChromeOptions()
        # # chrome_options.add_argument("--headless")  # Comment out this line
        # chrome_options.binary_location = "D:\\assets\\chromedriver.exe"  # Path to your Chrome executable

        driver = webdriver.Chrome()


        # driver=webdriver.ChromeOptions()

        # driver = webdriver.Chrome()
        # driver = webdriver.Chrome()
        username = 'karthikeyan.jayaraman@integra.co.in'
        password = 'Renew@123'

        # Open the web page
        driver.get('https://hub.taylorandfrancis.com/login#/')  # Replace 'https://example.com' with the actual login page URL

        time.sleep(2)
        # Find the input elements by their IDs and enter the username and password
        username_input = driver.find_element('id', 'email_id')
        password_input = driver.find_element('id', 'password')
        # username_input = driver.find_element_by_id('email_id')
        # password_input = driver.find_element_by_id('password')

        username_input.send_keys(username)
        password_input.send_keys(password)

        # time.sleep(5)
        # Click the login button
        login_button = driver.find_element(By.XPATH,'//*[@id="save_sla"]')
        login_button.click()



        time.sleep(10)

        # search_input = driver.find_element_by_id('search')
        search_input = driver.find_element(By.ID,'search')
        search_keyword = list_content

        # Replace with the keyword you want to search
        search_input.send_keys(search_keyword)

        # Find the search submit button by its ID and click it
        # search_submit_button = driver.find_element(By.ID,'search_submit')
        # search_submit_button.click()
        search_input.send_keys(Keys.ENTER)
        # Wait for the search results to load (you can adjust the time if needed)

        # wait = WebDriverWait(driver, 10)
        # links = wait.until(EC.presence_of_all_elements_located((By.TAG_NAME, 'a')))
        # wait = WebDriverWait(driver, 10)
        # # body_content_element = wait.until(
        #     EC.presence_of_element_located((By.XPATH, '//*[@class="range-label"]')))


        # body_content_element=driver.find_element(By.XPATH,  '//*[@id="jch_dashboard"]/div/div/div/div[2]/dir-pagination-controls/div[1]')
        #
        # #
        # # wait = WebDriverWait(driver, 10)  # Adjust the timeout as needed
        # # body_content_element = wait.until(EC.presence_of_element_located((By.XPATH,  '//*[@id="jch_dashboard"]/div/div/div/div[2]/dir-pagination-controls/div[1]')))
        # if body_content_element:
        # #     body_text = body_content_element.text
        # #     print(body_content_element)
        #
        #
        #     inner_html = body_content_element.get_attribute("innerHTML")
        #
        #     print(inner_html)

        #
        # wait = WebDriverWait(driver, 30)
        # element = wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, 'div.range-label')))
        # # Get the text content of the element
        # text_content = element.text
        # print(text_content)  # DISPLAYING 1 - 25 OF 722 QUERIES
        #

    # #
        # Get all the href attributes from the final page
        # hrefs = []
        # for link in links:
        #     href = link.get_attribute('href')
        #     if href:
        #         hrefs.append(href)

        # # Print all the href attributes
        # for href in hrefs:
        #     print(href)
        time.sleep(20)
        td_elements = driver.find_elements(By.TAG_NAME, 'td')
        anchor_elements_in_td = [td.find_element(By.TAG_NAME, 'a') for td in td_elements if td.find_elements(By.TAG_NAME, 'a')]

        output = []
        # Extract and print all href values for anchor elements inside <td> tags
        def bodyscriptlink(href_value):
            # Load the URL in the browser
            # driver = webdriver.Chrome()  # Assuming you're using Chrome webdriver
            driver.get(href_value)
            # username_input = driver.find_element('id', 'email_id')
            # password_input = driver.find_element('id', 'password')
            # # username_input = driver.find_element_by_id('email_id')
            # # password_input = driver.find_element_by_id('password')
            #
            # username_input.send_keys(username)
            # password_input.send_keys(password)
            #
            # # time.sleep(5)
            # # Click the login button
            # login_button = driver.find_element(By.XPATH, '//*[@id="save_sla"]')
            # login_button.click()

            try:
                # Wait for the element with class 'back-to-list-query-discription-details' to be present
                wait = WebDriverWait(driver, 30)
                body_content_element = wait.until(
                    EC.presence_of_element_located((By.XPATH, '//div[@class="query-reply-msg"]')))

                if body_content_element:
                    body_text = body_content_element.text
                    # print(body_text)
                    temp=[]
                    if re.search(r'Sent(?:(?!Sent:).)*', body_text,re.I|re.S):
                        body_cnt=re.search(r'Sent(?:(?!Sent:).)*', body_text,re.I|re.S).group()
                        # print(body_cnt)
                        if re.search('query-details/(\d+)/\?project_id',href_value,re.I|re.S):
                            query_id=re.search('query-details/(\d+)/\?project_id',href_value,re.I|re.S).group(1)
                            temp.append(query_id)
                        if re.search('Sent:((?:(?!From).)*)From',body_cnt,re.I|re.S):
                            Sent_date=re.search('Sent:((?:(?!From).)*)From',body_cnt,re.I|re.S).group(1)
                            temp.append(Sent_date)
                        if re.search('From:((?:(?!To:).)*)To',body_cnt,re.I|re.S):
                            From_add=re.search('From:((?:(?!To:).)*)To',body_cnt,re.I|re.S).group(1)
                            temp.append(From_add)
                        if re.search('To:(.*)',body_cnt,re.I|re.S):
                            To_add=re.search('To:(.*)',body_cnt,re.I|re.S).group(1)
                            temp.append(To_add)
                        # print("Body content found!")

                    output.append(temp)
                    print(temp)
                else:
                    print("Body content not found!")
            except Exception as e:
                print("Error: ", e)
            # finally:
            driver.back()
            # Navigate back to the previous page

            # Add some delay between back-to-back navigation (optional)
            time.sleep(3)
        list=[]
        for element in anchor_elements_in_td:
            href_value = element.get_attribute('href')
            # print(href_value)
            list.append(href_value)

        # print(list)
        for i in range(len(list)):
            try:
                if not list[i]==list[i+1]:
                    # for id_list in id_list_db:
                    #     if not list[i] == id_list:
                    bodyscriptlink(list[i])
                    # print(list[i])
                    # print("ok")
            except:
                pass
        time.sleep(10)

        # print(output)
        # Close the browser
        driver.quit()

        json_string= ""

        for n in range(len(output)):
            try:
                id = output[n][0]
                date = output[n][1]
                from_add = output[n][2]
                body_cnt = output[n][3]
            # Sample data for name, ID, and date

                if not re.search('(integra\.co\.in|cats@taylorandfrancis\.com)',from_add,re.I|re.S):

                # Create a dictionary with the information
                    data = {
                        "id": id,
                        "date": date,
                        "From": from_add,
                        "body": body_cnt
                    }

                    # Convert the dictionary to a JSON string
                    json_string =json_string+ json.dumps(data)+","

            except:
                pass
        # Print the JSON string
        json_string='['+json_string+']'
        json_string=json_string.replace("},]","}]")
        # print(json_string)


        #
        # json_string = json.dumps(output)
        #
        # # Write the JSON string to a file
        # outfilename=due+".json"
        with open(outfilename, 'w') as file:
            file.write(json_string)

        print("Mail scrapped successfully...")
        return "success"
# returnvalue=sentiment_analysis("RBJE.json")
#

# _list_content_process(list_content)
# if returnvalue=="success":
#     print("Sentiment analysis done successfully...")
#