import sys
from docx import Document
from urllib.parse import quote
from mtranslate import translate
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
def divide_content(content, char_limit):
    segments = []
    current_segment = ""

    for char in content:
        current_segment += char

        if len(current_segment) >= char_limit:
            segments.append(current_segment)
            current_segment = ""

    if current_segment:
        segments.append(current_segment)

    return segments

def translate_word_file(input_file, output_file, target_language):
    # Read the contents from the input Word file
    doc = Document(input_file)

    # Translate and replace the text in each paragraph
    char_limit = 400
    translated_text = ""
    for paragraph in doc.paragraphs:
        original_text = paragraph.text
        segments = divide_content(original_text, char_limit)
        translated_segments = []
        for segment in segments:

            translated_segment = translate(segment, target_language)
            paragraph.text = translated_segment

    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                original_text = cell.text
                translated_text = translate(original_text, target_language)
                cell.text = translated_text
                # Optional: Adjust the vertical alignment of the cell
                cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER

    # Save the translated text to the output file
    # with open(output_file, "w", encoding="utf-8") as f:
    #     f.write(translated_text)
    doc.save(output_file)

# Example usage
input_file_path = sys.argv[1]
output_file_path = sys.argv[1].split(".")[0] + "_translated.docx"
target_language = "en"  # German, Italian, Arabic, Korean, etc.

translate_word_file(input_file_path, output_file_path, target_language)

print("Translation complete!")
