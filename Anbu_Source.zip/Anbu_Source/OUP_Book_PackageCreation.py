#------------------------------------------------------------------
#  Tool Name    : OUP_Book_PackageCreation.py
#  Developer    : Premkumar P | CTAE XML
#  Description  : create zip file based on input
#  Client/DU    : OUP / Journal Others
#  Syntax		: <EXE> <FolderPath>
#------------------------------------------------------------------

#------------ Rivision History  -----------------------------------
#  15-04-2021 | v1.0.0.0 | Premkumar P | Initial Development
#  08-05-2021 | v1.0.1.0 | Premkumar P | Updates
#  11-06-2021 | v1.0.2.0 | Premkumar P | Appendix Updates
#  27-07-2021 | v1.0.3.0 | Premkumar P | Graphic Updates
#  23-11-2021 | v1.0.4.0 | Premkumar P | Updates
#  04-12-2021 | v1.0.5.0 | Premkumar P | OSO package updates
#------------------------------------------------------------------

ToolVersion = "1.0.5.0";

import os
from os.path import basename,dirname
import shutil
import ctypes
import sys 
import re
import subprocess
from iModule.Basic import*
from iModule.ErrorLog import *
from glob import glob
from iModule.ToolTracking import *
from datetime import datetime,date
from PIL import Image

Toolpath = dirname(sys.argv[0]);
Toolpath = re.sub(r'\/',r'\\',Toolpath,0)

os.system("cls");


# Inline argument checking & File path checking
if (len(sys.argv) != 3 or not os.path.isdir(sys.argv[1])): sys.exit("\n\tSyntax: OUP_Book_PackageCreation.exe <FolderPath> <stage>\n")
if(not re.match('^(FP|ELDS|COMP)$',(sys.argv[2]),re.I)):  sys.exit("\n\tSyntax: OUP_Book_PackageCreation.exe <FolderPath> <FP|ELDS|COMP>\n")

print ("\n\n\tOUP_Book_PackageCreation v"+str(ToolVersion)+" is Running...\n\n");

#------------ Tracking --------------------------------------------
Tra_input = sys.argv[1];
tool_id = 398; #OUP_Book_PackageCreation Tool
run_size = 0;
st_time = _get_timestamp();
#------------------------------------------------------------------

# Global variable declaration
InputDir = sys.argv[1]
stage = sys.argv[2]

IDDict= {};old_new = {};DOIDict = {}
MathgraphicID = 0;graphicID = 0;ErrStr = ""
#Validation tool path
ValidationTool = Toolpath+"\\"+"OUP_Book_Validation.exe";
MainFileXML = str(InputDir)+r'\OUP_Book_Main.xml'
BookIDSeqTool = str(Toolpath)+r'\OUP_BookID_Sequence.exe'

# Difference Subroutine:
def Difference(First, Second):
	return (list(set(First) - set(Second)))

#check validation supporting files	
def _Validation_tool_check():
	ErrStr = "";
	if not os.path.isfile(ValidationTool):
		ErrStr += "[1:1]: Error: [OUP-1001]: 'OUP_Book_Validation.exe' tool missing in '"+Toolpath+"' path.\n"
	if not os.path.isfile(MainFileXML):
		ErrStr += "[1:1]: Error: [OUP-1002]: 'OUP_Book_Main.xml' file is missing in '"+Toolpath+"' path.\n"
	if not os.path.isfile(BookIDSeqTool):
		ErrStr += "[1:1]: Error: [OUP-1003]: 'OUP_BookID_Sequence.exe' file is missing in '"+Toolpath+"' path.\n"
	if(ErrStr):
		CreateErrorLog(InputDir,"OUP_Book_PackageCreation Ver "+str(ToolVersion),ErrStr,0)
		print ("\n\tPlease clear the validation error!!!\n")
		sys.exit(0)

# Validation EXE run:
def _XmlValidation(xmlFiles,type):
	
	count = 0;
	myErrs='';
	def Label(txt=""):
		txt = "<tr/><tr/><tr/><tr/><tr/><tr/><tr/><tr/><tr bgcolor=\"#C0C5B4\"><td align=\"center\"><font size=\"3\" face=\"Verdana\" color=\"darkred\"><b>"+txt+"</b></font></td></tr>\n<tr><td/></tr>\n"
		return txt
	
	for file in xmlFiles:

		# Validate a xml with OUP_Book_Validation.exe tool:
		filename = os.path.basename(file)
		validate = ValidationTool+' '+file+' '+stage+' '+type
		os.system(validate)
		
		# read err file and remove err, err.htm file:
		error = ''; warning = ''; errCnt = '';
		errFile = file[:-4]+'_err.err';
		errhtm = file[:-4]+'_err.htm';
		
		if(os.path.isfile(errFile)) :
			errCnt = _open_utf8(errFile)
			os.remove(errFile)
		if (os.path.isfile(errhtm)): os.remove(errhtm)
		
		# split error, warning from err file and join into single error string:
		for m in re.finditer("\[(\d+):(\d+)\]\s*:\s*(Error\s*:\s*[^\n]+)", errCnt, re.I|re.S):
			cnt = m.group(3); ln = m.group(1); cl = m.group(2);
			error += AddErrWarn(cnt,ln,cl,file);
			count += 1
		
		for m in re.finditer("\[(\d+):(\d+)\]\s*:\s*((?:Warning|information)\s*:\s*[^\n]+)", errCnt, re.I|re.S):
			cnt = m.group(3); ln = m.group(1); cl = m.group(2);
			warning += AddErrWarn(cnt,ln,cl,file);
		
		myErrs += Label(filename)
		
		if len(error) or len(warning):
			(tmp, errcnt, Errors) = ErrorReturn(error)
			myErrs += AddSubLabel("<font color=\"red\">Errors: "+str(errcnt)+"("+str(tmp)+")</font>");
			myErrs += Errors
			(tmp, errcnt, Errors) = ErrorReturn(warning)
			myErrs += AddSubLabel("<font color=\"red\">Warnings: "+str(errcnt)+"("+str(tmp)+")</font>");
			myErrs += Errors
		else:
			myErrs +='<tr><td align="center"><font size="2" face="Arial Black" color="green">File '+filename+' has No Errors!!!</font></td></tr>';
		
	# Create error html creation:	
	CreateErrorLog4ErrorReturn(InputDir,"OUP_Book_PackageCreation Ver "+str(ToolVersion), myErrs,0,1);
	
	if(count == 0):
		return ""
	else:
		print ("\n\tPlease clear the validation error!!!\n")
		sys.exit(0)

	
def _BookIDSeqCreation():	
	Arg = BookIDSeqTool+' '+InputDir
	os.system(Arg)
	return ""
#Sub functions
def _ref_replacement(tmp):	
	try:
		tmp1 = old_new[tmp]
		return tmp1
	except:
		return tmp
	
def _DOIgenerator(tmp1,tmp2):
	if tmp1.lower() not in DOIDict:
		DOIDict[tmp1.lower()] = 0
	DOIDict[tmp1.lower()] += 1
	tmp2 = re.sub(r'.\w+$',r'.'+str(DOIDict[tmp1.lower()]).zfill(4),tmp2,0,re.I)
	return tmp2
	# return r'10.1093/oso/'+str(ISBN)+r'.'+str(doi_nums[tmp.lower()])+r'.'+str(DOIDict[tmp.lower()]).zfill(4)
	
def _IDgenerator(tmp1,tmp2):
	if tmp1.lower() not in IDDict:
		IDDict[tmp1.lower()] = 0
	IDDict[tmp1.lower()] += 1
	tmp2 = re.sub(r'-\w+$',r'-'+str(IDDict[tmp1.lower()]),tmp2,0,re.I)
	return tmp2
	
def _old_ID_convert(tmp):
	tmp = re.sub(r' id="([^"]+)"',r' id="\g<1>" oldid="\g<1>"',tmp,0,re.I|re.S)
	tmp = re.sub(r' ref="([^"]+)"',r' oldref="\g<1>"',tmp,0,re.I|re.S)
	return tmp

def _common_function(tmp):
	tmp = re.sub(r'<\?Insert-(Figure|Table|boxedMatter|media) ID="',r'<?Insert-\g<1> oldref="',tmp,0,re.I|re.S)
	tmp = re.sub(r'<(note|figureGroup|tableGroup|boxedMatter|mediaGroup|bibItem|xref|displayMaths|displayText|div[0-9]+|chapter|part|abbrevExpansion|abbrev|item1)((?: [^>]+)?>)',lambda m: _old_ID_convert(m.group()),tmp,0,re.I|re.S)
	tmp = re.sub(r'(<(chapter|miscMatter|bibliography|appendix|figureGroup|tableGroup|boxedMatter|parallelText|section|part|mediaGroup|e|eSub|frontMatter|miscMatterGroup|miscMatter|appendix|metaInfo|appendixGroup|bibItem|bibliography|bibliographyGroup|bookMeta|boxedMatter|docMeta|document|case|e|eSub|endMatter|figureGroup|frontMatter|graphic|indexGroup|indexList|law:extract|mainText|mediaGroup|floatGroup|metaInfo|parallelTextGroup|partFrontMatter|regulation|section|sectionFrontMatter|tableGroup|bibList|textMatter|titleGroup|work|workFrontMatter|workEndMatter|figure|table|note|displayMaths|displayText|abbrevExpansion|item[0-5]|itemN|div[0-9]+|list[0-9]+|media)(?: [^>]+)?) id="([^"]+)"((?: [^>]+)?/?>)',lambda m: str(m.group(1))+' newid="'+str(_IDgenerator(m.group(2),m.group(3)))+r'"'+str(m.group(4)),tmp,0,re.I|re.S)
	tmp = re.sub(r'(<(miscMatter|bibliography|appendix|figureGroup|tableGroup|boxedMatter|parallelText|section|mediaGroup|e|eSub|div[0-9]+)(?: [^>]+)?) doi="([^"]+)"((?: [^>]+)?/?>)',lambda m: str(m.group(1))+r' doi="'+str(_DOIgenerator(m.group(2),m.group(3)))+r'"'+str(m.group(4)),tmp,0,re.I|re.S)
	return tmp

#Graphic ID sequence
def _MathgraphicID(tmp,id,chap):
	global MathgraphicID,ErrStr
	MathgraphicID += 1
	sysID = re.search(r'<graphic(?: [^>]*)? sysId="([^"]+)"(?: [^>]*)?/?>',tmp,re.I|re.S)
	if sysID:
		sysID = sysID.group(1)
		ext = sysID.split('.')[-1]
		Gid = id+'-math-'+str(MathgraphicID).zfill(3)+r'.'+str(ext)
		try:
			src = InputDir+'\\'+str(chap)+'\\'+sysID
			imageSize  = os.path.getsize(src)
			try:
				img = Image.open(src)
				img.verify()
			except(IOError, SyntaxError) as e:
				ErrStr +="[1:1]: Error: [OUP-1018]: Invalid image file in path '"+str(src)+"'.\n"
			if not(imageSize):
				ErrStr +="[1:1]: Error: [OUP-1004]: Invalid image file size in path '"+str(src)+"'.\n"
			if not os.path.isfile(src):
				ErrStr += "[1:1]: Error: [OUP-1005]: '"+str(sysID)+"' image file is present in xml file but missing in '"+str(chap)+"' folder.\n";
			dst = InputDir+'\\'+id+'\\figures\\inline\\'+Gid
			shutil.copy(src,dst)
		except: 
			pass
		# print(src,dst)
		txt = re.sub(r'<graphic((?: [^>]*)? sysId=")([^"]+)("(?: [^>]*)?/?>)',r'<graphic_Tmp1\g<1>'+str(Gid)+r'\g<3>',tmp,0,re.I|re.S)
		txt = re.sub(r'<m:math((?: [^>]*)? altimg=")([^"]+)("(?: [^>]*)?>)',r'<m:math_Tmp1\g<1>'+str(Gid)+r'\g<3>',txt,0,re.I|re.S)
		return txt
#---
#Normal Graphic ID sequence
def _NgraphicID(tmp,id,chap):
	global graphicID,ErrStr

	sysID = re.search(r'<graphic(?: [^>]*)? sysId="([^"]+)"(?: [^>]*)?/?>',tmp,re.I|re.S)
	if sysID:
		sysID = sysID.group(1)

		ext = sysID.split('.')[-1]
		if (re.search(r'-color.(?:gif|jpg|jpeg|png|eps|tif)$', sysID, re.I)):
			Gid = id + '-graphic-' + str(graphicID).zfill(3) + r'-color.' + str(ext)
		else:
			graphicID += 1
			Gid = id+'-graphic-'+str(graphicID).zfill(3)+r'.'+str(ext)

		try:
			src = InputDir+'\\'+str(chap)+'\\'+sysID
			imageSize  = os.path.getsize(src)
			try:
				img = Image.open(src)
				img.verify()
			except(IOError, SyntaxError) as e:
				ErrStr +="[1:1]: Error: [OUP-1019]: Invalid image file in path '"+str(src)+"'.\n"
			if not(imageSize):
				ErrStr +="[1:1]: Error: [OUP-1006]: Invalid image file size in path '"+str(src)+"'.\n"
			if not os.path.isfile(src):
				ErrStr += "[1:1]: Error: [OUP-1007]: '"+str(sysID)+"' image file is present in xml file but missing in '"+str(chap)+"' folder.\n";
			dst = InputDir+'\\'+id+'\\figures\\inline\\'+Gid
			shutil.copy(src,dst)
		except: 
			pass
		# print(src,dst)
		txt = re.sub(r'<graphic((?: [^>]*)? sysId=")([^"]+)("(?: [^>]*)?/?>)',r'<graphic_Tmp2\g<1>'+str(Gid)+r'\g<3>',tmp,0,re.I|re.S)
		txt = re.sub(r'<m:math((?: [^>]*)? id=")([^"]+)("(?: [^>]*)?>)',r'<m:math_Tmp2\g<1>'+str(Gid)+r'\g<3>',txt,0,re.I|re.S)
		return txt
#---
#----
#Misc Sequence
def  _MiscSeq(cnt,MiscCount):
	cnt = re.sub(r'(<(?:appendix|metaInfo|appendixGroup|bibItem|bibliography|bibliographyGroup|bookMeta|boxedMatter|docMeta|document|case|e|eSub|endMatter|figureGroup|frontMatter|graphic|indexGroup|indexList|law:extract|mainText|mediaGroup|floatGroup|parallelTextGroup|partFrontMatter|regulation|section|sectionFrontMatter|tableGroup|bibList|textMatter|titleGroup|work|workFrontMatter|workEndMatter|figure|table|note|displayMaths|displayText|abbrevExpansion|item[0-5]|itemN|div[0-9]+|list[0-9]+|media|indexItem[0-9]+)(?: [^>]*)? newid="[^"]+miscMatter-)(\d+)([^"]+"(?: [^>]*)?/?>)',lambda m: f"{m.group(1)}{MiscCount}{m.group(3)}",cnt,0,re.I|re.S)
	return cnt
#---
#Package creation check
def _Package_Validation():
	global ErrStr
	FullCnt = "";PDFlist = []
	PartStatus = False
	FMList = [];global idISBN
	ChapterList=[];BackList=[]
	_BookIDSeqCreation()
	#Call Book validation EXE
	_XmlValidation(AllFiles,'Chapter')
	#---
	MainXMLcnt = _open_utf8(MainFileXML)
	FMFiles = re.search(r'<FM(?: [^>]*)?>(?:(?!</FM>).)*</FM>',MainXMLcnt,re.I|re.S)
	if FMFiles:
		FMList = [ m.group(1) for m in re.finditer(r'<FileName(?: [^>]*)?>((?:(?!</FileName>).)*)</FileName>', FMFiles.group(), re.I|re.S)]
	ChapterFiles = re.search(r'<Main(?: [^>]*)?>(?:(?!</Main>).)*</Main>',MainXMLcnt,re.I|re.S)
	if ChapterFiles:
		ChapterList = [ m.group(1) for m in re.finditer(r'<FileName(?: [^>]*)?>((?:(?!</FileName>).)*)</FileName>', ChapterFiles.group(), re.I|re.S)]
	BackFiles = re.search(r'<Back(?: [^>]*)?>(?:(?!</Back>).)*</Back>',MainXMLcnt,re.I|re.S)
	if BackFiles:
		BackList = [ m.group(1) for m in re.finditer(r'<FileName(?: [^>]*)?>((?:(?!</FileName>).)*)</FileName>', BackFiles.group(), re.I|re.S)]
	
	All_Files = _open_utf8(str(InputDir)+r'\\'+ChapterList[0]+r'.xml')
	idISBN = re.search(r'<book(?: [^>]*)? id="([a-z]+-[0-9]{13})[^"]*"(?: [^>]*)?>',All_Files,re.I|re.S)
	if idISBN:
		idISBN = idISBN.group(1)
	else: idISBN = ''
	_make_path(InputDir+'\\'+str(idISBN))
	# _make_path(InputDir+'\\'+str(idISBN)+'\\pdf')
	_make_path(InputDir+'\\'+str(idISBN)+'\\figures\\inline')
	OutInputDir = InputDir+'\\output-'+str(idISBN)
	#FM Files
	if FMList:
		for FMfile in FMList:
			FilePath = str(OutInputDir)+r'\\'+str(FMfile)+r'.xml'
			typeFile = re.sub(r'\.xml$', '', basename(FMfile), re.I)
			typeFiles = typeFile.split('-')[-1]
			FMcnt = _open_utf8(FilePath)
			# Copy pdf files
			FMpdf = InputDir+'\\pdf\\'+str(idISBN)+'-'+str(typeFiles)+'.pdf'
			if os.path.isfile(FMpdf):
				PDFlist.append(basename(FMpdf))
				# shutil.copy(FMpdf,InputDir+'\\'+str(idISBN)+'\\pdf')
			else: 
				ErrStr += "[1:1]: Warning: [OUP-1008]: '"+str(idISBN)+"-"+str(typeFiles)+r'.pdf'+"' file is missing in 'pdf' folder.\n";
			# ---
			FMcnt = re.sub(r'</book>',r'<mainText id="'+str(idISBN)+r'-mainText-1">\n',FMcnt,re.I)
			FMImage = re.findall(r'<graphic(?: [^>]*)? sysId="([^"]+)"(?: [^>]*)?/?>',FMcnt,re.I|re.S)
			if FMImage:
				if(os.path.isdir(InputDir+'\\'+str(typeFiles))):
					AllFMImage = list(map(lambda v: basename(v), _get_file_list(InputDir+'\\'+str(typeFiles),1,0,'')))
					ExtraFM = Difference(AllFMImage,FMImage)
					if ExtraFM: 
						ErrStr +="[1:1]: Error: [OUP-1009]: Extra files present in '"+str(typeFiles)+"' folder '"+', '.join(map(str,ExtraFM))+"' but not present in xml file.\n"
				else:
					ErrStr +="[1:1]: Error: [OUP-1010]: '"+str(typeFiles)+"' Folder is missing in input path.\n"
					
			FMcnt = re.sub(r'<(displayMaths|inlineMaths)(?: [^>]*)?>(?:(?!</\1>).)*</\1>',lambda h: _MathgraphicID(h.group(),idISBN,typeFiles),FMcnt,0,re.I|re.S)
			FMcnt = re.sub(r'<graphic((?: [^>]*)? sysId=")([^"]+)("(?: [^>]*)?/?>)',lambda h: _NgraphicID(h.group(),idISBN,typeFiles),FMcnt,0,re.I|re.S)
			
			FullCnt += FMcnt
	#Chapter Files
	if ChapterList:
		for Chfile in ChapterList:
			CHFilePath = str(OutInputDir)+r'\\'+str(Chfile)+r'.xml'
			typeFile = re.sub(r'\.xml$', '', basename(Chfile), re.I)
			chtypeFiles = typeFile.split('-')[-1]
			Chcnt = _open_utf8(CHFilePath)
			# exit(chtypeFiles)
			# Copy pdf files
			ChNo = re.search(r'Ch(?:ap)(\d+)',chtypeFiles,re.I)
			if ChNo: ChNo = ChNo.group(1)
			else: ChNo=''
			chpdf = InputDir+'\\pdf\\'+str(idISBN)+'-chapter-'+str(ChNo)+'.pdf'
			if os.path.isfile(chpdf):
				PDFlist.append(basename(chpdf))
				# shutil.copy(chpdf,InputDir+'\\'+str(idISBN)+'\\pdf')
			else: 
				ErrStr += "[1:1]: Warning: [OUP-1011]: '"+str(idISBN)+"-chapter-"+str(ChNo)+".pdf"+"' file is missing in 'pdf' folder.\n";
			# ---
			Tmppart = re.search(r'<part(?: [^>]*)?>(?:(?!</part>).)*',Chcnt,re.I|re.S)
			Tmpchap = re.search(r'<chapter(?: [^>]*)?>(?:(?!</chapter>).)*</chapter>',Chcnt,re.I|re.S)
			
			if(Tmppart):
				if PartStatus == True:
					cnts = "\n</part>\n"+Tmppart.group()
				else:
					cnts = Tmppart.group()
				PartStatus = True
			elif(Tmpchap):
				cnts = "\n"+Tmpchap.group()
			else:
				cnts = ''
			
			if cnts:
				ChapterImage = re.findall(r'<graphic(?: [^>]*)? sysId="([^"]+)"(?: [^>]*)?/?>',cnts,re.I|re.S)
				if ChapterImage:
					if(os.path.isdir(InputDir+'\\'+str(chtypeFiles))):
						AllChapterImage = list(map(lambda v: basename(v), _get_file_list(InputDir+'\\'+str(chtypeFiles),1,0,'')))
						ExtraChapter = Difference(AllChapterImage,ChapterImage)
						if ExtraChapter: 
							ErrStr +="[1:1]: Error: [OUP-1012]: Extra files present in '"+str(chtypeFiles)+"' folder '"+', '.join(map(str,ExtraChapter))+"' but not present in xml files.\n"
					else:
						ErrStr +="[1:1]: Error: [OUP-1013]: '"+str(chtypeFiles)+"' Folder is missing in input path.\n"
				
				cnts = re.sub(r'<(displayMaths|inlineMaths)(?: [^>]*)?>(?:(?!</\1>).)*</\1>',lambda h: _MathgraphicID(h.group(),idISBN,chtypeFiles),cnts,0,re.I|re.S)
				cnts = re.sub(r'<graphic((?: [^>]*)? sysId=")([^"]+)("(?: [^>]*)?/?>)',lambda h: _NgraphicID(h.group(),idISBN,chtypeFiles),cnts,0,re.I|re.S)
				
				FullCnt += cnts
	if PartStatus == True:
		FullCnt += "\n</part>\n"
	FullCnt += '</mainText>\n'
	#Back Files
	if BackList:
		FullCnt += r'<endMatter id="'+str(idISBN)+r'-endMatter-1">'
		for Backfile in BackList:
			BackFilePath = str(OutInputDir)+r'\\'+str(Backfile)+r'.xml'
			typeFile = re.sub(r'\.xml$', '', basename(Backfile), re.I)
			BacktypeFiles = typeFile.split('-')[-1]
			Backcnt = _open_utf8(BackFilePath)
			AppNo = re.search(r'App(\d+)',BacktypeFiles,re.I)
			if(AppNo):
				Backpdf = InputDir+'\\pdf\\'+str(idISBN)+'-appendix-'+str(AppNo.group(1))+'.pdf'
			else:
				Backpdf = InputDir+'\\pdf\\'+str(idISBN)+'-'+str(BacktypeFiles)+'.pdf'
			if os.path.isfile(Backpdf):
				PDFlist.append(basename(Backpdf))
				# shutil.copy(Backpdf,InputDir+'\\'+str(idISBN)+'\\pdf')
			else: 
				ErrStr += "[1:1]: Warning: [OUP-1014]: '"+str(idISBN)+"-"+str(BacktypeFiles)+r'.pdf'+"' file is missing in 'pdf' folder.\n";
			# ---
			BackImage = re.findall(r'<graphic(?: [^>]*)? sysId="([^"]+)"(?: [^>]*)?/?>',Backpdf,re.I|re.S)
			if BackImage:
				if(os.path.isdir(InputDir+'\\'+str(BacktypeFiles))):
					AllBackImage = list(map(lambda v: basename(v), _get_file_list(InputDir+'\\'+str(BacktypeFiles),1,0,'')))
					ExtraBack = Difference(AllBackImage,BackImage)
					if ExtraBack: 
						ErrStr +="[1:1]: Error: [OUP-1015]: Extra files present in '"+str(BacktypeFiles)+"' folder '"+', '.join(map(str,ExtraBack))+"' but not present in xml file.\n"
				else:
					ErrStr +="[1:1]: Error: [OUP-1016]: '"+str(BacktypeFiles)+"' Folder is missing in input path.\n"
			Backcnt = re.sub(r'<(displayMaths|inlineMaths)(?: [^>]*)?>(?:(?!</\1>).)*</\1>',lambda h: _MathgraphicID(h.group(),idISBN,BacktypeFiles),Backcnt,0,re.I|re.S)
			Backcnt = re.sub(r'<graphic((?: [^>]*)? sysId=")([^"]+)("(?: [^>]*)?/?>)',lambda h: _NgraphicID(h.group(),idISBN,BacktypeFiles),Backcnt,0,re.I|re.S)
			Backcnt = re.search(r'<endMatter(?: [^>]*)?>((?:(?!</endMatter>).)*)</endMatter>',Backcnt,re.I|re.S)
			if Backcnt:
				FullCnt += Backcnt.group(1)
		FullCnt += '</endMatter>'
	FullCnt += '\n</book>'
	
	FullCnt = re.sub(r'</appendixGroup>\s*<appendixGroup(?: [^>]*)?>','',FullCnt,0,re.I|re.S)
	
	AllPDF = list(map(lambda v: basename(v), _get_file_list(InputDir+'\\pdf',1,0,'')))
	ExtraPDF = Difference(AllPDF,PDFlist)
	if ExtraPDF: 
		ErrStr +="[1:1]: Warning: [OUP-1017]: Extra files present in 'pdf' folder '"+', '.join(map(str,ExtraPDF))+"'.\n"
	
	#Move PDF Temporarily
	if(os.path.isdir(InputDir+'\\pdf')):
		if(os.path.isdir(InputDir+'\\'+str(idISBN)+'\\pdf')): shutil.rmtree(InputDir+'\\'+str(idISBN)+'\\pdf')
		shutil.copytree(InputDir+'\\pdf', InputDir+'\\'+str(idISBN)+'\\pdf')
	#---
	(Errors,Warns)=_separate_error_warning(ErrStr)
	if(Errors):
		CreateErrorLog(InputDir,"OUP_Book_PackageCreation Ver "+str(ToolVersion), ErrStr,0)
		if os.path.isdir(InputDir+'\\'+str(idISBN)): shutil.rmtree(InputDir+'\\'+str(idISBN))
		if os.path.isdir(InputDir+'\\output-'+str(idISBN)): shutil.rmtree(InputDir+'\\output-'+str(idISBN))
		print ("\n\tPlease clear the validation error!!!\n")
		sys.exit(0)
	
	#Graphic id replace
	FullCnt = re.sub(r'<graphic_Tmp(1|2) ',r'<graphic ',FullCnt,0,re.S|re.I)
	FullCnt = re.sub(r'<m:math_Tmp(1|2) ',r'<m:math ',FullCnt,0,re.S|re.I)
	
	FullCnt = _common_function(FullCnt)
	FullCnt = re.sub(r'<miscMatter(?: [^>]*)? newid="[^"]+-(\d+)"(?: [^>]*)?>(?:(?!</miscMatter>).)*</miscMatter>',lambda m: _MiscSeq(m.group(),m.group(1)),FullCnt,0,re.I|re.S)
	# exit(FullCnt)
	for oldid in re.finditer(r'<[a-z\-\:0-9]+(?: [^>]*)? newid="([^"]+)"(?: [^>]*)? oldid="([^"]+)"(?: [^>]*)?>',FullCnt,re.I|re.S):
		old_new[oldid.group(2)] = oldid.group(1)

	FullCnt = re.sub(r' oldref="([^"]*)"',lambda m: r' ref="'+str(_ref_replacement(m.group(1)))+r'"',FullCnt,0,re.I|re.S)

	FullCnt = re.sub(r'(<[a-z\-\:0-9]+(?: [^>]*)?) oldid="[^"]+"((?: [^>]*)?/?>)',r'\g<1>\g<2>',FullCnt,0,re.I|re.S)
	FullCnt = re.sub(r'(<[a-z\-\:0-9]+(?: [^>]*)? )new(id="[^"]+"(?: [^>]*)?/?>)',r'\g<1>\g<2>',FullCnt,0,re.I|re.S)
	FullCnt = re.sub(r'<\?Insert-(Figure|Table|boxedMatter|media) ref="',r'<?Insert-\g<1> ID="',FullCnt,0,re.I|re.S)
	
	FullCnt = re.sub(r'\n\n',r'\n',FullCnt,0,re.S|re.I)
	FinalFile = InputDir+'\\'+str(idISBN)+'\\'+str(idISBN)+'.xml'
	_save_utf8(FinalFile,FullCnt)
	if os.path.isdir(InputDir+'\\output-'+str(idISBN)): shutil.rmtree(InputDir+'\\output-'+str(idISBN))
	#Call Book validation EXE
	_XmlValidation([FinalFile],'BOOK')
	#---
	shutil.make_archive(InputDir.rsplit('\\', 1)[0]+'\\'+str(idISBN)+'_to_Integra', "zip", InputDir+'\\'+str(idISBN))
	shutil.rmtree(InputDir+'\\'+str(idISBN))
#---

def _oso_PackageCreation():
	ErrStr = ""
	AllFiles = os.listdir(InputDir)
	if 'figures' not in AllFiles:
		ErrStr +="[1:1]: Error: [OUP-1020]: 'figures' folder is missing in input path.\n"
	if 'pdf' not in AllFiles:
		ErrStr +="[1:1]: Error: [OUP-1021]: 'pdf' folder is missing in input path.\n"
	xmlfile = _get_file_list(InputDir,1,0,r'^oso-\w+.xml$')
	if not os.path.isfile(xmlfile[0]):
		ErrStr +="[1:1]: Error: [OUP-1022]: oso xml file is missing in input path.\n"
	if(len(xmlfile) >1):
		ErrStr +="[1:1]: Error: [OUP-1023]: Extra xml files present in input path.\n"
	if(len(AllFiles) != 3):
		ErrStr +="[1:1]: Error: [OUP-1024]: Input directory only allowed folders ('figures','pdf') and 'xml' files. Please check extra files/folders.\n";
	if(ErrStr):
		CreateErrorLog(InputDir,"OUP_Book_PackageCreation Ver "+str(ToolVersion),ErrStr,0)
		print ("\n\tPlease clear the validation error!!!\n")
		sys.exit(0)
	else:
		_XmlValidation([xmlfile[0]],'BOOK')
		shutil.make_archive(InputDir, "zip", InputDir)
#Functions call
if(re.search(r'oso-\d+',basename(InputDir),re.I)):
	_oso_PackageCreation()
else:
	_Validation_tool_check()
	_Package_Validation()

#------ Local tracking -------------
_local_tracking(tool_id, ToolVersion, Tra_input,_get_file_size(Tra_input),st_time, _get_timestamp())
#-----------------------------------
print ("\n\tPackage Created successfully!!!\n");
sys.exit(0)