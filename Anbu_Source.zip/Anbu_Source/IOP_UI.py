import tkinter as tk
from tkinter import filedialog
import subprocess

def clear_result_label():
    result_label.config(text="")

def run_program_with_zip():
    clear_result_label()

    loading_label.config(text="Running your program. Please wait...")
    root.update_idletasks()  # Force immediate update of the label

    file_path = filedialog.askopenfilename(filetypes=[("Zip Files", "*.zip")])
    if file_path:
        loading_label.config(text="Extracting and running the program...")
        root.update_idletasks()  # Force immediate update of the label

        process = subprocess.Popen(
            ["IOPP.exe", file_path],  # Replace with your program's filename
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        output, error = process.communicate()

        if output:
            result_label.config(text=output, justify="left")  # Set text alignment to left
        else:
            result_label.config(text="No output", justify="left")
    else:
        result_label.config(text="No file selected", justify="left")

    loading_label.config(text="")  # Clear loading message after completion

# Create the main window
root = tk.Tk()
root.title("Run Program with Zip File")

# Set the initial size of the window in pixels (you might need to adjust based on DPI)
initial_width_pixels = root.winfo_fpixels("20c")
initial_height_pixels = root.winfo_fpixels("20c")
root.geometry(f"{int(initial_width_pixels)}x{int(initial_height_pixels)}")

# Create and place widgets
run_button = tk.Button(root, text="Run Program with Zip File", command=run_program_with_zip)
run_button.pack(pady=20)

loading_label = tk.Label(root, text="", justify="center")
loading_label.pack()

result_label = tk.Label(root, text="", justify="left")  # Set text alignment to left
result_label.pack()

# Start the main event loop
root.mainloop()
