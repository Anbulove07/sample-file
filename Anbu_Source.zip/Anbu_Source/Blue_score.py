import datetime
start_time = datetime.datetime.now()
import re
import nltk
from docx import Document
import docx2txt
from nltk.tokenize import word_tokenize
# nltk.download('wordnet')
# nltk.download('punkt')
# nltk.download('stopwords')
# nltk.download('punkt')
from nltk.translate.bleu_score import sentence_bleu
import os



# ###########   Simple UI   #######################
# import PySimpleGUI as sg
# sg.theme('Dark Blue 3')  # please make your windows colorful
# layout = [[sg.Text('Metrics Compare for Docx file for Translation Evaluaion')],
#           [sg.Text('Human Transalated file', size=(20, 1)), sg.InputText(), sg.FileBrowse()],
#     [sg.Text('Machine Transalated file', size=(20, 1)), sg.InputText(), sg.FileBrowse()],
#       [sg.Submit(), sg.Cancel()]]
# window = sg.Window('ML Recognize Image Match', layout, size=(600, 400))
# # window = sg.Window('My Window', layout, size=(300, 200))
# event, values = window.read()
# window.close()
# human_translated_file = values[0]       
# mt_translated_file = values[1]
# #############################################



def bleu_score_fun(text1, text2):
    reference =  [text1] 
    translated = text2 
    bleu_score = sentence_bleu(references=reference, hypothesis=translated) 
    return bleu_score

def count_words(sentence):
    words = word_tokenize(sentence)  # , preserve_line = True
    return len(words)

def read_wordfiles_1(file_path):
    def read_doc(file):
        f = open(file, 'r', encoding='latin1')
        text = f.read()
        f.close()
        return text
    try:
        new_text = docx2txt.process(file_path)
    except:
        new_text = read_doc(file_path)
    # print("\n\n\n\n  :: ", new_text)
    new_text=re.sub('\s+', ' ', new_text)
    new_text=re.sub('\t+', '\t', new_text)
    new_text=re.sub('\n+', '\n', new_text)
    # print("\n\n\n\n  :: ", new_text)
    return new_text


def bleu_score_fun_4_docx(human_translated_file, mt_translated_file):
    human_translated_file = human_translated_file
    mt_translated_file = mt_translated_file
    # print("mt_translated_file", mt_translated_file)
    # print("human_translated_file", human_translated_file)
    text1 = read_wordfiles_1(human_translated_file)
    word_count_h = count_words(text1)
    text2 = read_wordfiles_1(mt_translated_file)
    word_count_m = count_words(text2)
    sentence_bleu_score = bleu_score_fun(text1, text2)

    return sentence_bleu_score

# human_translated_file = human_translated_file
# mt_translated_file = mt_translated_file

# bleu_score, word_count_h, word_count_m = bleu_score_fun_4_docx(human_translated_file, mt_translated_file)
#
# print(f"Word count for Human translated file is :: {word_count_h}")
# print(f"Word count for Machine translated file is :: {word_count_m}")
# print(f"Sentence BLEU score: {round(bleu_score,4)*100}%")





#######################
"""
mt_translated_file D:/ML on Translation/Given by Anbu/Input/swis3e_9_4_EX2_sc_en.docx
human_translated_file C:/Users/is9904/Downloads/swis3e_9_4_EX2_sc_en es en-US.docx
Word count for Human translated file is :: 581
Word count for Machine translated file is :: 545
Sentence BLEU score: 0.8842


mt_translated_file D:/ML on Translation/Given by Anbu/Input_translated_Round_Trip/swis3e_11_1_EX3_sc_en_es_en.docx
human_translated_file D:/ML on Translation/Given by Anbu/Input/swis3e_11_1_EX3_sc_en.docx
Word count for Human translated file is :: 711
Word count for Machine translated file is :: 693
Sentence BLEU score: 0.9128


mt_translated_file D:/ML on Translation/Given by Anbu/Input_translated_Round_Trip/swis3e_11_1_EX3_ti_en_es_en-US.docx
human_translated_file D:/ML on Translation/Given by Anbu/Input/swis3e_11_1_EX3_ti_en.docx
Word count for Human translated file is :: 724
Word count for Machine translated file is :: 707
Sentence BLEU score: 0.9161


"""