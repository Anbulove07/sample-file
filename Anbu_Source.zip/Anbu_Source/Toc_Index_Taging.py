# ---------------------------------------------------------------------
#  Tool Name	: Toc_Index_Taging.py
#  Developer	: Anbu G
#  Description  : To Link Toc and Index
#  Client/DU	: OUP
#  Syntax		: <EXE> <XML> <TOC/Index>
# -----------------------------------------------------------------------



# ------------ Rivision History  -------------------------------------------
#  10-10-2022 | v1.0.0.0 | Anbu G | Initial Development
# --------------------------------------------------------------------------






import os.path
import sys
import re

from iModule.Basic import*
from iModule.ToolTracking import *


# xml_file=''
ToolVersion = "1.0.0.0";
print("\n\n\tCleanUp Tool v" + ToolVersion + " is Running...");
print("\tCopyright @ Integra Software Services Ltd.\n");


try :
    xml_file = sys.argv[1]
    Part = sys.argv[2]

except :
    # src = r'D:\Anbu\XML\pdftest.pdf'
    print("Please Enter Correct input \n\tSyntax    :   <EXE> <XML> <TOC/Index> ")
    sys.exit()


# _errfile=''
# with open((os.path.dirname(xml_file)) + "\\_erroLog.txt", "w", encoding="utf-8") as f1:
#     f1.write(_errfile)
#     f1.close()
# xml_file = sys.argv[1]
# print(sys.argv[1])


#------------ Tracking --------------------------------------------
Tra_input = sys.argv[1];
tool_id = 493; #TOClinking Tool
run_size = 0;
st_time = _get_timestamp();
#------------------------------------------------------------------
xml_cnt=_open_file(xml_file)
#
# with open(xml_file, "r", encoding="utf-8") as f1:
#     xml_cnt = f1.read()
#     f1.close()



if re.search(r'toc',Part,re.I|re.S):

    # print(xml_cnt)
    # exit()

    hash={}
    hash1={}
    hash2={}

    if re.search(r'<miscMatter(?: [^>]*)? class="contents">(?:(?!</miscMatter>).)*</miscMatter>',xml_cnt,re.I|re.S):
        misc_matt = re.search(r'<miscMatter(?: [^>]*)? class="contents">((?:(?!</miscMatter>).)*)</miscMatter>', xml_cnt, re.I | re.S)

        for m in re.finditer(r'<item\d+(?: [^>]*)?>\s*<p>((?:(?!</p>).)*)</p>',misc_matt.group(1),re.I|re.S):
            rem_tag=m.group(1)

            rem_tag=re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'',rem_tag,0,re.I|re.S)
            rem_tag=re.sub(r'^(\s*)|(\s*)$',r'',rem_tag,0,re.I|re.S)
            # print(rem_tag)
            for misck in re.finditer(r'<miscMatter(?: [^>]*)? id="([^"]*)"[^>]*?>(?:(?!</miscMatter>).)*</miscMatter>',xml_cnt,re.I|re.S):
                for titlegr in re.finditer(r'<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>',misck.group(),re.I|re.S):
                    if re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S):
                        titcnt=re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S)
                        rem_tag1 = re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'', titcnt.group(), 0, re.I | re.S)
                        # print(rem_tag,"------",rem_tag1)
                        # print()
                        # print(titlegr.group(1))
                        if re.search(rem_tag,rem_tag1,re.I|re.S):
                            # print(rem_tag)
                            hash[rem_tag]=misck.group(1)

            for misck in re.finditer(r'<chapter(?: [^>]*)? id="([^"]*)"[^>]*?>(?:(?!</chapter>).)*</chapter>',xml_cnt,re.I|re.S):
                for titlegr in re.finditer(r'<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>',misck.group(),re.I|re.S):
                    if re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S):
                        titcnt=re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S)
                        rem_tag1 = re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'', titcnt.group(), 0, re.I | re.S)
                        # print(rem_tag,"------",rem_tag1)
                        # print()
                        # print(titlegr.group(1))
                        if re.search(rem_tag,rem_tag1,re.I|re.S):
                            # print(rem_tag)
                            hash[rem_tag]=misck.group(1)

            for misck in re.finditer(r'<div(?: [^>]*)? id="([^"]*)"[^>]*?>(?:(?!</div>).)*</div>',xml_cnt,re.I|re.S):
                for titlegr in re.finditer(r'<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>',misck.group(),re.I|re.S):
                    if re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S):
                        titcnt=re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S)
                        rem_tag1 = re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'', titcnt.group(), 0, re.I | re.S)
                        # print(rem_tag,"------",rem_tag1)
                        # print()
                        # print(titlegr.group(1))
                        if re.search(rem_tag,rem_tag1,re.I|re.S):
                            # print(rem_tag)
                            hash[rem_tag]=misck.group(1)

            for misck in re.finditer(r'<figureGroup(?: [^>]*)? id="([^"]*)"[^>]*?>(?:(?!</figureGroup>).)*</figureGroup>',xml_cnt,re.I|re.S):
                for titlegr in re.finditer(r'<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>',misck.group(),re.I|re.S):
                    if re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S):
                        titcnt=re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S)
                        rem_tag1 = re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'', titcnt.group(), 0, re.I | re.S)
                        # print(rem_tag,"------",rem_tag1)
                        # print()
                        # print(titlegr.group(1))
                        if re.search(rem_tag,rem_tag1,re.I|re.S):
                            # print(rem_tag)
                            hash[rem_tag]=misck.group(1)

            for misck in re.finditer(r'<tableGroup(?: [^>]*)? id="([^"]*)"[^>]*?>(?:(?!</tableGroup>).)*</tableGroup>',xml_cnt,re.I|re.S):
                for titlegr in re.finditer(r'<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>',misck.group(),re.I|re.S):
                    if re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S):
                        titcnt=re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S)
                        rem_tag1 = re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'', titcnt.group(), 0, re.I | re.S)
                        # print(rem_tag,"------",rem_tag1)
                        # print()
                        # print(titlegr.group(1))
                        if re.search(rem_tag,rem_tag1,re.I|re.S):
                            # print(rem_tag)
                            hash[rem_tag]=misck.group(1)

            for misck in re.finditer(r'<appendix(?: [^>]*)? id="([^"]*)"[^>]*?>(?:(?!</appendix>).)*</appendix>',xml_cnt,re.I|re.S):
                for titlegr in re.finditer(r'<titleGroup(?: [^>]*)?>((?:(?!</titleGroup>).)*)</titleGroup>',misck.group(),re.I|re.S):
                    if re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S):
                        titcnt=re.search(r'<title(?: [^>]*)?>((?:(?!</title>).)*)</title>',titlegr.group(),re.I|re.S)
                        rem_tag1 = re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'', titcnt.group(), 0, re.I | re.S)
                        # print(rem_tag,"------",rem_tag1)
                        # print()
                        # print(titlegr.group(1))
                        if re.search(rem_tag,rem_tag1,re.I|re.S):
                            # print(rem_tag)
                            hash[rem_tag]=misck.group(1)


    for table in  re.finditer(r'<list class="tables">(?:(?!</list>).)*</list>',xml_cnt,re.I|re.S):
        # print(table.group())
        for itemcnt in re.finditer(r'<item\d+(?: [^>]*)?>\s*<p>((?:(?!</p>).)*)</p>',table.group(),re.I|re.S):
            rem_tag2 = itemcnt.group(1)

            rem_tag2 = re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'', rem_tag2, 0, re.I | re.S)
            rem_tag2 = re.sub(r'^(\s*)|(\s*)$', r'', rem_tag2, 0, re.I | re.S)
            # print(rem_tag2)

            for titlegr in re.finditer(r'<tableGroup(?: [^>]*)? id="([^"]*)"[^>]*?>(?:(?!</tableGroup>).)*</tableGroup>',xml_cnt,re.I|re.S):
                # if re.search(r'<tableGroup(?: [^>]*)? id="([^"]*)"[^>]*?>(?:(?!</tableGroup>).)*</tableGroup>',titlegr.group(),re.I|re.S):
                titcnt=re.search(r'<titleGroup(?: [^>]*)? id="([^"]*)"[^>]*?>(?:(?!</titleGroup>).)*</titleGroup>',titlegr.group(),re.I|re.S)
                # print(titcnt.group())
                rem_tag22 = re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'', titcnt.group(), 0, re.I | re.S)
                rem_tag22 = re.sub(r'^(\s*)|(\s*)$', r'', rem_tag22, 0, re.I | re.S)
                # print(rem_tag,"------",rem_tag1)
                # print("-----1-------")
                # print(rem_tag22)
                # print("-----2-------")
                # if re.search(rem_tag22,rem_tag2,re.I|re.S):
                if rem_tag22==rem_tag2:
                    # print(rem_tag2,"--",titcnt.group(1))
                    hash1[rem_tag2]=titlegr.group(1)
    for table in  re.finditer(r'<list class="figures">(?:(?!</list>).)*</list>',xml_cnt,re.I|re.S):
        # print(table.group())
        for itemcnt in re.finditer(r'<item\d+(?: [^>]*)?>\s*<p>((?:(?!</p>).)*)</p>',table.group(),re.I|re.S):
            rem_tag2 = itemcnt.group(1)

            rem_tag2 = re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'', rem_tag2, 0, re.I | re.S)
            rem_tag2 = re.sub(r'^(\s*)|(\s*)$', r'', rem_tag2, 0, re.I | re.S)
            # print(rem_tag2)

            for titlegr in re.finditer(r'<figureGroup(?: [^>]*)? id="([^"]*)"[^>]*?>(?:(?!</figureGroup>).)*</figureGroup>',xml_cnt,re.I|re.S):
                # if re.search(r'<tableGroup(?: [^>]*)? id="([^"]*)"[^>]*?>(?:(?!</tableGroup>).)*</tableGroup>',titlegr.group(),re.I|re.S):
                titcnt=re.search(r'<figureGroup(?: [^>]*)? id="([^"]*)"[^>]*?>(?:(?!</figureGroup>).)*</figureGroup>',titlegr.group(),re.I|re.S)
                # print(titcnt.group())
                rem_tag22 = re.sub(r'(<enumerator>(?:(?!</enumerator>).)*</enumerator>|(<pageNum(?: [^>]*)?>(?:(?!</pageNum>).)*</pageNum>|<(?:[^>]*)>))',r'', titcnt.group(), 0, re.I | re.S)
                rem_tag22 = re.sub(r'^(\s*)|(\s*)$', r'', rem_tag22, 0, re.I | re.S)
                # print(rem_tag,"------",rem_tag1)
                # print("-----1-------")
                # print(rem_tag22)
                # print("-----2-------")
                # if re.search(rem_tag22,rem_tag2,re.I|re.S):
                if rem_tag22==rem_tag2:
                    # print(rem_tag2,"--",titcnt.group(1))
                    hash2[rem_tag2]=titlegr.group(1)

    # print(hash1)





    # print(hash)

    def _tmpfunc(txt):
        for key,value in hash.items():
            txt = re.sub(r'(<item(\d+)(?: [^>]*)?>(?:(?!</?item\2|i>).)*)(<i>)?\s*'+re.escape(key)+r'\s*(</i>)?((?:(?!</item\2>).)*</item\2>)',r'\g<1><xrefGrp><xref ref="'+value+'">\g<3>'+key+r'\g<4></xref></xrefGrp>\g<5>',txt,0,re.I|re.S)
        # print(txt)
        return txt


    def _tmpfunc1(txt):
        # print(txt)
        for key, value in hash1.items():
            # print("ok" + key + "ok")
            txt = re.sub(r'(<item(\d+)(?: [^>]*)?>(?:(?!</?item\2|i>).)*)(<i>)?\s*' +re.escape(key)+ r'\s*(</i>)?((?:(?!</item\2>).)*</item\2>)',r'\g<1><xrefGrp><xref ref="' + value + '">\g<3>' + key + r'\g<4></xref></xrefGrp>\g<5>', txt, 0,re.I | re.S)
            # print(txt)
        return txt

    def _tmpfunc2(txt):
        # print(txt)
        for key, value in hash2.items():
            # print("ok" + key + "ok")
            txt = re.sub(r'(<item(\d+)(?: [^>]*)?>(?:(?!</?item\2|i>).)*)(<i>)?\s*' +re.escape(key)+ r'\s*(</i>)?((?:(?!</item\2>).)*</item\2>)',r'\g<1><xrefGrp><xref ref="' + value + '">\g<3>' + key + r'\g<4></xref></xrefGrp>\g<5>', txt, 0,re.I | re.S)
            # print(txt)
        return txt

    xml_cnt = re.sub(r'<miscMatter(?: [^>]*)? class="contents">(?:(?!</miscMatter>).)*</miscMatter>',lambda m: _tmpfunc(m.group()) ,xml_cnt,0,re.I | re.S)

    xml_cnt = re.sub(r'<list class="tables">(?:(?!</list>).)*</list>',lambda m: _tmpfunc1(m.group()) ,xml_cnt,0,re.I | re.S)
    xml_cnt = re.sub(r'<list class="figures">(?:(?!</list>).)*</list>',lambda m: _tmpfunc2(m.group()) ,xml_cnt,0,re.I | re.S)
    # print(xml_cnt)


    _save_file(xml_file,xml_cnt)

    # ------ Local tracking -------------
    _local_tracking(tool_id, ToolVersion, Tra_input,_get_file_size(Tra_input),st_time, _get_timestamp())
    # -----------------------------------
    print ("\n\tTOC Link Created successfully!!!\n")
    sys.exit(0)


if re.search(r'index', Part,re.I|re.S):
    # print("ok")

    # ----------------------------------------------Need to update-----------------------------------------------
    # def _getindexvalue(fulltag,opentag,grpno,closetag,endtag):
    #     # print(text1)
    #     if re.search(r'<milestone id="(\w+-\d+-\w+-\d+-milestone-'+grpno+')',xml_cnt,re.I|re.S):
    #         qq=re.search(r'<milestone id="(\w+-\d+-\w+-\d+-milestone-'+grpno+')',xml_cnt,re.I|re.S)
    #         idvalue=qq.group(1)
    #         text1="<xrefGrp>"+opentag+"<xref ref="+idvalue+">"+grpno+"</xref></pageNum></xrefGrp>"+endtag
    #         fulltag=re.sub(fulltag,text1,fulltag,0,re.I|re.S)
    #
    #     return fulltag
    # xml_cnt=re.sub(r'(<pageNum(?: [^>]*)?>)((?:(?!</pageNum>).)*)(</pageNum>)\s*(<i>(?:(?!</i>).)*</i>)',lambda m: _getindexvalue(m.group(),m.group(1),m.group(2),m.group(3),m.group(4)) ,xml_cnt,0,re.I|re.S)
    # # print(xml_cnt)
    # _save_file(xml_file, xml_cnt)
    #-------------------------------------------------------------------------------------------------------------




    def _getindexvaluetable(fulltag,opentag,grpno,closetag,endtag):
        # print(text1)
        if re.search(r'<list class="tables">(?:(?!</list>).)*</list>',xml_cnt,re.I|re.S):
            qq1=re.search(r'<list class="tables">(?:(?!</list>).)*</list>',xml_cnt,re.I|re.S)
            if re.search(r'<item(\d+)?(?: [^>]*)?>((?:(?!</item(\d+)?>).)*)</item(\d+)?>',qq1.group(),re.I|re.S):
                qq2=re.search(r'<item(\d+)?(?: [^>]*)?>((?:(?!</item(\d+)?>).)*)</item(\d+)?>',qq1.group(),re.I|re.S)
                if re.search(r'(\w+-\d+-\w+-\d+-milestone-'+grpno+')',qq2.group(),re.I|re.S):
                    if re.search(r'\w+-\d+-\w+-\d+-tableGroup-\d+',qq2.group(),re.I|re.S):
                        fulltag1=re.search(r'\w+-\d+-\w+-\d+-tableGroup-\d+', qq2.group(), re.I | re.S)
                        fulltag = "<xrefGrp>" + opentag + "<xref ref=\"" + fulltag1.group() + "\">" + grpno + "</xref></pageNum></xrefGrp>" + endtag
                        # print(fulltag)


        # if re.search(r'<milestone id="(\w+-\d+-\w+-\d+-milestone-'+grpno+')',xml_cnt,re.I|re.S):
        #     qq=re.search(r'<milestone id="(\w+-\d+-\w+-\d+-milestone-'+grpno+')((?:(?!<milestone [^>]*).)*)',xml_cnt,re.I|re.S)
        #     idvalue=qq.group()
        #     # text1="<xrefGrp>"+opentag+"<xref ref="+idvalue+">"+grpno+"</xref></pageNum></xrefGrp>"+endtag
        #     # fulltag=re.sub(fulltag,text1,fulltag,0,re.I|re.S)
        #     if re.search(r'<\?Insert-Table(?: [^>]*)? ID="([^>]*)"(?: [^>]*)?\?>',idvalue,re.I|re.S):
        #         fulltextID=re.search(r'<\?Insert-Table(?: [^>]*)? ID="([^>]*)"(?: [^>]*)?\?>',idvalue,re.I|re.S)
        #         fulltag1=fulltextID.group(1)
        #         fulltag = "<xrefGrp>" + opentag + "<xref ref=\"" + fulltag1 + "\">" + grpno + "</xref></pageNum></xrefGrp>" + endtag
        else:
            fulltag=fulltag
        # else:
        #     _errfile = "\n" + fulltag + "\t- Not updated!!! Please Check and update "
        #     with open((os.path.dirname(xml_file)) + "\\_erroLog.txt", "a", encoding="utf-8") as f1:
        #         f1.write(_errfile)
        #         f1.close()


        return fulltag

    def _getindexvaluefig(fulltag,opentag,grpno,closetag,endtag):
        if re.search(r'<list class="figures">(?:(?!</list>).)*</list>',xml_cnt,re.I|re.S):
            qq1=re.search(r'<list class="figures">(?:(?!</list>).)*</list>',xml_cnt,re.I|re.S)
            if re.search(r'<item(\d+)?(?: [^>]*)?>((?:(?!</item(\d+)?>).)*)</item(\d+)?>',qq1.group(),re.I|re.S):
                qq2=re.search(r'<item(\d+)?(?: [^>]*)?>((?:(?!</item(\d+)?>).)*)</item(\d+)?>',qq1.group(),re.I|re.S)
                if re.search(r'(\w+-\d+-\w+-\d+-milestone-'+grpno+')',qq2.group(),re.I|re.S):
                    if re.search(r'\w+-\d+-\w+-\d+-figureGroup-\d+',qq2.group(),re.I|re.S):
                        fulltag1=re.search(r'\w+-\d+-\w+-\d+-figureGroup-\d+', qq2.group(), re.I | re.S)
                        fulltag = "<xrefGrp>" + opentag + "<xref ref=\"" + fulltag1.group() + "\">" + grpno + "</xref></pageNum></xrefGrp>" + endtag
                        # print(fulltag)

        # print(text1)
        # if re.search(r'<milestone id="(\w+-\d+-\w+-\d+-milestone-'+grpno+')',xml_cnt,re.I|re.S):
        #     qq=re.search(r'<milestone id="(\w+-\d+-\w+-\d+-milestone-'+grpno+')((?:(?!<milestone [^>]*).)*)',xml_cnt,re.I|re.S)
        #     idvalue=qq.group()
        #     # text1="<xrefGrp>"+opentag+"<xref ref="+idvalue+">"+grpno+"</xref></pageNum></xrefGrp>"+endtag
        #     # fulltag=re.sub(fulltag,text1,fulltag,0,re.I|re.S)
        #     if re.search(r'<\?Insert-Figure(?: [^>]*)? ID="([^>]*)"(?: [^>]*)?\?>',idvalue,re.I|re.S):
        #         fulltextID=re.search(r'<\?Insert-Figure(?: [^>]*)? ID="([^>]*)"(?: [^>]*)?\?>',idvalue,re.I|re.S)
        #         fulltag1=fulltextID.group(1)
        #         fulltag = "<xrefGrp>" + opentag + "<xref ref=\"" + fulltag1 + "\">" + grpno + "</xref></pageNum></xrefGrp>" + endtag
        else:
            fulltag=fulltag
        # else:
        #     _errfile = "\n" + fulltag + "\t- Not updated!!! Please Check and update "
        #     with open((os.path.dirname(xml_file)) + "\\_erroLog.txt", "a", encoding="utf-8") as f1:
        #         f1.write(_errfile)
        #         f1.close()
        #

        return fulltag


    def _getindexgrp(fulltag3):


    # print(text1)
        for qq1 in re.finditer(r'<indexItem(\d+)?(?: [^>]*)>(?:(?!</indexItem(\d+)?>).)*</indexItem(\d+)?>',fulltag3,re.I|re.S):
            # qq1=re.search(r'<indexItem(\d+)?(?: [^>]*)>(?:(?!</indexItem(\d+)?>).)*</indexItem(\d+)?>',xml_cnt,re.I|re.S)
            for qq2 in re.finditer(r'(<pageNum(?: [^>]*)?>)(\d+)(?:(?!</pageNum>).)*(</pageNum>)((?:(?!<).)*)',qq1.group(),re.I|re.S):
                # qq2=re.search(r'(<pageNum(?: [^>]*)?>)(\d+)(?:(?!</pageNum>).)*(</pageNum>)((?:(?!<).)*)',qq1.group(),re.I|re.S)
                if re.search(r'n',qq2.group(4),re.I|re.S):
                    z1 = re.search('\d+',qq2.group(4),re.I|re.S)
                    # print(z1.group())
                    # print(qq2.group(2)+"--"+z1.group())
                    if re.search(r'<milestone id="\w+-\d+-\w+-\d+-milestone-'+qq2.group(2)+'"(?:(?!ref="\w+-\d+-\w+-\d+-note-'+z1.group()+'">\s*<sup>\s*'+z1.group()+'\s*</sup>).)*ref="(\w+-\d+-\w+-\d+-note-'+z1.group()+')">\s*<sup>\s*'+z1.group()+'\s*</sup>',xml_cnt,re.I|re.S):
                        z2=re.search(r'<milestone id="\w+-\d+-\w+-\d+-milestone-'+qq2.group(2)+'"(?:(?!ref="\w+-\d+-\w+-\d+-note-'+z1.group()+'">\s*<sup>\s*'+z1.group()+'\s*</sup>).)*ref="(\w+-\d+-\w+-\d+-note-'+z1.group()+')">\s*<sup>\s*'+z1.group()+'\s*</sup>',xml_cnt,re.I|re.S)
                        # print(z2.group(1))
                        # z4=qq2.group()
                        # substring="<xrefGrp><xref ref=\"" + z2.group(1) + "\">" + grpno + "</xref></pageNum></xrefGrp>" + endtag
                        substring='<xrefGrp>'+qq2.group(1)+'<xref ref="'+z2.group(1)+'">'+qq2.group(2)+'</xref></pageNum>'+qq2.group(4)+'</xrefGrp>'
                        # fulltag11=re.sub(qq2.group(),r'<xrefGrp>'+qq2.group(1)+r'<xref ref="'+z2.group(1)+r'">'+qq2.group(2)+r'</xref></pageNum>'+qq2.group(4)+r'</xrefGrp>',qq1.group(),0,re.I|re.S)

                        fulltag3=re.sub(qq2.group(),substring,fulltag3,0,re.I|re.S)
                        # print(fulltag11)


        return fulltag3
    # def _getindexvaluebox(fulltag,opentag,grpno,closetag,endtag):
    #     # print(text1)
    #     if re.search(r'<list class="tables">(?:(?!</list>).)*</list>',xml_cnt,re.I|re.S):
    #         qq1=re.search(r'<list class="tables">(?:(?!</list>).)*</list>',xml_cnt,re.I|re.S)
    #         if re.search(r'<item(\d+)?(?: [^>]*)?>((?:(?!</item(\d+)?>).)*)</item(\d+)?>',qq1.group(),re.I|re.S):
    #             qq2=re.search(r'<item(\d+)?(?: [^>]*)?>((?:(?!</item(\d+)?>).)*)</item(\d+)?>',qq1.group(),re.I|re.S)
    #             if re.search(r'(\w+-\d+-\w+-\d+-milestone-'+grpno+')',qq2.group(),re.I|re.S):
    #                 if re.search(r'\w+-\d+-\w+-\d+-tableGroup-\d+',qq2.group(),re.I|re.S):
    #                     fulltag1=re.search(r'\w+-\d+-\w+-\d+-tableGroup-\d+', qq2.group(), re.I | re.S)
    #                     fulltag = "<xrefGrp>" + opentag + "<xref ref=\"" + fulltag1.group() + "\">" + grpno + "</xref></pageNum></xrefGrp>" + endtag
    #                     # print(fulltag)
    #     # if re.search(r'<milestone id="(\w+-\d+-\w+-\d+-milestone-'+grpno+')',xml_cnt,re.I|re.S):
    #     #     qq=re.search(r'<milestone id="(\w+-\d+-\w+-\d+-milestone-'+grpno+')((?:(?!<milestone [^>]*).)*)',xml_cnt,re.I|re.S)
    #     #     idvalue=qq.group()
    #     #     # text1="<xrefGrp>"+opentag+"<xref ref="+idvalue+">"+grpno+"</xref></pageNum></xrefGrp>"+endtag
    #     #     # fulltag=re.sub(fulltag,text1,fulltag,0,re.I|re.S)
    #     #     if re.search(r'<\?Insert-boxMatter(?: [^>]*)? ID="([^>]*)"(?: [^>]*)?\?>',idvalue,re.I|re.S):
    #     #         fulltextID=re.search(r'<\?Insert-boxMatter(?: [^>]*)? ID="([^>]*)"(?: [^>]*)?\?>',idvalue,re.I|re.S)
    #     #         fulltag1=fulltextID.group(1)
    #     #         fulltag = "<xrefGrp>" + opentag + "<xref ref=\"" + fulltag1 + "\">" + grpno + "</xref></pageNum></xrefGrp>" + endtag
    #     else:
    #         fulltag=fulltag
    #     # else:
    #     #     _errfile = "\n" + fulltag + "\t- Not updated!!! Please Check and update "
    #     #     with open((os.path.dirname(xml_file)) + "\\_erroLog.txt", "a", encoding="utf-8") as f1:
    #     #         f1.write(_errfile)
    #     #         f1.close()
    #     return fulltag
    xml_cnt=re.sub(r'(<pageNum(?: [^>]*)?>)(\d+)(?:(?!</pageNum>).)*(</pageNum>)\s*(<i>t</i>)',lambda m: _getindexvaluetable(m.group(),m.group(1),m.group(2),m.group(3),m.group(4)) ,xml_cnt,0,re.I|re.S)
    xml_cnt = re.sub(r'(<pageNum(?: [^>]*)?>)(\d+)(?:(?!</pageNum>).)*(</pageNum>)\s*(<i>f</i>)',lambda m: _getindexvaluefig(m.group(), m.group(1), m.group(2), m.group(3), m.group(4)), xml_cnt, 0,re.I | re.S)
    # xml_cnt = re.sub(r'(<pageNum(?: [^>]*)?>)(\d+)(?:(?!</pageNum>).)*(</pageNum>)\s*(<i>b</i>)',lambda m: _getindexvaluebox(m.group(), m.group(1), m.group(2), m.group(3), m.group(4)), xml_cnt, 0,re.I | re.S)




    xml_cnt = re.sub(r'<indexGroup(?: [^>]*)>(?:(?!</indexGroup>).)*</indexGroup>',lambda m: _getindexgrp(m.group()), xml_cnt, 0,re.I | re.S)
    # print(xml_cnt)


    def _getindexvalue(fulltag,opentag,grpno,closetag):
        # print(text1)
        if re.search(r'<milestone id="(\w+-\d+-\w+-\d+-milestone-'+grpno+')',xml_cnt,re.I|re.S):
            qq=re.search(r'<milestone id="(\w+-\d+-\w+-\d+-milestone-'+grpno+')',xml_cnt,re.I|re.S)
            idvalue=qq.group(1)
            text1="<xrefGrp>"+opentag+"<xref ref=\""+idvalue+"\">"+grpno+"</xref></pageNum></xrefGrp>"
            fulltag=re.sub(fulltag,text1,fulltag,0,re.I|re.S)
        # else:
        #     _errfile = "\n" + fulltag + "\t- Not updated!!! Please Check and update "
        #     with open((os.path.dirname(xml_file)) + "\\_erroLog.txt", "a", encoding="utf-8") as f1:
        #         f1.write(_errfile)
        #         f1.close()
        return fulltag
    # xml_cnt=re.sub(r'(<pageNum(?: [^>]*)?>)((?:(?!</pageNum>).)*)(</pageNum>)',lambda m: _getindexvalue(m.group(),m.group(1),m.group(2),m.group(3)) ,xml_cnt,0,re.I|re.S)
    # print(xml_cnt)
    _save_file(xml_file, xml_cnt)


    # _save_file(xml_file, xml_cnt)
    # ------ Local tracking ------------------
    _local_tracking(tool_id, ToolVersion, Tra_input, _get_file_size(Tra_input), st_time, _get_timestamp());
    # -----------------------------------------

    print("\n\tIndex Created successfully!!!\n")
    sys.exit(0)

