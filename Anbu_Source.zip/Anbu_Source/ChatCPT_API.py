import re
from os.path import dirname

import openai
import os
import sys


ToolVersion = "1.0.15.0"
apppath = dirname(sys.argv[0]);
apppath = re.sub(r'\/', r'\\', apppath, 0)

os.system("cls");

print("\n\n\tChat-GPT OpenAI  v" + ToolVersion + " is Running...\n")

#---------Inline argument checking & File path checking------------#
if (len(sys.argv) != 2 or not os.path.isfile(sys.argv[1])):
    sys.exit("\n\tSyntax: Chat-GPT.exe <Input file>\n")

with open(sys.argv[1], "r", encoding="utf-8") as f1:
    input = f1.read().split("\n")

modelmethod = ""
modelmethod1 = ""
modlfun = os.path.basename(sys.argv[1]).split(".")[0]

if re.search('_fullout', modlfun, re.I|re.S):
    modelmethod= "full form for"
    modelmethod1= 1
    # print("Full output")

if re.search('_abbreviation_with_dot', modlfun, re.I|re.S):
    modelmethod= "abbreviation with dot for"
    modelmethod1 = 2
    # print("abbreviation_with_dot")

if re.search('_abbreviation_without_dot', modlfun, re.I|re.S):
    modelmethod= "abbreviation without dot for"
    modelmethod1 = 3
    # print("abbreviation_without_dot")

if modelmethod == "":
    print("Please check input file name")
    sys.exit()

# Define OpenAI API key
# openai.api_key = "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"
openai.api_key = "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"

# openai.api_key = "YOUR_API_KEY"

# Set up the model and prompt
model_engine = "text-davinci-003"
# prompt = "Once upon a time, in a land far, far away, there was a princess who..."
# prompt = sys.argv[1]
# prompt = f"give abbreviation of {sys.argv[1]}"
# print("Enter Full form to get abbreviation")
# prompt = f"citation abbreviation for {input()}"
# prompt = f"abbreviate without dot for {input()}"
arr=[]

for x in input:
    prompt = f"{modelmethod} {x}"
    # Generate a response
    completion = openai.Completion.create(
        engine=model_engine,
        prompt=prompt,
        max_tokens=1024,
        n=1,
        stop=None,
        temperature=0.5,
    )

    response = completion.choices[0].text
    if len(response) < 200:
        # response = "No response"
        # print(x)
        # print(response)
        arr.append(x)
        response = response.replace("\n", " ")
        arr.append(response)
        print(x+" : "+response)
#
# def makedir(path):
#     if not os.path.exists(path):
#         os.makedirs(path)
#
# makedir(dirname(sys.argv[1]) + "\\output")
filename=sys.argv[1].replace(".txt","_output.txt")

if modelmethod1 == 1:
    with open(filename, "w", encoding="utf-8") as f1:
        for x in arr:
            f1.write(x)
            f1.write("\n")
if modelmethod1 == 2:
    with open(filename, "w", encoding="utf-8") as f1:
        for x in arr:
            f1.write(x)
            f1.write("\n")
if modelmethod1 == 3:
    with open(filename, "w", encoding="utf-8") as f1:
        for x in arr:
            f1.write(x)
            f1.write("\n")

with open(filename, "r", encoding="utf-8") as f1:
    cont=f1.read()
    cont = re.sub('\n\s+', '\t|\t', cont, 0, re.I | re.S)
    with open(filename, "w", encoding="utf-8") as f21:
        f21.write(cont)

print("Output file generated in output folder")
#
# with open(sys.argv[1].replace(), "r", encoding="utf-8") as f1:
#     input = f1.read().split("\n")
#     for x in arr:
#

