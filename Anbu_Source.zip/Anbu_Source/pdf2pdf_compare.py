import pdfplumber
import difflib

def extract_text_from_pdf(pdf_path):
    with pdfplumber.open(pdf_path) as pdf:
        pages_text = []
        for page in pdf.pages:
            pages_text.append(page.extract_text())
        return "\n".join(pages_text)

def compare_pdfs_line_numbers(pdf_path1, pdf_path2):
    # Load PDF contents from both files
    text1 = extract_text_from_pdf(pdf_path1)
    text2 = extract_text_from_pdf(pdf_path2)

    # Convert text to lists of lines
    lines1 = text1.splitlines()
    lines2 = text2.splitlines()

    # Calculate differences using difflib
    diff = difflib.unified_diff(lines1, lines2, fromfile='Original', tofile='Modified', lineterm='')

    # Extract changed line numbers
    changed_line_numbers = [line[1:] for line in diff if line.startswith('+')]
    changed_line_numbers = [int(line.split(' ')[0]) for line in changed_line_numbers if line.split(' ')[0].isdigit()]

    return changed_line_numbers

if __name__ == "__main__":
    original_pdf_path = r"D:\Giventool\karthik\IOPP\IOPP\Input\TRAN_114304\Source\2DMacec58\2DMacec58.pdf"
    modified_pdf_path =  r"D:\Giventool\karthik\IOPP\IOPP\Input\TRAN_114304\Source\2DMacec58\Towards_tunable_PnCs_Clean1.pdf"

    changed_line_numbers = compare_pdfs_line_numbers(original_pdf_path, modified_pdf_path)
    print("Mistake Line Numbers:")
    print(changed_line_numbers)



# if __name__ == "__main__":
#     pdf_path1 = r"D:\Giventool\karthik\IOPP\IOPP\Input\TRAN_114304\Source\2DMacec58\2DMacec58.pdf"
#     pdf_path2 = r"D:\Giventool\karthik\IOPP\IOPP\Input\TRAN_114304\Source\2DMacec58\Towards_tunable_PnCs_Clean1.pdf"
#     print_diff_between_pdfs(pdf_path1, pdf_path2)
#
# # if __name__ == "__main__":
# #     pdf_path1 = r"D:\Giventool\karthik\IOPP\IOPP\Input\TRAN_114304\Source\2DMacec58\2DMacec58.pdf"
# #     pdf_path2 = r"D:\Giventool\karthik\IOPP\IOPP\Input\TRAN_114304\Source\2DMacec58\Towards_tunable_PnCs_Clean1.pdf"
# #     diff_content = compare_pdfs(pdf_path1, pdf_path2)
# #     print(diff_content)
# # if __name__ == "__main__":
# #     pdf_path1 = r"D:\Giventool\karthik\IOPP\IOPP\Input\TRAN_114304\Source\2DMacec58\2DMacec58.pdf"
# #     pdf_path2 = r"D:\Giventool\karthik\IOPP\IOPP\Input\TRAN_114304\Source\2DMacec58\Towards_tunable_PnCs_Clean1.pdf"
# #
#     accuracy_score = compare_pdfs(pdf_path1, pdf_path2)
#     print(f"Similarity Score: {accuracy_score:.2f}%")
