from iModule.Basic import _open_file

from gtts import gTTS
import os

def text_to_audio(text, output_file):
    tts = gTTS(text=text, lang='es')
    tts.save(output_file)

# Example usage
text =_open_file(r"D:\Giventool\Pradeep\Translate\21-06-2023\Video Transcripts for Testing\Text Transcripts - English\swis3e_9_4_EX2_sc_en.txt")
output_file = r"D:\Test\test\output1.mp3"
text_to_audio(text, output_file)
