import datetime
start_time= datetime.datetime.now()
from transformers import MarianMTModel, MarianTokenizer
from langdetect import detect
from threading import Thread
import queue
from langdetect import detect
import os
import spacy
import nltk

def detect_language(text):
    lang = detect(text)
    return lang

def calculate_similarity(sentence1, sentence2):
    nlp = spacy.load('en_core_web_md')
    doc1 = nlp(sentence1)
    doc2 = nlp(sentence2)
    similarity_percentage = doc1.similarity(doc2) * 100
    return similarity_percentage

def split_paragraphs(text, char_limit):
    paragraphs = text.split('\n\n')  # Assuming paragraphs are separated by two line breaks
    chunks = []
    current_chunk = ""

    for paragraph in paragraphs:
        if len(current_chunk) + len(paragraph) <= char_limit:
            current_chunk += paragraph + "\n"
        else:
            chunks.append(current_chunk.strip())
            current_chunk = paragraph + "\n"

    if current_chunk:
        chunks.append(current_chunk.strip())

    return chunks

def translate_text(que,index,text,source_lang, target_lang, max_tokens=512):
    print(f"translation for the para {index} started...")
    model_name = f'Helsinki-NLP/opus-mt-{source_lang}-{target_lang}'
    model = MarianMTModel.from_pretrained(model_name)
    tokenizer = MarianTokenizer.from_pretrained(model_name)

    # Split input text into segments
    segments = []
    sentences = text.splitlines()  #split lines

    for sentence in sentences:
        segments.append(sentence)

    translated_segments = []
    batch_size = 10  # Adjust batch size as per your resources
    for i in range(0, len(segments), batch_size):
        batch = segments[i : i + batch_size]
        encoded_inputs = tokenizer.batch_encode_plus(
            batch,
            padding="longest",
            truncation=True,
            max_length=max_tokens,
            return_tensors="pt"
        )
        translated = model.generate(**encoded_inputs, max_length=max_tokens)
        translated_texts = tokenizer.batch_decode(translated, skip_special_tokens=True)
        translated_segments.extend(translated_texts)
        # print(translated_segments)

    translated_text = "\n".join(translated_segments)
    print(f"translated para {index}...")
    
    que.put((index,translated_text))

file_path = "lang_trans\\swis3e_9_4_EX2_sc_en.txt" # change as per requirement
file_name = ""
with open(file_path, 'r') as file:
    text = file.read()
    file_name = os.path.splitext(os.path.basename(file.name))[0]

# print(file_name)
paragraphs = split_paragraphs(text, 1500)
source_text = "\n\n".join(paragraphs)
# for i, paragraph in enumerate(paragraphs):
#     print(f"Paragraph {i+1}:\n{paragraph}\n")

source_lang=detect_language(text=text)
target_lang="es"
final_output = ""

# this just translate the test para wise

# for para in paragraphs:
#     temp = translate_text(text=para,source_lang=source_lang,target_lang=target_lang)
#     final_output = final_output + temp + "\n\n"

# print(final_output)

# trying with multi threading in python

# creating number of threads
num_threads = len(paragraphs)
threads = []

# creating queues
queues=[]
for i in range(num_threads):
    q = queue.Queue()
    queues.append(q)

for i in range(num_threads):
    t = Thread(target=translate_text, args=(queues[i],i,paragraphs[i],source_lang,target_lang))
    t.start()
    threads.append(t)

for thread in threads:
    thread.join()

# translated paras
translated_paras = []


for que in queues:
    index, trans = que.get()
    translated_paras.insert(index,trans)

final_output = "\n\n".join(translated_paras)

output_file_path=""
with open(f"lang_trans\\translated_files\\{file_name}_translated_to_{target_lang}.txt","w",encoding="utf-8") as file:
    file.write(final_output)
    output_file_path = file.name

print(f"Translated check {output_file_path}")

# obtaining reference text
paragraphs_ref = split_paragraphs(final_output, 1500)
num_threads_ref = len(paragraphs_ref)
threads_ref = []

# creating queues
queues_ref=[]
for i in range(num_threads_ref):
    q = queue.Queue()
    queues_ref.append(q)

for i in range(num_threads_ref):
    t = Thread(target=translate_text, args=(queues_ref[i],i,paragraphs_ref[i],target_lang,source_lang))
    t.start()
    threads.append(t)

for thread in threads:
    thread.join()

# reference paras
reference_paras = []

for que in queues_ref:
    index, trans = que.get()
    reference_paras.insert(index,trans)

ref_final_output = "\n\n".join(reference_paras)
print("**********************************************************************************************")
print("\nTranslated Text: \n")
print(final_output)
print("Reference Text: \n")
print(ref_final_output)
print("**********************************************************************************************")
print("Similarity %",calculate_similarity(source_text,ref_final_output))
end_time=datetime.datetime.now()
print("Total Time: ",end_time-start_time)