import os.path
import sys

import docx
import re
from docx.shared import Pt
from docx.enum.text import WD_COLOR_INDEX

def replace_and_highlight_text(paragraph, target_word, replacement_word):
    new_runs = []
    for run in paragraph.runs:
        text = run.text
        parts = re.split(r'(\b' + re.escape(target_word) + r'\b)', text, flags=re.IGNORECASE)
        if len(parts) > 1:
            for i, part in enumerate(parts):
                if part.lower() == target_word.lower():
                    new_run = paragraph.add_run(replacement_word)
                    new_run.font.highlight_color = WD_COLOR_INDEX.YELLOW
                    new_runs.append(new_run)
                else:
                    new_run = paragraph.add_run(part)
                    new_runs.append(new_run)
        else:
            new_runs.append(run)

    # Clear all runs in the paragraph
    for run in paragraph.runs:
        paragraph._p.remove(run._element)

    # Add the new runs in place of the original runs
    for new_run in new_runs:
        paragraph._p.append(new_run._element)

def main_final(path1, path2):
    # Load the Word document
    doc = docx.Document(path1)
    pathsup=os.path.dirname((sys.argv[0]))+'\\Words.txt'

    # Read the contents of the TXT file
    with open(pathsup, 'r', encoding='utf-8') as txt_file:
        lines = txt_file.readlines()
    # Create a dictionary to store the word mappings
    word_mapping = {}
    for line in lines:
        left_word, right_word = line.strip().split(', ')
        word_mapping[left_word] = right_word

    # Iterate through the word mappings and replace and highlight the words in the Word document
    for paragraph in doc.paragraphs:
        for target_word, replacement_word in word_mapping.items():
            replace_and_highlight_text(paragraph, target_word, replacement_word)
    # Save the modified Word document
    doc.save(path2)

if __name__ == "__main__":
    main()
