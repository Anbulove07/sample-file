# ---------------------------------------------------------------------
# Tool Name	: Excel2Excel_TagConversion.py
#  Developer	: Anbu G
#  Description  : To Convert the Excel file
#  Client/DU	: Pearson / Pearson
#  Syntax		: <EXE> <ExcelFile>
# -----------------------------------------------------------------------

# -------------------------Revision History------------------------------

# 14-09-2022 | V1.0.0.0 | Anbu G | LIVE req by AyyyanarBosan

# -----------------------------------------------------------------------


# Python3 code to select
# data from excel
from iModule.ToolTracking import _get_timestamp, _get_file_size, _local_tracking

import xlwings as xw
import re
import sys

from autocorrect import Speller
import language_tool_python
tool = language_tool_python.LanguageTool('en-US')
spell = Speller(lang='en')


ToolVersion = "1.0.0.0";

print("\n\n\tExcel2Excel_tagConversion v" + ToolVersion + " is Running...");
print("\tCopyright @ Integra Software Services Ltd.\n");




try :
	_excel_path = sys.argv[1]
	# Specifying a sheet
	ws = xw.Book(_excel_path).sheets[0]

except :
	# src = r'D:\Anbu\XML\pdftest.pdf'
	print("Please Enter Excel file location")
	sys.exit()

# ------------ Tracking --------------------------------------------
Tra_input = sys.argv[1];
tool_id = 477;  # Excel2Excel_tagConversion
run_size = 0;
st_time = _get_timestamp();
# ------------------------------------------------------------------

# Selecting data from
# a single cell
def _hexa(tmp):
	test = hex(ord(tmp)).split('x')[-1];
	test = '&#x'+test.zfill(4).upper()+';';
	return test

def _hex2chr(hex):
	return chr(int(hex, 16));

# last_row = ws.range("K:K").end('down').row
# v1 = ws.range("K1:K"+str(last_row)).value

listtofindheadervalue=['A1', 'B1', 'C1', 'D1', 'E1', 'F1', 'G1', 'H1', 'I1', 'J1', 'K1', 'L1', 'M1', 'N1', 'O1', 'P1', 'Q1', 'R1', 'S1', 'T1', 'U1', 'V1', 'W1', 'X1', 'Y1', 'Z1', 'AA1', 'AB1', 'AC1', 'AD1', 'AE1', 'AF1', 'AG1', 'AH1', 'AI1', 'AJ1', 'AK1', 'AL1', 'AM1', 'AN1', 'AO1', 'AP1', 'AQ1', 'AR1', 'AS1', 'AT1', 'AU1', 'AV1', 'AW1', 'AX1', 'AY1', 'AZ1', 'BA1', 'BB1', 'BC1', 'BD1', 'BE1', 'BF1', 'BG1', 'BH1', 'BI1', 'BJ1', 'BK1', 'BL1', 'BM1', 'BN1', 'BO1', 'BP1', 'BQ1', 'BR1', 'BS1', 'BT1', 'BU1', 'BV1', 'BW1', 'BX1', 'BY1', 'BZ1', 'CA1', 'CB1', 'CC1', 'CD1', 'CE1', 'CF1', 'CG1', 'CH1', 'CI1', 'CJ1', 'CK1', 'CL1', 'CM1', 'CN1', 'CO1', 'CP1', 'CQ1', 'CR1', 'CS1', 'CT1', 'CU1', 'CV1', 'CW1', 'CX1', 'CY1', 'CZ1', 'DA1', 'DB1', 'DC1', 'DD1', 'DE1', 'DF1', 'DG1', 'DH1', 'DI1', 'DJ1', 'DK1', 'DL1', 'DM1', 'DN1', 'DO1', 'DP1', 'DQ1', 'DR1', 'DS1', 'DT1', 'DU1', 'DV1', 'DW1', 'DX1', 'DY1', 'DZ1', 'EA1', 'EB1', 'EC1', 'ED1', 'EE1', 'EF1', 'EG1', 'EH1', 'EI1', 'EJ1', 'EK1', 'EL1', 'EM1', 'EN1', 'EO1', 'EP1', 'EQ1', 'ER1', 'ES1', 'ET1', 'EU1', 'EV1', 'EW1', 'EX1', 'EY1', 'EZ1', 'EA1', 'FB1', 'FC1', 'FD1', 'FE1', 'FF1', 'FG1', 'FH1', 'FI1', 'FJ1', 'FK1', 'FL1', 'FM1', 'FN1', 'FO1', 'FP1', 'FQ1', 'FR1', 'FS1', 'FT1', 'FU1', 'FV1', 'FW1', 'FX1', 'FY1', 'FZ1', 'FA1', 'GB1', 'GC1', 'GD1', 'GE1', 'GF1', 'GG1', 'GH1', 'GI1', 'GJ1', 'GK1', 'GL1', 'GM1', 'GN1', 'GO1', 'GP1', 'GQ1', 'GR1', 'GS1', 'GT1', 'GU1', 'GV1', 'GW1', 'GX1', 'GY1', 'GZ1', 'GA1', 'HB1', 'HC1', 'HD1', 'HE1', 'HF1', 'HG1', 'HH1', 'HI1', 'HJ1', 'HK1', 'HL1', 'HM1', 'HN1', 'HO1', 'HP1', 'HQ1', 'HR1', 'HS1', 'HT1', 'HU1', 'HV1', 'HW1', 'HX1', 'HY1', 'HZ1', 'HA1', 'IB1', 'IC1', 'ID1', 'IE1', 'IF1', 'IG1', 'IH1', 'II1', 'IJ1', 'IK1', 'IL1', 'IM1', 'IN1', 'IO1', 'IP1', 'IQ1', 'IR1', 'IS1', 'IT1', 'IU1', 'IV1', 'IW1', 'IX1', 'IY1', 'IZ1', 'IA1', 'JB1', 'JC1', 'JD1', 'JE1', 'JF1', 'JG1', 'JH1', 'JI1', 'JJ1', 'JK1', 'JL1', 'JM1', 'JN1', 'JO1', 'JP1', 'JQ1', 'JR1', 'JS1', 'JT1', 'JU1', 'JV1', 'JW1', 'JX1', 'JY1', 'JZ1', 'JA1', 'KB1', 'KC1', 'KD1', 'KE1', 'KF1', 'KG1', 'KH1', 'KI1', 'KJ1', 'KK1', 'KL1', 'KM1', 'KN1', 'KO1', 'KP1', 'KQ1', 'KR1', 'KS1', 'KT1', 'KU1', 'KV1', 'KW1', 'KX1', 'KY1', 'KZ1', 'KA1', 'LB1', 'LC1', 'LD1', 'LE1', 'LF1', 'LG1', 'LH1', 'LI1', 'LJ1', 'LK1', 'LL1', 'LM1', 'LN1', 'LO1', 'LP1', 'LQ1', 'LR1', 'LS1', 'LT1', 'LU1', 'LV1', 'LW1', 'LX1', 'LY1', 'LZ1', 'LA1', 'MB1', 'MC1', 'MD1', 'ME1', 'MF1', 'MG1', 'MH1', 'MI1', 'MJ1', 'MK1', 'ML1', 'MM1', 'MN1', 'MO1', 'MP1', 'MQ1', 'MR1', 'MS1', 'MT1', 'MU1', 'MV1', 'MW1', 'MX1', 'MY1', 'MZ1', 'MA1', 'NB1', 'NC1', 'ND1', 'NE1', 'NF1', 'NG1', 'NH1', 'NI1', 'NJ1', 'NK1', 'NL1', 'NM1', 'NN1', 'NO1', 'NP1', 'NQ1', 'NR1', 'NS1', 'NT1', 'NU1', 'NV1', 'NW1', 'NX1', 'NY1', 'NZ1', 'NA1', 'OB1', 'OC1', 'OD1', 'OE1', 'OF1', 'OG1', 'OH1', 'OI1', 'OJ1', 'OK1', 'OL1', 'OM1', 'ON1', 'OO1', 'OP1', 'OQ1', 'OR1', 'OS1', 'OT1', 'OU1', 'OV1', 'OW1', 'OX1', 'OY1', 'OZ1', 'OA1', 'PB1', 'PC1', 'PD1', 'PE1', 'PF1', 'PG1', 'PH1', 'PI1', 'PJ1', 'PK1', 'PL1', 'PM1', 'PN1', 'PO1', 'PP1', 'PQ1', 'PR1', 'PS1', 'PT1', 'PU1', 'PV1', 'PW1', 'PX1', 'PY1', 'PZ1', 'PA1', 'QB1', 'QC1', 'QD1', 'QE1', 'QF1', 'QG1', 'QH1', 'QI1', 'QJ1', 'QK1', 'QL1', 'QM1', 'QN1', 'QO1', 'QP1', 'QQ1', 'QR1', 'QS1', 'QT1', 'QU1', 'QV1', 'QW1', 'QX1', 'QY1', 'QZ1', 'QA1', 'RB1', 'RC1', 'RD1', 'RE1', 'RF1', 'RG1', 'RH1', 'RI1', 'RJ1', 'RK1', 'RL1', 'RM1', 'RN1', 'RO1', 'RP1', 'RQ1', 'RR1', 'RS1', 'RT1', 'RU1', 'RV1', 'RW1', 'RX1', 'RY1', 'RZ1', 'RA1', 'SB1', 'SC1', 'SD1', 'SE1', 'SF1', 'SG1', 'SH1', 'SI1', 'SJ1', 'SK1', 'SL1', 'SM1', 'SN1', 'SO1', 'SP1', 'SQ1', 'SR1', 'SS1', 'ST1', 'SU1', 'SV1', 'SW1', 'SX1', 'SY1', 'SZ1']
listtofindheadervalue221=['A1', 'B1', 'C1', 'D1', 'E1', 'F1', 'G1', 'H1', 'I1', 'J1', 'K1', 'L1', 'M1', 'N1', 'O1', 'P1', 'Q1', 'R1', 'S1', 'T1', 'U1', 'V1', 'W1', 'X1', 'Y1', 'Z1', 'AA1', 'AB1', 'AC1', 'AD1', 'AE1', 'AF1', 'AG1', 'AH1', 'AI1', 'AJ1', 'AK1', 'AL1', 'AM1', 'AN1', 'AO1', 'AP1', 'AQ1', 'AR1', 'AS1', 'AT1', 'AU1', 'AV1', 'AW1', 'AX1', 'AY1', 'AZ1', 'BA1', 'BB1', 'BC1', 'BD1', 'BE1', 'BF1', 'BG1', 'BH1', 'BI1', 'BJ1', 'BK1', 'BL1', 'BM1', 'BN1', 'BO1', 'BP1', 'BQ1', 'BR1', 'BS1', 'BT1', 'BU1', 'BV1', 'BW1', 'BX1', 'BY1', 'BZ1', 'CA1', 'CB1', 'CC1', 'CD1', 'CE1', 'CF1', 'CG1', 'CH1', 'CI1', 'CJ1', 'CK1', 'CL1', 'CM1', 'CN1', 'CO1', 'CP1', 'CQ1', 'CR1', 'CS1', 'CT1', 'CU1', 'CV1', 'CW1', 'CX1', 'CY1', 'CZ1', 'DA1', 'DB1', 'DC1', 'DD1', 'DE1', 'DF1', 'DG1', 'DH1', 'DI1', 'DJ1', 'DK1', 'DL1', 'DM1', 'DN1', 'DO1', 'DP1', 'DQ1', 'DR1', 'DS1', 'DT1', 'DU1', 'DV1', 'DW1', 'DX1', 'DY1', 'DZ1', 'EA1', 'EB1', 'EC1', 'ED1', 'EE1', 'EF1', 'EG1', 'EH1', 'EI1', 'EJ1', 'EK1', 'EL1', 'EM1', 'EN1', 'EO1', 'EP1', 'EQ1', 'ER1', 'ES1', 'ET1', 'EU1', 'EV1', 'EW1', 'EX1', 'EY1', 'EZ1', 'EA1', 'FB1', 'FC1', 'FD1', 'FE1', 'FF1', 'FG1', 'FH1', 'FI1', 'FJ1', 'FK1', 'FL1', 'FM1', 'FN1', 'FO1', 'FP1', 'FQ1', 'FR1', 'FS1', 'FT1', 'FU1', 'FV1', 'FW1', 'FX1', 'FY1', 'FZ1', 'FA1', 'GB1', 'GC1', 'GD1', 'GE1', 'GF1', 'GG1', 'GH1', 'GI1', 'GJ1', 'GK1', 'GL1', 'GM1', 'GN1', 'GO1', 'GP1', 'GQ1', 'GR1', 'GS1', 'GT1', 'GU1', 'GV1', 'GW1', 'GX1', 'GY1', 'GZ1', 'GA1', 'HB1', 'HC1', 'HD1', 'HE1', 'HF1', 'HG1', 'HH1', 'HI1', 'HJ1', 'HK1', 'HL1', 'HM1', 'HN1', 'HO1', 'HP1', 'HQ1', 'HR1', 'HS1', 'HT1', 'HU1', 'HV1', 'HW1', 'HX1', 'HY1', 'HZ1', 'HA1', 'IB1', 'IC1', 'ID1', 'IE1', 'IF1', 'IG1', 'IH1', 'II1', 'IJ1', 'IK1', 'IL1', 'IM1', 'IN1', 'IO1', 'IP1', 'IQ1', 'IR1', 'IS1', 'IT1', 'IU1', 'IV1', 'IW1', 'IX1', 'IY1', 'IZ1', 'IA1', 'JB1', 'JC1', 'JD1', 'JE1', 'JF1', 'JG1', 'JH1', 'JI1', 'JJ1', 'JK1', 'JL1', 'JM1', 'JN1', 'JO1', 'JP1', 'JQ1', 'JR1', 'JS1', 'JT1', 'JU1', 'JV1', 'JW1', 'JX1', 'JY1', 'JZ1', 'JA1', 'KB1', 'KC1', 'KD1', 'KE1', 'KF1', 'KG1', 'KH1', 'KI1', 'KJ1', 'KK1', 'KL1', 'KM1', 'KN1', 'KO1', 'KP1', 'KQ1', 'KR1', 'KS1', 'KT1', 'KU1', 'KV1', 'KW1', 'KX1', 'KY1', 'KZ1', 'KA1', 'LB1', 'LC1', 'LD1', 'LE1', 'LF1', 'LG1', 'LH1', 'LI1', 'LJ1', 'LK1', 'LL1', 'LM1', 'LN1', 'LO1', 'LP1', 'LQ1', 'LR1', 'LS1', 'LT1', 'LU1', 'LV1', 'LW1', 'LX1', 'LY1', 'LZ1', 'LA1', 'MB1', 'MC1', 'MD1', 'ME1', 'MF1', 'MG1', 'MH1', 'MI1', 'MJ1', 'MK1', 'ML1', 'MM1', 'MN1', 'MO1', 'MP1', 'MQ1', 'MR1', 'MS1', 'MT1', 'MU1', 'MV1', 'MW1', 'MX1', 'MY1', 'MZ1', 'MA1', 'NB1', 'NC1', 'ND1', 'NE1', 'NF1', 'NG1', 'NH1', 'NI1', 'NJ1', 'NK1', 'NL1', 'NM1', 'NN1', 'NO1', 'NP1', 'NQ1', 'NR1', 'NS1', 'NT1', 'NU1', 'NV1', 'NW1', 'NX1', 'NY1', 'NZ1', 'NA1', 'OB1', 'OC1', 'OD1', 'OE1', 'OF1', 'OG1', 'OH1', 'OI1', 'OJ1', 'OK1', 'OL1', 'OM1', 'ON1', 'OO1', 'OP1', 'OQ1', 'OR1', 'OS1', 'OT1', 'OU1', 'OV1', 'OW1', 'OX1', 'OY1', 'OZ1', 'OA1', 'PB1', 'PC1', 'PD1', 'PE1', 'PF1', 'PG1', 'PH1', 'PI1', 'PJ1', 'PK1', 'PL1', 'PM1', 'PN1', 'PO1', 'PP1', 'PQ1', 'PR1', 'PS1', 'PT1', 'PU1', 'PV1', 'PW1', 'PX1', 'PY1', 'PZ1', 'PA1', 'QB1', 'QC1', 'QD1', 'QE1', 'QF1', 'QG1', 'QH1', 'QI1', 'QJ1', 'QK1', 'QL1', 'QM1', 'QN1', 'QO1', 'QP1', 'QQ1', 'QR1', 'QS1', 'QT1', 'QU1', 'QV1', 'QW1', 'QX1', 'QY1', 'QZ1', 'QA1', 'RB1', 'RC1', 'RD1', 'RE1', 'RF1', 'RG1', 'RH1', 'RI1', 'RJ1', 'RK1', 'RL1', 'RM1', 'RN1', 'RO1', 'RP1', 'RQ1', 'RR1', 'RS1', 'RT1', 'RU1', 'RV1', 'RW1', 'RX1', 'RY1', 'RZ1', 'RA1', 'SB1', 'SC1', 'SD1', 'SE1', 'SF1', 'SG1', 'SH1', 'SI1', 'SJ1', 'SK1', 'SL1', 'SM1', 'SN1', 'SO1', 'SP1', 'SQ1', 'SR1', 'SS1', 'ST1', 'SU1', 'SV1', 'SW1', 'SX1', 'SY1', 'SZ1']

for x in range(len(listtofindheadervalue)):
	if ws.range(listtofindheadervalue[x]).value == "Content Asset:Long Description":
		indexhead1 = listtofindheadervalue[x+1]
		indexhead2 = listtofindheadervalue[x+2]
		indexhead3 = listtofindheadervalue[x+3]
		indexhead4 = listtofindheadervalue[x+4]
		listtofindheadervalue[x]=listtofindheadervalue[x].replace('1','')
		indexhead=listtofindheadervalue[x]
		break
for x in range(len(listtofindheadervalue221)):
	if ws.range(listtofindheadervalue221[x]).value == "Prepared By":
		listtofindheadervalue221[x]=listtofindheadervalue221[x].replace('1','')
		indexhead_find_end_row=listtofindheadervalue221[x]


if indexhead_find_end_row:
	last_row = ws.range(str(indexhead_find_end_row)+":"+str(indexhead_find_end_row)).end('down').row
	v1 = ws.range(str(indexhead)+"1:"+str(indexhead) + str(last_row)).value

else:
	print("\"Content Assest:Long Description\" not found in excel")
	sys.exit()


#
# num_col = ws.range('A1').end('right').column
# num_row = ws.range('A1').end('down').row
# cellsRight = ws.range('A1')
# # collect data
# content_list = ws.range((1,1),(num_row,num_col)).value
# print(content_list)
# num_col = ws.range('A1').end('right').column
# ww=ws.range('A' + str(ws.cells.last_cell.row)).end('up').row
# last_row = ws.range('A1').end('right').column
listtofind=['a','A','b','B', 'c','C', 'd','D', 'e','E', 'f','F', 'g','G', 'h','H', 'i','I', 'j','J', 'k','K', 'l','L', 'm','M', 'n','N','O', 'p','P', 'q','Q', 'r','R', 's','S', 't','T','u','U', 'v','V', 'w','W', 'x','X', 'y','Y', 'z','Z','I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X','XI', 'XII', 'XIII', 'XIV', 'XV', 'XVI', 'XVII', 'XVIII','XIX', 'XX']

listtofind1 = ['&#x2022', '&#xF0D8', 'o', '&#xF0A7', '&#xF076', '&#xF0FC']

stringtext=[]
for x in range (1,len(v1)):
	# print(x)
	if not v1[x]==None and not v1[x]=="Nil":
		count = 0
		count1 = 0
		count2 = 0
		string_out = ""
		if v1[x]:
			v2=v1[x].split("\n")

			if len(v2)>1:
				for y in range (len(v2)):
					srch = re.sub(r'[^\x00-\x7F]', lambda m: _hexa(m.group()), v2[y])
					vv=re.search(r'((?!^[0-9_-]$(?=\s))^[\d\w&#]{1,})((?:(?! [^ ]*).)*)',srch,re.I|re.S)
					try:
						txt=vv.group(1)

						if txt in listtofind:
							vv2 = re.sub(r'((?!^[0-9_-]$(?=\s))^[\d\w&#]{1,})((?:(?! [^ ]*).)*)', r'', srch, 0, re.I | re.S)
						elif txt in listtofind1:
							vv2 = re.sub(r'((?!^[0-9_-]$(?=\s))^[\d\w&#]{1,})((?:(?! [^ ]*).)*)', r'', srch, 0, re.I | re.S)
						elif txt.isnumeric():
							vv2 = re.sub(r'((?!^[0-9_-]$(?=\s))^[\d\w&#]{1,})((?:(?! [^ ]*).)*)', r'', srch, 0, re.I | re.S)
						else:
							vv2 = re.search(r'((?!^[0-9_-]$(?=\s))^[\d\w&#]{1,})((?:(?! [^ ]*).)*)', srch, re.I | re.S)

						a=txt.isnumeric()

						if a==1:
							if count==0:
								vv3="<ol start=\""+txt+"\" type=\""+txt+"\"><li start_ref=\""+txt+"\">"+vv2+"</li>"
								# print(vv3)
								string_out=string_out+"\n"+vv3
								count=count+1
							elif  y == len(v2) - 2:
								vv3 = "<li start_ref=\""+txt+"\">" + vv2 + "</li></ol>"
								# print(vv3)
								string_out = string_out +"\n"+ vv3
							else:
								vv3 = "<li start_ref=\""+txt+"\">" + vv2 + "</li>"
								# print(vv3)
								string_out = string_out +"\n"+ vv3

						else:
							if txt in listtofind1:
								if count2 == 0:
									converttext =re.sub(r'&#x([A-Z0-9]+)',lambda m:_hex2chr(m.group(1)),txt,re.I|re.S)
									vv3 = "<ul start=\""+converttext+"\"><li start_ref=\""+txt+"\">" + vv2 + "</li>"
									string_out = string_out +"\n"+ vv3
									count2 = count2 + 1
								elif y == len(v2)-2:
									vv3 = "<li start_ref=\""+txt+"\">" + vv2 + "</li></ul>"
									string_out = string_out +"\n"+ vv3
								else:
									vv3 = "<li start_ref=\""+txt+"\">" + vv2 + "</li>"
									string_out = string_out +"\n"+ vv3
							elif txt in listtofind:
								if count1 == 0:
									vv3 = "<ol start=\""+txt+"\" type=\""+txt+"\"><li start_ref=\""+txt+"\">" + vv2 + "</li>"
									string_out = string_out +"\n"+ vv3
									count1=count1+1
								elif y == len(v2) :
									vv3 = "<li start_ref=\""+txt+"\">" + vv2 + "</li></ol>"
									string_out = string_out +"\n"+ vv3

								else:
									vv3 = "<li start_ref=\""+txt+"\">" + vv2 + "</li>"
									string_out = string_out +"\n"+ vv3
							else:
								vv3 = "<p>" + vv2 + "</p>"
								string_out = string_out + vv3

					except:
						v3=v2[y].replace(v2[y],"<p>"+str(v2[y])+"</p>")
						string_out = string_out +"\n"+ v3
			else:
				v3 = ("<p>" + str(v2[0]) + "</p>")
				string_out = string_out + v3
		else:
			v3 = ("")
			string_out = string_out + "\n" + v3

		stringtext.append(string_out)
	else:

		stringtext.append(" ")

cellvaluupdate=[]
for mm in range(len(stringtext)):
	if stringtext!=None:
		# print(mm)
		cnt1=0
		cnt2=0
		cnt=0

		splittedlines=stringtext[mm].split('\n')
		val2=len(splittedlines)

		for lines in splittedlines:

			textmatch=re.search(r'<li start_ref="((?:(?! [^>]).)*)">',lines,re.I|re.S)
			try:
				getno=textmatch.group(1)

				if getno=='a':
					stringtext[mm]=stringtext[mm].replace("<li start_ref=\"a\">","<ol start=\"a\" type=\"a\"><li>")
					cnt=cnt+1
				if cnt!=0:
					if getno.isnumeric():
						stringtext[mm] = stringtext[mm].replace("<li start_ref=\""+getno+"\">", "</ol><li>")
			except:
				pass

		stringtext[mm]=re.sub(r'( start_ref="((?:(?! [^>]).)*)")',r'',stringtext[mm],0,re.I|re.S)
		stringtext[mm]=re.sub(r'<p>\s*</p>',r'',stringtext[mm],0,re.I|re.S)
		stringtext[mm]=re.sub(r'<ol(?: [^>]*)>(<ol(?: [^>]*)>)',r'\1',stringtext[mm],0,re.I|re.S)
		cellvaluupdate.append(stringtext[mm])

if indexhead1:
	indexhead1=indexhead1.replace('1','')
	indexhead2=indexhead2.replace('1','')
	indexhead3=indexhead3.replace('1','')
	indexhead4=indexhead4.replace('1','')
	# ws.range(indexhead1+':'+indexhead1).xl_range.Delete()
	# ws.range(indexhead2+':'+indexhead2).xl_range.Delete()
	ws.range(indexhead1+':'+indexhead1).insert()
	ws.range(indexhead2+':'+indexhead2).insert()


for xy in range(len(cellvaluupdate)):
	if cellvaluupdate[xy]!=None:
		# print(cellvaluupdate)
		# print(xy)
		ws.range(indexhead1 + "1").value = "Tag applied"
		ws.range(indexhead1+str(xy+2)).value = str(cellvaluupdate[xy])
		correctedspell=spell(str(cellvaluupdate[xy]))
		matches = tool.check(correctedspell)

		ws.range(indexhead2+"1").value = "spell Check"
		ws.range(indexhead2 + str(xy + 2)).value = str(correctedspell)
		# is_bad_rule = lambda rule: rule.message == 'Possible spelling mistake found.' and len(rule.replacements) and rule.replacements[0][0].isupper()
		# matches = [rule for rule in matches if not is_bad_rule(rule)]
		# matches1=language_tool_python.utils.correct(correctedspell, matches)
		ws.range(indexhead3+"1").value = "Grammer Check"
		if len(matches)>0:
			ws.range(indexhead3 + str(xy + 2)).value = str(matches)
		else:
			matches=""
			ws.range(indexhead3 + str(xy + 2)).value = str(matches)


# ------ Local tracking ------------------
_local_tracking(tool_id, ToolVersion, Tra_input, _get_file_size(Tra_input), st_time, _get_timestamp());
# -----------------------------------------

print("\nProcess completed...!!!")
sys.exit()
