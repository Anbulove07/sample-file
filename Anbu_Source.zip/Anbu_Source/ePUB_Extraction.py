# ---------------------------------------------------------------------
# Tool Name	: ePub_Extraction.py
#  Developer	: Anbu G
#  Description  : To Create Excel file from ePub
#  Client/DU	: Pearson / Pearson
#  Syntax		: <EXE> <ZIP_File>
# -----------------------------------------------------------------------
import shutil
from iModule.Basic import _element_leveling

# -------------------------Revision History------------------------------

# 26-06-2023 | V1.0.0.0 | Anbu G | LIVE req by Thangaprakasam

# -----------------------------------------------------------------------


import xlsxwriter
import sys
from os.path import dirname, basename
import itertools
import os
import re
import time
import zipfile

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
ToolVersion = "1.0.0.0";
from iModule import *

ToolPath = dirname(sys.argv[0]);
ToolPath = re.sub(r'\/', r'\\', ToolPath, 0)

os.system("cls")

# Inline argument checking
if (len(sys.argv) != 3 or not os.path.isfile(sys.argv[1])): sys.exit(
    "\n\tSyntax: ePub_Extraction.exe <Zip file path> <text_book_name>\n")

print("\n\n\tePub_Extraction v" + ToolVersion + " is Running...");
print("\tCopyright @ Integra Software Services Ltd.\n");



zip_file_path = (sys.argv[1])

isbn = basename(zip_file_path).split('.')[0]
# print(isbn)
# exit()
excelupdate = []
question_list = []
filenamelist = []


def extract_zip_file(zip_file_path):
    # Get the directory path of the zip file
    zip_dir = os.path.dirname(zip_file_path)

    # Create an output folder path
    output_folder = os.path.join(zip_dir)

    # Create the output folder if it doesn't exist
    os.makedirs(output_folder, exist_ok=True)

    # Open the zip file
    # with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
        # Extract all files to the output folder
        # zip_ref.extractall(output_folder)
    shutil.unpack_archive(zip_file_path, output_folder, 'zip')
    print(f'Zip file extracted to: {output_folder}')


extract_zip_file(zip_file_path)



def capture_full_page_screenshot(url, output_image,width,height):
    # Configure Chrome options
    chrome_options = Options()
    chrome_options.add_argument('--headless')  # Run Chrome in headless mode

    # Set path to chromedriver executable
    # Initialize Chrome driver
    driver = webdriver.Chrome(options=chrome_options)

    url = re.sub(r'\\', '/', url, 0)

    # Navigate to the URL
    driver.get(f'file:///{url}')
    print(f'file:///{url}')
    time.sleep(5)
    # Get page height
    page_height = driver.execute_script('return document.body.scrollHeight')

    # Set window size to match the entire page height
    # driver.set_window_size(driver.execute_script('return window.innerWidth'), page_height)
    driver.set_window_size(width, page_height)

    # Capture screenshot of the entire page
    driver.save_screenshot(output_image)

    # Close the driver
    driver.quit()
def _createtable(param,linkcnt,path,tabcount):

    path1=os.path.dirname(path)+'\\'+f'{isbn}\\OPS\\xhtml/'
    htmlcnt=f'<html><head>{linkcnt}</head><body>{param}</body></html>'
    with open(path1+f'table{tabcount}.html','w',encoding='utf-8') as f:
        f.write(htmlcnt)
    # html_to_image(path1+'table.html',path1+'table.png')
    # tabcount = tabcount + 1
    # url = path1+f'table{tabcount}.html'
    # # url = re.sub(r'\\', '//', url1)
    # # url = re.sub(r' ', '%20', url)
    # output_image = re.sub(r'\.html$', r'.png', url)

    width = 1280  # Desired screen width
    height = 800  # Desired screen height
    print(path1+f'table{tabcount}.html')
    retn="\n\n[pathin]"+(path1+f'table{tabcount}.png')+"[pathout]\n\n"
    capture_full_page_screenshot(path1+f'table{tabcount}.html', path1+f'table{tabcount}.png',width,height)
    return retn
    # print(path1)
    # print(r"D:\Giventool\Thangaprakasam\Newfolder\Digibooks_Content_Extraction\output\OPS\xhtml\table1.html")

    # print(tabcount)

def _lichange(param):
    count_alpha=97
    out=''
    for li in re.finditer(r'<li(?:[^>]*)?>((?:(?!</li>).)*)</li>',param,re.I|re.S):
        licnt=re.sub(r'<[^>]*>', '', li.group(1), 0, re.I | re.S)
        licnt=re.sub(r'&nbsp;','',licnt,0,re.I|re.S)
        licnt=re.sub(r'[\n\r][\n\r]+','',licnt,0,re.I|re.S)
        out =out+ chr(count_alpha)+'. '+licnt+'\n'
        count_alpha=count_alpha+1
        # print(out)
    return out

# 97 for a 122 for z
# def _tableimage(param):
#     print(param)
#     print('------------------------------------')
#     pass

tabcount=itertools.count(1)


def _mathconvo(param):
    param=re.sub(r'<','&lt;',param,0,re.I|re.S)
    param=re.sub(r'>','&gt;',param,0,re.I|re.S)
    return param


with zipfile.ZipFile(zip_file_path, 'r') as zip_file:
    # List all files in the ZIP archive
    file_list1 = zip_file.namelist()
    navorderlist=[]
    navorderlist_fin=[]
    for order in file_list1:
        if order.endswith('toc.xhtml'):
            with zip_file.open(order) as file:
                toccontent = file.read()
            for navpoint in re.finditer(r'<a(?:[^>]*)?href="([^>]*\.xhtml)(?:[^>]*)?>',toccontent.decode('utf-8'),re.I|re.S):
                navorderlist.append(navpoint.group(1))

    # print(navorderlist)
    # exit()

    for navordercheck in navorderlist:
        for file_name in file_list1:
            if re.search(navordercheck,file_name):
                navorderlist_fin.append(file_name)

    unique_list = []
    seen = set()

    for item in navorderlist_fin:
        if item not in seen:
            unique_list.append(item)
            seen.add(item)
    # print(unique_list)
    # exit()
    for file_name in unique_list:

        if file_name.endswith('.xhtml'):
            cnt = []
            # Extract and read only .xhtml files in the ZIP archive
            # print(f"Reading {file_name}...")
            filenamelist.append(file_name)
            with zip_file.open(file_name) as file:
                content = file.read()
                question_list=[]
                question_list_no=[]
                linkcnt=''
                for linkcont in re.finditer(r'<link(?: [^>]*)?>(?:(?!</link>).)*</link>', content.decode('utf-8'), re.DOTALL):
                    # linkcont=re.search(r'<link(?: [^>]*)?>(?:(?!</link>).)*</link>', content.decode('utf-8'), re.DOTALL).group(0)
                    linkcnt=linkcnt+linkcont.group()
                    # print(linkcont.group())

                # print(linkcnt)

                if re.search(r'<section(?:[^>]*)?aria-label="([^"]*)" (?:[^>]*)?>((?:(?!</section>).)*)</section>', content.decode('utf-8'), re.DOTALL):
                    section=re.search(r'<section(?:[^>]*)?aria-label="([^"]*)" (?:[^>]*)?>((?:(?!</section>).)*)</section>', content.decode('utf-8'), re.DOTALL).group(1)
                else:
                    section=''
                    # print(section)
                cnttotal=_element_leveling(content.decode('utf-8'), "div",1)
                for question in re.finditer(r'<div(\d+)(?:[^>]*)?class="question"(?:[^>]*)?>((?:(?!</div\1>).)*)</div\1>\s*(<ol(?:[^>]*)?>((?:(?!</ol>).)*)</ol>)?', cnttotal, re.DOTALL):
                    # print(question.group(1))
                    if re.search(r'<span(?:[^>]*)?class="number"(?:[^>]*)?>((?:(?!</span>).)*)</span>', question.group(2), re.DOTALL):
                        question_no=re.search(r'<span(?:[^>]*)?class="number"(?:[^>]*)?>((?:(?!</span>).)*)</span>', question.group(2), re.DOTALL).group(1)
                    else:
                        question_no=''

                    upd = re.sub(r'<span(?:[^>]*)?class="number"(?:[^>]*)?>((?:(?!</span>).)*)</span>', '', question.group(2), 1)
                    upd = re.sub(r'<ol(?:[^>]*)?>((?:(?!</ol>).)*)</ol>', lambda m: _lichange(m.group(1)), upd, 0,re.I | re.S)
                    if question.group(3):
                        upd =upd+"\n"+ re.sub(r'<ol(?:[^>]*)?>((?:(?!</ol>).)*)</ol>', lambda m: _lichange(m.group(1)), question.group(3), 0,re.I | re.S)
                    upd = re.sub(r'<table(?:[^>]*)?>((?:(?!</table>).)*)</table>', lambda m: _createtable(m.group(),linkcnt,zip_file_path,next(tabcount)), upd, 0,re.I|re.S)
                    # upd = re.sub(r'<math ([^>]*)>', 'ltopen\g<1>gtopen', upd, 0)
                    upd = re.sub(r'<(m:math|math)(?:[^>]*)?>((?:(?!</(m:math|math)>).)*)</(m:math|math)>', lambda m: _mathconvo(m.group()), upd, 0)
                    # upd = re.sub(r'<[a-zA-Z]>((?:(?! [^>]*).)*)</[a-zA-Z]>', '\g<1>', upd, 0)
                    upd = re.sub(r'<!--(?:(?!-->).)*-->', '', upd, 0)
                    upd = re.sub(r'<[^>]*>', '', upd, 0)
                    upd = re.sub(r'&lt;', '<', upd, 0)
                    upd = re.sub(r'&gt;', '>', upd, 0)
                    # upd = re.sub(r'<([^m][^/m][^>]*)>', '', upd, 0)
                    # upd = re.sub(r'ltopen', '<math ', upd, 0)
                    # upd = re.sub(r'gtopen', '>', upd, 0)
                    # upd = re.sub(r'ltclose', '</math>', upd, 0)
                    upd=re.sub(r'&amp;', '&', upd)
                    upd=re.sub(r'&nbsp;', ' ', upd)
                    # upd = re.sub(r'[\n\r][\n\r]+', r'\n', upd, 0)
                    question_list.append(upd)
                    question_list_no.append(question_no)
                    # print(f"Reading {file_name}...")
                    # print(upd)
                    # print('------------------------')
                    # cnt.append(file_name)
                    # cnt.append(upd)
                # Process the content of the file as needed
                # print(f"Content of {file_name}:")
                # print(content.decode('utf-8'))
            cnt.append(file_name)
            cnt.append(question_list)
            cnt.append(question_list_no)
            cnt.append(section)
            excelupdate.append(cnt)
            # excelupdate[file_name]=question_list


# print(len(question_list))
# print(excelupdate)
# for x in excelupdate:
#     # print(x)
#     print(x[0])
#     print(os.path.basename(x[0]))
#     print(x[1])
#     print('------------------------')
InPath = re.sub(r'\.zip$', r'', zip_file_path, 0)

# exit()
try:
    workbook = xlsxwriter.Workbook(InPath+'_Log_Report.xlsx')
    worksheet = workbook.add_worksheet('Index')
except:
    print("Please close the excel file")
    sys.exit()

worksheet.write("A1", "problem_text")
worksheet.write("B1", "text_book_name_ed")
worksheet.write("C1", "chapter number_problem number")
worksheet.write("D1", "Filename")
worksheet.write("E1", "Section")

count=2
for x in range(len(excelupdate)):
    # print(x)
    # print(x[0])
    # print(os.path.basename(x[0]))
    # print(x[1])
    # print(excelupdate[x][2])
    # print('------------------------')
    for y in range(len(excelupdate[x][1])):
        # print(excelupdate[x][1][y])
        # print(excelupdate[x][2][y])
        # print('------------------------')
        # excelupdate[x][1][y]=re.sub(r'&nbsp;', ' ', excelupdate[x][1][y])
        # # excelupdate[x][1][y]=re.sub(r'[\n\r][\n\r]+', ' ', excelupdate[x][1][y])
        # # excelupdate[x][1][y]=re.sub(r'$\s+', ' ', excelupdate[x][1][y])
        excelupdate[x][1][y]=re.sub(r'\d+\.\d+\-\d+ Full Alternative Text', '', excelupdate[x][1][y])
        if re.search(r'\[pathin\](?:(?!\[pathout\]).)*\[pathout\]', excelupdate[x][1][y],re.I|re.S):
            img=re.search(r'\[pathin\]((?:(?!\[pathout\]).)*)\[pathout\]', excelupdate[x][1][y],re.I|re.S).group(1)
            img_url = re.sub(r'\\', '/', img, 0)
            # excelupdate[x][1][y]=re.sub(r'\[pathin\](?:(?!\[pathout\]).)*\[pathout\]', '', excelupdate[x][1][y])
            worksheet.insert_image("F" + str(count), img_url, {'x_scale': 0.5, 'y_scale': 0.5})
        else:
            img_url=''
        worksheet.write("A" + str(count), str(excelupdate[x][1][y]).strip())
        worksheet.write("B" + str(count), str(sys.argv[2]))
        worksheet.write("C" + str(count), str(excelupdate[x][2][y]))
        worksheet.write("E" + str(count), str(excelupdate[x][3]))
        # worksheet.write("C" + str(count), str(excelupdate[x][0]))
        worksheet.write("D" + str(count), str(os.path.basename(excelupdate[x][0])))
        count=count+1
    # index_A = "A" + str(x + 2)
    # worksheet.write(index_A, str(excelupdate[x][1]))
try:
    workbook.close()
    print("Excel file created successfully")
except:
    print("Please close the excel file")
    sys.exit()