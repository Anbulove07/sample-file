'''
# ---------------------------------------------------------------------
#  Tool Name	: ACS_Journal_Validation.py
#  Developer	: Premkumar P
#  Description  : To validate the XML file
#  Client/DU	: Emerald / Journal Others
#  Syntax		: <EXE> <XML_File> <STAGE>
# -----------------------------------------------------------------------

#-------------------- Functions ----------------------------------------------------------
#	_FileChecking		 			- File checking error
#	_XmlValid_process	 			- xmlvalid.exe process
#	_XmlSaxon_validation_process	- Saxon parsing process
#	_GeneralValidation	 			- General Validation
#	_Figure_Validation	 			- Figure based validation
#	_Table_Validation	 			- Table based validation
#	_Ref_Validation	 				- Ref based validation
#	_validate_non_ascii_utf8cnt		- Validate Non-ascii Character
#	_validate_columns_in_table		- Validate Table column numbers
#-----------------------------------------------------------------------------------------

#------------- Error information ----------------------------------------
# _FileChecking functions			-GEN-1001 to GEN-1020
# _GeneralValidation functions		-EMD-1001 to EMD-1050
# _Figure_Validation functions		-EMD-1051 to EMD-1060
# _Table_Validation functions		-EMD-1061 to EMD-1070
# _FrontValidation functions		-EMD-1100 to EMD-1200
# _Validation function				-EMD-1201 to EMD-1400
#------------------------------------------------------------------------
'''

# ------------ Rivision History  -------------------------------------------
#  26-04-2023 | v1.0.0.0 | Premkumar P | Initial Development
# --------------------------------------------------------------------------
ToolVersion = "1.0.0.0"

import os
from os.path import basename, dirname
import shutil
import sys
import re
from iModule.Basic import  _open_utf8, _save_file, _save_utf8, _make_path, _element_leveling, _get_file_list
from iModule.ErrorLog import *
from iModule.iValid import _validate_non_ascii_utf8cnt, _validate_columns_in_table, _validate_combine_utf8cnt
from iModule.ToolTracking import *


apppath = dirname(sys.argv[0])
apppath = re.sub(r'\/', r'\\', apppath, 0)

os.system("cls")
print("\n\n\tACS_Journal_Validation v" + ToolVersion + " is Running...")
print("\tCopyright @ Integra Software Services Ltd.\n")

if (len(sys.argv) != 3 or not os.path.isfile(sys.argv[1]) or not sys.argv[1].endswith('.xml') or not re.match('^(FP|ELDS|CE)$', sys.argv[2], re.I)): sys.exit(
"\n\tSyntax: ACS_Journal_Validation.exe <XML_File>\t<FP|ELDS|CE>\n")

# ------------ Tracking --------------------------------------------
Tra_input = sys.argv[1]
tool_id = 425  # ACS_Journal_Validation
run_size = 0
st_time = _get_timestamp()
# ------------------------------------------------------------------

# Global variable declaration
xml_file = sys.argv[1]
Stage = sys.argv[2]
Filename = basename(xml_file)
Filename_without_extension = re.sub(r'.xml$', '', Filename, re.I)
Dir_name = dirname(xml_file)
transPath = Dir_name+'\\acs_transaction.xml'
xmlvalidpath = apppath + r'\xmlvalid.exe'
dtd_path = apppath + r'\iCore_DTD\ACS_dtd\ACSJournal-production-v103.dtd'


errfile = re.sub(r'\.xml$', '_err.htm', xml_file, re.I)
err = re.sub(r'\.xml$', '_err.err', xml_file, re.I)
xsl1 = apppath + '\\1.xsl'
Reportxml = apppath + '\\Report.xml'
schPath = apppath + r'\\ACS_Journal_Validation.sch'
saxonPath = apppath + r'\\saxon9\\saxon9.jar'
extern_pkg = apppath + r'\\tep-web-services-external-pkg'

if os.path.isfile(errfile): os.remove(errfile)
if os.path.isfile(err): os.remove(err)
if os.path.isfile(xsl1): os.remove(xsl1)
if os.path.isfile(Reportxml): os.remove(Reportxml)

if not os.path.isfile(transPath):
    sys.exit("\n\t Transaction xml is missing!!!\n")

transCnt = _open_utf8(transPath)

# Support files checking:
def _FileChecking():
    '''GEN-1001 to GEN-1020'''
    '''
        Don't make these error to warning
    '''
    ErrStr = ''
    if not os.path.exists(dtd_path):
        ErrStr = "[1:1]: Error: [GEN-0001]: Invalid or not exist dtd file '" + str(basename(dtd_path)) + "' to parse. Please check XML Parsing.\n"
    if not os.path.isfile(xmlvalidpath):
        ErrStr = "[1:1]: Error: [GEN-0002]: Invalid or not exist xmlvalid.exe in toolpath to parse. Please check XML Parsing.\n"
    if not os.path.exists(schPath):
        ErrStr += "[1:1]: Error: [GEN-0003]: 'ACS_Journal_Validation.sch' schema file is missing in toolpath.\n"
    if not os.path.exists(saxonPath):
        ErrStr += "[1:1]: Error: [GEN-0004]: 'saxon9.jar' file is missing in toolpath.\n"
    if not os.path.isdir(extern_pkg):
        ErrStr += "[1:1]: Error: [GEN-0005]: 'tep-web-services-external-pkg' folder is missing in toolpath.\n"
    '''
        Don't make these error to warning
    '''
    return ErrStr


def _parserValidation(xml_file):
    errfile = xml_file
    errfile = re.sub(r'\.xml$', '_err.htm', errfile, re.I)
    err = re.sub(r'\.xml$', '_err.err', xml_file, re.I)

    if os.path.isfile(errfile): os.remove(errfile)
    if os.path.isfile(err): os.remove(err)

    tmp = r'""' + xmlvalidpath + '" --dtd="' + dtd_path + '" "' + xml_file + '" >"' + errfile + '""'
    os.system(tmp)
    ErrStr = ""
    parse_Err_Cnt = _open_utf8(errfile)
    if not re.match(re.escape(xml_file) + ' is valid', parse_Err_Cnt, re.I | re.S):
        mytm = xml_file
        mytm = re.sub(r'\\', '\/', mytm, 0, re.S)
        parse_Err_Cnt = re.sub(r'^' + mytm + ' *', '', parse_Err_Cnt, 0, re.M | re.I)
        parse_Err_Cnt = re.sub(r' *(?:Fatal )?(Error\: )element content invalid\. *', '\g<0>', parse_Err_Cnt, 0,
                               re.S | re.I)
        parse_Err_Cnt = re.sub(r' *(?:Fatal )?(Error\: *)', '\g<0>', parse_Err_Cnt, 0, re.S | re.I)
        parse_Err_Cnt = re.sub(r'^((?:[a-z]\:|\\\\|\/\/)(?:(?!\[[0-9]+\:[0-9]+\]|$).)*) (\[[0-9]+\:[0-9]+\] \:)(.*?)$','\2\3\1', parse_Err_Cnt, 0, re.M | re.I)
        # _save_file(err,parse_Err_Cnt) # to create err file.
        return parse_Err_Cnt
    else:
        return ""


# Saxon based validation
def _schematronValidation(file):
    errsch = file
    err_cnt = ""
    errsch = re.sub(r'\.xml$', '_sch.log', errsch, re.I)
    if os.path.isfile(errsch):
        os.remove(errsch)

    # remove already temp folder is created
    if (os.path.isdir(Dir_name + "\\temp")): shutil.rmtree(Dir_name + "\\temp")
    os.chdir(Dir_name)
    _make_path(Dir_name + "\\temp")

    # Copy all folder into temp
    shutil.copy(xml_file, Dir_name + "\\temp")
    # ---
    # For XML
    file_cnt = _open_utf8(file)
    file_cnt = re.sub(r'<!DOCTYPE(?: [^>]+)?>', '', file_cnt)

    # for save XML file
    _save_utf8(Dir_name + "\\temp\\" + Filename, file_cnt)
    back_xml = Dir_name + "\\temp\\" + Filename

    # step_A1 = "java -jar \"" + apppath + "\\saxon9.jar\" -s:\"" + schPath + "\" -xsl:\"" + apppath + "\\iso_svrl.xsl\" -o:\"" + apppath + "\\1.xsl\" -versionmsg:off"
    step_A2 = "call java.exe -Xss2m -Xmx512m -cp \"" + apppath + "\\saxon9.jar\" net.sf.saxon.Transform -l -dtd:off -s:\"" + back_xml + "\" -xsl:\"" + apppath + "\\1.xsl\" -o:\"" + apppath + "\\Report.xml\" -versionmsg:off"
    step_A3 = "call java.exe -Xss2m -Xmx512m -cp \"" + apppath + "\\saxon9.jar\" net.sf.saxon.Transform -l -s:\"" + apppath + "\\Report.xml\" -xsl:\"" + apppath + "\\General-Schematron.xsl\" -o:\"" + errsch + "\" -versionmsg:off"
    # os.system(step_A1)
    os.system(step_A2)
    os.system(step_A3)
    if not os.path.isfile(xsl1):
        err_cnt += "[1:1]:Error: [GEN-1015]: '1.xsl' file missing in toolpath, Please Check the XML file.\n"
    if not os.path.isfile(Reportxml):
        err_cnt += "[1:1]:Error: [GEN-1016]: 'Report.xml' file missing in toolpath, Please Check the XML file.\n"
    if err_cnt:
        # remove temp file
        shutil.rmtree(Dir_name + "\\temp")
        return err_cnt
    else:
        SchErr_cnt = _open_utf8(errsch)
        for m in re.finditer(r'\[(\d+)\:(\d+)\]\s*\:([^\:]+):([^\:]+):((?:(?!\[\d+\:\d+\]).)*)', SchErr_cnt,re.I | re.S):
            line = m.group(1)
            col = m.group(2)
            err_text = m.group(3)
            errno = m.group(4)
            content = m.group(5)
            content = re.sub(r'^\s+', '', content, 0, re.I | re.S)
            content = re.sub(r'\n', ' ', content, 0, re.I | re.S)
            content = re.sub(r'  ', ' ', content, 0, re.I | re.S)
            err_cnt += "[" + str(line) + ":" + str(col) + "]:"+str(err_text)+": '" + content + "'.\n"
        # remove temp file
        shutil.rmtree(Dir_name + "\\temp")
        # if os.path.isfile(errsch):
            # os.remove(errsch)
        return err_cnt

# Difference Subroutine:
def Difference(First, Second):
    return (list(set(First) - set(Second)))


# Remove query
def _RemoveQuery(txt):
    txt = re.sub(r'<!--(?:(?!-->).)*-->', '', txt, 0, re.I);
    return txt;

def _duplicate(txt):
    tmp = txt.split('\n')
    tm = ''
    for t in tmp:
        tm += "x" * len(t)
        tm += "\n"
    tm = re.sub(r'\n$', '', tm, 0, re.S)
    return tm


def _CharConv(txt):
    txt = re.sub(r'&#x([a-f0-9]{4});', lambda c: chr(int(c.group(1), 16)), txt, 0, re.I)
    return txt


# Full format
def _FullFormate(txt):
    txt = _RemoveQuery(txt)
    txt = re.sub(r'</(italic|i|bold|b|sup|sub|sc|underline|u)>(\s*)<\1(?: [^>]+)?>', '\g<2>', txt, 0, re.I | re.S)
    return txt


def _GeneralValidation(cnt):
    '''ACS-1001 to ACS-1050'''
    ErrStr = ""
    # Checking Non ASCII characters
    for m in re.finditer(r'([^\x00-\x7F]|\'|\`)', cnt, re.I | re.S):
        word = m.group()
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1001]: Non-ASCII characters found '" + str(word) + "', Please Check the XML file.\n"

    # Empty Tags
    for m in re.finditer(r'(?:<([^><]*)>\s*<\/\1>)|(?:<[a-z0-9:-]+/>)', cnt, re.I | re.S):
        word = m.group()
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        word = re.sub(r'\n', '', word, 0, re.I | re.S)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1002]: Empty tag '" + str(word) + "' is not allowed, Please Check the XML file.\n"

    # Tab Checking:
    for m in re.finditer(r'(?:[\t]+)|(?:&#x0009;)', cnt, re.I | re.S):
        word = m.group()
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1003]: The usage of tab character is not allowed, Please Check the XML file.\n"

    # Extra Space in opening tag
    for m in re.finditer(r'<[^>]*[ ]>', cnt, re.I | re.S):  ### v1.0.4.0 ###
        word = m.group()
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1004]: Extra space in  opening tag >'" + str(word) + "', Please Check the XML file.\n"
    # ---
    # space before open tag
    for m in re.finditer(r'<(?!\/|\?|\!)[^\/>]*>[ ]+', cnt, re.I | re.S):
        word = m.group();
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1005]: The word space exits after the opening tag '" + str(word) + "', Please Check the XML file.\n"

    # space before closing tag
    for m in re.finditer(r'[ ]+<\/[^>]*>', cnt, re.I | re.S):
        word = m.group()
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1006]: The word space exits before the closing tag '" + str(word) + "', Please Check the XML file.\n"

    # Multiple space
    for m in re.finditer(r'[ ]{2,}', cnt, re.I | re.S):
        word = m.group()
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1007]: Check for multiple space in the XML file.\n"

    # Multiple multiple enter marks
    for m in re.finditer(r'\n{2,}', cnt, re.I | re.S):
        word = m.group();
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1008]: Check for multiple enter mark in the XML file.\n"

    # Check empty attribute in tags:
    for m in re.finditer(r'<[^>]+=\"\"[^>]*>', cnt, re.I | re.S):
        word = m.group()
        if not re.search(r'href=', word, re.I | re.S):
            prematch = cnt[0:m.start()]
            (ln, cl) = _get_LineCol(prematch)
            ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1009]: Check for empty attribute in tag '" + word + "'.\n"

    # Check <uri> in tags
    for m in re.finditer(r'<uri(?: [^>]*)?>(?:(?!</uri>).)*</uri>', cnt, re.I | re.S):
        uri = m.group()
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1010]: Invalid <uri> tag present instead of <ext=link>'" + uri + "'.\n"


    # Check Comment tags:
    for m in re.finditer(r'<\!--(?:(?!-->).)*-->', cnt, re.I | re.S):
        word = m.group()
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Warning: [ACS-1011]: Comment tag should not be used in the XML file.\n"

    # W: Check Keyboard chr.
    # keycnt = cnt
    # keycnt = re.sub(r'(="([^"]+)"|&#|<\!([^><]+)>|<\!--(?:(?!-->).)*-->)', lambda m: _duplicate(m.group()), keycnt, 0, re.I)
    # for m in re.finditer(r'([`~\+\!@#$%\^\&\*=\'"])', keycnt, re.I | re.S):
    #     word = m.group()
    #     prematch = cnt[0:m.start()]
    #     (ln, cl) = _get_LineCol(prematch)
    #     ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Warning: [ACS-1012]: '" + str(word) + "' Check Keyboard chr. found.\n"

    # W: Space presented before dot [.], [,], [;]
    for m in re.finditer(r'([ ](?:\.|\,|\;))', cnt, re.I | re.S):
        word = m.group()
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        word = re.sub('\n', '', word, re.I | re.S)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Warning: [ACS-1013]: Space presented before '" + str(word) + "'.\n";

    # E: Check tab space found in the text (except preformat elements).
    # W: Check double space found in the text (except preformat elements).
    for m in re.finditer(r'(\t{1,}|[^\s]*[ ][ ]+|\n[ ]+|[ ]+\n)', cnt, re.I | re.S):
        word = m.group(1)
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        word = re.sub('(\n|\t)', '', word, re.I | re.S)
        if word:
            ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1014]: '" + str(word) + "' Unwanted Tab(s) found.\n"
        else:
            ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Warning: [ACS-1015]: '" + str(word) + "' Check Keyboard chr. found.\n"

    # E: Space presented before the right double quotation(&#x201D;)
    for m in re.finditer(r'\s+(\&\#x201D\;)', cnt, re.I | re.S):
        word = m.group(1)
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1016]: '" + str(word) + "' Space found before the right double quotation.\n"

    # E: Space found after the left single quotation(&#x2018;)
    for m in re.finditer(r'(\&\#x2018\;)\s+', cnt, re.I | re.S):
        word = m.group(1)
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1017]: '" + str(word) + "' Space found after the left single quotation.\n";

    # E: Space found before the right single quotation(&#x2019;)
    for m in re.finditer(r'\s+(\&\#x2019\;)', cnt, re.I | re.S):
        word = m.group(1)
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1018]: '" + str(word) + "' Space found before the right single quotation.\n"

    # E: Space found after the left double quotation(&#x201C;)
    for m in re.finditer(r'(\&\#x201C\;)\s+', cnt, re.I | re.S):
        word = m.group(1)
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1019]: '" + str(word) + "' Space found after the left double quotation.\n"

    # E: Entities should be hexa decimal format with 5 digits
    # for m in re.finditer(r'&\#x([^\;]+);', cnt, re.I | re.S):
    #     word = m.group(1)
    #     if not (re.search(r'^[0-9a-f]{4}$', word, re.I | re.S)):
    #         prematch = cnt[0:m.start()]
    #         (ln, cl) = _get_LineCol(prematch)
    #         ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1020]: '" + str(word) + "' Entities should be hexa decimal format with 5 digits.\n"

    # E: Check cross reference missing for (Fig. 1|figure 1 & 2|Figs. 1 & 2|fig. 1-6).
    for m in re.finditer(r'[ \(](?:fig[ures\.]*|Tables?|chapters?)(?:\.)?\s+((?:[0-9]+[0-9\.]*[a-z]?|[ivxdlmc]+|[a-z][\.0-9]*)(?:(\s*(?:,|,\s*and\s+|,\s*&amp;\s+|&ndash;|\-|\&\#x2013\;))([0-9]+[0-9\.]*[a-z]?|[ivxdlmc]+|[a-z][\.0-9]*))?) ',cnt, re.I | re.S):
        word = m.group()
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        word = word.strip()
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Warning: [ACS-1019]: '" + str(word) + "' cross reference is missing.\n"

    # E: Check doctype doesn’t associate with DTD.
    Doctype = re.search(r'<\!doctype[^><]*>', cnt, re.I | re.S)
    if not Doctype:
        ErrStr += "[0:0]: Error: [ACS-1021]: Check doctype does not associate with DTD.\n";
    # E: DTD name should be "****.dtd".
    if Doctype:
        DoctypeDTD = re.search(r'<!doctype[^><]+ "[^"]+\.dtd"[^><]*>', Doctype.group().strip(), re.I | re.S)
        if not DoctypeDTD:
            prematch = cnt[0:Doctype.start()]
            (ln, cl) = _get_LineCol(prematch)
            word = Doctype.group().strip()
            ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1022]: '" + str(word) + "' DTD name should be \"*****.dtd\".\n"

    # W: Check for single|double quotes should not present as a key-board character - ' "
    def single(dec):
        no = re.sub(r'.', 'a', dec)
        return no

    tmpstr = cnt
    tmpstr = re.sub(r'<[^><]+>', lambda m: single(m.group()), tmpstr, 0, re.I)
    for m in re.finditer(r'[\"]+', tmpstr, re.I | re.S):
        word = m.group()
        prematch = tmpstr[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Warning: [ACS-1023]: '" + str(word) + "' Check for single|double quotes should not present as a key-board character.\n"

    # W: Check space should not come before and after "(|)|[|]|{|}".
    for m in re.finditer(r' (?:\(|\)|\[|\]|\{|\}) ', cnt, re.I | re.S):
        word = m.group()
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1024]: '" + str(word) + "' Check space should not come before and after " + "\"(|)|[|]|{|}" + "\".\"\n"

    # W: Check named entities are not allowed; - &ndash;.
    for m in re.finditer(r'&ndash;', cnt, re.I | re.S):
        word = m.group()
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Warning: [ACS-1025]: '" + word + "' Check named entities are not allowed; - &ndash;.\n"

    # W: Check  Punctuations(, :, ; - )  present in closing elements.
    tmpstr = cnt
    tmpstr = re.sub(r'(&\#x[^\;]+);', r'\g<1>&;#', tmpstr)
    for m in re.finditer(r'(?: |\:|\;|,)+</[a-z][^>]*>', tmpstr, re.I | re.S):
        word = m.group()
        prematch = tmpstr[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Warning: [ACS-1026]: '" + word + "' Check  Punctuations(, :, ; - )  present in closing elements.\n"

    # E: check <, > keyboard character found should be entity.
    tmpstr = cnt
    tmpstr = re.sub(r'(<)([^><]+)(>)', lambda n: _duplicate(n.group(1))+n.group(2)+_duplicate(n.group(3)), tmpstr, 0, re.I | re.S)
    for m in re.finditer(r'[><]+', tmpstr, re.I | re.S):
        word = m.group()
        prematch = tmpstr[0:m.start()]
        (ln1, cl1) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln1) + ":" + str(cl1) + "]: Error: [ACS-1027]: '" + word + "' check <, > keyboard character found should be entity.\n"

    # Check Non_Ascii Character
    Ascii_err = _validate_non_ascii_utf8cnt(cnt)
    if Ascii_err:
        for er in re.finditer(r'\[(\d+)\:(\d+)\]\s*\:\s*(?:Error\s*:)?((?:(?!\n).)*)$', Ascii_err, re.I | re.M):
            ErrStr += "\n[" + er.group(1) + ":" + er.group(2) + "]: Error: [ACS-1028]: " + er.group(3) + "\n"
    # ---

    # Check Combined Character
 
    # for ref in re.finditer(r'<ref-list(?: [^>]*)?>(?:(?!</ref-list>).)*</ref-list>', cnt, re.I | re.S):
    #     combine = '(0301|0306|030c|0327|0339|0302|0323|030b|033f|0324|20e1|0300|0311|0328|030a|0307|0308|20d6|0337|0335|0303|0304|0332|20d7|0305|032F|032A)'
    #     for m in re.finditer(r'[a-z](&#[xy]' + str(combine) + r';)', ref.group(), re.I | re.S):
    #         prematch = cnt[0:ref.start()+m.start()]
    #         (ln, cl) = _get_LineCol(prematch)
    #         ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error : [ACS-1029]: Combine character '" + str(m.group()) + "' found.\n"
        # Combine_err = _validate_combine_utf8cnt(ref_list.group())
        # if Combine_err:
        #     for er in re.finditer(r'\[(\d+)\:(\d+)\]\s*\:\s*(?:Error\s*:)?((?:(?!\n).)*)$', Combine_err, re.I | re.M):
        #         ErrStr += "\n[" + er.group(1) + ":" + er.group(2) + "]: Error: [ACS-1029]: " + er.group(3) + "\n"
    # ---

    # Hard enter check
    for m in re.finditer(r'^[a-z0-9-,.:;\'\"]+', cnt, re.I | re.M):
        prematch = cnt[0:m.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += "[" + str(ln) + ":" + str(cl) + "]: Error: [ACS-1030]: Hard enter present in xml. Please check and update.\n"

    '''Last id ACS-1030'''
    return ErrStr

def _Validation(cnt):
    '''ACS-1201 to ACS-1400'''
    ErrStr = ""
    try:
        articleType = re.search(r'<nlmTypeName>((?:(?!</nlmTypeName>).)*)</nlmTypeName>',transCnt,re.I|re.S).group(1)
    except:
        articleType = ""
        ErrStr += f"[1:1]: Error: [ACS-1201]: nlmTypeName is missing in 'acs_transaction.xml', Please check and update.\n"
    try:
        articleID = re.search(r'<mscNo>((?:(?!</mscNo>).)*)</mscNo>',transCnt,re.I|re.S).group(1)
    except:
        articleID = ""
        ErrStr += f"[1:1]: Error: [ACS-1202]: mscNo is missing in 'acs_transaction.xml', Please check and update.\n"
    try:
        Jid = re.search(r'<journal(?: [^>]*)? journalId="([^"]+)">',transCnt,re.I|re.S).group(1)
    except:
        Jid = ""
        ErrStr += f"[1:1]: Error: [ACS-1203]: journalId is missing in 'acs_transaction.xml', Please check and update.\n"

    #full formate check
    for fullformate in re.finditer(r'<(head|document-title|title)(?:[^><]+)?>((?:(?!<\/\1>).)*)<\/\1>',cnt,re.I|re.S):
        title = _FullFormate(fullformate.group(2))
        for fullFormateCheck in re.finditer(r'^<(italic|i|bold|b|sup|sub|sc|underline|u)(?: [^>]+)?>((?:(?!</?\1[ >]).)*)</\1>$', title,re.I | re.S):
            prematch = cnt[0:fullformate.start()+fullFormateCheck.start()];(ln, cl) = _get_LineCol(prematch)
            ErrStr += f"[{ln}:{cl}]: Error: [ACS-1204]: Full formatting is not allowed in '{fullformate.group(1)}', Please check and remove.\n"

    #unwanted bib ref check
    for bibrefCheck in re.finditer(r'(</bibref>,<bibref|</bibref>\s*<sup>)',cnt,re.I|re.S):
        prematch = cnt[0:bibrefCheck.start()];(ln, cl) = _get_LineCol(prematch)
        ErrStr += f"[{ln}:{cl}]: Error: [ACS-1205]: Unwanted bibref present after 'bibref-group', Please check and update.\n"

    #uri content check
    for uricheck in re.finditer(r'</uri>(\=|\/|([a-z])|\&)',cnt,re.I|re.S):
        prematch = cnt[0:uricheck.start()];(ln, cl) = _get_LineCol(prematch)
        ErrStr += f"[{ln}:{cl}]: Error: [ACS-1206]: uri content present in after uri tag, Please check and update.\n"

    #italic check entity
    # for styleCheck in re.finditer(r'<italic(?: [^>]*)?>((?:(?!</italic>).)*)</italic>',cnt,re.I|re.S):
    #     for styleEntity in re.finditer(r'(&#x0391;|&#x0392;|&#x0393;|&#x0394;|&#x0395;|&#x0396;|&#x0397;|&#x0398;|&#x0399;|&#x039A;|&#x039B;|&#x039C;|&#x039D;|&#x039E;|&#x039F;|&#x03A0;|&#x03A1;|&#x03A3;|&#x03A4;|&#x03A5;|&#x03A6;|&#x03A7;|&#x03A8;|&#x03A9;|&#x03B1;|&#x03B2;|&#x03B3;|&#x03B4;|&#x03B5;|&#x03B6;|&#x03B7;|&#x03B8;|&#x03B9;|&#x03BA;|&#x03BB;|&#x03BC;|&#x03BD;|&#x03BE;|&#x03BF;|&#x03C0;|&#x03C1;|&#x03C2;|&#x03C3;|&#x03C4;|&#x03C5;|&#x03C6;|&#x03C7;|&#x03C8;|&#x03C9;|&#x0374;|&#x0375;|&#x037A;|&#x037E;|&#x0384;|&#x0385;|&#x0386;|&#x0387;|&#x0388;|&#x0389;|&#x038A;|&#x038C;|&#x038E;|&#x038F;|&#x03AC;|&#x03AD;|&#x03AE;|&#x03CC;|&#x03AF;|&#x03CD;|&#x03CE;|&#x03AA;|&#x03AB;|&#x03CA;|&#x03CB;|&#x03B0;|&#x0390;|&#x03D0;|&#x03D1;|&#x03D2;|&#x03D3;|&#x03D4;|&#x03D5;|&#x03D6;|&#x03D7;|&#x03DA;|&#x03DB;|&#x03DC;|&#x03DD;|&#x03DE;|&#x03DF;|&#x03E0;|&#x03E1;|&#x00B0;|&#x02DA;|&#x002B;|&#x2012;|&#x00B1;|&#x00D7;|&#x00F7;|&#x003D;|\=|\(|\)|&#x391;|&#x392;|&#x393;|&#x394;|&#x395;|&#x396;|&#x397;|&#x398;|&#x399;|&#x39A;|&#x39B;|&#x39C;|&#x39D;|&#x39E;|&#x39F;|&#x3A0;|&#x3A1;|&#x3A3;|&#x3A4;|&#x3A5;|&#x3A6;|&#x3A7;|&#x3A8;|&#x3A9;|&#x3B1;|&#x3B2;|&#x3B3;|&#x3B4;|&#x3B5;|&#x3B6;|&#x3B7;|&#x3B8;|&#x3B9;|&#x3BA;|&#x3BB;|&#x3BC;|&#x3BD;|&#x3BE;|&#x3BF;|&#x3C0;|&#x3C1;|&#x3C2;|&#x3C3;|&#x3C4;|&#x3C5;|&#x3C6;|&#x3C7;|&#x3C8;|&#x3C9;|&#x374;|&#x375;|&#x37A;|&#x37E;|&#x384;|&#x385;|&#x386;|&#x387;|&#x388;|&#x389;|&#x38A;|&#x38C;|&#x38E;|&#x38F;|&#x3AC;|&#x3AD;|&#x3AE;|&#x3CC;|&#x3AF;|&#x3CD;|&#x3CE;|&#x3AA;|&#x3AB;|&#x3CA;|&#x3CB;|&#x3B0;|&#x390;|&#x3D0;|&#x3D1;|&#x3D2;|&#x3D3;|&#x3D4;|&#x3D5;|&#x3D6;|&#x3D7;|&#x3DA;|&#x3DB;|&#x3DC;|&#x3DD;|&#x3DE;|&#x3DF;|&#x3E0;|&#x3E1;|&#x0B0;|&#x2DA;|&#x02B;|&#x2012;|&#x0B1;|&#x0D7;|&#x0F7;|&#x03D;)',styleCheck.group(1),re.I|re.S):
    #         prematch = cnt[0:styleCheck.start()+styleEntity.start()];(ln, cl) = _get_LineCol(prematch)
    #         ErrStr += f"[{ln}:{cl}]: Error: [ACS-1207]: Italic formatting should not be applied to 'Greek or brackets or math operator' characters '{styleEntity.group(1)}' in text, Please check and update.\n"

    #Superscript check entity
    for supCheck in re.finditer(r'<sup(?: [^>]*)?>((?:(?!</sup>).)*)</sup>',cnt,re.I|re.S):
        for supEntity in re.finditer(r'(&#x2020;|&#x2021;|&#x002A;|\*|&#x2032;|&#x201C;|&#x201D;|&#x2018;|&#x2019;)',supCheck.group(1),re.I|re.S):
            prematch = cnt[0:supCheck.start()+supEntity.start()];(ln, cl) = _get_LineCol(prematch)
            ErrStr += f"[{ln}:{cl}]: Error: [ACS-1208]: Superscript formatting should not be applied to '{supEntity.group(1)}' in text, Please check and update.\n"

    #check stack attribute
    for stackAttrib in re.finditer(r'(</sub>\s*<sup>|</sup>\s*<sub>)',cnt,re.I|re.S):
        prematch = cnt[0:stackAttrib.start()];(ln, cl) = _get_LineCol(prematch)
        ErrStr += f"[{ln}:{cl}]: Warning: [ACS-1209]: Check stack attribute. Super script and Subscript present.\n"

    #check stack m:mn data
    for decimalCheck in re.finditer(r'<m:mn>([0-9]+)</m:mn>\s*<m:mo>\.</m:mo>\s*<m:mn>([0-9]+)</m:mn>',cnt,re.I|re.S):
        prematch = cnt[0:decimalCheck.start()];(ln, cl) = _get_LineCol(prematch)
        ErrStr += f"[{ln}:{cl}]: Error: [ACS-1210]: All parts of a single number, including the decimal point, should be included in a single <m:mn> element '{decimalCheck.group()}'.\n"

    #external id missing check
    for instTag in re.finditer(r'<institution>((?:(?!</institution>).)*)</institution>',cnt,re.I|re.S):
        if not re.search(r'<external-id ',instTag.group(),re.I|re.S):
            prematch = cnt[0:instTag.start()];(ln, cl) = _get_LineCol(prematch)
            ErrStr += f"[{ln}:{cl}]: Warning: [ACS-1211]: 'external-id' missing in affiliation, Please check and update.\n"

    #hyphen check
    for hypCheck in re.finditer(r' -([0-9])',cnt,re.I|re.S):
        prematch = cnt[0:hypCheck.start()];(ln, cl) = _get_LineCol(prematch)
        ErrStr += f"[{ln}:{cl}]: Warning: [ACS-1211]: Check minus symbol or hyphen, Please check and update.\n"

    #contrib meta check
    for contribTag in re.finditer(r'<contrib ([^><]+)>((?:(?!</contrib>).)*)</contrib>',cnt,re.I|re.S):
        if not re.search(r'<contrib-meta ',contribTag.group(),re.I|re.S):
            prematch = cnt[0:contribTag.start()];(ln, cl) = _get_LineCol(prematch)
            ErrStr += f"[{ln}:{cl}]: Warning: [ACS-1212]: 'contrib-meta' missing in author, Please check and update.\n"

    #mtext not allowed
    for mtextCheck in re.finditer(r'<m:mtext(?: [^>]*)?>',cnt,re.I|re.S):
        prematch = cnt[0:mtextCheck.start()];(ln, cl) = _get_LineCol(prematch)
        ErrStr += f"[{ln}:{cl}]: Error: [ACS-1213]: 'mtext' not allowed change '<mi mathvariant=\"normal\">'.\n"

    #mstyle not allowed
    for mtextCheck in re.finditer(r'<m:mstyle(?: [^>]*)?>',cnt,re.I|re.S):
        prematch = cnt[0:mtextCheck.start()];(ln, cl) = _get_LineCol(prematch)
        ErrStr += f"[{ln}:{cl}]: Error: [ACS-1214]: 'mstyle' not allowed, Please check and update.\n"

    #Single digit accented numbers check
    for moverCheck in re.finditer(r'<m:mover accent="true">\s*<m:([a-z]+)>(?:(?!</m:\1>).)*</m:\1>\s*<m:([a-z]+)>(?:(?!</m:\2>).)*</m:\2>\s*</m:mover>',cnt,re.I|re.S):
        prematch = cnt[0:moverCheck.start()];(ln, cl) = _get_LineCol(prematch)
        ErrStr += f"[{ln}:{cl}]: Error: [ACS-1215]: Single digit accented numbers are included with the desired accent in a single '{moverCheck.group(1)}' element, Please check and update.\n"

    #xml processing check
    if not re.search(r'^<\?xml version="1\.0" encoding="US\-ASCII"\?>',cnt,re.I|re.S):
        ErrStr += f"[1:1]: Error: [ACS-1216]: xml processing instructions should be '<?xml version=\"1.0\" encoding=\"US-ASCII\"?>', Please check and update.\n"

    #Article type check
    if not re.search(r'<document(?: [^>]*)? nlm-article-type="'+str(articleType)+r'"(?: [^>]*)?>',cnt,re.I|re.S):
        ErrStr += f"[1:1]: Error: [ACS-1217]: Article Type '{articleType}' is incorrect/mismatch/incorrect case in 'xml', Please check and update.\n"

    ##Updated by Sudhakar
    # xref text not allowed
    txt=cnt
    txt = _element_leveling(txt, 'xref')
    for xrefCheck in re.finditer(r'<xref1(?: [^>]*)?>((?:(?!</xref1>).)*)</xref1>', txt, re.I | re.S):
        xref = re.search(r'<xref2(?: [^>]*)?>((?:(?!</xref2>).)*)</xref2>', xrefCheck.group(1), re.I | re.S)
        prematch = txt[0:xrefCheck.start()]
        (ln, cl) = _get_LineCol(prematch)
        if xref:
            if xref.group(1).strip() != '':
                ErrStr += f"[{ln}:{cl}]: Error: [ACS-1218]: Text not allowed between the <xref>.\n"

    # Incorrect Punctuation Check
    temp_cnt = cnt
    temp_cnt = re.sub(r'<\?xml(?: [^>]*)?>((?:(?!<metadata>).)*)<metadata>', lambda m: _duplicate(m.group()), temp_cnt,0, flags=re.I | re.S)
    temp_cnt = _RemoveQuery(temp_cnt)

    # Figure <xref> link checking
    temp = temp_cnt
    temp = re.sub(r' rid="fig\d+"', r'', temp, 0, flags=re.I | re.S)
    for fig in re.finditer(r'\b((Figure|Fig|Table|Figures|Tables) ([a-z0-9]+))\b', temp, re.I | re.S):
        prematch = temp[0:fig.start()]
        (ln, cl) = _get_LineCol(prematch)
        if fig:
            if not re.search(r'(S\d+|colsep|id)', fig.group(3), re.I | re.S):
                ErrStr += f"[{ln}:{cl}]: Error: [ACS-1223]: xref missing.\n"


    # for punchCheck in re.finditer(r'<\/(?:[^>]*)?>(?:\.|;|:|,|\!|\?)<\/(?:[^>]*)?>', temp_cnt, re.I | re.S):
    # 	prematch = cnt[0:punchCheck.start()]
    # 	if punchCheck.group():
    # 		(ln, cl) = _get_LineCol(prematch)
    # 		ErrStr += f"[{ln}:{cl}]: Error: [ACS-1219]: Incorrect Punctuation present in between two closing tag.\n"

    for punchCheck1 in re.finditer(r'([\.]{2,}|[;]{2,}|[:]{2,}|[,]{2,}|[\!]{2,}|[\?]{2,})', temp_cnt, re.I | re.S):
        if punchCheck1.group():
            prematch = temp_cnt[0:punchCheck1.start()]
            (ln, cl) = _get_LineCol(prematch)
            ErrStr += f"[{ln}:{cl}]: Error: [ACS-1220]: More than 1 Punctuation Present. Please check XML file.\n"

    for punchCheck2 in re.finditer(r'(\.|;|:|,|\!|\?)<\/(?:[^>]*)?>\1', temp_cnt, re.I | re.S):
        prematch = cnt[0:punchCheck2.start()]
        if punchCheck2.group():
            (ln, cl) = _get_LineCol(prematch)
            ErrStr += f"[{ln}:{cl}]: Error: [ACS-1221]: More than 1 Punctuation Present. Please check XML file.\n"

    temp_cnt = re.sub(r'<inline-formula(?: [^>]*)?>((?:(?!</inline-formula>).)*)</inline-formula>', lambda m: _duplicate(m.group()), temp_cnt,0, flags=re.I | re.S)
    temp_cnt = re.sub(r'<disp-formula(?: [^>]*)?>((?:(?!</disp-formula>).)*)</disp-formula>', lambda m: _duplicate(m.group()), temp_cnt,0, flags=re.I | re.S)
    temp_cnt = re.sub(r'<[^>]*>', lambda m: _duplicate(m.group()), temp_cnt,0, flags=re.I | re.S)

    if not (sys.argv[2]).lower() == 'fp':
        for op in re.finditer(r'(.)(=|\+)(.)', temp_cnt, re.I | re.S):
            if op.group(1) != ' ' and op.group(3) != ' ':
                prematch = temp_cnt[0:op.start()]
                (ln, cl) = _get_LineCol(prematch)
                ErrStr += f"[{ln}:{cl}]: Error: [ACS-1222]: Space missing before and after operators.\n"

    # # Empty Elements not allowed inside <ref-list>
    # for refListCheck in re.finditer(r'<ref-list(?: [^>]*)?>((?:(?!</ref-list>).)*)</ref-list>', cnt, re.I | re.S):
    #     for emptytag in re.finditer(r'<([a-z0-9-_:]+)(?: [^>]*)?>\s*</\1>', refListCheck.group(1), re.I | re.S):
    #         prematch = cnt[0:refListCheck.start()+emptytag.start()]
    #         if emptytag.group():
    #             (ln, cl) = _get_LineCol(prematch)
    #             ErrStr += f"[{ln}:{cl}]: Error: [ACS-1222]: Empty Elements not allowed inside <ref-list>.\n"
    #     for emptytag1 in re.finditer(r'<([a-z0-9-_:]+)(?: [^>]*)?/>', refListCheck.group(1), re.I | re.S):
    #         prematch = cnt[0:refListCheck.start()+emptytag1.start()]
    #         if emptytag1.group():
    #             (ln, cl) = _get_LineCol(prematch)
    #             ErrStr += f"[{ln}:{cl}]: Error: [ACS-1222]: Empty Elements not allowed inside <ref-list>.\n"

    # Multiple <organization> tag not allowed inside <aff>
    for affCheck in re.finditer(r'<aff(?: [^>]*)?>((?:(?!</aff>).)*)</aff>', cnt, re.I | re.S):
        affCnt = affCheck.group()
        if affCnt.count("<organization>") > 1:
            prematch = cnt[0:affCheck.start()]
            (ln, cl) = _get_LineCol(prematch)
            ErrStr += f"[{ln}:{cl}]: Error: [ACS-1223]: Multiple <organization> tag not allowed inside <aff>.\n"

        for affCheck1 in re.finditer(r'<organization(?: [^>]*)?>((?:(?!</organization>).)*)</organization>', affCheck.group(), re.I | re.S):
            org_cnt = affCheck1.group(1)
            org_cnt = re.sub(r'<([a-z]+)(?: [^>]*)?>((?:(?!</\1>).)*)</\1>', r'', org_cnt, 0, re.I | re.S)
            if re.search(r'\w+', org_cnt, re.I | re.S):
                prematch = cnt[0:affCheck.start() + affCheck1.start()]
                (ln, cl) = _get_LineCol(prematch)
                ErrStr += f"[{ln}:{cl}]: Error: [ACS-1224a]:  Child element missing inside of <organization>.\n"
            if not re.search(r'<(?:[^>]*)?>', affCheck1.group(1), re.I | re.S):
                prematch = cnt[0:affCheck.start()+affCheck1.start()]
                (ln, cl) = _get_LineCol(prematch)
                ErrStr += f"[{ln}:{cl}]: Error: [ACS-1224b]:  Child element missing inside of <organization>.\n"

    for mmath in re.finditer(r'<m:math(?: [^>]*)?>((?:(?!</m:math>).)*)</m:math>', cnt, re.I | re.S):
        for mtable in re.finditer(r'<m:mtable(?: [^>]*)?>((?:(?!</m:mtable>).)*)</m:mtable>', mmath.group(1), re.I | re.S):
            mtable = mtable.group()
            if mtable.count("<m:mtable") > 1:
                prematch = cnt[0:mmath.start()]
                (ln, cl) = _get_LineCol(prematch)
                ErrStr += f"[{ln}:{cl}]: Error: [ACS-1225]: Multiple <m:mtable> tag not allowed inside <m:math>.\n"

    #  stretchy="" attribute not allowed in FP stage
    if Stage == "FP":
        for mmath in re.finditer(r'<m:math(?: [^>]*)?>((?:(?!</m:math>).)*)</m:math>', cnt, re.I | re.S):
            stretch = re.search(r'stretchy="(true|false)"', mmath.group(), re.I | re.S)
            if stretch:
                prematch = cnt[0:mmath.start() + stretch.start()]
                (ln, cl) = _get_LineCol(prematch)
                ErrStr += f"[{ln}:{cl}]: Error: [ACS-1226]: stretchy attribute not allowed inside of <math> in FP stage.\n"

            #  mml:math tag not allowed in FP stage
            mtable = re.search(r'<m:mtable', mmath.group(), re.I | re.S)
            if mtable:
                prematch = cnt[0:mmath.start() + mtable.start()]
                (ln, cl) = _get_LineCol(prematch)
                ErrStr += f"[{ln}:{cl}]: Error: [ACS-1227]: m:mtable tag not allowed in FP stage.\n"


    for mmath in re.finditer(r'<m:math ([^><]+)>((?:(?!</m:math>).)*)</m:math>', cnt, re.I | re.S):
        mtable = re.search(r'<m:mtable ([^><]+)>', mmath.group(2), re.I | re.S)
        if mtable:
            if re.search(r'(displaystyle="true"|columnalign="right left"|columnspacing="0em"|rowspacing="3pt")', mmath.group(2), re.I | re.S):
                prematch = cnt[0:mmath.start()]
                (ln, cl) = _get_LineCol(prematch)
                ErrStr += f"[{ln}:{cl}]: Error: [ACS-1228]:  Invalid attribute present inside of <m:mtable> (columnalign="'left'" attribute only allowed).\n"

    for indent in re.finditer(r'<p content-type="noindent">', cnt, re.I | re.S):
        prematch = cnt[0:indent.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += f'[{ln}:{cl}]: Error: [ACS-1229]: <p content-type="noindent"> not allowed, should be run-on the previous <p>.\n'

    ref_list = re.search(r'<ref-list(?: [^>]*)?>((?:(?!</ref-list>).)*)</ref-list>', cnt, re.I | re.S)
    if ref_list:
        for gname in re.finditer(r'<given-names>', ref_list.group(1), re.I | re.S):
            prematch = cnt[0:ref_list.start() + gname.start()]
            (ln, cl) = _get_LineCol(prematch)
            ErrStr += f'[{ln}:{cl}]: Error: [ACS-1230]: <given-names> not allowed should be <intials>.\n'

    if Stage == "FP":
        for datetype in re.finditer(r'<date date-type="([^"]+)">', cnt, re.I | re.S):
            if datetype.group(1) != "xml-first-instance":
                prematch = cnt[0:datetype.start()]
                (ln, cl) = _get_LineCol(prematch)
                ErrStr += f'[{ln}:{cl}]: Error: [ACS-1231a]: Unwanted date-type="{datetype.group(1)}" present in FP stage.\n'

    count = 0
    for xml in re.finditer(r'<date date-type="xml-first-instance">', cnt, re.I | re.S):
        count = count + 1
        if count > 1:
            prematch = cnt[0:xml.start()]
            (ln, cl) = _get_LineCol(prematch)
            ErrStr += f'[{ln}:{cl}]: Error: [ACS-1231b]: Multiple <date date-type="xml-first-instance"> not allowed.\n'

    for keep in re.finditer(r'<keep-together>', cnt, re.I | re.S):
        prematch = cnt[0:keep.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += f'[{ln}:{cl}]: Warning: [ACS-1232]:  keep-together element present please check if need or not.\n'

    for scheme in re.finditer(r'<scheme ([^><]+)>((?:(?!</scheme>).)*)</scheme>', cnt, re.I | re.S):
        for caption in re.finditer(r'<caption>((?:(?!</caption>).)*)</caption>', scheme.group(2), re.I | re.S):
            if re.search(r'<p>((?:(?!</p>).)*)</p>', caption.group(1)):
                prematch = cnt[0:scheme.start()]
                (ln, cl) = _get_LineCol(prematch)
                ErrStr += f'[{ln}:{cl}]: Error: [ACS-1233]: Incorrect <p> present inside of <schema><caption> should be <schema><caption><title>.\n'

    for mrow in re.finditer(r'<m:mrow(?: [^>]*)?>((?:(?!</m:mrow>).)*)</m:mrow>', cnt, re.I | re.S):
        for mo in re.finditer(r'<m:mo stretchy="(false|true)">', mrow.group(1), re.I | re.S):
            mo = mo.group()
            if mo.count('<m:mo stretchy="(false|true)">') <= 1:
                prematch = cnt[0:mrow.start()]
                (ln, cl) = _get_LineCol(prematch)
                ErrStr += f'[{ln}:{cl}]: Error: [ACS-1234]: Unwanted <m:mrow> present  before bra-ket.\n'

    if not ((sys.argv[2]).lower()=="fp"):
        for mi in re.finditer(r'<m:mn>\d+</m:mn><m:mi(?: [^>]*)?>\w+</m:mi>', cnt, re.I | re.S):
            prematch = cnt[0:mi.start()]
            (ln, cl) = _get_LineCol(prematch)
            ErrStr += f'[{ln}:{cl}]: Error: [ACS-1235a]: Space missing between number and units.\n'

    temp_cnt1 = cnt
    temp_cnt1 = re.sub(r'<\?xml(?: [^>]*)?>((?:(?!<metadata>).)*)<metadata>', lambda m: _duplicate(m.group()), temp_cnt1,0, flags=re.I | re.S)
    temp_cnt1 = re.sub(r'&#x[a-z0-9]+;', lambda m: _duplicate(m.group()), temp_cnt1,0, flags=re.I | re.S)
    temp_cnt1 = _RemoveQuery(temp_cnt1)
    for mi in re.finditer(r'\d+(m|kg|s|A|k)', temp_cnt1, re.S):
        prematch = temp_cnt1[0:mi.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += f'[{ln}:{cl}]: Warning: [ACS-1235b]: Space missing between number and units.\n'

    metadata = re.search(r'<metadata(?: [^>]*)?>((?:(?!</metadata>).)*)</metadata>', cnt, re.I | re.S)
    if metadata:
        for notes in re.finditer(r'<notes(?: [^>]*)?>((?:(?!</notes>).)*)</notes>', metadata.group(1), re.I | re.S):
            prematch = cnt[0:notes.start()]
            (ln, cl) = _get_LineCol(prematch)
            ErrStr += f'[{ln}:{cl}]: Warning Critical: [ACS-1236]: <notes> Check the notes element placement.\n'

    for contrib in re.finditer(r'<contrib(?: [^>]*)? contrib-type="author"(?: [^>]*)? corresponding="yes"[^>]*>((?:(?!</contrib>).)*)</contrib>', cnt, re.I | re.S):
        given_names = re.search(r'<given-names>([^><]+)</given-names>', contrib.group(1), re.I | re.S)
        surname = re.search(r'<surname>([^><]+)</surname>', contrib.group(1), re.I | re.S)
        rid = re.search(r'<xref(?: [^>]*)? rid="(cor\d+)"/?>', contrib.group(1), re.I | re.S)
        if given_names and surname and rid:
            notes = re.search(r'<author-notes(?: [^>]*)?>((?:(?!</author-notes>).)*)</author-notes>', cnt, re.I | re.S)
            if notes:
                if re.search(r'<corresp(?: [^>]*)? id="' + rid.group(1) + r'"(?: [^>]*)?>((?:(?!</corresp>).)*)</corresp>', notes.group(), re.I | re.S):
                    val=re.search(r'<corresp(?: [^>]*)? id="' + rid.group(1) + r'"(?: [^>]*)?>((?:(?!</corresp>).)*)</corresp>', notes.group(), re.I | re.S)
                    finame=str(given_names.group(1))+" "+str(surname.group(1))
                    if not re.search(finame, val.group(), re.I | re.S):
                        prematch = cnt[0:notes.start()+val.start()]
                        (ln, cl) = _get_LineCol(prematch)
                        ErrStr += f'[{ln}:{cl}]: Error: [ACS-1237]:  Incorrect <corresp> links for author.\n'

    for title in re.finditer(r'<article-title(?: [^>]*)?>((?:(?!</article-title>).)*)</article-title>', cnt, re.I | re.S):
        if len(title.group(1)) < 4:
            prematch = cnt[0:title.start()]
            (ln, cl) = _get_LineCol(prematch)
            ErrStr += f'[{ln}:{cl}]: Warning Critical: [ACS-1238]: <article-title> content is too short.\n'

    for source in re.finditer(r'<source(?: [^>]*)?>((?:(?!</source>).)*)</source>', cnt, re.I | re.S):
        if len(source.group(1)) < 4:
            prematch = cnt[0:source.start()]
            (ln, cl) = _get_LineCol(prematch)
            ErrStr += f'[{ln}:{cl}]: Warning Critical: [ACS-1239]: <source> content is too short.\n'

    for thead in re.finditer(r'<thead(?: [^>]*)?>((?:(?!</thead>).)*)</thead>', cnt, re.I | re.S):
        for inline in re.finditer(r'<inline-formula(?: [^>]*)?>((?:(?!</inline-formula>).)*)</inline-formula>', thead.group(), re.I | re.S):
            prematch = cnt[0:thead.start() + inline.start()]
            (ln, cl) = _get_LineCol(prematch)
            ErrStr += f'[{ln}:{cl}]: Error: [ACS-1240]: <inline-formula> Inline equation not allowed inside table head.\n'

    for ini in re.finditer(r'<initials>((?:(?!</initials>).)*)</initials>', cnt, re.I | re.S):
        initial = str(ini.group(1))
        initial = initial.replace('.', '')
        initial = initial.replace(' ', '')
        if len(initial) >= 4:
            prematch = cnt[0:ini.start()]
            (ln, cl) = _get_LineCol(prematch)
            ErrStr += f'[{ln}:{cl}]: Error: [ACS-1241]: Incorrect initial present inside of <initials>.\n'

    for mi in re.finditer(r'<m:mi(?: [^>]*)?>[A-Z]</m:mi>\s*<m:mo>(?:(?!</m:mo>).)*</m:mo>', cnt, re.I | re.S):
        mo = re.search(r'<m:mo>((?:(?!</m:mo>).)*)</m:mo>', mi.group(), re.I | re.S)
        if mo:
            if re.search(r'&#x223c;', mo.group(1), re.I | re.S):
                prematch = cnt[0:mi.start() + mo.start()]
                (ln, cl) = _get_LineCol(prematch)
                ErrStr += f'[{ln}:{cl}]: Error: [ACS-1242]: Incorrect combine character. Check with ACS guidelines.\n'

    for citation in re.finditer(r'<citation(?: [^>]*)?citation-type=\"conf-proc\"(?: [^>]*)?>', cnt, re.I | re.S):
        prematch = cnt[0:citation.start()]
        (ln, cl) = _get_LineCol(prematch)
        ErrStr += f'[{ln}:{cl}]: Error: [ACS-1243]: Citation type conf-proc not allowed as per ACS guidelines.\n'

    # Article type check
    # if not re.search(r'<document(?: [^>]*)? nlm-article-type="' + str(articleType) + r'"(?: [^>]*)?>', cnt, re.I | re.S):
    #     ErrStr += f"[1:1]: Error: [ACS-1217]: Article Type '{articleType}' is incorrect/mismatch/incorrect case in 'xml', Please check and update.\n"

    return ErrStr


def customervalidation():
    source_file = apppath + "//vendorValidationClient.bat"
    destination_folder = apppath + "//tep-web-services-external-pkg"
    shutil.copy(source_file, destination_folder)
    customertool = destination_folder + "//vendorValidationClient.bat"
    tool_cnt = _open_utf8(customertool)
    tool_cnt = tool_cnt.replace("XML-INPUT", xml_file)
    tool_cnt = tool_cnt.replace("ERROR-OUTPUT", xml_file.replace(".xml", "_validation.out"))
    tool_cnt = tool_cnt.replace("ConvertController.groovy", "VTEWebServiceController.groovy")
    _save_utf8(customertool, tool_cnt)
    os.chdir(destination_folder)
    # CREATE_NO_WINDOW = 0x08000000
    # subprocess.call(f"start /wait {customertool}", creationflags=CREATE_NO_WINDOW)
    os.popen(customertool)

#Main Process
ErrCnt = ""
ErrCnt = _FileChecking()
if not ErrCnt:
    ErrCnt += _parserValidation(xml_file)
    if not ErrCnt:
        xml_file_cnt = _open_utf8(xml_file)
        ErrCnt += _schematronValidation(xml_file)
        ErrCnt += _GeneralValidation(xml_file_cnt)
        ErrCnt += _Validation(xml_file_cnt)
        customervalidation()
CreateErrorLog(xml_file, "ACS Validation v" + str(ToolVersion), ErrCnt, 0)

sys.exit("\n\"" + Filename + "\" Validation Process completed...!!!\n")