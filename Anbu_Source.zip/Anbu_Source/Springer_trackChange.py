# ---------------------------------------------------------------------
# Tool Name	: Springer_trackChange.py
#  Developer	: Anbu G
#  Description  : To clean the xml file
#  Client/DU	: Springer Trackchange
#  Syntax		: <EXE> <xml file>
# -----------------------------------------------------------------------



# -------------------------Revision History------------------------------

# 23-08-2023 | V1.0.0.0 | Anbu G | Req by stella

# -----------------------------------------------------------------------

import os.path
import re
import sys
from iModule.Basic import _open_file, _open_utf8
ToolVersion = "1.0.0.0";
os.system("cls")
if len(sys.argv) == 1:
    sys.exit("Syntax: python Springer_trackChange.py <XML file>")



print("\n\n\tSpringer_trackChange v" + ToolVersion + " is Running...");
print("\tCopyright @ Integra Software Services Ltd.\n");


filepath=sys.argv[1]
cnt=_open_utf8(filepath)

# cnt=re.sub(r'( )<\?oxy_delete contentntent="[^>]*"\?>( )', ' ', cnt,0,re.I|re.S)
# cnt=re.sub(r'( )<\?oxy_delete content="[^>]*"\?>', '', cnt,0,re.I|re.S)
# cnt=re.sub(r'<\?oxy_delete content="[^>]*"\?>( )', '',cnt,0,re.I|re.S)
# cnt=re.sub(r'([a-zA-Z0-9.\],]+)<\?oxy_delete content="[^>]*"\?>([a-zA-Z0-9.\],]+)', '\g<1>\g<2>',cnt,0, re.I|re.S)
cnt=re.sub(r'<\?oxy_delete content="[^>]*"\?>', '',cnt,0, re.I|re.S)
# cnt=re.sub(r'><\?oxy_delete content="[^>]*"\?> ', '> ', cnt,0,re.I|re.S)
# cnt=re.sub(r'<\?oxy_delete content="[^>]*"\?>([a-zA-Z0-9.,]+)', ' \g<1>', cnt,0,re.I|re.S)
# cnt=re.sub(r'><\?oxy_delete content="[^>]*"\?>', '> ',cnt,0, re.I|re.S)
# cnt=re.sub(r' <\?oxy_delete content="[^>]*"\?><', ' <',cnt,0, re.I|re.S)
# cnt=re.sub(r'<\?oxy_delete content="[^>]*"\?><', ' <',cnt,0, re.I|re.S)
# cnt=re.sub(r'([a-zA-Z0-9.,]+)<\?oxy_delete content="[^>]*"\?><', '\g<1> <',cnt,0, re.I|re.S)
# cnt=re.sub(r'><\?oxy_delete content="[^>]*"\?><', '> <',cnt,0, re.I|re.S)
cnt=re.sub(r'<\?oxy_delete content="[^>]*"\?>', '',cnt,0, re.I|re.S)
cnt=re.sub(r'<\?oxy_insert_start\?>', '',cnt,0, re.I|re.S)
cnt=re.sub(r'<\?oxy_insert_end\?>', '',cnt,0, re.I|re.S)
cnt=re.sub(r'<\?oxy_comment_start([^>]*)?\?>', '',cnt,0, re.I|re.S)
cnt=re.sub(r'<\?oxy_comment_end\?>', '',cnt,0, re.I|re.S)
cnt=re.sub(r'  ', ' ',cnt,0, re.I|re.S)
# cnt=re.sub(r'(<\?oxy_insert_start\?>)((?:(?!<\?oxy_insert_end\?>).)*)(<\?oxy_insert_end\?>)', '\2',cnt,0, re.I|re.S)



def symbol_to_hex_entity(symbol):
    hex_entity = '&#x{:04x};'.format(ord(symbol))
    return hex_entity

def convert_symbols_to_entities(content):
    converted_content = ""
    for char in content:
        if char.isalpha() or char.isspace():
            converted_content += char
        else:
            converted_content += symbol_to_hex_entity(char)
    return converted_content
# cnt = cnt.replace('<', '&lt;').replace('>', '&gt;')
# cnt=convert_symbols_to_entities(cnt)

cnt = re.sub(r'[^\x00-\x7F]', lambda m: '&#x{:04x};'.format(ord(m.group())), cnt,0, re.I|re.S)

# # cnt = cnt.replace('&lt;', '<').replace('&gt;', '>')
# print(cnt)
os.makedirs(os.path.dirname(filepath)+"\\completed\\", exist_ok=True)
with open(os.path.dirname(filepath)+"\\completed\\"+os.path.basename(filepath), 'w', encoding="utf-8") as f:
    f.write(cnt)

print("Process completed.")